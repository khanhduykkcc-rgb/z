# Tích hợp OLLVM (Hikari) vào build DSWUnity

Tài liệu này mô tả cách obfuscate project **DSWUnity (Cofi)** bằng
**llvm-pass-hikari** (biến thể `hikari`) ngay trên GitHub Actions — **phần XPF
build giữ nguyên 100% bằng Apple clang như trước**.

---

## 1. Kiến trúc tích hợp

```
GitHub Actions (macos-15)
│
├─ brew install llvm@19  (fallback 20 → 18)
├─ cmake + ninja build Hikari.dylib (từ ollvm/llvm-pass-hikari — vendored)
├─ copy policy.json vào các working-directory ứng viên
├─ smoke test (biên dịch file .m thử qua wrapper)
│
└─ xcodebuild ... CC=ollvm/cc-wrapper.sh CXX=ollvm/cxx-wrapper.sh CLANG_ENABLE_MODULES=NO
   │
   ├─ Compile nguồn APP  (Cofi/*.m, *.mm — KHÔNG thuộc Cofi/XPF/)
   │    → brew LLVM clang + -fpass-plugin=Hikari.dylib   ← OBfuscate ở đây
   │
   ├─ Compile XPF/ChOma  (Cofi/XPF/...)
   │    → xcrun clang (Apple clang)                        ← GIỮ NGUYÊN
   │      (script phase `make -C Cofi/XPF ...` vẫn y hệt trước)
   │
   └─ Link + các bước khác → xcrun clang (Apple clang)     ← GIỮ NGUYÊN
```

Vì plugin LLVM là thư viện động nạp vào clang, **bắt buộc dùng clang cùng phiên
bản LLVM với plugin** (Readme của tác giả lich4: "Con #1: must use a matching
clang"). Nên nguồn app được compile bằng `brew llvm@19` — không phải Apple
clang. Việc này không ảnh hưởng XPF vì wrapper chỉ chuyển hướng file app.

## 2. File thêm vào repo

| File | Vai trò |
|---|---|
| `.github/workflows/build-ipa.yml` | Workflow "Build IPA" (bản cũ + OLLVM) |
| `ollvm/policy.json` | Chính sách obfuscate theo module/hàm (6 mức) |
| `ollvm/cc-wrapper.sh` | Wrapper cho build setting `CC` |
| `ollvm/cxx-wrapper.sh` | Wrapper cho build setting `CXX` (file .mm) |
| `ollvm/setup-ollvm.sh` | Cài LLVM, build plugin, đặt policy, chạy smoke |
| `ollvm/smoke-test.sh` | Kiểm tra nhanh trước build |
| `ollvm/verify-ollvm.sh` | Kiểm chứng obfuscation sau build |
| `ollvm/llvm-pass-hikari/` | Source plugin (vendored, ~1.9MB) |

Project (`Cofi/`, `Cofi.xcodeproj/`) **không sửa bất kỳ dòng nào** — mọi thứ
đưa qua tham số dòng lệnh của `xcodebuild`, nên mở Xcode local build vẫn như
cũ.

## 3. Mức bảo hộ theo module (ollvm/policy.json)

| Mức | Pass bật | Áp cho module nào | Lý do |
|---|---|---|---|
| `f_light` | strenc + sub(30%) | Mọi file còn lại (UI, AppDelegate, main.m, SettingsViewController, LogTextView, DSKeepAlive, MemoryProviderOwner…) | An toàn tuyệt đối, không đổi control flow |
| `f_safe` | light + constenc + indibr | `Cofi/kexploit/*`, `Cofi/TaskRop/*`, `Cofi/kpf/*`, `Cofi/utils/*` | Kernel exploit/ROP/race **nhạy cảm timing** — không dùng fla/bcf để không vỡ exploit |
| `f_core` | safe + **fla** + split | `Cofi/Core/*` (UnityMath, AimAssistEngine, GameLogic, OffsetRegistry, PhantomMemory), `Cofi/drawing_view/*`, `Cofi/ESP/*`, `DarkSwordMemoryProvider.m` | Bảo vệ offsets + logic đọc/ghi memory |
| `f_core_noindibr` | f_core nhưng **tắt indibr** | `ESP/ESPDrawOverlay.m` (rule cuối, ưu tiên cao nhất) | Hàm rất lớn + BlockAddress table làm brew clang crash codegen (run #4) |
| `f_max` | core + **bcf** + **funcwra** + constenc_togv + sub(60%) | *(dự phòng — file nhỏ)* | Đầy đủ 12 kỹ thuật; file lớn sẽ timeout/OOM rồi tụt f_safe |
| `f_max_lite` | core + **bcf(25%)** + constenc_togv + sub(60%), **không** funcwra/split | `api/khanhduy.mm`, `DuyServer.mm`, `ESPInstallerViewController.m` | Chuỗi license — run #10: cả 3 file đều timeout/OOM ở f_max rồi bị hạ f_safe (mất gần hết bảo hộ); bản lite giữ fla+bcf+strenc+constenc+togv+indibr và đủ nhẹ chạy < 300s |

Tắt có chủ đích (theo Phase 1 V2.0 — đã gỡ anti-tamper):
`antihook`, `antidbg (adb)`, `acd`, `fco` = **OFF**. Lý do riêng của `acd`:
app tự gọi `objc_getClass("khanhduy")` — nếu acd rename IMP thì license gate
tự vỡ. Khi sang phase 2 muốn bật lại thì sửa `mod_common` + thêm
`enable-antihook/enable-adb` vào policy tương ứng.

Chuỗi nhạy cảm được strenc che: `kBaseAPIURL`, `kPackageToken`,
`kLicensePublicKeyPEM` (trong `HeaderAPI.h` — mỗi TU include sẽ có bản mã hoá riêng).

**Tinh chỉnh nhanh:**
- Muốn mạnh hơn nữa: tăng `bcf_prob` 40→70, `fw_prob` 20→40, bật
  `indibran-enc-jump-target: true`.
- Muốn nhẹ hơn (build nhanh, app mượt): đổi `f_core` thành `"base": "f_safe"`
  (bỏ fla), hoặc hạ `strcry_prob`.
- Muốn đưa file từ mức này sang mức khác: sửa regex `module` trong mảng
  `policies` (quy tắc **đứng sau ghi đè đứng trước**).

## 4. Biến cấu hình (sửa trực tiếp trong `build-ipa.yml` → phần `env:`)

| Biến | Mặc định | Ý nghĩa |
|---|---|---|
| `OLLVM_MODE` | `on` | `off` = build y như trước kia, không obfuscate (công tắc khẩn cấp) |
| `OLLVM_VARIANT` | `hikari` | `obfuscator` (bcf-fla-sub cổ điển) / `pluto` (MBA + mã hoá global, cần z3) / `arkari` (EncKey) |
| `OLLVM_LLVM_VERSION` | `19` | brew llvm; script tự thử 19 → 20 → 18 |
| `XCODE_PREFER` | `16.4` | Ưu tiên Xcode 16.4 (SDK iOS 18.4 — cùng thời clang 19, giảm rủi ro lỗi header). Để trống = Xcode mới nhất |
| `OLLVM_ZIP_URL` | raw…/ollvm.zip | Nguồn tải plugin nếu không dùng bản vendored trong repo |

## 5. Cách xác nhận đã obfuscate thật

Workflow tự chạy `verify-ollvm.sh` và **fail đỏ** nếu:
- `Running Hikari On` < 15 module (plugin không nạp / CC không ăn)
- `>>>> run` < 200 (policy không match)
- có `Error: conf not found` (policy.json không nằm đúng working directory)

Tự kiểm tra bằng tay sau khi tải IPA:

```bash
# 1. Log build: đếm module/pass
grep -c "Running Hikari On" build.log
grep -c ">>>> run" build.log

# 2. Chuỗi nhạy cảm không còn hiện rõ (strenc đã mã hoá)
strings Payload/Cofi.app/Cofi | grep -c "khanhduyz.fun"        # kỳ vọng 0
strings Payload/Cofi.app/Cofi | grep -c "BEGIN PUBLIC KEY"     # kỳ vọng 0

# 3. Control flow đã bị flatten (dễ thấy trong IDA/Ghidra: hàm trong
#    f_core/f_max sẽ có dispatcher switch + case xoá trộn scramble32)
```

Lưu ý về kiểm tra 2: nếu một chuỗi được **nhiều hàm** dùng chung, strenc có thể
bỏ qua không mã hoá (ràng buộc "1 hàm sử dụng" của tác giả) → vẫn thấy rõ.
Đây là cảnh báo (warning) chứ không phải lỗi — muốn che triệt để thì tách chuỗi
thành biến cục bộ trong từng hàm, hoặc đắp `constenc_togv`.

## 6. Xử lý sự cố

| Triệu chứng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Build **treo không chạy tiếp** (run #5: 45+ phút dừng tại `>>>> run indibr on __cxx_global_var_init`, `UnityMath.mm`) | Pass `indibr` với `indibran-use-stack: true` copy **bảng BlockAddress của cả TU** vào stack cho **từng lệnh nhánh** → TU C++ nhiều hàm (UnityMath: 78 hàm, sau fla+split ~vạn block) làm IR phình hàng GB → clang đứng máy (swap) | **Đã sửa 3 lớp**: (1) `indibran-use-stack: false` trong `mod_common`; (2) plugin patch skip `__cxx_global_var_init*` / `_GLOBAL__sub_I_*` (không có giá trị bảo hộ); (3) wrapper **timeout 300s** (`OLLVM_COMPILE_TIMEOUT`) → tự hạ f_safe → Apple clang, không bao giờ treo quá 5 phút/lần |
| `clang: error: unknown argument: '-index-store-path'` (run #2) | Xcode Debug truyền cờ Apple-only cho compiler; clang upstream (brew) không hiểu | **Đã sửa sẵn 3 lớp**: (1) workflow thêm `COMPILER_INDEX_STORE_ENABLE=NO`; (2) wrapper lọc cờ trước khi gọi brew clang; (3) smoke-test A2 chặn hồi quy. Nếu gặp cờ Apple-only KHÁC: thêm vào `filter_apple_only_flags` trong cả 2 wrapper |
| `clang frontend command failed with exit code 139` / segfault ở codegen (run #4, `ESPDrawOverlay.m`) | Hàm rất lớn (357 dòng) + split×3 + fla + **indibr** (BlockAddress table) làm MC writer của brew clang 19 crash trên arm64e | **Đã pre-seed** trong `policy.json`: `ESPDrawOverlay.m` → `f_core_noindibr` (tắt indibr, giữ fla/split/strenc/constenc/sub). File KHÁC gặp nốt: thêm 1 entry cuối mảng `policies` theo mẫu |
| **Link fail**: `ld: warning: ignoring file '….o': found architecture 'arm64e.old', required architecture 'arm64e'` ×37 → `Undefined symbols for architecture arm64e: "_main"` (run #10) | **brew llvm@19 chỉ phát sinh object arm64e ABI CŨ** (`arm64e.old`); ld64 của Xcode 16.4 + libxpf.dylib (Apple clang, ABI mới) yêu cầu ABI mới → linker vứt TOÀN BỘ object arm64e. llvm@19 không có cờ bật ABI mới (phải llvm@20+; Hikari plugin đang ghim 19) | **Đã sửa trong wrapper**: mọi compile `-target arm64e-*` tự chuyển sang Apple clang (log có dòng `[ollvm] arm64e slice -> Apple clang: …`). **Slice arm64 — slice app chạy thật trên device — vẫn brew clang + Hikari đầy đủ**. Muốn obfuscate cả arm64e: phải port Hikari lên llvm@20+ |
| `error: unable to rename temporary '….o.tmp' to output file '….o': 'No such file or directory'` (run #10: `file.m`, `esp.mm` — 2 compile arm64 cuối) | cc1 compile xong nhưng file `.o.tmp` **biến mất giữa chừng** — race lúc build sập (linker arm64e fail → hệ build dọn dẹp/lỗi). Lỗi phát sinh SAU khi cc1 đã xong ("N warnings and 1 error generated") | **Đã sửa trong wrapper**: tự nhận diện lỗi này (rc=1 + câu chữ rename tmp) → **retry cùng policy 1 lần** (thường thành công vì là lỗi thoáng qua) → vẫn lỗi → Apple clang + ghi `DEGRADED … rename-tmp x2`. Với arm64e đã fix linker thì race này không còn đường xảy ra |
| **Link fail**: `Undefined symbols for architecture arm64e` — hàng loạt `_kSec*`, `_CGRect*`, `_CGAffineTransform*`, `_AVAudioSession*`, `_IOSurface*`, `_CACurrentMediaTime`, `OBJC_CLASS_$_UI*`... từ `DuyServer.o`, `khanhduy.o`, `esp.o`, `ESPDrawOverlay.o`... (run #12) | Project có `CLANG_ENABLE_MODULES = YES` + **Frameworks build phase RỖNG** → app **phụ thuộc hoàn toàn module autolinking** (clang nhúng `LC_LINKER_OPTION -framework …` vào .o khi `-fmodules` bật). Workflow inject `CLANG_ENABLE_MODULES=NO` (từ run #2, để brew clang ổn định) → .o **mất toàn bộ autolink hint** → Ld không có nguồn `-framework` nào | **Đã sửa trong `project.pbxproj`**: khai báo tường minh 7 system framework (`AVFoundation`, `CoreGraphics`, `Foundation`, `IOSurface`, `QuartzCore`, `Security`, `UIKit`) vào `OTHER_LDFLAGS` + `OTHER_LDFLAGS[sdk=iphoneos*]` (giữ nguyên `libxpf.dylib` + `$(inherited)`) ở cả 3 config. Khi modules bật lại (OLLVM off) ld tự dedup framework trùng — vô hại. Step Collect logs giờ in `Undefined-at-link` để phát hiện sớm |
| Log có dòng `DEGRADED ... -> f_safe` / `-> apple-clang` | **Auto-degrade đã tự cứu build**: brew clang crash/timeout/rename-tmp → wrapper tự hạ policy (f_safe) rồi compile lại; vẫn lỗi → Apple clang không obfuscate file đó | Không cần làm gì — build vẫn xanh. Muốn bảo hộ lại file đó: xem tên trong `ollvm/build/degraded.txt`, thêm policy trung gian phù hợp (VD `f_core_noindibr`) vào cuối mảng `policies`. Wrapper chỉ tự hạ khi thật sự lỗi nên không lo hạ oan file tốt |
| Smoke test lỗi compile Foundation headers | brew clang ≠ SDK Xcode quá lệch | Đặt `XCODE_PREFER: 16.4`; hoặc đổi `OLLVM_LLVM_VERSION` cho khớp thời đại Xcode (26.x ↔ 20) |
| `brew install llvm@19` fail (đã bị disable) | Homebrew retire versioned formula | Script tự thử 20 → 18; hoặc đặt `OLLVM_LLVM_VERSION: 20` |
| Verify fail `conf not found` | clang chạy với CWD lạ | Xem đường dẫn trong thông báo lỗi rồi thêm thư mục đó vào `CANDIDATES` của `setup-ollvm.sh` |
| Verify fail `>>>> run` quá ít | Regex trong policy không khớp | So sánh `getSourceFileName` thật trong log (`Running Hikari On <file>`) với regex `module` |
| App chạy sai/lag sau obfuscate | Pass nào đó phá logic nhạy cảm | Đặt `OLLVM_MODE: off` để xác nhận; rồi lần lượt hạ mức: bỏ `funcwra` → bỏ `bcf` → hạ `f_core` về `f_safe` |
| Build chậm / binary phình | fla+bcf ở -O0 | Bình thường (Debug). Muốn gọn: để script tự thêm `GCC_OPTIMIZATION_LEVEL=s` (nó tự làm nếu phát hiện -O0 không kích hoạt plugin) hoặc thêm thủ công vào `env` |
| Muốn build không obfuscate 1 lần | — | Vào Actions → Build IPA → Run workflow, hoặc đổi `OLLVM_MODE: off` rồi push |

## 7. Đưa lên GitHub — QUAN TRỌNG

1. Thư mục `Cofi/XPF/` **vẫn đang nằm trên repo GitHub** và bản zip này
   KHÔNG chứa nó (đã xoá local cho nhẹ). Khi push **KHÔNG xoá `Cofi/XPF/`** —
   workflow vẫn cần `Cofi/XPF/output/ios/libxpf.dylib` và script phase
   `make -C Cofi/XPF` build ChOma.
2. Nếu repo đang có workflow cũ (ví dụ `.github/workflows/build.yml`) thì
   **xoá file cũ** sau khi thêm `build-ipa.yml`, không thì mỗi push chạy 2 build.
3. Push xong: Actions → "Build IPA" → chạy. Đợi ~10–16 phút (brew LLVM ~3′,
   plugin ~2′, XPF make ~4′, app obfuscate ~3′).

## 8. Ghi chú

- `aesSeed` trong `policy.json` cố định (20260927) → **build lặp lại được cùng
  kết quả**. Muốn mỗi bản build khác nhau → xoá field này (seed ngẫu nhiên).
- Thứ tự pass của hikari là cố định trong plugin: strenc → split → bcf → fla →
  sub → constenc → indibr → fw (cùng thứ tự tác giả lich4 dùng).
- Hiệu năng tham khảo (từ tài liệu OLLVM): fla ~+10% runtime trên hàm được
  flatten. Các hàm tick cao tần (UnityMath, esp.mm) vẫn nằm ở `f_core` — nếu
  thấy ESP giật có thể hạ riêng 2 file đó xuống `f_safe` bằng regex bổ sung
  đứng sau trong `policies`.
- Nguồn plugin: `lich4/llvm-pass-hikari` (LLVM New Pass Manager, hỗ trợ LLVM
  12–20, đã test macOS 15 + LLVM 15–19). Báo cáo phân tích chi tiết 4 biến thể
  kèm theo phiên bản PDF trước đó.
- **Cơ chế auto-degrade** (từ run #4, mở rộng run #5): khi brew clang **crash**
  (exit 132–139, SIGSEGV/SIGABRT/…) hoặc **treo quá hạn**
  (`OLLVM_COMPILE_TIMEOUT`, mặc định 300s — kill cả process tree kể cả cc1)
  ở 1 file, wrapper tự: (1) append override `f_safe` cho đúng file đó vào TẤT
  CẢ bản policy.json (an toàn atomic qua temp+rename), compile lại — f_safe tắt
  fla/split nên số block giảm mạnh, kèm use-stack đã OFF nên hết cả phình IR;
  (2) vẫn crash/timeout thì chuyển file đó qua Apple clang (không obfuscate,
  như XPF). Mọi lần hạ mức ghi vào `ollvm/build/degraded.txt` — hiển thị ở
  step Verify và cuối log.txt (`Files degraded`). Verify sẽ fail nếu > 5 file
  bị degrade (lúc đó là vấn đề LLVM/SDK hệ thống, không phải 1 file đơn lẻ).
  Đường Apple clang (XPF/link) KHÔNG bị giới hạn timeout — build XPF giữ
  nguyên 100%.
