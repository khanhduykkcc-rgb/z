#!/bin/bash
# =============================================================================
# verify-ollvm.sh — Kiểm chứng obfuscation SAU khi build
#
# Cách dùng: ./ollvm/verify-ollvm.sh <build.log> <đường dẫn binary Cofi>
#
# Fail (exit 1) nếu:
#   - Có "Error: conf not found"  -> policy.json không nạp ở một số lần compile
#   - Có "could not find policy"  -> policy.json tham chiếu sai tên
#   - "Running Hikari On" < 15    -> plugin không chạy trên nguồn app
#   - ">>>> run" < 200            -> policy không match đủ hàm
# Cảnh báo (::warning) nếu chuỗi nhạy cảm vẫn còn hiện trong binary
# (GV dùng chung nhiều hàm có thể bị strenc bỏ qua — tham khảo README-OLLVM.md)
# =============================================================================
set -uo pipefail

LOG="${1:-build.log}"
BIN="${2:-}"

echo "===== VERIFY OLLVM ====="

if [ "${OLLVM_MODE:-on}" != "on" ]; then
    echo "OLLVM_MODE=off — bỏ qua kiểm chứng (build không obfuscate)"
    exit 0
fi

if [ ! -f "$LOG" ]; then
    echo "::error::Không tìm thấy log build: $LOG"
    exit 1
fi

C_ERR=$(grep -c "Error: conf not found" "$LOG" || true)
C_POL=$(grep -c "could not find policy" "$LOG" || true)
C_MOD=$(grep -c "Running Hikari On" "$LOG" || true)
C_RUN=$(grep -c ">>>> run" "$LOG" || true)
C_TOT=$(grep -c "Hikari total time" "$LOG" || true)
C_E64=$(grep -c "arm64e slice -> Apple clang" "$LOG" || true)

echo "Module có Hikari chạy : $C_MOD"
echo "Lần áp pass obfuscate : $C_RUN"
echo "Module tính tổng time : $C_TOT"
echo "Lỗi 'conf not found'  : $C_ERR"
echo "Lỗi 'could not find'  : $C_POL"
echo "Slice arm64e (Apple)  : $C_E64  (by design — run #10: ld64 từ chối object arm64e.old của brew llvm@19; slice arm64 vẫn Hikari)"

FAIL=0
if [ "$C_ERR" -gt 0 ]; then
    echo "::error::policy.json KHÔNG được nạp ở $C_ERR lần compile — obfuscation KHÔNG chạy ở các file đó!"
    FAIL=1
fi
if [ "$C_POL" -gt 0 ]; then
    echo "::error::policy.json tham chiếu tên policy không tồn tại"
    FAIL=1
fi
if [ "$C_MOD" -lt 15 ]; then
    echo "::error::Hikari chỉ chạy trên $C_MOD module (< 15) — CC override có thể không có tác dụng"
    FAIL=1
fi
if [ "$C_RUN" -lt 200 ]; then
    echo "::error::Chỉ $C_RUN lần áp pass (< 200) — policy không match hàm hay file nguồn nào"
    FAIL=1
fi

if [ -n "$BIN" ]; then
    if [ -f "$BIN" ]; then
        SIZE=$(du -h "$BIN" | cut -f1)
        echo "Kích thước binary     : $SIZE"
        # Fat binary (arm64 + arm64e): slice arm64e là Apple clang KHÔNG
        # obfuscate (run #10 — ABI) nên strings sẽ hiện rõ — chỉ kiểm tra
        # slice arm64 (slice app chạy thật, có Hikari).
        CHECKBIN="$BIN"
        THIN=""
        if command -v lipo >/dev/null 2>&1 && lipo -info "$BIN" 2>/dev/null | grep -q "arm64e"; then
            THIN="$(mktemp "${TMPDIR:-/tmp}/cofi-thin-arm64.XXXXXX" 2>/dev/null || true)"
            if [ -n "$THIN" ] && lipo -thin arm64 "$BIN" -output "$THIN" 2>/dev/null && [ -s "$THIN" ]; then
                CHECKBIN="$THIN"
                echo "Binary fat arm64+arm64e — kiểm tra strings trên slice arm64 (obfuscated)"
            fi
        fi
        echo "--- Kiểm tra chuỗi nhạy cảm (strenc) ---"
        for s in "khanhduyz.fun" "d20f4cfede4042aa85f90c42b0ddaa10" "BEGIN PUBLIC KEY"; do
            if strings "$CHECKBIN" | grep -q "$s"; then
                echo "::warning:: Vẫn thấy chuỗi rõ trong binary: '$s'"
            else
                echo "PASS: '$s' không còn xuất hiện (đã mã hoá)"
            fi
        done
        [ -n "$THIN" ] && rm -f "$THIN" 2>/dev/null
    else
        echo "::warning:: Không tìm thấy binary: $BIN (bỏ qua kiểm tra strings)"
    fi
fi

# --- Báo cáo file bị hạ mức bảo hộ (auto-degrade) ---------------------------
DEGRADE_LOG="${OLLVM_DEGRADE_LOG:-$PWD/ollvm/build/degraded.txt}"
if [ -f "$DEGRADE_LOG" ]; then
    C_DEG=$(grep -c "^DEGRADED" "$DEGRADE_LOG" || true)
    C_TMO=$(grep -c "timeout" "$DEGRADE_LOG" || true)
    C_RNM=$(grep -c "rename-tmp" "$DEGRADE_LOG" || true)
    echo "--- Auto-degrade (brew clang crash/timeout/rename-tmp -> hạ mức) ---"
    cat "$DEGRADE_LOG"
    echo "Số lần timeout       : $C_TMO"
    echo "Số lần rename-tmp    : $C_RNM"
    if [ "$C_DEG" -gt 0 ]; then
        echo "::warning:: $C_DEG lần hạ mức bảo hộ (xem danh sách trên) — build vẫn OK nhưng các file này bảo hộ yếu hơn"
    fi
    # Quá nhiều file bị degrade = có vấn đề hệ thống (LLVM/SDK lệch) — fail
    if [ "$C_DEG" -gt 5 ]; then
        echo "::error:: Quá nhiều file bị degrade ($C_DEG > 5) — khả năng brew clang không tương thích SDK; thử đổi OLLVM_LLVM_VERSION hoặc XCODE_PREFER"
        FAIL=1
    fi
fi

if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
    {
        echo "### OLLVM Verify"
        echo ""
        echo "| Chỉ số | Giá trị |"
        echo "|---|---|"
        echo "| Module có Hikari | $C_MOD |"
        echo "| Lần áp pass | $C_RUN |"
        echo "| Lỗi conf not found | $C_ERR |"
        if [ -f "${OLLVM_DEGRADE_LOG:-$PWD/ollvm/build/degraded.txt}" ]; then
            echo "| File bị auto-degrade | $(grep -c '^DEGRADED' "${OLLVM_DEGRADE_LOG:-$PWD/ollvm/build/degraded.txt}" || echo 0) |"
        echo "| Số lần timeout | $(grep -c 'timeout' "${OLLVM_DEGRADE_LOG:-$PWD/ollvm/build/degraded.txt}" || echo 0) |"
        fi
    } >> "$GITHUB_STEP_SUMMARY"
fi

if [ "$FAIL" = "0" ]; then
    echo "==> OBFUSCATION OK"
    exit 0
else
    echo "==> OBFUSCATION FAIL — xem các lỗi ::error ở trên"
    exit 1
fi
