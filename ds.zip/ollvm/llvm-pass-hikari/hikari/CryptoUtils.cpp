// For open-source license, please refer to
// [License](https://github.com/HikariObfuscator/Hikari/wiki/License).
//===----------------------------------------------------------------------===//

#include "CryptoUtils.h"
#include "llvm/Support/Format.h"
#include "llvm/Support/raw_ostream.h"
#include <chrono>
#include <unistd.h>

using namespace llvm;
namespace llvm {
ManagedStatic<CryptoUtils> cryptoutils;
}
CryptoUtils::CryptoUtils() {}

uint32_t CryptoUtils::scramble32(
    uint32_t in, std::unordered_map<uint32_t /*IDX*/, uint32_t /*VAL*/> &VMap) {
  if (VMap.find(in) == VMap.end()) {
    uint32_t V = get_uint32_t();
    VMap[in] = V;
    return V;
  } else {
    return VMap[in];
  }
}
CryptoUtils::~CryptoUtils() {
  if (eng != nullptr)
    delete eng;
}
void CryptoUtils::prng_seed() {
  using namespace std::chrono;
  std::uint_fast64_t ms =
      duration_cast<milliseconds>(system_clock::now().time_since_epoch())
          .count();
  // UP: mix multiple entropy sources. Previously only the millisecond
  // timestamp was used, so two modules compiled within the same millisecond
  // (parallel Xcode build) shared the exact same obfuscation constants,
  // keys and random names, which made cross-file patterns trivially
  // recoverable. Keep the explicit prng_seed(seed) overload untouched so
  // reproducible builds (aesSeed) still behave identically.
  std::random_device rd;
  std::uint_fast64_t entropy =
      ((std::uint_fast64_t)rd() << 32) ^ (std::uint_fast64_t)rd();
  std::uint_fast64_t pidns =
      ((std::uint_fast64_t)getpid() << 32) ^
      (std::uint_fast64_t)duration_cast<nanoseconds>(
          steady_clock::now().time_since_epoch())
          .count();
  std::uint_fast64_t seed = ms ^ (entropy * 0x9E3779B97F4A7C15ULL) ^
                            (pidns * 0xC2B2AE3D27D4EB4FULL);
  errs() << format("std::mt19937_64 auto-seeded with mixed entropy: %" PRIu64 "",
                   seed)
         << "\n";
  eng = new std::mt19937_64(seed);
}
void CryptoUtils::prng_seed(std::uint_fast64_t seed) {
  errs() << format("std::mt19937_64 seeded with: %" PRIu64 "", seed) << "\n";
  eng = new std::mt19937_64(seed);
}
std::uint_fast64_t CryptoUtils::get_raw() {
  if (eng == nullptr)
    prng_seed();
  return (*eng)();
}
uint32_t CryptoUtils::get_range(uint32_t min, uint32_t max) {
  if (max == 0)
    return 0;
  // UP: harden degenerate calls (previously UB via
  // uniform_int_distribution(min, max-1) when max <= min) and seed lazily
  // so get_range() never dereferences a null engine.
  if (max <= min)
    return min;
  if (eng == nullptr)
    prng_seed();
  std::uniform_int_distribution<uint32_t> dis(min, max - 1);
  return dis(*eng);
}
