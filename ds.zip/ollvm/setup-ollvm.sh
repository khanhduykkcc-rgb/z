#!/bin/bash
# =============================================================================
# setup-ollvm.sh — Chuẩn bị OLLVM (Hikari) cho build DSWUnity trên GitHub Actions
#
# Các bước:
#   [1] brew install cmake, ninja (+ z3 nếu OLLVM_VARIANT=pluto)
#   [2] Lấy source llvm-pass-hikari (vendored trong repo, fallback tải zip)
#   [3] brew install llvm@<ver> (thử OLLVM_LLVM_VERSION -> 20 -> 18)
#   [4] cmake + ninja build plugin <Variant>.dylib
#   [5] Sinh policy.json từ template (thay __SRC_ROOT__) và copy vào TẤT CẢ
#       các thư mục có thể là working-directory của clang khi xcodebuild chạy
#   [6] Smoke test: biên dịch file .m thử — xác nhận plugin chạy + wrapper
#       route đúng (app -> Hikari, XPF -> Apple clang)
#
# Sau khi chạy: export qua $GITHUB_ENV (CI) và ghi ollvm/build/ollvm-env.sh
# (chạy local: source ollvm/build/ollvm-env.sh trước khi gọi xcodebuild).
# =============================================================================
set -euo pipefail

cd "${GITHUB_WORKSPACE:-$PWD}"

VARIANT="${OLLVM_VARIANT:-hikari}"
WANT_LLVM="${OLLVM_LLVM_VERSION:-19}"
SRC_DIR="$PWD/ollvm/llvm-pass-hikari"
BUILD_DIR="$PWD/ollvm/build/${VARIANT}"
DERIVED="$PWD/build/DerivedData"
CONFIG="${XCODE_BUILD_CONFIGURATION:-Debug}"
PLATFORM="iphoneos"

echo "==> [OLLVM 1/6] Homebrew: cmake + ninja"
brew install cmake ninja
if [ "$VARIANT" = "pluto" ]; then
    echo "    (variant pluto cần Z3)"
    brew install z3 || true
fi

echo "==> [OLLVM 2/6] Source llvm-pass-hikari"
if [ ! -f "$SRC_DIR/$VARIANT/CMakeLists.txt" ]; then
    if [ -z "${OLLVM_ZIP_URL:-}" ]; then
        echo "::error::Không tìm thấy ollvm/llvm-pass-hikari/$VARIANT và OLLVM_ZIP_URL chưa đặt"
        exit 1
    fi
    echo "    Tải source từ: $OLLVM_ZIP_URL"
    curl -fL --retry 3 -o /tmp/ollvm.zip "$OLLVM_ZIP_URL"
    rm -rf /tmp/ollvm_src && mkdir -p /tmp/ollvm_src
    unzip -q /tmp/ollvm.zip -d /tmp/ollvm_src
    FOUND=$(find /tmp/ollvm_src -maxdepth 4 -type f -name CMakeLists.txt -path "*/$VARIANT/*" | head -1)
    if [ -z "$FOUND" ]; then
        echo "::error::Trong zip không có variant '$VARIANT'"
        exit 1
    fi
    SRC_DIR=$(dirname "$(dirname "$FOUND")")
fi
echo "    SRC_DIR = $SRC_DIR"

echo "==> [OLLVM 3/6] brew install llvm (thử llvm@$WANT_LLVM -> llvm@20 -> llvm@18)"
BREW_LLVM=""
TRIED=""
for v in "$WANT_LLVM" 20 18; do
    case ",$TRIED," in
        *",$v,"*) continue ;;
    esac
    TRIED="$TRIED,$v"
    echo "    brew install llvm@$v ..."
    if brew install "llvm@$v" 2>&1 | tail -5; then
        if [ -x "/opt/homebrew/opt/llvm@$v/bin/clang" ]; then
            BREW_LLVM="/opt/homebrew/opt/llvm@$v"
            echo "    OK: $BREW_LLVM"
            break
        fi
    fi
    echo "    llvm@$v không khả dụng — thử bản khác"
done
if [ -z "$BREW_LLVM" ]; then
    echo "::error::Không cài được llvm@19/20/18 qua Homebrew. Kiểm tra: brew search llvm@"
    exit 1
fi
"$BREW_LLVM/bin/clang" --version | head -2

echo "==> [OLLVM 4/6] Build plugin $VARIANT.dylib"
mkdir -p "$PWD/ollvm/build"
rm -rf "$BUILD_DIR"
cmake -S "$SRC_DIR/$VARIANT" -G Ninja -B "$BUILD_DIR" \
    -DLLVM_DIR="$BREW_LLVM/lib/cmake/llvm"
cmake --build "$BUILD_DIR"
PLUGIN=$(find "$BUILD_DIR" -type f -name "*.dylib" | head -1)
if [ -z "$PLUGIN" ]; then
    echo "::error::Build xong nhưng không tìm thấy *.dylib trong $BUILD_DIR"
    exit 1
fi
echo "    PLUGIN = $PLUGIN"

echo "==> [OLLVM 5/6] Đặt policy.json vào các working directory ứng viên"
POLICY_TEMPLATE="$PWD/ollvm/policy.json"
if [ ! -f "$POLICY_TEMPLATE" ]; then
    echo "::error::Thiếu ollvm/policy.json"
    exit 1
fi
POLICY_TMP=$(mktemp)
sed "s|__SRC_ROOT__|$PWD|g" "$POLICY_TEMPLATE" > "$POLICY_TMP"
python3 -c "import json; json.load(open('$POLICY_TMP'))" || {
    echo "::error::policy.json không hợp lệ sau khi thay __SRC_ROOT__"
    exit 1
}
# Plugin doc policy.json tu working directory cua tung tien trinh clang.
# xcodebuild co the dat CWD o nhieu cho khac nhau tuy phien ban XCBuild nen
# copy vao TAT CA cac thu muc ung vien (pattern trong policy da anchor "/.*"
# nen khong phu thuoc CWD).
CANDIDATES=(
    "$PWD"
    "$PWD/Cofi"
    "$DERIVED"
    "$DERIVED/Build/Products/${CONFIG}-${PLATFORM}"
    "$DERIVED/Build/Intermediates.noindex/Cofi.build/${CONFIG}-${PLATFORM}/Cofi.build"
    "$DERIVED/Build/Intermediates.noindex/Cofi.build/${CONFIG}-${PLATFORM}/Cofi.build/Objects-normal/arm64"
    "$DERIVED/Build/Intermediates.noindex/Cofi.build/${CONFIG}-${PLATFORM}/Cofi.build/Objects-normal/arm64e"
    "$DERIVED/Build/Intermediates/Cofi.build/${CONFIG}-${PLATFORM}/Cofi.build"
    "$DERIVED/Build/Intermediates/Cofi.build/${CONFIG}-${PLATFORM}/Cofi.build/Objects-normal/arm64"
)
for d in "${CANDIDATES[@]}"; do
    mkdir -p "$d"
    cp -f "$POLICY_TMP" "$d/policy.json"
done
echo "    Đã copy policy.json vào ${#CANDIDATES[@]} thư mục ứng viên"

# Danh sách policy.json (phân cách ':') cho wrapper dùng khi auto-degrade
# (append override f_safe khi brew clang crash — xem cc-wrapper.sh)
POLICY_FILES=""
for d in "${CANDIDATES[@]}"; do
    if [ -f "$d/policy.json" ]; then
        POLICY_FILES="${POLICY_FILES:+$POLICY_FILES:}$d/policy.json"
    fi
done

# Log các file bị hạ mức bảo hộ (auto-degrade) — reset mỗi lần setup
DEGRADE_LOG="$PWD/ollvm/build/degraded.txt"
rm -f "$DEGRADE_LOG"

echo "==> [OLLVM 6/6] Smoke test"
chmod +x "$PWD"/ollvm/*.sh
export OLLVM_LLVM_HOME="$BREW_LLVM"
export OLLVM_HIKARI_PLUGIN="$PLUGIN"
export OLLVM_MODE="${OLLVM_MODE:-on}"
export OLLVM_POLICY_FILES="$POLICY_FILES"
export OLLVM_DEGRADE_LOG="$DEGRADE_LOG"
export OLLVM_COMPILE_TIMEOUT="${OLLVM_COMPILE_TIMEOUT:-300}"
"$PWD/ollvm/smoke-test.sh"

# ---- Export môi trường cho các step sau ----
ENV_FILE="$PWD/ollvm/build/ollvm-env.sh"
mkdir -p "$PWD/ollvm/build"
{
    echo "export OLLVM_LLVM_HOME=\"$BREW_LLVM\""
    echo "export OLLVM_HIKARI_PLUGIN=\"$PLUGIN\""
    echo "export OLLVM_MODE=\"${OLLVM_MODE:-on}\""
    echo "export OLLVM_POLICY_FILES=\"$POLICY_FILES\""
    echo "export OLLVM_DEGRADE_LOG=\"$DEGRADE_LOG\""
    echo "export OLLVM_COMPILE_TIMEOUT=\"${OLLVM_COMPILE_TIMEOUT:-300}\""
    if [ -f "$PWD/ollvm/build/ollvm-env-extra.txt" ]; then
        echo "export OLLVM_EXTRA_XCODEBUILD_ARGS=\"$(cat "$PWD/ollvm/build/ollvm-env-extra.txt")\""
    fi
} > "$ENV_FILE"

if [ -n "${GITHUB_ENV:-}" ]; then
    {
        echo "OLLVM_LLVM_HOME=$BREW_LLVM"
        echo "OLLVM_HIKARI_PLUGIN=$PLUGIN"
        echo "OLLVM_POLICY_FILES=$POLICY_FILES"
        echo "OLLVM_DEGRADE_LOG=$DEGRADE_LOG"
        echo "OLLVM_COMPILE_TIMEOUT=${OLLVM_COMPILE_TIMEOUT:-300}"
        if [ -f "$PWD/ollvm/build/ollvm-env-extra.txt" ]; then
            echo "OLLVM_EXTRA_XCODEBUILD_ARGS=$(cat "$PWD/ollvm/build/ollvm-env-extra.txt")"
        fi
    } >> "$GITHUB_ENV"
fi

if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
    EXTRA_DISP="CC/CXX wrapper + CLANG_ENABLE_MODULES=NO"
    if [ -f "$PWD/ollvm/build/ollvm-env-extra.txt" ]; then
        EXTRA_DISP="CC/CXX wrapper + CLANG_ENABLE_MODULES=NO + $(cat "$PWD/ollvm/build/ollvm-env-extra.txt")"
    fi
    {
        echo "### OLLVM / $VARIANT"
        echo ""
        echo "- LLVM: \`$BREW_LLVM\`"
        echo "- Plugin: \`$PLUGIN\`"
        echo "- Xcodebuild args thêm: \`$EXTRA_DISP\`"
    } >> "$GITHUB_STEP_SUMMARY"
fi

echo "==> SETUP OLLVM OK"
