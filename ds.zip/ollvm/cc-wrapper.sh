#!/bin/bash
# =============================================================================
# OLLVM CC wrapper — DSWUnity (Cofi)
#
# Nhiem vu: xcodebuild goi compiler qua build setting CC/CXX = script nay.
#   1. Compile file APP  (khong nam trong Cofi/XPF/)
#        -> brew LLVM clang (OLLVM_LLVM_HOME) + -fpass-plugin=Hikari.dylib
#   2. Compile file XPF/ChOma (nam trong .../Cofi/XPF/...)
#        -> Apple clang (xcrun clang) — build XPF giu nguyen 100% nhu truoc
#   3. Link & cac lenh khac (khong co -c)
#        -> Apple clang (xcrun clang) — toolchain Apple dung lai
#   4. Compile bat ky ai cho SLICE arm64e (-target arm64e-*)
#        -> Apple clang (xcrun clang) — run #10: brew llvm@19 chi phat sinh
#           object arm64e ABI CU ("arm64e.old"), ld64 Xcode 16.4 tu choi
#           (Undefined symbols: _main). llvm@19 khong co co bat ABI moi.
#           Slice arm64 (slice app chay that tren device) van du Hikari.
#
# Bien moi truong (do setup-ollvm.sh export):
#   OLLVM_LLVM_HOME     /opt/homebrew/opt/llvm@<ver>
#   OLLVM_HIKARI_PLUGIN duong dan Hikari.dylib
#   OLLVM_MODE          on/off (off = moi thu qua Apple clang)
#   OLLVM_COMPILE_TIMEOUT  han compile bang brew clang (giay, mac dinh 300)
#                         qua han -> tu ha muc bao ho giong crash (run #5)
# =============================================================================
set -uo pipefail

BREW_LLVM="${OLLVM_LLVM_HOME:-}"
PLUGIN="${OLLVM_HIKARI_PLUGIN:-}"

# cc-wrapper.sh -> clang ; cxx-wrapper.sh -> clang++
MODE=cc
case "$(basename "$0")" in
    cxx*) MODE=cxx ;;
esac

apple_cc() {
    if [ "$MODE" = "cxx" ]; then
        exec xcrun clang++ "$@"
    else
        exec xcrun clang "$@"
    fi
}

# --- Lọc cờ Apple-only mà clang upstream (brew) KHÔNG hiểu ------------------
# Xcode (Debug) truyền "-index-store-path <dir>" cho compiler — cờ Apple-only.
# clang upstream (brew llvm@19) báo "error: unknown argument" -> BUILD FAILED
# (GitHub run #2, 36290479569). Bộ lọc này CHỈ áp dụng trên đường brew clang;
# đường Apple clang (XPF/link) KHÔNG đi qua -> build XPF giữ nguyên 100%.
# Gặp thêm cờ Apple-only mới? Bổ sung vào case bên dưới (kèm skip=1 nếu cờ
# nhận value ở tham số kế tiếp).
FILTERED=()
filter_apple_only_flags() {
    FILTERED=()
    local skip=0 a
    for a in "$@"; do
        if [ "$skip" = "1" ]; then skip=0; continue; fi
        case "$a" in
            -index-store-path)   skip=1; continue ;;  # Apple-only, value ở tham số kế tiếp
            -index-store-path=*) continue ;;          # Apple-only, dạng =value
        esac
        FILTERED+=("$a")
    done
}

# --- Tự hạ mức bảo hộ khi brew clang CRASH (auto-degrade) -------------------
# brew clang (upstream LLVM) có thể segfault ở codegen với một số hàm rất lớn
# sau obfuscate (run #4: ESPDrawOverlay.m — exit 139, MCSymbol::getSection,
# arm64e). Để build không chết vì 1 file:
#   retry 1: append override policy "f_safe" vào policy.json rồi compile lại
#            (tắt fla/split/indibr — giữ strenc/constenc/sub)
#   retry 2: vẫn crash -> Apple clang, KHÔNG obfuscate file đó (như XPF)
# Mọi lần hạ mức ghi vào $OLLVM_DEGRADE_LOG (đọc ở step Verify / Collect logs).
is_crash_rc() {
    case "$1" in
        124) return 0 ;;                                  # timeout (run_with_timeout kill)
        132|133|134|135|136|137|138|139) return 0 ;;      # SIGILL/TRAP/ABRT/EMT/FPE/KILL/BUS/SEGV
        *) return 1 ;;
    esac
}

# --- Timeout cho brew clang (chống hang — run #5 treo 45 phút) --------------
# macOS KHÔNG có lệnh `timeout` -> chạy nền + poll. Quá hạn giết cả process
# tree (cc1 là con của clang driver) rồi return 124 -> đi vào luồng
# auto-degrade như crash (f_safe -> Apple clang).
# Đường Apple clang (XPF/link) KHÔNG bị giới hạn — build XPF giữ nguyên 100%.
run_with_timeout() { # $1 = số giây (0/invalid = không giới hạn); còn lại = lệnh
    local t="$1"; shift
    case "$t" in
        ''|*[!0-9]*) t=0 ;;
    esac
    if [ "$t" -eq 0 ]; then
        "$@"
        return $?
    fi
    "$@" &
    local pid=$! el=0
    while kill -0 "$pid" 2>/dev/null; do
        if [ "$el" -ge "$t" ]; then
            pkill -9 -P "$pid" 2>/dev/null
            kill -9 "$pid" 2>/dev/null
            wait "$pid" 2>/dev/null
            return 124
        fi
        sleep 1
        el=$((el+1))
    done
    wait "$pid"
    return $?
}

log_degrade() { # $1 = file nguồn, $2 = mức hạ xuống, $3 = lý do
    local log="${OLLVM_DEGRADE_LOG:-}"
    [ -n "$log" ] || log="$PWD/ollvm/build/degraded.txt"
    mkdir -p "$(dirname "$log")" 2>/dev/null
    echo "DEGRADED $1 -> $2 (${3:-auto-fallback}, $(date -u '+%Y-%m-%d %H:%M:%SZ'))" >> "$log" 2>/dev/null || true
}

append_policy_override() { # $1 = file nguồn, $2 = policy
    local src="$1" pol="$2"
    [ -n "$src" ] || return 0
    command -v python3 >/dev/null 2>&1 || return 0
    local files="${OLLVM_POLICY_FILES:-$PWD/policy.json}"
    local f OLDIFS="$IFS"
    IFS=':'
    for f in $files; do
        [ -f "$f" ] || continue
        python3 - "$f" "$src" "$pol" <<'PYEOF' 2>/dev/null || true
import json, re, sys, os, tempfile
path, src, pol = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    with open(path) as fh:
        conf = json.load(fh)
except Exception:
    sys.exit(0)  # policy hỏng -> bỏ qua, retry vẫn chạy như cũ
pat = re.escape(src)
lst = conf.setdefault("policies", [])
if not any(e.get("module") == pat and e.get("policy") == pol for e in lst):
    lst.append({"module": pat, "func": ".*", "policy": pol})
    d = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".policy-", suffix=".json")
    with os.fdopen(fd, "w") as fh:
        json.dump(conf, fh, indent=4)
    os.replace(tmp, path)
PYEOF
    done
    IFS="$OLDIFS"
}

brew_cc() {
    if [ -z "$BREW_LLVM" ] || [ -z "$PLUGIN" ] || \
       [ "${OLLVM_MODE:-on}" != "on" ] || \
       [ ! -x "$BREW_LLVM/bin/clang" ] || [ ! -f "$PLUGIN" ]; then
        apple_cc "$@"
        return
    fi
    filter_apple_only_flags "$@"
    CT_TIMEOUT="${OLLVM_COMPILE_TIMEOUT:-300}"
    # stderr cua brew clang ghi ra file tam: (1) van in nguyen ven diagnostics
    # ra log build, (2) doan hoi loi "unable to rename temporary" (run #10).
    ERRFILE="$(mktemp "${TMPDIR:-/tmp}/ollvm-cc-err.XXXXXX" 2>/dev/null || true)"
    run_brew() {
        : > "$ERRFILE" 2>/dev/null
        if [ "$MODE" = "cxx" ]; then
            if [ ${#FILTERED[@]} -gt 0 ]; then
                run_with_timeout "$CT_TIMEOUT" "$BREW_LLVM/bin/clang++" "${FILTERED[@]}" -fpass-plugin="$PLUGIN" 2> "$ERRFILE"
            else
                run_with_timeout "$CT_TIMEOUT" "$BREW_LLVM/bin/clang++" -fpass-plugin="$PLUGIN" 2> "$ERRFILE"
            fi
        else
            if [ ${#FILTERED[@]} -gt 0 ]; then
                run_with_timeout "$CT_TIMEOUT" "$BREW_LLVM/bin/clang" "${FILTERED[@]}" -fpass-plugin="$PLUGIN" 2> "$ERRFILE"
            else
                run_with_timeout "$CT_TIMEOUT" "$BREW_LLVM/bin/clang" -fpass-plugin="$PLUGIN" 2> "$ERRFILE"
            fi
        fi
        local r=$?
        cat "$ERRFILE" >&2 2>/dev/null
        return "$r"
    }
    is_rename_tmp_fail() { # rc=1 + stderr chua loi rename .o.tmp (run #10)
        [ "$1" = "1" ] || return 1
        [ -n "$ERRFILE" ] && grep -q "unable to rename temporary" "$ERRFILE" 2>/dev/null
    }
    run_brew
    local rc=$?
    # --- run #10: cc1 chay xong nhung file .o.tmp bien mat (bi xoa giua chung)
    #     -> retry 1 lan cung policy; van mat -> Apple clang.
    if is_rename_tmp_fail "$rc"; then
        echo "::warning::brew clang mat file .o.tmp giua chung (run #10) voi $(basename "${SRC:-file}") — retry 1/1 cung policy" >&2
        run_brew
        rc=$?
        if is_rename_tmp_fail "$rc"; then
            echo "::warning::van mat .o.tmp — fallback Apple clang, KHONG obfuscate file nay" >&2
            log_degrade "${SRC:-unknown}" "apple-clang" "rename-tmp x2"
            rm -f "$ERRFILE" 2>/dev/null
            apple_cc "$@"
            return
        fi
    fi
    if [ "$rc" = "124" ]; then
        echo "::warning::brew clang TIMEOUT sau ${CT_TIMEOUT}s với $(basename "${SRC:-file}") — retry 1/2: hạ policy f_safe" >&2
        append_policy_override "$SRC" "f_safe"
        log_degrade "${SRC:-unknown}" "f_safe" "timeout"
    elif is_crash_rc "$rc"; then
        echo "::warning::brew clang CRASH (rc=$rc) với $(basename "${SRC:-file}") — retry 1/2: hạ policy f_safe" >&2
        append_policy_override "$SRC" "f_safe"
        log_degrade "${SRC:-unknown}" "f_safe" "crash rc=$rc"
    else
        return "$rc"
    fi
    run_brew
    rc=$?
    if [ "$rc" = "124" ]; then
        echo "::warning::vẫn timeout sau ${CT_TIMEOUT}s — retry 2/2: Apple clang, KHÔNG obfuscate file này" >&2
        log_degrade "${SRC:-unknown}" "apple-clang" "timeout x2"
    elif is_crash_rc "$rc"; then
        echo "::warning::vẫn crash (rc=$rc) — retry 2/2: Apple clang, KHÔNG obfuscate file này" >&2
        log_degrade "${SRC:-unknown}" "apple-clang" "crash x2 rc=$rc"
    else
        return "$rc"
    fi
    apple_cc "$@"
}

# --- Quet tham so: phan biet compile (-c) voi link, va tim file nguon -------
# Gom tham so goc + noi dung cac @response-file (neu xcodebuild dung) thanh
# mot danh sach de quet; khi exec thi van dung tham so goc.
ARGS=()
for a in "$@"; do
    case "$a" in
        @*)
            f="${a#@}"
            if [ -f "$f" ]; then
                while IFS= read -r line || [ -n "$line" ]; do
                    for t in $line; do
                        ARGS+=("$t")
                    done
                done < "$f"
            else
                ARGS+=("$a")
            fi
            ;;
        *)
            ARGS+=("$a")
            ;;
    esac
done

if [ ${#ARGS[@]} -eq 0 ]; then
    apple_cc
fi

IS_COMPILE=0
for a in "${ARGS[@]}"; do
    if [ "$a" = "-c" ]; then
        IS_COMPILE=1
    fi
done

# File nguon = tham so cuoi cung co duoi .m/.mm/.c/... khong phai gia tri cua -o/-MF/-MT/-MQ
SRC=""
skip_next=0
for a in "${ARGS[@]}"; do
    if [ "$skip_next" = "1" ]; then
        skip_next=0
        continue
    fi
    case "$a" in
        -o|-MF|-MT|-MQ|-dependency-file)
            skip_next=1
            ;;
        *.m|*.mm|*.c|*.cc|*.cpp|*.cxx|*.C|*.S|*.s)
            SRC="$a"
            ;;
    esac
done

# --- Slice arm64e: Apple clang BAT BUOC (run #10) ---------------------------
# ld64 (Xcode 16.4) yeu cau object arm64e ABI MOI; brew llvm@19 (Hikari) chi
# phat sinh ABI CU -> 37 object arm64e bi ld bo ("found architecture
# 'arm64e.old', required architecture 'arm64e'") -> Undefined symbols: _main.
# llvm@19 khong co co bat ABI moi -> slice arm64e phai dung Apple clang.
# Slice arm64 (slice app chay that tren device) van brew clang + Hikari du du.
# CHU Y: xcodebuild truyen "-target" va gia tri la HAI tham so rieng biet
# -> phai nhin tham so dung sau -target/-arch, khong the match 1 chuoi lien.
IS_ARM64E=0
prev=""
for a in "${ARGS[@]}"; do
    case "$prev" in
        -target|-arch)
            case "$a" in
                arm64e|arm64e-*) IS_ARM64E=1 ;;
            esac
            ;;
    esac
    case "$a" in
        -target=arm64e*|-arch=arm64e*) IS_ARM64E=1 ;;
    esac
    prev="$a"
done

if [ "$IS_COMPILE" = "1" ] && [ -n "$SRC" ]; then
    if [ "$IS_ARM64E" = "1" ]; then
        echo "[ollvm] arm64e slice -> Apple clang: $(basename "$SRC") (ld64 yeu cau arm64e ABI moi; brew llvm@19 chi co arm64e.old — run #10)" >&2
        apple_cc "$@"
    else
        case "$SRC" in
            */Cofi/XPF/*|*/XPF/*)
                # XPF + ChOma: Apple clang — GIU NGUYEN nhu build cu
                apple_cc "$@"
                ;;
            *)
                # Nguon app: brew clang + Hikari
                brew_cc "$@"
                ;;
        esac
    fi
else
    # Link / tien xu ly / khac: Apple clang
    apple_cc "$@"
fi
