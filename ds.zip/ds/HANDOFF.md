# HANDOFF.md — Project DSWUnity (iOS External ESP Overlay)

This document is a comprehensive handoff guide for **Claude** (or any subsequent AI assistant) to take over and continue working on the **DSWUnity** project without requiring the user to re-explain project history, architecture, or status.

---

## 📌 1. Project Overview & Identity

- **Project Name:** DSWUnity (formerly Cofi / External-FF)
- **App Display Name:** `DSWUnity`
- **Bundle Identifier:** `Ds.Dswunity.Esp`
- **Target OS:** iOS / iPadOS 17.0 – 18.7.1 & 26.0 – 26.0.1 (arm64 / arm64e, A12–A17, M1–M3, A16 T8110 verified)
- **Primary Game Target:** Free Fire (Current Offsets: Version `1.132.1`)
- **GitHub Repository:** `tuananh404/luachuasv` (Branch: `main`)
- **Support / Contact Link:** `https://t.me/duydzne` (`@duydzne`)

---

## 📁 2. Workspace File System Layout

- **`/storage/emulated/0/DarkSwordFreeFire/freefiresv/`**: The main Git repository root containing all source code, Xcode project (`Cofi.xcodeproj`), and GitHub Actions workflow (`.github/workflows/build.yml`).
- **`/storage/emulated/0/DarkSwordFreeFire/Cofi-1.0.ipa`**: The latest successfully compiled and packaged unsigned IPA artifact (7.0 MB).
- **`/storage/emulated/0/DarkSwordFreeFire/DarkSwordFreeFire.zip`** & **`DSWUnity_Project.zip`**: Full archive containing source code, offsets, artifacts, and dumper files.
- **`/storage/emulated/0/DarkSwordFreeFire/ffdump132/`**: Official IL2CPP dump files for Free Fire v1.132.1 (`dump.cs`, `script.json`, `il2cpp.h`).
- **`/storage/emulated/0/DarkSwordFreeFire/new.jpg`**: Source image used for generating the app icon set.
- **`/storage/emulated/0/debugdsw/`**: Device test execution logs (`no.log` for iOS 17.5.1 A13, `ok.log` for iOS 18.0 / 26.0 A16).

---

## 🏗️ 3. Architecture & Execution Pipeline

DSWUnity is an external iOS overlay running completely outside the game process without repackaging or injecting dylibs into the game.

### Execution Chain:
1. **Kernel Exploit (`kexploit/kexploit_opa334.m`):** Acquires Kernel R/W via a TCP-socket race & `icmp6filter` memory overwrite.
2. **XPF Kernel Patchfinder (`kpf/patchfinder.m`):** Uses `/Cofi/XPF/output/ios/libxpf.dylib` to dynamically find kernel symbols (`allproc`, `ptov_table`, `gPhysBase`, etc.) in <0.2s.
3. **Sandbox Escape (`utils/sandbox.m`):** Patches sandbox extensions to grant cross-process memory access.
4. **RemoteCall / SpringBoard Channel (`TaskRop/RemoteCall.m`):** Injects EXC_GUARD thread hijack into `SpringBoard` (PID ~3738) to host a passthrough overlay window (`windowLevel = 10000001`).
5. **Memory Provider (`DarkSwordMemoryProvider.m` + `Core/PhantomMemory.m`):** Reads game process memory (`UnityFramework` base address, roster, camera data) via kernel read.
6. **Camera Projection Engine (`Core/UnityMath.mm`):** Dynamically scans native C++ Camera objects (`0x480` bytes scan window) to extract perspective projection matrix and perform WorldToScreen projection.
7. **ESP Drawing Engine (`drawing_view/esp.mm` + `ESP/ESPDrawOverlay.m`):** Renders 2D Bounding Boxes, Tracelines, Health Bars, Nicknames, Distance Meters, and Enemy Counter via `CAShapeLayer`.
8. **Aim Engine (`Core/AimAssistEngine.mm`):** Runs on the same worker tick as the ESP builder, reuses the calibrated projection to pick the best target inside the aim FOV, and steers the local player's aim rotation via kernel writes (`RemoteWriteDomain::Aim`). The overlay-facing FOV circle + lock line travel inside the `ESPDrawPacket`.

---

## 🛠️ 4. Summary of Recent Fixes & Modifications Applied

000. **UIKey Tích Hợp Vào Lớp Màn Chính + Đổi Tên Toàn Bộ LDVQuang/Quang → khanhduy/Duy — 2026-09-25:**
   - **TÍCH HỢP "MỘT KHỐI" (không còn trôi nổi):** gate KHÔNG còn là `UIWindow` nổi ở `windowLevel = statusBar+100` phủ TRÊN app. Giờ `gate_attach` tìm **cửa sổ chính (storyboard)** trong UIWindowScene và đặt gate VC làm `rootViewController` của CHÍNH cửa sổ đó → UIKey LÀ màn hình app. Cửa sổ đen tạm chỉ tồn tại vài trăm ms lúc launch (trước khi cửa sổ storyboard xuất hiện) rồi tự gỡ sau khi chuyển giao — vẫn đảm bảo màn đen phủ ngay từ đầu. Mở khóa (`gate_dismiss`) → **trả root gốc lại bằng cross-dissolve** — một lớp duy nhất, không fade lộ UI phía dưới.
   - **Watchdog cập nhật theo:** `kdy_alive_tick` giờ xác định gate "sống" = `rootViewController của cửa sổ chính vẫn là gate VC` — ai swap root/giấu màn để bypass → alive ngừng cập nhật → watchdog kill (0x53). Chế độ cửa sổ tạm vẫn được hỗ trợ (dự phòng khi storyboard không load).
   - **UI tối giản (flat, không card nổi):** nhãn **KÍCH HOẠT** (cyan nhỏ) + tên app **FreeFire Ds** (trắng bold 36) → ô **License Key** (bo góc 12, nền trắng 8%) → nút **LOGIN** (cyan) → dòng status đỏ (lỗi) → link **Liên hệ hỗ trợ** mờ sát đáy. Chạm nền → ẩn bàn phím (`gate_bg_tapped`). Nhóm input+nút trong suốt để giữ hiệu ứng rung khi sai key. Bố cục dùng autoresizing — an toàn mọi kích thước màn.
   - **ĐỔI TÊN TOÀN BỘ (de-brand Quang):** `Cofi/api/LDVQuang.mm` → **`Cofi/api/khanhduy.mm`** (class `LDVQuang` → `khanhduy`, `objc_getClass("khanhduy")`); `Cofi/QuangServer.mm` → **`Cofi/DuyServer.mm`**; prefix method/biến `ldq_` → `kdy_` (`g_ldq_*` → `g_kdy_*`); macro `LDQ_*` → `KDY_*`; hàm C `qs_*` → `dy_*` (`qs_piece_valid` → `dy_piece_valid`...); marker chết NSUserDefaults `qs9` → `dy9`. Tag token `q1..q5` + mirror `vk4` + `saved_license_key` giữ nguyên (không ảnh hưởng persisted data).
   - **IMP baseline mở rộng 13 → 15 method:** thêm `gate_attach` + `kdy_alive_tick` vào danh sách chống swizzle.

00. **Anti-Crack Hardening — Verify Key Siêu Mạnh + UIKey Chống Patch/Bypass — 2026-09-25:**
   - **6 LỚP KIỂM TRA SERVER + LOCAL:**
     - **Lớp 1** — `init` khi mở app (token package + maintenance + contact) — lưu có từ trước.
     - **Lớp 2** — `check` key (server là nguồn chuẩn tuyệt đối).
     - **Lớp 3 (MỚI)** — `kdy_entry_final` (recheck trước khi gỡ màn chắn): sau khi check xong và hiện màn ✓ thành công, app **check server lần nữa** rồi mới gỡ màn đen. Patch 1 điểm check duy nhất là KHÔNG đủ. Lỗi mạng lúc này → khoan dung (timeout 6s, heartbeat sẽ xử lý).
     - **Lớp 4 (MỚI)** — Heartbeat ngẫu nhiên 240–420s + beat ngay khi app trở lại foreground (debounce 90s, beat đầu 30–60s sau khi vào app). Server thu hồi/hết hạn key giữa phiên → kill ngay. **Offline liên tiếp ≥24 lượt (~2h) → coi là giả mạo → kill.**
     - **Lớp 5 (MỚI)** — Watchdog canary (pthread C thuần, tick 2–5s jitter) chạy MÃI MÃI sau khi vào app: [1] dò DYLD_INSERT_LIBRARIES / frida / gadget / cycript / cynject qua env + danh sách image dyld; [2] CHƯA verify mà màn chắn biến mất → kill (handshake qua main queue, grace 20s, chống false-positive khi app background; từ bản tích hợp root thì check = rootVC của cửa sổ chính vẫn là gate VC); [3] token đa kho phải nguyên vẹn; [4] IMP baseline 15 method trọng yếu (chống swizzle/hook — MSHookMessageEx/Frida hooks đều đổi IMP → phát hiện). Patch tách bit PAC arm64e để so sánh ổn định.
     - **Lớp 6 (MỚI)** — 2 điểm khởi động độc lập: `+load` của khanhduy **+** `__attribute__((constructor))` ẩn trong DuyServer.mm (2.5s sau launch gọi `kdy_reassert` → nếu +load bị NOP thì tự khởi động watchdog + hiện lại màn chắn). NOP 1 điểm không đủ.
   - **TOKEN ĐA KHO (không còn 1 BOOL đơn lẻ để patch):** `q1=FNV(key)^K1, q2=FNV(expiry)^K2, q3=days^K3, q4=nonce^K4, q5=xor(q1..q4)^MAGIC` — q1..q5 sống trong **kho C thuần của DuyServer.mm** (không phải ObjC object — công cụ phân tích class không thấy), q1 mirror thêm vào **static khanhduy** + **hash lại từ saved key mỗi lần check**, q4 mirror vào **NSUserDefaults "vk4"**. `dy_piece_valid` yêu cầu XOR cả 5 mảnh == MAGIC. Sửa/xóa/zero 1 mảnh bất kỳ → vỡ → kill.
   - **TAMPER RESPONSE:** xóa saved key + mirror, ghi marker `dy9` (lần chạy sau chết ngay ở +load), phá token, thoát **4 đường khác nhau** (exit / abort / dlsym-exit / crash cố ý) với **trễ ngẫu nhiên 0.15–1.35s** (khó truy vết điểm check nào đã bắn). `forceExitApp` cũng có exit dự phòng sau 8s kể cả khi không bấm Thoát.
   - **gate_dismiss có guard:** chỉ gỡ màn chắn khi `verified + token_ok` — gọi gate_dismiss bằng hook mà không verify → tự hiện lại màn nhập key.
   - **Code nằm trong 2 file riêng biệt** (api/khanhduy.mm + DuyServer.mm → 2 vùng binary khác nhau) — phải patch cả 2 file. Toàn bộ giữ phong cách obfuscation: computed goto (`Q_ERR..Q_END`, watchdog states), `sel_registerName` + cast `objc_msgSend`, chuỗi char array.
   - **Ghi chú dev:** Build **Debug** (`DEBUG=1`) và **VPhone Debug** (`COFI_VPHONE_DEBUG=1`) tự bỏ kiểm tra debugger (debug bằng Xcode được). Build **Release = đầy đủ**. Muốn tắt hẳn: sửa `KDY_ANTI_DEBUG` thành 0 trong DuyServer.mm.
   - **Rate limit an toàn:** mỗi launch ~3 request (init + check + recheck), heartbeat ~9–13 request/giờ — nằm sâu dưới giới hạn server 120 req/60s/IP.

0. **Full-Screen Black Key Gate (UI nhập key — bản tích hợp root) — 2026-09-25:**
   - `Cofi/api/khanhduy.mm` hiển thị **màn đen phủ toàn app** ngay khi launch (0.05s sau `+load`, retry 0.15s tới khi UIWindowScene sẵn sàng). Từ bản 000: màn key **tích hợp vào cửa sổ chính của app** (xem mục 000) — không còn lớp cửa sổ nổi tạm tồn tại lâu.
   - Các trạng thái của gate: **loading** (spinner cyan + "Đang kết nối server..." / "Đang kiểm tra key..."), **input** (KÍCH HOẠT + FreeFire Ds, ô License Key + nút LOGIN + status đỏ + link Liên hệ hỗ trợ mờ ở đáy, keyboard tự bật, chạm nền ẩn bàn phím), **success** (dấu ✓ xanh mint + "Kích hoạt thành công" + hạn dùng → tự dismiss sau 1.3s, trả root gốc cross-dissolve), **maintenance** (⚠ vàng + LIÊN HỆ + THOÁT).
   - Flow: key sai → hiện message đỏ + rung nhóm input; key đúng (server `status=true`) → lưu `saved_license_key` → success → mở khóa vào app chính. Auto-login bằng key đã lưu cũng chạy ẩn sau gate.
   - Thay thế hoàn toàn UIAlertController cũ cho key/maintenance/success (các alert lỗi kết nối vẫn là UIAlertController nhưng present từ `gate_presenter` — hiện TRÊN màn đen). LaunchScreen.storyboard đổi nền đen để liền mạch lúc launch.
   - Không đổi protocol API: `?action=init&token=` và `?action=check&token=&key=&uuid=`.

0a. **Matched với Server TemplateAPIKEY (khanhduyz.fun) — 2026-09-25 (CẬP NHẬT):**
   - `Cofi/HeaderAPI.h`: `kBaseAPIURL` đã trỏ sẵn tới **`https://khanhduyz.fun/api/connect.php`** (server zip deploy ở thư mục gốc domain → path API là `api/connect.php`, không có rewrite). ⬇️ Chỉ cần thay `kPackageToken` = Project Token (32 hex) lấy từ admin → Packages.
   - Server là **nguồn chuẩn tuyệt đối**: `connect.php` tự chặn key invalid/expired/revoked/suspended/max-devices TRƯỚC khi trả `status=true`; client đã **bỏ self-check expiry bằng NSDateFormatter** (lệch múi giờ thiết bị↔server sẽ chặn nhầm key hợp lệ) — giờ chỉ tin `status` + hiển thị `days_left`/`expiry` server trả.
   - Thêm `localizedServerMessage:` — dịch 13 thông điệp chuẩn của server (`Key expired`, `Max devices reached`, `Invalid Package Token`, `Too many requests`, `System Maintenance`...) sang tiếng Việt trên UIKey; thông điệp lạ thì giữ nguyên.
   - HTTPS endpoint → ATS an toàn (giữ `NSAllowsArbitraryLoads` làm fallback http).
   - Rate limit server: **120 request/60s/IP** cho `connect.php` — client chỉ gọi 1–2 request/lần launch (init + auto-check), hoàn toàn an toàn. **KHÔNG thêm polling.**
   - API protocol (khớp 100% server `api/connect.php`): `?action=init&token=<kPackageToken>` → `{status, contact, maintenance}`; `?action=check&token=&key=&uuid=<IDFV>` → `{status, message, expiry, days_left, contact}`; mọi lỗi → `{status:false, message, force_exit?, contact?}`. Key hợp lệ lưu `NSUserDefaults` `saved_license_key`.
   - Lưu ý server: key `dynamic` tự kích hoạt lần đầu check (expire = now + duration); thiết bị mới vượt `max_devices` → `Max devices reached`. Admin: `https://khanhduyz.fun/auth/login.php` (tài khoản mặc định trong `config.php` — đổi ngay).
   - Server-side PHP (TemplateAPIKEY) là repo riêng — deploy tại `https://khanhduyz.fun/` (đã hoạt động, không cần chỉnh gì thêm phía client).

0b. **Aim Engine (VIP Standard) Re-Added — 2026-09-20:**
   - New `Cofi/Core/AimAssistEngine.h/.mm` — full VIP-standard aimbot port:
     FOV-window target scan (3× drawn radius), lock persistence (2 lost
     frames), PhysicalCCT velocity + weapon-profile bullet prediction,
     Slerp quaternion steering, AuxAimResetTime zeroing, ±89° pitch limits,
     single-shot snap (AWM/M590), and auto-fire via `TrySetDataUInt16`.
   - Write transport enabled: `DarkSwordMemoryProvider.writeMemory:from:size:`
     maps game pages through `vm_map_remote_page` (READ|WRITE) into a dedicated
     24-slot writable cache; `phantom_write_bytes` + `MemoryUtils._write` gate
     every write behind `RemoteWriteDomain::Aim` (armed only while Aimbot is
     on, fails closed otherwise).
   - Aim offsets added to `GameOffsets.h` (dump-verified): AuxAimResetTime
     0xE38, MinAngleX 0xE3C, MaxAngleX 0xE40, PhysicalCCT 0x268 / Velocity
     0x17C, Inventory chain 0x740→0xA0→0x768 with weapon fields 0x1F4/0x1F8/
     0x208/0x27C.
   - `ESPDrawPacket` extended (magic bumped to `0x45535033` "ESP3") with
     `showFov`, `fovRadius`, `aimHasTarget`, `aimTargetPoint`; the SpringBoard
     overlay renders the VIP-mint FOV circle (`gFovLayer`) and aim lock line
     (`gAimLineLayer`) purely from the packet.
   - Settings UI: new "Aim Engine (VIP)" section (Aimbot, FOV circle, lock
     line, FOV radius slider 5–500, Aim speed slider 100–2000, Aim position,
     Trigger mode, ignore bot/knocked, visibility check) plus a reusable
     SliderRow control. In-game ESP menu gained the same `renew.aim*` keys.
   - Deliberate deltas vs the reference build: prediction uses the LOCAL
     player's weapon profile; AimSpeed scales the Slerp factor (1000 ==
     reference constants 0.97/0.92/0.85).

1. **GitHub Actions CI/CD Fixes:**
   - Installed `ldid` via `brew install ldid` in workflow.
   - Added manual copy step `cp Cofi/XPF/output/ios/libxpf.dylib $APP_PATH/libxpf.dylib` to prevent missing dylib launch crash.
   - Preserved git symlink `Cofi/XPF/external/ChOma/include/choma` with mode `120000`.

2. **Game Offsets Updated to v1.132.1:**
   - `Cofi/Core/GameOffsets.h` updated with values verified against `ffdump132`:
     - `GameFacadeTypeInfo` = `0xBB46A50ULL`
     - `GameVarDefTypeInfo` = `0xBB46AF8ULL`
     - `PlayerHeadNode` = `0x6A0ULL`
     - `PlayerAimRotation` = `0x614ULL`

3. **Complete UI Redesign (DSWUnity):**
   - Redesigned app theme to Cyan (`#06B6D4`) & Deep Slate (`#0F172A`) gaming aesthetic in `UITheme.h` and `SettingsViewController.m`.
   - Removed all unneeded non-ESP functions (Aim, FOV, No Recoil, Ghost, Fast Fire, Fast Reload, Fast Medikit, Fast Run).
   - Focused strictly on pure ESP features: Tracelines, 2D Box, Health Bar, Nickname, Distance, Player Counter, Refresh Rate (1–30 Hz).
   - Set Telegram Support Contact to: `https://t.me/duydzne` (`@duydzne`).

4. **App Icon Set Update:**
   - Converted `new.jpg` into all required iOS/iPadOS/macOS icon sizes in `Cofi/Assets.xcassets/AppIcon.appiconset/`.

5. **Anti-Screen Capture Removal:**
   - Completely removed `setDisableUpdateMask:0x10` and `kSettingsHideScreenCapture` from codebase because `setDisableUpdateMask` caused `CALayer` rendering to become hidden on iOS 26.

6. **iOS 26 Camera Matrix Projection Optimization (`Core/UnityMath.mm`):**
   - Expanded camera native C++ memory scan window `kCameraScanSize` from `0x240` to `0x480` bytes to cover Unity Engine 2023/2024 matrix offsets on iOS 26.
   - Lowered calibration score threshold `kLockedScoreThreshold` from `18.0f` to `4.0f` for instant matrix locking.
   - Added instant fallback projection so ESP draws from frame 1 without delay.

7. **Enemy Counter Indicator (`ESP/ESPDrawOverlay.m`):**
   - Updated `esp_draw_overlay_apply_counter`:
     - When ESP is active (`gDrawState == ESPDrawOverlayStateRunning`), the top-center counter label **always displays `--`** as an active status indicator.
     - When in-game with valid target data, it automatically displays the real numeric enemy count (e.g. `1`, `2`, `3`...).

---

## 💡 5. Crucial Instructions for the Next Assistant (Claude)

1. **Git Symlink Protection on Android Filesystem:**
   - Android filesystems convert symlinks to plain text files. Before running `git commit`, ALWAYS execute:
     ```bash
     printf '../src' | git hash-object -w --stdin
     git update-index --add --cacheinfo 120000,5cd551cf2693e4b4f65d7954ec621454c2b20326,Cofi/XPF/external/ChOma/include/choma
     ```
     Failure to do so will break the `ChOma` C++ header include during CI build!

2. **Automated CI/CD Workflow:**
   - Pushing to `main` branch automatically triggers `.github/workflows/build.yml` on GitHub Actions, which builds the IPA, uploads artifact zip, and creates a Release on GitHub (`tuananh404/luachuasv`).

3. **Key Header Files:**
   - `Cofi/Core/GameOffsets.h` — Offsets for Free Fire (ESP + Aim).
   - `Cofi/Core/UnityMath.mm` — Matrix calculation & WorldToScreen.
   - `Cofi/Core/AimAssistEngine.mm` — VIP-standard aim engine.
   - `Cofi/ESP/ESPDrawOverlay.m` — Overlay window rendering, FOV circle, counter label.
   - `Cofi/SettingsViewController.m` — DSWUnity main dashboard & settings.

---
*Generated & Handed off on 2026-09-19.*
