#ifndef HeaderAPI_h
#define HeaderAPI_h

#import <Foundation/Foundation.h>

// ======================================================================
//  CẤU HÌNH API — KHỚP VỚI SERVER (TemplateAPIKEY / khanhduyz.fun)
//
//  • kBaseAPIURL: domain + đường dẫn tới file API trên server.
//    Server zip được deploy ở thư mục gốc của https://khanhduyz.fun/
//    → endpoint thật là: https://khanhduyz.fun/api/connect.php
//    (KHÔNG cần sửa dòng này nữa — đã đúng theo server)
//
//  • kPackageToken: ⬇️ DÒNG DUY NHẤT CẦN THAY ĐỔI ⬇️
//    Đăng nhập trang admin của server (https://khanhduyz.fun/auth/login.php)
//    → menu Packages → copy "Project Token" (32 ký tự hex) → dán vào đây.
// ======================================================================

static NSString *const kBaseAPIURL = @"https://khanhduyz.fun/api/connect.php";

// ⬇️⬇️ CHỈ THAY ĐỔI DÒNG NÀY — dán Project Token của bạn ⬇️⬇️
static NSString *const kPackageToken = @"YOU_TOKEN_PACKAGE";

#endif
