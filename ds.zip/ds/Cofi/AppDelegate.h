//
//  AppDelegate.h
//  Cofi
//
//  Created by seo on 3/24/26.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

