#import <UIKit/UIKit.h>

static NSString * const UIThemePreferenceKey = @"renew.appearance";

static inline UIColor *UIAccent(void) {
    return [UIColor colorWithRed:0.025 green:0.714 blue:0.831 alpha:1.0]; // #06B6D4 Cyan
}

static inline UIColor *UISecondaryAccent(void) {
    return [UIColor colorWithRed:0.231 green:0.510 blue:0.965 alpha:1.0]; // #3B82F6 Blue
}

static inline UIColor *UISectionColor(NSInteger section) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
        if (traits.userInterfaceStyle == UIUserInterfaceStyleDark)
            return [UIColor colorWithRed:0.094 green:0.133 blue:0.204 alpha:1.0]; // #182234
        return [UIColor colorWithRed:0.96 green:0.98 blue:1.0 alpha:1.0];
    }];
}

static inline void UIApplyTheme(void) {
    NSInteger value = [NSUserDefaults.standardUserDefaults integerForKey:UIThemePreferenceKey];
    UIUserInterfaceStyle style = value == 1 ? UIUserInterfaceStyleLight
        : value == 2 ? UIUserInterfaceStyleDark : UIUserInterfaceStyleUnspecified;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if ([window.rootViewController isKindOfClass:UITabBarController.class])
                window.overrideUserInterfaceStyle = style;
        }
    }
}

static inline void UIConfigureTable(UITableViewController *controller) {
    controller.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    controller.tableView.backgroundColor = [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
        if (traits.userInterfaceStyle == UIUserInterfaceStyleDark)
            return [UIColor colorWithRed:0.059 green:0.090 blue:0.165 alpha:1.0]; // #0F172A
        return UIColor.systemGroupedBackgroundColor;
    }];
    controller.tableView.tintColor = UIAccent();
    controller.tableView.rowHeight = UITableViewAutomaticDimension;
    controller.tableView.estimatedRowHeight = 72;
    controller.tableView.separatorInset = UIEdgeInsetsMake(0, 20, 0, 0);
    controller.tableView.contentInset = UIEdgeInsetsMake(8, 0, 16, 0);
}
