//
//  DuyServer.mm — Shield Core (lõi khiên bảo vệ hệ thống key).
//
//  File này chứa các helper cấp thấp cho hệ thống xác minh NHIỀU LỚP:
//    • Token "đa kho" (multi-store token): 5 mảnh giá trị sống trong
//      kho C thuần (không phải ObjC — khó tìm bằng công cụ phân tích
//      class/dict thông thường). XOR của cả 5 mảnh phải ra đúng magic
//      constant thì token mới hợp lệ.
//    • FNV-1a hash + xorshift RNG (tạo jitter ngẫu nhiên cho heartbeat).
//    • Thoát đa đường (exit / abort / dlsym-exit / crash cố ý) — patch
//      chặn 1 đường thì 3 đường khác vẫn giết app.
//    • Dò môi trường lạ: biến DYLD_* (tiêm dylib), ảnh dyld chứa
//      frida/gadget/cycript/cynject, debugger gắn vào process.
//    • dy_imp_mask: tách bit PAC arm64e để so sánh IMP ổn định cho
//      cơ chế chống swizzle/hook method.
//
//  File KHÔNG chứa UI — khanhduy.mm điều khiển toàn bộ luồng chính.
//
//  Ghi chú build:
//    • Build Debug (DEBUG=1) và VPhone Debug (COFI_VPHONE_DEBUG=1) tự
//      bỏ kiểm tra debugger để dev vẫn chạy/debug bằng Xcode được.
//    • Build Release: đầy đủ mọi lớp phòng thủ.
//

#import "HeaderAPI.h"
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <stdlib.h>
#import <string.h>
#import <stdio.h>
#import <stdint.h>
#import <unistd.h>
#import <time.h>
#import <dlfcn.h>
#import <sys/sysctl.h>
#import <mach-o/dyld.h>

#ifndef KDY_ANTI_DEBUG
#define KDY_ANTI_DEBUG 1
#endif

/* Build dev (Xcode Debug / VPhone Debug) bỏ kiểm tra debugger */
#if defined(DEBUG) || defined(COFI_VPHONE_DEBUG)
#define KDY_DEBUG_SAFE 1
#endif

/* ------------------------- kho token C ------------------------- */

#define DY_SLOT_MAX 8

typedef struct {
    char     tag[8];
    uint64_t val;
    int      used;
} dy_slot;

static dy_slot dy_store[DY_SLOT_MAX];

static dy_slot *dy_slot_find(const char *tag, int create) {
    if (!tag) return NULL;
    for (int i = 0; i < DY_SLOT_MAX; i++) {
        if (dy_store[i].used && strncmp(dy_store[i].tag, tag, sizeof(dy_store[i].tag)) == 0) {
            return &dy_store[i];
        }
    }
    if (!create) return NULL;
    for (int i = 0; i < DY_SLOT_MAX; i++) {
        if (!dy_store[i].used) {
            dy_slot *s = &dy_store[i];
            memset(s, 0, sizeof(*s));
            strncpy(s->tag, tag, sizeof(s->tag) - 1);
            s->used = 1;
            return s;
        }
    }
    return NULL;
}

/* so sánh chuỗi con không phân biệt hoa/thường (ASCII) */
static int dy_cistr(const char *hay, const char *needle) {
    if (!hay || !needle) return 0;
    size_t nl = strlen(needle);
    if (nl == 0) return 1;
    for (const char *p = hay; *p; p++) {
        size_t i = 0;
        while (i < nl && p[i]) {
            char a = p[i];
            char b = needle[i];
            if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
            if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
            if (a != b) break;
            i++;
        }
        if (i == nl) return 1;
    }
    return 0;
}

extern "C" {

/* --------------------- hằng số khóa token --------------------- */

uint64_t dy_k1(void) { return 0xA5C31E7D9F2B4801ULL; }
uint64_t dy_k2(void) { return 0x3F7B2A9C4E1D6055ULL; }
uint64_t dy_k3(void) { return 0x7D1F3C9A5E28064BULL; }
uint64_t dy_k4(void) { return 0xC95A6E1B703F8D2AULL; }
uint64_t dy_magic(void) { return (0x6E2D9B41ULL << 32) | 0xF7A0C385ULL; }

/* --------------------------- hash --------------------------- */

uint64_t dy_fnv1a(const char *s, uint64_t seed) {
    uint64_t h = seed ^ 0xcbf29ce484222325ULL;
    if (!s) return h;
    while (*s) {
        h ^= (uint64_t)(unsigned char)*s++;
        h *= 0x100000001b3ULL;
    }
    return h;
}

/* ---------------------- xorshift RNG ---------------------- */

static uint64_t dy_state = 0;

uint64_t dy_rand64(void) {
    if (dy_state == 0) {
        dy_state = (uint64_t)time(NULL) ^ 0x9E3779B97F4A7C15ULL;
        dy_state ^= ((uint64_t)getpid()) << 32;
        dy_state |= 1ULL;
    }
    dy_state ^= dy_state << 13;
    dy_state ^= dy_state >> 7;
    dy_state ^= dy_state << 17;
    return dy_state;
}

/* tách bit PAC (arm64e) — IMP so sánh ổn định trong 1 process */
uintptr_t dy_imp_mask(uintptr_t p) {
    return (uintptr_t)(p & 0x0000FFFFFFFFFFFFULL);
}

/* ---------------------- kho token ---------------------- */

int dy_piece_set(const char *tag, uint64_t v) {
    dy_slot *s = dy_slot_find(tag, 1);
    if (!s) return -1;
    s->val = v;
    return 0;
}

uint64_t dy_piece_get(const char *tag, uint64_t defv) {
    dy_slot *s = dy_slot_find(tag, 0);
    return s ? s->val : defv;
}

/*
 * XOR của TOÀN BỘ mảnh (>= 5) phải đúng magic.
 * q5 được ghi = q1^q2^q3^q4^magic → xor cả 5 = magic.
 * Mọi mảnh bị zero/xóa/sửa 1 bit đều làm kết quả lệch.
 */
int dy_piece_valid(uint64_t magic) {
    uint64_t x = 0;
    int n = 0;
    for (int i = 0; i < DY_SLOT_MAX; i++) {
        if (dy_store[i].used) {
            x ^= dy_store[i].val;
            n++;
        }
    }
    if (n < 5) return 0;
    return x == magic;
}

void dy_piece_wipe(void) {
    memset(dy_store, 0, sizeof(dy_store));
}

/* ------------------- thoát đa đường ------------------- */

void dy_exit_paths(int path) {
    volatile int mode = path & 3;
    if (mode == 0) {
        exit(0);
    }
    if (mode == 1) {
        abort();
    }
    if (mode == 2) {
        void (*fn)(int) = (void (*)(int))dlsym(RTLD_DEFAULT, "exit");
        if (fn) fn(0);
        abort();
    }
    volatile int *z = (volatile int *)0;
    *z = mode;                 /* fault cố ý */
    _Exit(0);
}

/* ---------------- dò môi trường lạ ---------------- */

int dy_env_suspicious(void) {
    char e1[] = {'D','Y','L','D','_','I','N','S','E','R','T','_','L','I','B','R','A','R','I','E','S',0};
    char e2[] = {'D','Y','L','D','_','L','I','B','R','A','R','Y','_','P','A','T','H',0};
    char e3[] = {'F','R','I','D','A','_','S','E','R','V','E','R',0};
    int mask = 0;
    if (getenv(e1)) mask |= 1;
    if (getenv(e2)) mask |= 2;
    if (getenv(e3)) mask |= 4;
    return mask;
}

int dy_dyld_suspicious(void) {
    char f1[] = {'f','r','i','d','a',0};
    char f2[] = {'g','a','d','g','e','t',0};
    char f3[] = {'c','y','c','r','i','p','t',0};
    char f4[] = {'c','y','n','j','e','c','t',0};
    int mask = 0;
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; i++) {
        const char *nm = _dyld_get_image_name(i);
        if (!nm) continue;
        if (dy_cistr(nm, f1)) mask |= 1;
        else if (dy_cistr(nm, f2)) mask |= 2;
        else if (dy_cistr(nm, f3)) mask |= 4;
        else if (dy_cistr(nm, f4)) mask |= 8;
    }
    return mask;
}

int dy_debug_attached(void) {
#if defined(KDY_DEBUG_SAFE)
    return 0; /* build dev: bỏ qua để debug bằng Xcode được */
#elif KDY_ANTI_DEBUG
    {
        int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid() };
        struct kinfo_proc info;
        memset(&info, 0, sizeof(info));
        size_t sz = sizeof(info);
        if (sysctl(mib, 4, &info, &sz, NULL, 0) != 0) return 0;
        return (info.kp_proc.p_flag & P_TRACED) ? 1 : 0;
    }
#else
    return 0;
#endif
}

} /* extern "C" */

/* ------------------------------------------------------------------
 * ĐIỂM KHỞI ĐỘNG DỰ PHÒNG THỨ 2 (chống NOP +load của khanhduy).
 * Constructor ẩn chạy lúc load image — sau 2.5s gọi kdy_reassert:
 *   • +load bình thường → không làm gì (đã verify / gate đang hiện).
 *   • +load bị NOP → tự khởi động watchdog + hiện lại màn chắn.
 * Cracker phải patch CẢ HAI điểm khởi động mới bỏ qua được hệ thống.
 * ------------------------------------------------------------------ */
__attribute__((constructor))
static void dy_ctor(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        Class cls = objc_getClass("khanhduy");
        if (!cls) return;
        SEL sharedSel = sel_registerName("sharedInstance");
        id inst = ((id(*)(id, SEL))objc_msgSend)(cls, sharedSel);
        if (!inst) return;
        ((void(*)(id, SEL))objc_msgSend)(inst, sel_registerName("kdy_reassert"));
    });
}
