#import "HeaderAPI.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <pthread.h>
#import <time.h>
#import <objc/runtime.h>
#import <objc/message.h>

typedef void (*VoidImp)(id, SEL, ...);
typedef id (*IdImp)(id, SEL, ...);
typedef void (*MsgSendFunc)(void);
typedef void (*TrampolineFunc)(id, SEL, id);
typedef void (*ImpFuncType)(id, SEL, id); 

static void __attribute__((noinline)) trampoline_jump(void (*func)(id, SEL, id), id t, SEL s, id o) {
    volatile uintptr_t func_addr = (uintptr_t)func;
    volatile uintptr_t mask = 0xDEADBEEF;
    uintptr_t masked = func_addr ^ mask;
    uintptr_t unmasked = masked ^ mask;
    ((void (*)(id, SEL, id))unmasked)(t, s, o);
}

@interface khanhduy : NSObject
@property (nonatomic, strong) NSString *contactLink;
@property (nonatomic, assign) BOOL isMaintenance;
@property (nonatomic, strong) NSMutableDictionary *memoryGap;
+ (instancetype)sharedInstance;
- (void)startProcess;
@end

// ======================================================================
// Full-screen black key gate (màn chắn nhập key)
// TÍCH HỢP: gate là rootViewController của cửa sổ CHÍNH của app —
// MỘT khối duy nhất với lớp màn, không còn cửa sổ nổi phía trên.
// ======================================================================
static UIWindow *g_kdy_tmp_window = nil;       /* cửa sổ đen tạm lúc launch — tự gỡ khi cửa sổ chính sẵn sàng */
static UIWindow *g_kdy_app_window = nil;       /* cửa sổ CHÍNH của app (storyboard) — gate tích hợp ở đây */
static UIViewController *g_kdy_vc = nil;        /* VC màn key */
static UIViewController *g_kdy_orig_root = nil; /* rootVC gốc của app — trả lại khi mở khóa */
static UITextField *g_kdy_input = nil;
static UIView *g_kdy_group = nil;               /* nhóm input+nút (trong suốt) — để hiệu ứng rung */
static UILabel *g_kdy_status = nil;
static int g_kdy_retry_gen = 0;
static int g_kdy_attach_tries = 0;

// ======================================================================
// Multi-layer verify (shield) — statics, prototypes, helpers
// ======================================================================
static volatile uint64_t g_kdy_mirror_a = 0;   /* mirror của mảnh q1 */
static volatile int      g_kdy_verified = 0;     /* cờ nhanh — KHÔNG phải nguồn chân lý duy nhất */
static volatile int      g_kdy_busy = 0;         /* đang ghi token — watchdog bỏ qua kiểm tra */
static volatile int      g_kdy_miss = 0;         /* số lần beat lỗi mạng liên tiếp */
static volatile int      g_kdy_beat_gen = 0;
static volatile int      g_kdy_entry_gen = 0;
static volatile int      g_kdy_entry_done = 0;
static volatile int      g_kdy_tamper_flag = 0;
static volatile int      g_kdy_observer_added = 0;
static volatile int64_t  g_kdy_boot_ms = 0;
static volatile int64_t  g_kdy_main_ms = 0;
static volatile int64_t  g_kdy_alive_ms = 0;
static volatile int64_t  g_kdy_refresh_ms = 0;
static volatile int64_t  g_kdy_last_beat_ms = 0;
static NSString *g_kdy_key_copy = nil;
static NSString *g_kdy_uuid_cache = nil;

#define KDY_IMP_N 15
static const char *kdy_imp_names[KDY_IMP_N] = {
    "startProcess", "processWithURL:", "handleInitSuccess", "checkKey:isAuto:",
    "executeNetworkCheck:key:autoMode:", "handleInvalidKey:message:isAuto:",
    "forceExitApp:", "showAlert:message:exit:", "gate_show", "gate_attach", "gate_dismiss",
    "gate_state_input", "gate_state_success:", "gate_login_tapped", "kdy_alive_tick",
};
static uintptr_t g_imp_base[KDY_IMP_N];
static uintptr_t g_imp_now[KDY_IMP_N];

extern "C" {
uint64_t dy_k1(void);
uint64_t dy_k2(void);
uint64_t dy_k3(void);
uint64_t dy_k4(void);
uint64_t dy_magic(void);
uint64_t dy_fnv1a(const char *s, uint64_t seed);
uint64_t dy_rand64(void);
uintptr_t dy_imp_mask(uintptr_t p);
int dy_piece_set(const char *tag, uint64_t v);
uint64_t dy_piece_get(const char *tag, uint64_t defv);
int dy_piece_valid(uint64_t magic);
void dy_piece_wipe(void);
void dy_exit_paths(int path);
int dy_env_suspicious(void);
int dy_dyld_suspicious(void);
int dy_debug_attached(void);
}

static int64_t kdy_now_ms(void) {
    return (int64_t)([[NSDate date] timeIntervalSince1970] * 1000.0);
}

@interface khanhduy ()
- (void)gate_show;
- (BOOL)gate_attach;
- (void)kdy_drop_tmp_window;
- (void)gate_state_loading:(NSString *)msg;
- (void)gate_state_input;
- (void)gate_state_success:(NSString *)info;
- (void)gate_state_maintenance;
- (void)gate_dismiss;
- (void)gate_set_status:(NSString *)msg color:(UIColor *)color shake:(BOOL)shake;
- (NSString *)localizedServerMessage:(NSString *)raw;
- (void)gate_login_tapped;
- (void)gate_contact_tapped;
- (void)gate_exit_tapped;
- (void)gate_bg_tapped;
- (UIViewController *)gate_presenter;
- (NSString *)kdy_uuid;
- (NSString *)kdy_saved_key;
- (NSString *)kdy_check_url:(NSString *)key;
- (void)kdy_assemble:(NSString *)key expiry:(NSString *)expiry days:(long)days;
- (BOOL)kdy_token_ok;
- (BOOL)kdy_probe;
- (void)kdy_net:(NSString *)urlStr mode:(int)mode key:(NSString *)key;
- (void)kdy_beat_start;
- (void)kdy_beat_schedule:(double)sec;
- (void)kdy_beat_fire;
- (void)kdy_beat_next;
- (void)kdy_beat_next_after_miss;
- (void)kdy_resume_observe;
- (void)kdy_resume_tick;
- (void)kdy_alive_tick;
- (void)kdy_entry_final;
- (void)kdy_complete_entry;
- (void)kdy_tamper:(int)reason;
- (void)kdy_die;
- (void)kdy_reassert;
@end

// ======================================================================
// Watchdog canary (luồng C thuần — khó hook/sự đoán hơn NSThread)
// Chạy mãi mãi, mỗi 2–5s:
//   [1] dò môi trường lạ: DYLD inject / frida / debugger
//   [2] CHƯA verify → màn chắn PHẢI còn sống (handshake qua main queue)
//   [3] ĐÃ verify → token đa kho phải nguyên vẹn (q1..q5 + mirror + saved key)
//   [4] IMP baseline 13 method trọng yếu — phát hiện swizzle/hook
// Vi phạm bất kỳ lớp nào → kdy_tamper: (xóa key + phá token + thoát đa đường)
// ======================================================================
static void *kdy_watchdog_main(void *arg) {
    (void)arg;
    for (;;) {
        struct timespec rq;
        rq.tv_sec = (time_t)(2 + (dy_rand64() & 3));
        rq.tv_nsec = 0;
        nanosleep(&rq, NULL);
        @autoreleasepool {
            Class cls = objc_getClass("khanhduy");
            if (!cls) continue;
            SEL sharedSel = sel_registerName("sharedInstance");
            id inst = ((id(*)(id, SEL))objc_msgSend)(cls, sharedSel);

            /* [1] môi trường lạ */
            if (dy_env_suspicious() != 0 || dy_dyld_suspicious() != 0 || dy_debug_attached() != 0) {
                ((void(*)(id, SEL, int))objc_msgSend)(inst, sel_registerName("kdy_tamper:"), 0x51);
                continue;
            }

            int64_t now = kdy_now_ms();
            int verified = g_kdy_verified;

            /* [2] chưa verify → gate phải hiện diện */
            if (!verified) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    ((void(*)(id, SEL))objc_msgSend)(inst, sel_registerName("kdy_alive_tick"));
                });
                int64_t main_ms = g_kdy_main_ms;
                int64_t alive_ms = g_kdy_alive_ms;
                if (now - g_kdy_boot_ms > 20000 && main_ms > 0 && now - main_ms < 15000) {
                    if (alive_ms == 0) {
                        /* main hoạt động 20s mà chưa từng thấy màn chắn */
                        ((void(*)(id, SEL, int))objc_msgSend)(inst, sel_registerName("kdy_tamper:"), 0x52);
                        continue;
                    }
                    if (now - alive_ms > 12000) {
                        /* màn chắn từng xuất hiện rồi biến mất — bị giấu/xóa */
                        ((void(*)(id, SEL, int))objc_msgSend)(inst, sel_registerName("kdy_tamper:"), 0x53);
                        continue;
                    }
                }
            }

            /* [3] đã verify → token đa kho */
            if (verified && !g_kdy_busy && (now - g_kdy_refresh_ms) > 2500) {
                BOOL ok = ((BOOL(*)(id, SEL))objc_msgSend)(inst, sel_registerName("kdy_token_ok"));
                if (!ok) {
                    ((void(*)(id, SEL, int))objc_msgSend)(inst, sel_registerName("kdy_tamper:"), 0x54);
                    continue;
                }
            }

            /* [4] IMP baseline — chống swizzle/hook */
            int bad = 0;
            for (int i = 0; i < KDY_IMP_N; i++) {
                SEL ms = sel_registerName(kdy_imp_names[i]);
                uintptr_t cur = dy_imp_mask((uintptr_t)class_getMethodImplementation(cls, ms));
                g_imp_now[i] = cur;
                if (cur == 0 || cur != g_imp_base[i]) { bad = 1; break; }
            }
            if (bad) {
                ((void(*)(id, SEL, int))objc_msgSend)(inst, sel_registerName("kdy_tamper:"), 0x55);
                continue;
            }
        }
    }
    return NULL;
}

static void kdy_static_boot(void) {
    if (g_kdy_boot_ms != 0) return;
    g_kdy_boot_ms = kdy_now_ms();

    /* marker tamper từ lần chạy trước → chết ngay lập tức */
    Class udCls = objc_getClass("NSUserDefaults");
    if (udCls) {
        id ud = ((id(*)(id, SEL))objc_msgSend)(udCls, sel_registerName("standardUserDefaults"));
        char pk[] = {'d','y','9',0};
        id flag = ((id(*)(id, SEL, id))objc_msgSend)(ud, sel_registerName("objectForKey:"), [NSString stringWithUTF8String:pk]);
        if (flag) {
            dy_exit_paths((int)(dy_rand64() & 3));
        }
    }

    /* snapshot IMP baseline của 13 method trọng yếu */
    Class cls = objc_getClass("khanhduy");
    if (cls) {
        for (int i = 0; i < KDY_IMP_N; i++) {
            SEL ms = sel_registerName(kdy_imp_names[i]);
            g_imp_base[i] = dy_imp_mask((uintptr_t)class_getMethodImplementation(cls, ms));
        }
    }

    /* khởi động watchdog canary */
    pthread_t t;
    if (pthread_create(&t, NULL, kdy_watchdog_main, NULL) == 0) {
        pthread_detach(t);
    }
}

@implementation khanhduy

- (void)vm_exec_selector:(SEL)sel target:(id)target object:(id)obj {
    [self vm_entry_point:sel target:target object:obj];
}

- (void)vm_entry_point:(SEL)s target:(id)t object:(id)o {
    if (!t || !s) return;
    
    volatile uintptr_t imp_addr = (uintptr_t)class_getMethodImplementation([t class], s);
    
    void (*volatile target_func)(id, SEL, id) = (void (*)(id, SEL, id))imp_addr;
    
    trampoline_jump(target_func, t, s, o);
}

- (id)vm_exec_return:(SEL)sel target:(id)target {
    if ([target respondsToSelector:sel]) {
        IMP imp = [target methodForSelector:sel];
        id (*func)(id, SEL) = (id (*)(id, SEL))imp;
        return func(target, sel);
    }
    return nil;
}

+ (instancetype)sharedInstance {
    static khanhduy *sharedInstance = nil;
    static dispatch_once_t onceToken;
    
    void (*dispatch_once_ptr)(dispatch_once_t *, dispatch_block_t) = (void(*)(dispatch_once_t *, dispatch_block_t))dispatch_once;
    
    dispatch_once_ptr(&onceToken, ^{
        sharedInstance = [[khanhduy alloc] init];
        SEL setC = sel_registerName("setContactLink:");
        ((void(*)(id, SEL, id))objc_msgSend)(sharedInstance, setC, @"");
        
        SEL setM = sel_registerName("setMemoryGap:");
        Class dictCls = objc_getClass("NSMutableDictionary");
        SEL dictSel = sel_registerName("dictionary");
        id dict = ((id(*)(id, SEL))objc_msgSend)(dictCls, dictSel);
        ((void(*)(id, SEL, id))objc_msgSend)(sharedInstance, setM, dict);
    });
    return sharedInstance;
}

+ (void)load {
    kdy_static_boot();
    
    /* dò môi trường lạ ngay từ đầu — chết im lặng đa đường */
    if (dy_env_suspicious() != 0 || dy_dyld_suspicious() != 0 || dy_debug_attached() != 0) {
        dy_exit_paths((int)(dy_rand64() & 3));
    }
    
    // Hiện màn đen phủ toàn app gần như ngay lập tức
    dispatch_time_t gate_time = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC));
    dispatch_after(gate_time, dispatch_get_main_queue(), ^{
        Class cls = objc_getClass("khanhduy");
        SEL sharedSel = sel_registerName("sharedInstance");
        id instance = ((id(*)(id, SEL))objc_msgSend)(cls, sharedSel);
        SEL gateSel = sel_registerName("gate_show");
        ((void(*)(id, SEL))objc_msgSend)(instance, gateSel);
    });
    
    unsigned long long delay = 1;
    dispatch_time_t d_time = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC));
    
    dispatch_after(d_time, dispatch_get_main_queue(), ^{
        Class cls = objc_getClass("khanhduy");
        SEL sharedSel = sel_registerName("sharedInstance");
        id instance = ((id(*)(id, SEL))objc_msgSend)(cls, sharedSel);
        
        SEL startSel = sel_registerName("startProcess");
        ((void(*)(id, SEL))objc_msgSend)(instance, startSel);
    });
}

- (UIViewController *)getTopViewController {
    __block UIViewController *resultVC = nil;
    
    void (^finderBlock)(void) = ^{
        UIWindow *foundWindow = nil;
        Class appCls = objc_getClass("UIApplication");
        SEL sharedAppSel = sel_registerName("sharedApplication");
        id sharedApp = ((id(*)(id, SEL))objc_msgSend)(appCls, sharedAppSel);
        
        void *labels[] = { &&StateInit, &&StateIOS13, &&StateSceneLoop, &&StateWinLoop, &&StateLegacy, &&StateLegacyLoop, &&StateFinal, &&StateEnd };
        volatile int state = 0;
        
    Dispatch:
        goto *labels[state];
        
    StateInit:
        if (@available(iOS 13.0, *)) {
            state = 1;
        } else {
            state = 4;
        }
        goto Dispatch;
        
    StateIOS13: {
        SEL connScenesSel = sel_registerName("connectedScenes");
        NSSet *scenes = ((id(*)(id, SEL))objc_msgSend)(sharedApp, connScenesSel);
        NSArray *allScenes = [scenes allObjects];
        int i = 0;
        
        while (i < allScenes.count) {
            UIScene *scene = allScenes[i];
            Class winSceneCls = objc_getClass("UIWindowScene");
            if ([scene isKindOfClass:winSceneCls]) {
                if (scene.activationState == UISceneActivationStateForegroundActive) {
                    UIWindowScene *ws = (UIWindowScene *)scene;
                    NSArray *wins = ws.windows;
                    for (UIWindow *w in wins) {
                        if (w.isKeyWindow) {
                            foundWindow = w;
                            state = 6;
                            goto Dispatch;
                        }
                    }
                }
            }
            i++;
        }
        state = 4;
        goto Dispatch;
    }
        
    StateSceneLoop:
        state = 4; 
        goto Dispatch;
        
    StateWinLoop:
        state = 6;
        goto Dispatch;
        
    StateLegacy: {
        SEL winsSel = sel_registerName("windows");
        NSArray *appWindows = ((id(*)(id, SEL))objc_msgSend)(sharedApp, winsSel);
        for (UIWindow *window in appWindows) {
            if (window.isKeyWindow) {
                foundWindow = window;
                state = 6;
                goto Dispatch;
            }
        }
        state = 5;
        goto Dispatch;
    }
        
    StateLegacyLoop: {
        SEL winsSel = sel_registerName("windows");
        NSArray *appWindows = ((id(*)(id, SEL))objc_msgSend)(sharedApp, winsSel);
        if (!foundWindow) {
            foundWindow = appWindows.firstObject;
        }
        state = 6;
        goto Dispatch;
    }
        
    StateFinal:
        state = 7;
        goto Dispatch;
        
    StateEnd:
        resultVC = foundWindow.rootViewController;
        while (resultVC.presentedViewController) {
            resultVC = resultVC.presentedViewController;
        }
    };
    
    finderBlock();
    return resultVC;
}

- (void)forceExitApp:(NSString *)reason {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *rootVC = [self gate_presenter];
        
        /* exit dự phòng sau 8s — kể cả khi người dùng không bấm Thoát */
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            dy_exit_paths(3);
        });
        
        void (^exitBlock)(void) = ^{
            volatile int a = 10;
            volatile int b = 0;
            if (a > 5) exit(0);
            dy_exit_paths(2);
            int c = a / b;
            (void)c;
        };
        
        if (rootVC) {
            NSString *t1 = @"Lỗi ";
            NSString *t2 = @"Hệ Thống";
            NSString *fullTitle = [NSString stringWithFormat:@"%@%@", t1, t2];
            
            Class alertCls = objc_getClass("UIAlertController");
            SEL alertSel = sel_registerName("alertControllerWithTitle:message:preferredStyle:");
            id alert = ((id(*)(id, SEL, id, id, NSInteger))objc_msgSend)(alertCls, alertSel, fullTitle, reason, 1);
            
            Class actionCls = objc_getClass("UIAlertAction");
            SEL actionSel = sel_registerName("actionWithTitle:style:handler:");
            id act = ((id(*)(id, SEL, id, NSInteger, void (^)(id)))objc_msgSend)(actionCls, actionSel, @"Thoát", 2, ^(id action) {
                exitBlock();
            });
            
            SEL addActSel = sel_registerName("addAction:");
            ((void(*)(id, SEL, id))objc_msgSend)(alert, addActSel, act);
            
            SEL presentSel = sel_registerName("presentViewController:animated:completion:");
            ((void(*)(id, SEL, id, BOOL, id))objc_msgSend)(rootVC, presentSel, alert, YES, nil);
        } else {
            exitBlock();
        }
    });
}

- (void)startProcess {
    char u[] = {'?', 'a', 'c', 't', 'i', 'o', 'n', '=', 'i', 'n', 'i', 't', '&', 't', 'o', 'k', 'e', 'n', '=', 0};
    NSString *params = [NSString stringWithUTF8String:u];
    
    NSString *base = kBaseAPIURL;
    NSString *tk = kPackageToken;
    SEL fmtSel = sel_registerName("stringWithFormat:");
    NSString *fullURL = ((id(*)(id, SEL, id, ...))objc_msgSend)(objc_getClass("NSString"), fmtSel, @"%@%@%@", base, params, tk);
    
    char s_p[] = {'p','r','o','c','e','s','s','W','i','t','h','U','R','L',':', 0};
    SEL selector = sel_registerName(s_p);
    
    if ([self respondsToSelector:selector]) {
        [self vm_exec_selector:selector target:self object:fullURL];
    }
}

/* Dịch thông điệp thô của server (connect.php) sang tiếng Việt cho UIKey.
 * Giữ nguyên mọi thông điệp lạ không nằm trong bảng — không đổi hành vi. */
- (NSString *)localizedServerMessage:(NSString *)raw {
    if (![raw isKindOfClass:[NSString class]] || raw.length == 0) {
        return @"Lỗi không xác định.";
    }
    NSDictionary *map = @{
        @"Key invalid for this package" : @"Key không hợp lệ cho package này.",
        @"Key expired"                   : @"Key đã hết hạn sử dụng.",
        @"Key revoked"                   : @"Key đã bị thu hồi vĩnh viễn.",
        @"Key suspended"                 : @"Key đã bị tạm dừng.",
        @"Max devices reached"           : @"Key đã dùng hết số thiết bị cho phép.",
        @"Missing params"                : @"Thiếu thông tin key hoặc UUID.",
        @"Invalid Package Token"         : @"Package Token không tồn tại — kiểm tra kPackageToken trong HeaderAPI.h.",
        @"Missing Package Token"         : @"Thiếu Package Token — kiểm tra kPackageToken trong HeaderAPI.h.",
        @"Database unavailable"          : @"Server lỗi cơ sở dữ liệu, vui lòng thử lại sau.",
        @"Too many requests"             : @"Quá nhiều yêu cầu, vui lòng thử lại sau ít phút.",
        @"System Maintenance"            : @"Hệ thống đang bảo trì, vui lòng quay lại sau.",
        @"Server error"                   : @"Server gặp lỗi không xác định.",
        @"Unknown action"                 : @"Yêu cầu không hợp lệ.",
    };
    NSString *mapped = map[raw];
    return (mapped.length > 0) ? mapped : raw;
}

- (void)processWithURL:(NSString *)urlString {
    Class urlCls = objc_getClass("NSURL");
    SEL urlSel = sel_registerName("URLWithString:");
    id url = ((id(*)(id, SEL, id))objc_msgSend)(urlCls, urlSel, urlString);
    
    Class sessionCls = objc_getClass("NSURLSession");
    SEL sharedSel = sel_registerName("sharedSession");
    id session = ((id(*)(id, SEL))objc_msgSend)(sessionCls, sharedSel);
    
    SEL dataTaskSel = sel_registerName("dataTaskWithURL:completionHandler:");
    
    id task = ((id(*)(id, SEL, id, void (^)(NSData*, NSURLResponse*, NSError*)))objc_msgSend)(session, dataTaskSel, url, ^(NSData *data, NSURLResponse *response, NSError *error) {
        
        volatile int state = 0;
        NSDictionary *json = nil;
        void *branchTable[] = { &&L_CHECK_ERR, &&L_PARSE_JSON, &&L_CHECK_FORCE, &&L_CHECK_STATUS, &&L_ERR_DATA, &&L_EXIT };
        
    Branching:
        if (state < 0 || state > 5) state = 5;
        goto *branchTable[state];
        
    L_CHECK_ERR:
        if (error) {
            SEL forceSel = sel_registerName("forceExitApp:");
            ((void(*)(id, SEL, id))objc_msgSend)(self, forceSel, @"Không thể kết nối đến server.");
            state = 5;
        } else {
            state = 1;
        }
        goto Branching;
        
    L_PARSE_JSON:
        if (data) {
            Class jsonCls = objc_getClass("NSJSONSerialization");
            SEL jsonSel = sel_registerName("JSONObjectWithData:options:error:");
            json = ((id(*)(id, SEL, id, NSInteger, id))objc_msgSend)(jsonCls, jsonSel, data, 0, nil);
            state = (json) ? 2 : 4;
        } else {
            state = 4;
        }
        goto Branching;
        
    L_CHECK_FORCE: {
        BOOL force = NO;
        if (json[@"force_exit"]) force = [json[@"force_exit"] boolValue];
        
        if (force) {
            SEL forceSel = sel_registerName("forceExitApp:");
            id rawMsg = json[@"message"];
            if (![rawMsg isKindOfClass:[NSString class]]) rawMsg = @"Token package không tồn tại.";
            id msg = [self localizedServerMessage:rawMsg];
            ((void(*)(id, SEL, id))objc_msgSend)(self, forceSel, msg);
            state = 5;
        } else {
            state = 3;
        }
        goto Branching;
    }
        
    L_CHECK_STATUS: {
        BOOL st = NO;
        if (json[@"status"]) st = [json[@"status"] boolValue];
        
        if (st) {
            SEL setCSel = sel_registerName("setContactLink:");
            ((void(*)(id, SEL, id))objc_msgSend)(self, setCSel, json[@"contact"]);
            
            SEL setMSel = sel_registerName("setIsMaintenance:");
            BOOL maint = [json[@"maintenance"] boolValue];
            ((void(*)(id, SEL, BOOL))objc_msgSend)(self, setMSel, maint);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                SEL succSel = sel_registerName("handleInitSuccess");
                ((void(*)(id, SEL))objc_msgSend)(self, succSel);
            });
        } else {
            SEL forceSel = sel_registerName("forceExitApp:");
            id rawMsg = json[@"message"];
            if (![rawMsg isKindOfClass:[NSString class]]) rawMsg = @"Lỗi không xác định.";
            id msg = [self localizedServerMessage:rawMsg];
            ((void(*)(id, SEL, id))objc_msgSend)(self, forceSel, msg);
        }
        state = 5;
        goto Branching;
    }
        
    L_ERR_DATA:
        {
            SEL forceSel = sel_registerName("forceExitApp:");
            ((void(*)(id, SEL, id))objc_msgSend)(self, forceSel, @"Dữ liệu server không hợp lệ.");
            state = 5;
        }
        goto Branching;
        
    L_EXIT:
        return;
    });
    
    SEL resumeSel = sel_registerName("resume");
    ((void(*)(id, SEL))objc_msgSend)(task, resumeSel);
}

- (void)handleInitSuccess {
    int index = 0;
    
    char k_key[] = {'s','a','v','e','d','_','l','i','c','e','n','s','e','_','k','e','y',0};
    NSString *savedKeyName = [NSString stringWithUTF8String:k_key];
    
    if (self.isMaintenance) {
        index = 0;
    } else {
        Class userDefCls = objc_getClass("NSUserDefaults");
        SEL stdSel = sel_registerName("standardUserDefaults");
        id userDef = ((id(*)(id, SEL))objc_msgSend)(userDefCls, stdSel);
        SEL objSel = sel_registerName("objectForKey:");
        NSString *savedKey = ((id(*)(id, SEL, id))objc_msgSend)(userDef, objSel, savedKeyName);
        index = (savedKey) ? 1 : 2;
    }
    
    typedef void (^ProcessBlock)(void);
    ProcessBlock b0 = ^{ [self showMaintenanceAlert]; };
    ProcessBlock b1 = ^{
        Class userDefCls = objc_getClass("NSUserDefaults");
        SEL stdSel = sel_registerName("standardUserDefaults");
        id userDef = ((id(*)(id, SEL))objc_msgSend)(userDefCls, stdSel);
        SEL objSel = sel_registerName("objectForKey:");
        NSString *k = ((id(*)(id, SEL, id))objc_msgSend)(userDef, objSel, savedKeyName);
        
        SEL checkSel = sel_registerName("checkKey:isAuto:");
        ((void(*)(id, SEL, id, BOOL))objc_msgSend)(self, checkSel, k, YES);
    };
    ProcessBlock b2 = ^{ [self showKeyAlert]; };
    
    ProcessBlock blocks[4];
    blocks[0] = b0;
    blocks[1] = b1;
    blocks[2] = b2;
    blocks[3] = b2;
    
    volatile int target_idx = index & 3;
    blocks[target_idx]();
}

- (void)showMaintenanceAlert {
    [self gate_state_maintenance];
}

- (void)showKeyAlert {
    [self gate_state_input];
}

- (void)checkKey:(NSString *)key isAuto:(BOOL)isAuto {
    SEL loadSel = sel_registerName("gate_state_loading:");
    ((void(*)(id, SEL, id))objc_msgSend)(self, loadSel, @"Đang kiểm tra key...");
    
    Class deviceCls = objc_getClass("UIDevice");
    SEL curDevSel = sel_registerName("currentDevice");
    id dev = ((id(*)(id, SEL))objc_msgSend)(deviceCls, curDevSel);
    SEL idVendorSel = sel_registerName("identifierForVendor");
    NSUUID *uuidObj = ((id(*)(id, SEL))objc_msgSend)(dev, idVendorSel);
    NSString *uuid = uuidObj.UUIDString;
    
    char fmt[] = {'%','@','?','a','c','t','i','o','n','=','c','h','e','c','k','&','t','o','k','e','n','=','%','@','&','k','e','y','=','%','@','&','u','u','i','d','=','%','@',0};
    NSString *fmtStr = [NSString stringWithUTF8String:fmt];
    
    SEL strFmtSel = sel_registerName("stringWithFormat:");
    NSString *urlString = ((id(*)(id, SEL, id, ...))objc_msgSend)(objc_getClass("NSString"), strFmtSel, fmtStr, kBaseAPIURL, kPackageToken, key, uuid);
    
    SEL execSel = sel_registerName("executeNetworkCheck:key:autoMode:");
    ((void(*)(id, SEL, id, id, BOOL))objc_msgSend)(self, execSel, urlString, key, isAuto);
}

- (void)executeNetworkCheck:(NSString *)urlStr key:(NSString *)key autoMode:(BOOL)isAuto {
    NSURL *url = [NSURL URLWithString:urlStr];
    
    Class sessionCls = objc_getClass("NSURLSession");
    SEL sharedSel = sel_registerName("sharedSession");
    id session = ((id(*)(id, SEL))objc_msgSend)(sessionCls, sharedSel);
    SEL dataTaskSel = sel_registerName("dataTaskWithURL:completionHandler:");
    
    id task = ((id(*)(id, SEL, id, void (^)(NSData*, NSURLResponse*, NSError*)))objc_msgSend)(session, dataTaskSel, url, ^(NSData *data, NSURLResponse *response, NSError *error) {
        
        volatile int currentState = 100;
        NSDictionary *json = nil;
        volatile BOOL loop = YES;
        
        void *labels[] = { &&State100, &&State200, &&State300, &&State400, &&State401, &&State402, &&State500, &&State501, &&ExitLoop };
        
        int labelIndex = 0;
        
    DispatchLoop:
        if (!loop) goto ExitLoop;
        
        if (currentState == 100) labelIndex = 0;
        else if (currentState == 200) labelIndex = 1;
        else if (currentState == 300) labelIndex = 2;
        else if (currentState == 400) labelIndex = 3;
        else if (currentState == 401) labelIndex = 4;
        else if (currentState == 402) labelIndex = 5;
        else if (currentState == 500) labelIndex = 6;
        else if (currentState == 501) labelIndex = 7;
        else labelIndex = 8;
        
        goto *labels[labelIndex];
        
    State100:
        if (error) currentState = 500;
        else currentState = 200;
        goto DispatchLoop;
        
    State200:
        if (!data) { currentState = 501; goto DispatchLoop; }
        {
            Class jsonCls = objc_getClass("NSJSONSerialization");
            SEL jsonSel = sel_registerName("JSONObjectWithData:options:error:");
            json = ((id(*)(id, SEL, id, NSInteger, id))objc_msgSend)(jsonCls, jsonSel, data, 0, nil);
        }
        if (!json) currentState = 501;
        else currentState = 300;
        goto DispatchLoop;
        
    State300:
        if ([json[@"force_exit"] boolValue]) {
            SEL forceSel = sel_registerName("forceExitApp:");
            id rawMsg = json[@"message"];
            if (![rawMsg isKindOfClass:[NSString class]]) rawMsg = @"Token package lỗi.";
            id msg = [self localizedServerMessage:rawMsg];
            ((void(*)(id, SEL, id))objc_msgSend)(self, forceSel, msg);
            loop = NO;
        } else {
            currentState = 400;
        }
        goto DispatchLoop;
        
    State400:
        if (json[@"contact"]) {
            self.contactLink = json[@"contact"];
        }
        if ([json[@"status"] boolValue]) currentState = 401;
        else currentState = 402;
        goto DispatchLoop;
        
    State401: {
        /* Server là nguồn chuẩn: connect.php đã tự chặn key hết hạn/suspended/
         * revoked TRƯỚC khi trả status=true, và days_left luôn >= 0.
         * Client không tự parse lại expiry theo timezone máy — lệch múi giờ
         * giữa thiết bị và server sẽ chặn nhầm key hợp lệ. */
        NSInteger daysLeft = [json[@"days_left"] integerValue];
        if (daysLeft < 0) daysLeft = 0;
        
        id expiryRaw = json[@"expiry"];
        NSString *expiryStr = ([expiryRaw isKindOfClass:[NSString class]]) ? expiryRaw : nil;
        
        char k_sv[] = {'s','a','v','e','d','_','l','i','c','e','n','s','e','_','k','e','y',0};
        Class udCls = objc_getClass("NSUserDefaults");
        id ud = ((id(*)(id, SEL))objc_msgSend)(udCls, sel_registerName("standardUserDefaults"));
        SEL setObj = sel_registerName("setObject:forKey:");
        ((void(*)(id, SEL, id, id))objc_msgSend)(ud, setObj, key, [NSString stringWithUTF8String:k_sv]);
        ((void(*)(id, SEL))objc_msgSend)(ud, sel_registerName("synchronize"));
        
        /* ghi token đa kho (5 mảnh + mirror) NGAY SAU khi server xác nhận */
        SEL asmSel = sel_registerName("kdy_assemble:expiry:days:");
        ((void(*)(id, SEL, id, id, long))objc_msgSend)(self, asmSel, key, (expiryStr ?: @""), (long)daysLeft);
        
        NSString *info = (expiryStr.length > 0)
            ? [NSString stringWithFormat:@"Hạn dùng: %@ (%ld ngày)", expiryStr, (long)daysLeft]
            : @"Key hợp lệ";
        
        dispatch_async(dispatch_get_main_queue(), ^{
            SEL succSel = sel_registerName("gate_state_success:");
            ((void(*)(id, SEL, id))objc_msgSend)(self, succSel, info);
        });
        loop = NO;
        goto DispatchLoop;
    }
        
    State402:
        {
            SEL invKeySel = sel_registerName("handleInvalidKey:message:isAuto:");
            NSString *msg = [self localizedServerMessage:json[@"message"]];
            ((void(*)(id, SEL, id, id, BOOL))objc_msgSend)(self, invKeySel, key, msg, isAuto);
        }
        loop = NO;
        goto DispatchLoop;
        
    State500:
        {
            SEL alertSel = sel_registerName("showAlert:message:exit:");
            ((void(*)(id, SEL, id, id, BOOL))objc_msgSend)(self, alertSel, @"Lỗi kết nối", error.localizedDescription, NO);
        }
        loop = NO;
        goto DispatchLoop;
        
    State501:
        {
            SEL alertSel = sel_registerName("showAlert:message:exit:");
            ((void(*)(id, SEL, id, id, BOOL))objc_msgSend)(self, alertSel, @"Lỗi Server", @"Dữ liệu không hợp lệ", NO);
        }
        loop = NO;
        goto DispatchLoop;
        
    ExitLoop:
        return;
        
    });
    SEL resumeSel = sel_registerName("resume");
    ((void(*)(id, SEL))objc_msgSend)(task, resumeSel);
}

- (void)handleInvalidKey:(NSString *)key message:(NSString *)msg isAuto:(BOOL)isAuto {
    char sel_c[] = {'r','e','m','o','v','e','O','b','j','e','c','t','F','o','r','K','e','y',':',0};
    SEL removeSel = NSSelectorFromString([NSString stringWithUTF8String:sel_c]);
    Class udCls = objc_getClass("NSUserDefaults");
    SEL stdSel = sel_registerName("standardUserDefaults");
    
    if ([udCls instancesRespondToSelector:removeSel]) {
        char k_sv[] = {'s','a','v','e','d','_','l','i','c','e','n','s','e','_','k','e','y',0};
        NSString *k = [NSString stringWithUTF8String:k_sv];
        id ud = ((id(*)(id, SEL))objc_msgSend)(udCls, stdSel);
        
        ImpFuncType func = (ImpFuncType)objc_msgSend;
        
        void (*volatile indirect_call)(id, SEL, id) = func;
        indirect_call(ud, removeSel, k);
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        g_kdy_verified = 0;
        g_kdy_entry_done = 1;
        dy_piece_set("q1", dy_rand64());
        dy_piece_set("q5", dy_rand64() ^ dy_magic());
        
        SEL showKeySel = sel_registerName("showKeyAlert");
        ((void(*)(id, SEL))objc_msgSend)(self, showKeySel);
        
        SEL stSel = sel_registerName("gate_set_status:color:shake:");
        UIColor *errColor = [UIColor colorWithRed:1.0 green:0.35 blue:0.35 alpha:1.0];
        NSString *errMsg = (msg.length > 0) ? msg : @"Key không hợp lệ";
        ((void(*)(id, SEL, id, id, BOOL))objc_msgSend)(self, stSel, errMsg, errColor, YES);
    });
}

- (void)showAlert:(NSString *)title message:(NSString *)message exit:(BOOL)retry {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *rootVC = [self gate_presenter];
        if (!rootVC) return;
        if (title == nil) return;
        
        Class alertCls = objc_getClass("UIAlertController");
        SEL alertSel = sel_registerName("alertControllerWithTitle:message:preferredStyle:");
        id alert = ((id(*)(id, SEL, id, id, NSInteger))objc_msgSend)(alertCls, alertSel, title, message, 1);
        
        typedef void (^ActionBlock)(UIAlertAction *);
        
        ActionBlock contactHandler = ^(UIAlertAction *action) {
            Class appCls = objc_getClass("UIApplication");
            SEL sharedSel = sel_registerName("sharedApplication");
            id app = ((id(*)(id, SEL))objc_msgSend)(appCls, sharedSel);
            SEL openSel = sel_registerName("openURL:options:completionHandler:");
            
            NSURL *u = [NSURL URLWithString:self.contactLink];
            ((void(*)(id, SEL, id, id, id))objc_msgSend)(app, openSel, u, @{}, nil);
            
            if (retry) {
                SEL showKeySel = sel_registerName("showKeyAlert");
                ((void(*)(id, SEL))objc_msgSend)(self, showKeySel);
            }
        };
        
        ActionBlock okHandler = ^(UIAlertAction *action) {
            if (retry) {
                SEL showKeySel = sel_registerName("showKeyAlert");
                ((void(*)(id, SEL))objc_msgSend)(self, showKeySel);
            }
        };
        
        Class actionCls = objc_getClass("UIAlertAction");
        SEL actionSel = sel_registerName("actionWithTitle:style:handler:");
        SEL addActSel = sel_registerName("addAction:");
        
        if (self.contactLink.length > 0) {
            id act = ((id(*)(id, SEL, id, NSInteger, void (^)(id)))objc_msgSend)(actionCls, actionSel, @"Liên hệ", 2, contactHandler);
            ((void(*)(id, SEL, id))objc_msgSend)(alert, addActSel, act);
        }
        
        id actOK = ((id(*)(id, SEL, id, NSInteger, void (^)(id)))objc_msgSend)(actionCls, actionSel, @"OK", 0, okHandler);
        ((void(*)(id, SEL, id))objc_msgSend)(alert, addActSel, actOK);
        
        SEL presentSel = sel_registerName("presentViewController:animated:completion:");
        ((void(*)(id, SEL, id, BOOL, id))objc_msgSend)(rootVC, presentSel, alert, YES, nil);
    });
}

#pragma mark - Full-screen black key gate

- (UIViewController *)gate_presenter {
    if (g_kdy_vc) return g_kdy_vc;
    SEL getTopSel = sel_registerName("getTopViewController");
    return ((UIViewController *(*)(id, SEL))objc_msgSend)(self, getTopSel);
}

- (void)gate_show {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_show]; });
        return;
    }
    if ([self gate_attach]) {
        [self gate_state_loading:@"Đang kết nối server..."];
    }
}

/* ------------------------------------------------------------------
 * GẮN MÀN KEY VÀO CỬA SỔ CHÍNH CỦA APP — một khối, không nổi.
 *   • Cửa sổ chính (storyboard) chưa sẵn sàng: phủ tạm bằng cửa sổ
 *     đen (chỉ tồn tại vài trăm ms lúc launch), tự gỡ khi chuyển giao.
 *   • Cửa sổ chính sẵn sàng: gate VC trở thành rootViewController
 *     của CHÍNH cửa sổ đó — UIKey LÀ màn hình của app.
 *   • Mở khóa (gate_dismiss): trả root gốc lại bằng cross-dissolve.
 * ------------------------------------------------------------------ */
- (BOOL)gate_attach {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_attach]; });
        return NO;
    }

    /* đã tích hợp vào cửa sổ chính rồi */
    if (g_kdy_app_window && g_kdy_vc && g_kdy_app_window.rootViewController == g_kdy_vc) {
        return YES;
    }

    UIWindowScene *scene = nil;
    if (@available(iOS 13.0, *)) {
        Class appCls = objc_getClass("UIApplication");
        SEL sharedAppSel = sel_registerName("sharedApplication");
        id sharedApp = ((id(*)(id, SEL))objc_msgSend)(appCls, sharedAppSel);
        SEL connScenesSel = sel_registerName("connectedScenes");
        NSSet *scenes = ((id(*)(id, SEL))objc_msgSend)(sharedApp, connScenesSel);
        for (UIScene *s in scenes) {
            if ([s isKindOfClass:[UIWindowScene class]]) {
                scene = (UIWindowScene *)s;
                if (s.activationState == UISceneActivationStateForegroundActive) break;
            }
        }
        if (!scene) {
            int gen = ++g_kdy_retry_gen;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                if (g_kdy_app_window || g_kdy_tmp_window) return;
                if (gen != g_kdy_retry_gen) return;
                [self gate_show];
            });
            return NO;
        }
    }

    /* tìm cửa sổ CHÍNH của app trong scene (bỏ qua cửa sổ tạm của gate) */
    UIWindow *appWin = nil;
    if (scene) {
        for (UIWindow *w in scene.windows) {
            if (w == g_kdy_tmp_window) continue;
            if (w.rootViewController) { appWin = w; break; }
            if (!appWin) appWin = w;
        }
    }

    if (appWin) {
        /* === CHUYỂN GIAO: gate trở thành root của cửa sổ chính === */
        if (!g_kdy_vc) {
            UIViewController *vc = [[UIViewController alloc] init];
            vc.view.backgroundColor = [UIColor blackColor];
            g_kdy_vc = vc;
        }
        UIViewController *orig = appWin.rootViewController;
        if (orig && orig != g_kdy_vc) g_kdy_orig_root = orig;
        appWin.rootViewController = g_kdy_vc;
        g_kdy_app_window = appWin;
        [appWin makeKeyAndVisible];

        /* gỡ cửa sổ tạm sau 1 nhịp — màn đen đã nằm ở chính cửa sổ */
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            [self kdy_drop_tmp_window];
        });
        return YES;
    }

    /* cửa sổ chính chưa xuất hiện → phủ đen tạm, chờ chuyển giao */
    if (!g_kdy_tmp_window) {
        UIViewController *vc = [[UIViewController alloc] init];
        vc.view.backgroundColor = [UIColor blackColor];
        g_kdy_vc = vc;
        if (scene) {
            g_kdy_tmp_window = [[UIWindow alloc] initWithWindowScene:scene];
        } else {
            g_kdy_tmp_window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        }
        g_kdy_tmp_window.windowLevel = UIWindowLevelStatusBar + 100.0;
        g_kdy_tmp_window.backgroundColor = [UIColor blackColor];
        g_kdy_tmp_window.rootViewController = vc;
        [g_kdy_tmp_window makeKeyAndVisible];
    }

    /* chờ cửa sổ chính (thường < 1s) — thử lại sau 0.15s, tối đa ~12s */
    g_kdy_attach_tries++;
    if (g_kdy_attach_tries < 80) {
        int gen = ++g_kdy_retry_gen;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (g_kdy_app_window) return;
            if (gen != g_kdy_retry_gen) return;
            [self gate_attach];
        });
    }
    return YES;   /* màn đen tạm đã phủ — gate đang hiện */
}

- (void)kdy_drop_tmp_window {
    if (!g_kdy_tmp_window) return;
    UIWindow *w = g_kdy_tmp_window;
    g_kdy_tmp_window = nil;
    w.hidden = YES;
    [w removeFromSuperview];
}

- (void)gate_state_loading:(NSString *)msg {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_loading:msg]; });
        return;
    }
    [self gate_attach];
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;
    
    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;
    
    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    CGSize spSize = spinner.frame.size;
    spinner.color = [UIColor colorWithRed:0.02 green:0.71 blue:0.83 alpha:1.0];
    spinner.frame = CGRectMake((b.size.width - spSize.width) / 2.0,
                               b.size.height * 0.42,
                               spSize.width,
                               spSize.height);
    spinner.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                               UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    [spinner startAnimating];
    [root addSubview:spinner];
    
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, spinner.frame.origin.y + spSize.height + 18, b.size.width, 22)];
    lbl.text = (msg.length > 0) ? msg : @"Đang tải...";
    lbl.textColor = [UIColor colorWithWhite:0.62 alpha:1.0];
    lbl.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    lbl.textAlignment = NSTextAlignmentCenter;
    lbl.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:lbl];
}

- (void)gate_state_input {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_input]; });
        return;
    }
    [self gate_attach];
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }

    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;

    UIColor *accent = [UIColor colorWithRed:0.02 green:0.71 blue:0.83 alpha:1.0];
    UIViewAutoresizing centerMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                                    UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;

    CGFloat cw = MIN(b.size.width - 48.0, 340.0);
    CGFloat cx = (b.size.width - cw) / 2.0;
    CGFloat top = b.size.height * 0.30;

    /* nhãn KÍCH HOẠT — nằm thẳng trên nền, không khung */
    UILabel *kick = [[UILabel alloc] initWithFrame:CGRectMake(0, top, b.size.width, 18)];
    kick.text = @"KÍCH HOẠT";
    kick.textColor = accent;
    kick.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    kick.textAlignment = NSTextAlignmentCenter;
    kick.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:kick];

    /* tên app — FreeFire Ds */
    UILabel *brand = [[UILabel alloc] initWithFrame:CGRectMake(0, top + 26, b.size.width, 46)];
    brand.text = @"FreeFire Ds";
    brand.textColor = [UIColor whiteColor];
    brand.font = [UIFont systemFontOfSize:36 weight:UIFontWeightBold];
    brand.textAlignment = NSTextAlignmentCenter;
    brand.adjustsFontSizeToFitWidth = YES;
    brand.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:brand];

    /* nhóm license + LOGIN — trong suốt, một khối với nền đen */
    UIView *group = [[UIView alloc] initWithFrame:CGRectMake(cx, top + 100, cw, 120)];
    group.backgroundColor = [UIColor clearColor];
    group.autoresizingMask = centerMask;
    [root addSubview:group];
    g_kdy_group = group;

    UITextField *tf = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, cw, 52)];
    tf.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.08];
    tf.layer.cornerRadius = 12.0;
    tf.textColor = [UIColor whiteColor];
    tf.placeholder = @"License Key";
    tf.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    tf.textAlignment = NSTextAlignmentCenter;
    tf.autocorrectionType = UITextAutocorrectionTypeNo;
    tf.autocapitalizationType = UITextAutocapitalizationTypeNone;
    tf.spellCheckingType = UITextSpellCheckingTypeNo;
    tf.keyboardType = UIKeyboardTypeASCIICapable;
    tf.returnKeyType = UIReturnKeyDone;
    tf.clearButtonMode = UITextFieldViewModeWhileEditing;
    [tf addTarget:self action:@selector(gate_login_tapped) forControlEvents:UIControlEventEditingDidEndOnExit];
    [group addSubview:tf];
    g_kdy_input = tf;

    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 68, cw, 52)];
    btn.backgroundColor = accent;
    btn.layer.cornerRadius = 12.0;
    [btn setTitle:@"LOGIN" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
    [btn addTarget:self action:@selector(gate_login_tapped) forControlEvents:UIControlEventTouchUpInside];
    [group addSubview:btn];

    /* dòng trạng thái — báo lỗi key / thông báo */
    UILabel *status = [[UILabel alloc] initWithFrame:CGRectMake(cx, top + 234, cw, 42)];
    status.textColor = [UIColor colorWithRed:1.0 green:0.35 blue:0.35 alpha:1.0];
    status.font = [UIFont systemFontOfSize:13];
    status.textAlignment = NSTextAlignmentCenter;
    status.numberOfLines = 2;
    status.autoresizingMask = centerMask;
    [root addSubview:status];
    g_kdy_status = status;

    /* liên hệ mờ sát đáy màn */
    if (self.contactLink.length > 0) {
        UIButton *contact = [UIButton buttonWithType:UIButtonTypeSystem];
        contact.frame = CGRectMake(cx, b.size.height - 84.0, cw, 32);
        [contact setTitle:@"Liên hệ hỗ trợ" forState:UIControlStateNormal];
        [contact setTitleColor:[UIColor colorWithWhite:0.55 alpha:1.0] forState:UIControlStateNormal];
        contact.titleLabel.font = [UIFont systemFontOfSize:13];
        contact.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                                   UIViewAutoresizingFlexibleTopMargin;
        [contact addTarget:self action:@selector(gate_contact_tapped) forControlEvents:UIControlEventTouchUpInside];
        [root addSubview:contact];
    }

    /* chạm nền → ẩn bàn phím */
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                            action:@selector(gate_bg_tapped)];
    tap.cancelsTouchesInView = NO;
    [root addGestureRecognizer:tap];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [g_kdy_input becomeFirstResponder];
    });
}

- (void)gate_bg_tapped {
    [g_kdy_input resignFirstResponder];
}

- (void)gate_state_success:(NSString *)info {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_success:info]; });
        return;
    }
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;
    
    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;
    
    UIColor *mint = [UIColor colorWithRed:0.02 green:0.83 blue:0.55 alpha:1.0];
    
    UILabel *check = [[UILabel alloc] initWithFrame:CGRectMake(0, b.size.height * 0.36, b.size.width, 64)];
    check.text = @"✓";
    check.textColor = mint;
    check.font = [UIFont systemFontOfSize:56 weight:UIFontWeightBold];
    check.textAlignment = NSTextAlignmentCenter;
    check.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:check];
    
    UILabel *t = [[UILabel alloc] initWithFrame:CGRectMake(0, b.size.height * 0.36 + 78, b.size.width, 26)];
    t.text = @"Kích hoạt thành công";
    t.textColor = [UIColor whiteColor];
    t.font = [UIFont systemFontOfSize:19 weight:UIFontWeightSemibold];
    t.textAlignment = NSTextAlignmentCenter;
    t.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:t];
    
    if (info.length > 0) {
        UILabel *d = [[UILabel alloc] initWithFrame:CGRectMake(24, b.size.height * 0.36 + 112, b.size.width - 48.0, 20)];
        d.text = info;
        d.textColor = [UIColor colorWithWhite:0.60 alpha:1.0];
        d.font = [UIFont systemFontOfSize:14];
        d.textAlignment = NSTextAlignmentCenter;
        d.adjustsFontSizeToFitWidth = YES;
        d.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
        [root addSubview:d];
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        /* KHÔNG gỡ màn chắn trực tiếp — phải qua recheck lớp 3 */
        [self kdy_entry_final];
    });
}

- (void)gate_state_maintenance {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_maintenance]; });
        return;
    }
    [self gate_attach];
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;
    
    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;
    
    UIColor *amber = [UIColor colorWithRed:1.0 green:0.72 blue:0.15 alpha:1.0];
    UIColor *accent = [UIColor colorWithRed:0.02 green:0.71 blue:0.83 alpha:1.0];
    
    CGFloat cw = MIN(b.size.width - 48.0, 340.0);
    CGFloat cx = (b.size.width - cw) / 2.0;
    CGFloat top = b.size.height * 0.30;
    
    UILabel *icon = [[UILabel alloc] initWithFrame:CGRectMake(0, top, b.size.width, 56)];
    icon.text = @"⚠";
    icon.textColor = amber;
    icon.font = [UIFont systemFontOfSize:48];
    icon.textAlignment = NSTextAlignmentCenter;
    icon.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:icon];
    
    UILabel *t = [[UILabel alloc] initWithFrame:CGRectMake(0, top + 68, b.size.width, 26)];
    t.text = @"Bảo Trì";
    t.textColor = [UIColor whiteColor];
    t.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    t.textAlignment = NSTextAlignmentCenter;
    t.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:t];
    
    UILabel *m = [[UILabel alloc] initWithFrame:CGRectMake(cx, top + 104, cw, 44)];
    m.text = @"Hệ thống đang bảo trì. Vui lòng quay lại sau.";
    m.textColor = [UIColor colorWithWhite:0.60 alpha:1.0];
    m.font = [UIFont systemFontOfSize:14];
    m.textAlignment = NSTextAlignmentCenter;
    m.numberOfLines = 2;
    m.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:m];
    
    if (self.contactLink.length > 0) {
        UIButton *contact = [[UIButton alloc] initWithFrame:CGRectMake(cx, top + 168, cw, 48)];
        contact.backgroundColor = accent;
        contact.layer.cornerRadius = 10.0;
        [contact setTitle:@"LIÊN HỆ" forState:UIControlStateNormal];
        [contact setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        contact.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        contact.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
        [contact addTarget:self action:@selector(gate_contact_tapped) forControlEvents:UIControlEventTouchUpInside];
        [root addSubview:contact];
    }
    
    UIButton *exitBtn = [[UIButton alloc] initWithFrame:CGRectMake(cx, top + 226, cw, 48)];
    exitBtn.layer.cornerRadius = 10.0;
    exitBtn.layer.borderWidth = 1.0;
    exitBtn.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
    [exitBtn setTitle:@"THOÁT" forState:UIControlStateNormal];
    [exitBtn setTitleColor:[UIColor colorWithWhite:0.75 alpha:1.0] forState:UIControlStateNormal];
    exitBtn.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    exitBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
    [exitBtn addTarget:self action:@selector(gate_exit_tapped) forControlEvents:UIControlEventTouchUpInside];
    [root addSubview:exitBtn];
}

- (void)gate_dismiss {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_dismiss]; });
        return;
    }

    /* chỉ được qua màn chắn khi đã verify + token đa kho hợp lệ */
    if (!g_kdy_verified && (g_kdy_tamper_flag || ![self kdy_token_ok])) {
        [self gate_state_input];
        return;
    }

    if (g_kdy_app_window) {
        /* MỞ KHÓA: trả root gốc về cho CHÍNH cửa sổ của app —
           một khối duy nhất, không còn lớp cửa sổ nổi phía trên */
        UIWindow *win = g_kdy_app_window;
        UIViewController *restore = g_kdy_orig_root;
        if (!restore) {
            restore = [[UIViewController alloc] init];
            restore.view.backgroundColor = [UIColor blackColor];
        }
        g_kdy_app_window = nil;
        g_kdy_vc = nil;
        g_kdy_input = nil;
        g_kdy_group = nil;
        g_kdy_status = nil;
        g_kdy_orig_root = nil;
        [UIView transitionWithView:win
                            duration:0.35
                             options:(UIViewAnimationOptionTransitionCrossDissolve | UIViewAnimationOptionLayoutSubviews)
                          animations:^{
            win.rootViewController = restore;
        }
                          completion:^(BOOL finished) {
            [win makeKeyAndVisible];
        }];
        [self kdy_drop_tmp_window];
        return;
    }

    /* chế độ cửa sổ tạm (dự phòng khi app không có cửa sổ chính) */
    if (!g_kdy_tmp_window) return;

    UIWindow *w = g_kdy_tmp_window;
    UIWindowScene *scene = (UIWindowScene *)w.windowScene;
    UIWindow *restoreWin = nil;
    if (scene) {
        for (UIWindow *win in scene.windows) {
            if (win != w) { restoreWin = win; break; }
        }
    }

    g_kdy_tmp_window = nil;
    g_kdy_vc = nil;
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;

    [UIView animateWithDuration:0.35
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
        w.alpha = 0.0;
    }
                     completion:^(BOOL finished) {
        w.hidden = YES;
        [w removeFromSuperview];
        if (restoreWin) [restoreWin makeKeyWindow];
    }];
}

- (void)gate_set_status:(NSString *)msg color:(UIColor *)color shake:(BOOL)shake {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_set_status:msg color:color shake:shake]; });
        return;
    }
    if (g_kdy_status) {
        g_kdy_status.text = msg;
        g_kdy_status.textColor = color ?: [UIColor colorWithRed:1.0 green:0.35 blue:0.35 alpha:1.0];
    }
    if (shake && g_kdy_group) {
        [UIView animateKeyframesWithDuration:0.45
                                         delay:0.0
                                       options:UIViewKeyframeAnimationOptionCalculationModeLinear
                                    animations:^{
            [UIView addKeyframeWithRelativeStartTime:0.0 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(-12, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.2 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(12, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.4 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(-7, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.6 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(7, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.8 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformIdentity;
            }];
        }
                                    completion:nil];
    }
}

- (void)gate_login_tapped {
    NSString *k = g_kdy_input.text ?: @"";
    if (k.length > 0) {
        [g_kdy_input resignFirstResponder];
        SEL checkSel = sel_registerName("checkKey:isAuto:");
        ((void(*)(id, SEL, id, BOOL))objc_msgSend)(self, checkSel, k, NO);
    } else {
        [self gate_set_status:@"Vui lòng nhập key"
                        color:[UIColor colorWithRed:1.0 green:0.35 blue:0.35 alpha:1.0]
                        shake:YES];
    }
}

- (void)gate_contact_tapped {
    NSString *link = self.contactLink;
    if (link.length > 0) {
        Class appCls = objc_getClass("UIApplication");
        SEL sharedSel = sel_registerName("sharedApplication");
        id app = ((id(*)(id, SEL))objc_msgSend)(appCls, sharedSel);
        SEL openSel = sel_registerName("openURL:options:completionHandler:");
        NSURL *u = [NSURL URLWithString:link];
        ((void(*)(id, SEL, id, id, id))objc_msgSend)(app, openSel, u, @{}, nil);
    }
}

- (void)gate_exit_tapped {
    exit(0);
}

#pragma mark - Multi-layer verify (shield core)

/* ------------------------------------------------------------------
 * UUID thiết bị (cache) — dùng chung cho mọi vòng verify
 * ------------------------------------------------------------------ */
- (NSString *)kdy_uuid {
    if (!g_kdy_uuid_cache) {
        Class deviceCls = objc_getClass("UIDevice");
        SEL curDevSel = sel_registerName("currentDevice");
        id dev = ((id(*)(id, SEL))objc_msgSend)(deviceCls, curDevSel);
        SEL idVendorSel = sel_registerName("identifierForVendor");
        NSUUID *uuidObj = ((id(*)(id, SEL))objc_msgSend)(dev, idVendorSel);
        g_kdy_uuid_cache = uuidObj.UUIDString ?: @"";
    }
    return g_kdy_uuid_cache;
}

/* Key đã lưu trong defaults (nguồn để hash lại token) */
- (NSString *)kdy_saved_key {
    Class udCls = objc_getClass("NSUserDefaults");
    SEL stdSel = sel_registerName("standardUserDefaults");
    id ud = ((id(*)(id, SEL))objc_msgSend)(udCls, stdSel);
    SEL objSel = sel_registerName("objectForKey:");
    char k_key[] = {'s','a','v','e','d','_','l','i','c','e','n','s','e','_','k','e','y',0};
    id v = ((id(*)(id, SEL, id))objc_msgSend)(ud, objSel, [NSString stringWithUTF8String:k_key]);
    return ([v isKindOfClass:[NSString class]]) ? v : nil;
}

/* URL check key (khớp protocol server connect.php) */
- (NSString *)kdy_check_url:(NSString *)key {
    NSString *uuid = [self kdy_uuid] ?: @"";
    char fmt[] = {'%','@','?','a','c','t','i','o','n','=','c','h','e','c','k','&','t','o','k','e','n','=','%','@','&','k','e','y','=','%','@','&','u','u','i','d','=','%','@',0};
    SEL strFmtSel = sel_registerName("stringWithFormat:");
    return ((id(*)(id, SEL, id, ...))objc_msgSend)(objc_getClass("NSString"), strFmtSel, [NSString stringWithUTF8String:fmt], kBaseAPIURL, kPackageToken, key, uuid);
}

/* ------------------------------------------------------------------
 * GHI TOKEN ĐA KHO sau khi server xác nhận status=true:
 *   q1 = FNV(key) ^ K1   (mirror thêm vào static + hash lại từ
 *   saved key lúc check)
 *   q2 = FNV(expiry) ^ K2
 *   q3 = days ^ K3
 *   q4 = nonce ^ K4       (mirror thêm vào NSUserDefaults "vk4")
 *   q5 = q1^q2^q3^q4 ^ MAGIC
 * XOR cả 5 mảnh phải ra MAGIC — sửa/xóa/mất 1 mảnh là vỡ.
 * ------------------------------------------------------------------ */
- (void)kdy_assemble:(NSString *)key expiry:(NSString *)expiry days:(long)days {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self kdy_assemble:key expiry:expiry days:days];
        });
        return;
    }
    g_kdy_busy = 1;
    const char *kc = key.UTF8String ?: "";
    const char *ec = expiry.UTF8String ?: "";
    uint64_t p1 = dy_fnv1a(kc, 0x9E3779B97F4A7C15ULL) ^ dy_k1();
    uint64_t p2 = dy_fnv1a(ec, 0xC2B2AE3D27D4EB4FULL) ^ dy_k2();
    uint64_t p3 = ((uint64_t)days) ^ dy_k3();
    uint64_t p4 = dy_rand64() ^ dy_k4();
    char t1[] = {'q','1',0}, t2[] = {'q','2',0}, t3[] = {'q','3',0};
    char t4[] = {'q','4',0}, t5[] = {'q','5',0};
    dy_piece_set(t1, p1);
    dy_piece_set(t2, p2);
    dy_piece_set(t3, p3);
    dy_piece_set(t4, p4);
    dy_piece_set(t5, p1 ^ p2 ^ p3 ^ p4 ^ dy_magic());
    g_kdy_mirror_a = p1;
    g_kdy_key_copy = [key copy];

    /* mirror NSUserDefaults cho mảnh q4 */
    Class udCls = objc_getClass("NSUserDefaults");
    id ud = ((id(*)(id, SEL))objc_msgSend)(udCls, sel_registerName("standardUserDefaults"));
    char mk[] = {'v','k','4',0};
    ((void(*)(id, SEL, id, id))objc_msgSend)(ud, sel_registerName("setObject:forKey:"),
        [NSNumber numberWithUnsignedLongLong:p4], [NSString stringWithUTF8String:mk]);
    ((void(*)(id, SEL))objc_msgSend)(ud, sel_registerName("synchronize"));

    g_kdy_busy = 0;
    g_kdy_refresh_ms = kdy_now_ms();
}

/* Kiểm tra token đa kho — gọi từ watchdog (bg) và các điểm chốt (main) */
- (BOOL)kdy_token_ok {
    if (g_kdy_busy) return YES;   /* đang ghi — bỏ qua lượt này */
    if (!dy_piece_valid(dy_magic())) return NO;
    uint64_t q1 = dy_piece_get("q1", 0);
    if (q1 == 0 || q1 != g_kdy_mirror_a) return NO;

    /* hash lại từ key đã lưu — đổi defaults mà không qua server là vỡ */
    NSString *saved = [self kdy_saved_key];
    if (saved.length == 0) return NO;
    uint64_t h = dy_fnv1a(saved.UTF8String ?: "", 0x9E3779B97F4A7C15ULL) ^ dy_k1();
    if (h != q1) return NO;

    /* mirror q4 trong defaults */
    Class udCls = objc_getClass("NSUserDefaults");
    id ud = ((id(*)(id, SEL))objc_msgSend)(udCls, sel_registerName("standardUserDefaults"));
    char mk[] = {'v','k','4',0};
    id mv = ((id(*)(id, SEL, id))objc_msgSend)(ud, sel_registerName("objectForKey:"), [NSString stringWithUTF8String:mk]);
    uint64_t m4 = ([mv isKindOfClass:[NSNumber class]]) ? [mv unsignedLongLongValue] : 0;
    if (m4 == 0 || m4 != dy_piece_get("q4", ~m4)) return NO;

    return YES;
}

/* dò môi trường — trả về NO nếu phát hiện inject/debug */
- (BOOL)kdy_probe {
    if (dy_env_suspicious() != 0) return NO;
    if (dy_dyld_suspicious() != 0) return NO;
    if (dy_debug_attached() != 0) return NO;
    return YES;
}

/* ------------------------------------------------------------------
 * MẠNG ĐA LỚP: mode 1 = recheck trước khi gỡ màn chắn (lớp 3),
 *              mode 2 = heartbeat giữa phiên (lớp 5).
 * Máy trạng thái computed-goto giống phong cách phần còn lại.
 * ------------------------------------------------------------------ */
- (void)kdy_net:(NSString *)urlStr mode:(int)mode key:(NSString *)key {
    NSURL *url = [NSURL URLWithString:urlStr];
    if (!url) {
        if (mode == 1) {
            dispatch_async(dispatch_get_main_queue(), ^{ [self kdy_complete_entry]; });
        } else {
            [self kdy_beat_next_after_miss];
        }
        return;
    }
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
        volatile int st = 0;
        volatile int miss_local = 0;
        NSDictionary *js = nil;
        void *lb[] = { &&Q_ERR, &&Q_PARSE, &&Q_FORCE, &&Q_STATUS, &&Q_OK, &&Q_BAD, &&Q_END };

    Q_TOP:
        if (st < 0 || st > 6) st = 6;
        goto *lb[st];

    Q_ERR: {
            BOOL bad = (err != nil);
            if (!bad && [resp isKindOfClass:[NSHTTPURLResponse class]]) {
                NSHTTPURLResponse *hr = (NSHTTPURLResponse *)resp;
                NSString *ct = hr.allHeaderFields[@"Content-Type"] ?: @"";
                bad = (hr.statusCode != 200) || ([ct rangeOfString:@"json"].location == NSNotFound);
            }
            if (bad) { miss_local = 1; st = 6; goto Q_TOP; }
            st = 1;
            goto Q_TOP;
        }

    Q_PARSE: {
            js = nil;
            if (data) {
                Class jsonCls = objc_getClass("NSJSONSerialization");
                SEL jsonSel = sel_registerName("JSONObjectWithData:options:error:");
                js = ((id(*)(id, SEL, id, NSInteger, id))objc_msgSend)(jsonCls, jsonSel, data, 0, nil);
            }
            if (!js) { miss_local = 1; st = 6; goto Q_TOP; }
            st = 2;
            goto Q_TOP;
        }

    Q_FORCE: {
            if ([js[@"force_exit"] boolValue]) {
                id rawMsg = js[@"message"];
                if (![rawMsg isKindOfClass:[NSString class]]) rawMsg = @"Lỗi hệ thống.";
                NSString *msg = [self localizedServerMessage:rawMsg];
                dispatch_async(dispatch_get_main_queue(), ^{
                    g_kdy_entry_done = 1;
                    SEL fSel = sel_registerName("forceExitApp:");
                    ((void(*)(id, SEL, id))objc_msgSend)(self, fSel, msg);
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)),
                                   dispatch_get_main_queue(), ^{
                        dy_exit_paths(2);
                    });
                });
                st = 6;
                goto Q_TOP;
            }
            st = 3;
            goto Q_TOP;
        }

    Q_STATUS: {
            if ([js[@"status"] boolValue]) { st = 4; }
            else { st = 5; }
            goto Q_TOP;
        }

    Q_OK: {
            NSInteger dl = [js[@"days_left"] integerValue];
            if (dl < 0) dl = 0;
            id ex = js[@"expiry"];
            NSString *exs = ([ex isKindOfClass:[NSString class]]) ? ex : @"";
            dispatch_async(dispatch_get_main_queue(), ^{
                SEL aSel = sel_registerName("kdy_assemble:expiry:days:");
                ((void(*)(id, SEL, id, id, long))objc_msgSend)(self, aSel, key, exs, (long)dl);
                if (mode == 1) {
                    g_kdy_entry_done = 1;
                    SEL cSel = sel_registerName("kdy_complete_entry");
                    ((void(*)(id, SEL))objc_msgSend)(self, cSel);
                } else {
                    g_kdy_miss = 0;
                    [self kdy_beat_next];
                }
            });
            st = 6;
            goto Q_TOP;
        }

    Q_BAD: {
            id rawMsg = js[@"message"];
            if (![rawMsg isKindOfClass:[NSString class]]) rawMsg = @"Key không hợp lệ.";
            NSString *msg = [self localizedServerMessage:rawMsg];
            dispatch_async(dispatch_get_main_queue(), ^{
                g_kdy_entry_done = 1;
                if (mode == 1) {
                    /* key vừa check xong lại bị từ chối → quay lại màn chắn */
                    SEL invSel = sel_registerName("handleInvalidKey:message:isAuto:");
                    ((void(*)(id, SEL, id, id, BOOL))objc_msgSend)(self, invSel, key, msg, NO);
                } else {
                    /* giữa phiên server từ chối dứt khoát (thu hồi/hết hạn) */
                    SEL fSel = sel_registerName("forceExitApp:");
                    ((void(*)(id, SEL, id))objc_msgSend)(self, fSel, msg);
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)),
                                   dispatch_get_main_queue(), ^{
                        dy_exit_paths(3);
                    });
                }
            });
            st = 6;
            goto Q_TOP;
        }

    Q_END: {
            if (miss_local) {
                if (mode == 1) {
                    /* lỗi mạng lúc recheck đầu vào → khoan dung, beat sẽ xử lý */
                    dispatch_async(dispatch_get_main_queue(), ^{
                        g_kdy_entry_done = 1;
                        [self kdy_complete_entry];
                    });
                } else {
                    g_kdy_miss++;
                    if (g_kdy_miss >= 24) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            SEL tSel = sel_registerName("kdy_tamper:");
                            ((void(*)(id, SEL, int))objc_msgSend)(self, tSel, 0xE1);
                        });
                    } else {
                        [self kdy_beat_schedule:(240.0 + (double)(dy_rand64() % 180))];
                    }
                }
            }
            (void)miss_local;
            return;
        }
    }];
    SEL resumeSel = sel_registerName("resume");
    ((void(*)(id, SEL))objc_msgSend)(task, resumeSel);
}

/* ------------------------------------------------------------------
 * LỚP 3: recheck trước khi gỡ màn chắn — patch 1 điểm check
 * duy nhất là KHÔNG đủ để qua được lớp này.
 * ------------------------------------------------------------------ */
- (void)kdy_entry_final {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self kdy_entry_final]; });
        return;
    }
    if (g_kdy_verified) { [self gate_dismiss]; return; }
    if (![self kdy_probe]) { [self kdy_tamper:0x56]; return; }
    NSString *k = g_kdy_key_copy ?: [self kdy_saved_key];
    if (k.length == 0) { [self gate_dismiss]; return; }
    g_kdy_entry_done = 0;
    int gen = ++g_kdy_entry_gen;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (gen == g_kdy_entry_gen && !g_kdy_entry_done) {
            [self kdy_complete_entry];   /* recheck quá chậm → khoan dung */
        }
    });
    [self kdy_net:[self kdy_check_url:k] mode:1 key:k];
}

/* hoàn tất vào app: chỉ SAU đây màn chắn mới được gỡ */
- (void)kdy_complete_entry {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self kdy_complete_entry]; });
        return;
    }
    g_kdy_entry_done = 1;
    g_kdy_verified = 1;
    [self kdy_beat_start];
    [self kdy_resume_observe];
    [self gate_dismiss];
}

/* ------------------------------------------------------------------
 * LỚP 5: heartbeat ngẫu nhiên 4–7 phút + khi app trở lại foreground.
 * Server thu hồi / hết hạn key giữa phiên → kill ngay.
 * Offline liên tiếp >= 24 lượt (~2h) → coi như giả mạo → kill.
 * ------------------------------------------------------------------ */
- (void)kdy_beat_start {
    [self kdy_beat_schedule:(30.0 + (double)(dy_rand64() % 30))];
}

- (void)kdy_beat_schedule:(double)sec {
    int gen = ++g_kdy_beat_gen;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (gen == g_kdy_beat_gen && g_kdy_verified) {
            [self kdy_beat_fire];
        }
    });
}

- (void)kdy_beat_fire {
    if (!g_kdy_verified) return;
    int64_t now = kdy_now_ms();
    if (now - g_kdy_last_beat_ms < 90000) {
        [self kdy_beat_schedule:95.0];
        return;
    }
    g_kdy_last_beat_ms = now;
    NSString *k = g_kdy_key_copy ?: [self kdy_saved_key];
    if (k.length == 0) return;
    [self kdy_net:[self kdy_check_url:k] mode:2 key:k];
}

- (void)kdy_beat_next {
    [self kdy_beat_schedule:(240.0 + (double)(dy_rand64() % 180))];
}

- (void)kdy_beat_next_after_miss {
    g_kdy_miss++;
    if (g_kdy_miss >= 24) {
        [self kdy_tamper:0xE2];
    } else {
        [self kdy_beat_schedule:(240.0 + (double)(dy_rand64() % 180))];
    }
}

/* nghe app trở lại foreground → beat ngay (đã debounce 90s bên trong) */
- (void)kdy_resume_observe {
    if (g_kdy_observer_added) return;
    g_kdy_observer_added = 1;
    Class ncCls = objc_getClass("NSNotificationCenter");
    SEL ctrSel = sel_registerName("defaultCenter");
    id nc = ((id(*)(id, SEL))objc_msgSend)(ncCls, ctrSel);
    SEL addSel = sel_registerName("addObserver:selector:name:object:");
    SEL tickSel = sel_registerName("kdy_resume_tick");
    ((void(*)(id, SEL, id, SEL, id, id))objc_msgSend)(nc, addSel, self, tickSel,
                                                     UIApplicationDidBecomeActiveNotification, nil);
}

- (void)kdy_resume_tick {
    if (!g_kdy_verified) return;
    [self kdy_beat_fire];
}

/* watchdog ↔ main handshake: màn chắn còn sống khi chưa verify.
 * Tích hợp root: gate "sống" = rootVC của cửa sổ chính VẪN là gate VC.
 * Ai swap root / giấu màn để bypass → alive ngừng cập nhật → watchdog giết. */
- (void)kdy_alive_tick {
    g_kdy_main_ms = kdy_now_ms();
    BOOL alive = NO;
    if (g_kdy_app_window && g_kdy_vc) {
        alive = (!g_kdy_app_window.hidden && g_kdy_app_window.rootViewController == g_kdy_vc);
    } else if (g_kdy_tmp_window) {
        alive = (!g_kdy_tmp_window.hidden && g_kdy_tmp_window.alpha > 0.5);
    }
    if (!g_kdy_verified && alive) {
        g_kdy_alive_ms = kdy_now_ms();
    }
}

/* ------------------------------------------------------------------
 * TAMPER: xóa key, phá token, ghi marker chết cho lần chạy sau,
 * thoát đa đường im lặng với trễ ngẫu nhiên (khó truy vết điểm check).
 * ------------------------------------------------------------------ */
- (void)kdy_tamper:(int)reason {
    (void)reason;
    g_kdy_verified = 0;
    g_kdy_tamper_flag = 1;
    g_kdy_busy = 1;

    Class udCls = objc_getClass("NSUserDefaults");
    id ud = ((id(*)(id, SEL))objc_msgSend)(udCls, sel_registerName("standardUserDefaults"));
    char pk[] = {'d','y','9',0};
    ((void(*)(id, SEL, id, id))objc_msgSend)(ud, sel_registerName("setObject:forKey:"),
        [NSString stringWithUTF8String:pk], [NSString stringWithUTF8String:pk]);
    char k_key[] = {'s','a','v','e','d','_','l','i','c','e','n','s','e','_','k','e','y',0};
    ((void(*)(id, SEL, id))objc_msgSend)(ud, sel_registerName("removeObjectForKey:"),
        [NSString stringWithUTF8String:k_key]);
    char mk[] = {'v','k','4',0};
    ((void(*)(id, SEL, id))objc_msgSend)(ud, sel_registerName("removeObjectForKey:"),
        [NSString stringWithUTF8String:mk]);
    ((void(*)(id, SEL))objc_msgSend)(ud, sel_registerName("synchronize"));

    dy_piece_set("q1", dy_rand64());
    dy_piece_set("q4", dy_rand64());
    dy_piece_set("q5", dy_rand64() ^ dy_magic());
    g_kdy_mirror_a = dy_rand64();

    [self kdy_die];
}

- (void)kdy_die {
    double d1 = 0.15 + ((double)(dy_rand64() % 1200)) / 1000.0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(d1 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        dy_exit_paths((int)(dy_rand64() & 3));
    });
    dy_exit_paths((int)((dy_rand64() >> 9) & 3));
}

/* ------------------------------------------------------------------
 * REASSERT — được gọi từ constructor ẩn trong DuyServer.mm.
 * Nếu +load của khanhduy bị NOP/cắt bỏ: watchdog chưa chạy (boot_ms==0)
 * và màn chắn chưa từng xuất hiện → tự khởi động lại toàn bộ hệ thống.
 * Nếu bình thường: không làm gì cả (đã verify hoặc gate đang hiện).
 * ------------------------------------------------------------------ */
- (void)kdy_reassert {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self kdy_reassert]; });
        return;
    }
    if (g_kdy_boot_ms == 0) {
        kdy_static_boot();
    }
    if (!g_kdy_verified && !g_kdy_app_window && !g_kdy_tmp_window) {
        [self gate_show];
    }
}
@end
