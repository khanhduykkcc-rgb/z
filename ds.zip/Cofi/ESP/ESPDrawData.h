#ifndef ESPDrawData_h
#define ESPDrawData_h

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

// 64-slot cap so BR-mode roster scenes with valid counts above the
// legacy 16-cap aren't throttled by the packet.
#define ESP_MAX_DRAW_PLAYERS 64
#define ESP_DRAW_MAGIC 0x45535033 /* "ESP3": adds aim/FOV overlay fields */

// Box style toggle (per-packet, set by frame builder from prefs)
#define ESP_BOX_STYLE_RECT    0   // full rectangle (legacy alternative)
#define ESP_BOX_STYLE_CORNER  1   // corner-box (DS default, VIP-style)

// HP bar style toggle
#define ESP_HP_STYLE_HORIZONTAL 0 // DS legacy: 75pt-wide bar above box
#define ESP_HP_STYLE_VERTICAL   1 // VIP-style: 3.5pt-wide bar left of box

#pragma pack(push, 4)

typedef struct {
    uint8_t valid;
    uint8_t isEnemy;
    uint8_t isVisible; // Projectable/on-screen eligibility, NOT verified game LOS.
    uint8_t hasBones;

    // Class flags (Phase A)
    uint8_t isBot;
    uint8_t isKnocked;     // drawn in red, NOT filtered
    uint8_t nameColorIdx;  // pawn%3 → 0=mint, 1=purple, 2=cyan; ignored if isKnocked

    // Distance-based opacity (Phase C): 0..255, 255 = full visibility
    uint8_t opacity;

    CGRect box;

    CGPoint headPos;
    CGPoint hipPos;
    CGPoint leftHandPos;
    CGPoint rightHandPos;
    CGPoint leftAnklePos;
    CGPoint rightAnklePos;
    CGPoint leftToePos;
    CGPoint rightToePos;

    // Skeleton (Phase G — populated only when hasBones=1)
    CGPoint boneNeck;       // computed: head + 0.15*(hip-head)
    CGPoint boneLElbow;
    CGPoint boneRElbow;
    CGPoint boneLShoulder;  // computed: neck + 0.30*(LElbow-neck)
    CGPoint boneRShoulder;
    CGPoint boneLKnee;      // computed: hip + 0.45*(LAnkle-hip)
    CGPoint boneRKnee;

    float hpPercent;
    int32_t currentHP;
    int32_t maximumHP;
    float distanceMeters;
    char name[32];
} ESPPlayerDrawEntry;

typedef struct {
    uint32_t magic;
    uint32_t sequence;
    uint32_t count;

    uint8_t showLines;
    uint8_t showBoxes;
    uint8_t showHealth;
    uint8_t showNames;
    uint8_t showDistance;
    uint8_t showPlayerCount;
    // Aim overlay bundle (filled by the frame builder from AimAssistEngine):
    uint8_t showFov;       // draw the aim FOV circle
    uint8_t aimHasTarget;  // draw the aim lock line to aimTargetPoint
    float fovRadius;       // FOV circle radius in overlay points
    CGPoint aimTargetPoint;

    // ESP rendering toggles (Phase B) — frame builder reads from prefs
    uint8_t boxStyle;        // ESP_BOX_STYLE_RECT / ESP_BOX_STYLE_CORNER
    uint8_t hpStyle;         // ESP_HP_STYLE_HORIZONTAL / ESP_HP_STYLE_VERTICAL
    uint8_t countColorIdx;   // 0=red(legacy), 1=cyan(VIP)
    uint8_t showSkeleton;    // gate per-packet so prefs can disable

    ESPPlayerDrawEntry players[ESP_MAX_DRAW_PLAYERS];
} ESPDrawPacket;

#pragma pack(pop)

#endif /* ESPDrawData_h */
