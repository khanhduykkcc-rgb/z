// Core/AimAssistEngine.mm — VIP-standard aim assist for DSWUnity.
//
// Faithful port of the reference Vip build's aimbot pipeline:
//   target scan (FOV window + score) -> lock persistence -> velocity
//   prediction (PhysicalCCT + tracker + weapon data) -> quaternion steering
//   (Slerp + AuxAimResetTime + pitch limits) -> single-shot snap + auto-fire.
//
// This is a 1:1 port of VIP's esp.mm aimbot section. The only difference is
// the memory backend: VIP uses task_for_pid + mach_vm_read/write, DS uses
// the darksword RemoteWriteDomain::Aim-gated phantom_write_bytes. The aim
// math, target selection, prediction, and steering are byte-identical.

#import "AimAssistEngine.h"
#import "../drawing_view/ESPDataCollector.h"
#import "MemoryUtils.h"
#import "GameOffsets.h"
#import "GameLogic.h"

#import <mach/mach_time.h>
#import <QuartzCore/QuartzCore.h>
#import <cmath>
#import <float.h>

#pragma mark - Tunables (VIP defaults, copied verbatim)

static const float kAimFovMin = 5.0f;
static const float kAimFovMax = 500.0f;
static const float kAimSpeedMin = 1.0f;
static const float kAimSpeedMax = 2000.0f;
static const float kAimMaxDistance = 1000.0f;    // VIP hardcodes 1000m
static const float kAimCloseRangeBonus = 50.0f;  // meters
static const int   kAimLockMaxLostFrames = 2;    // VIP lock grace
static const int   kVelocityTrackerCapacity = 64;
static const float kVelocityMaxMagnitude = 100.0f;

#pragma mark - Preference cache (mirrors VIP globals)

static bool   gAimbot = false;
static bool   gShowFov = true;
static bool   gAimLine = false;
static bool   gAimIgnoreBot = false;
static bool   gAimIgnoreKnock = false;
static bool   gAimCheckVisible = true;
static int    gAimPosition = 0;   // 0 head · 1 neck · 2 chest · 3 upper head
static int    gTriggerMode = 0;   // 0 always · 1 firing · 2 scoping · 3 fire|scope
static float  gAimFov = 250.0f;
static float  gAimSpeed = 1000.0f;

#pragma mark - Velocity tracker (per-pawn, VIP layout)

struct AimVelocityTrack {
    uint64_t pawn;
    Vector3 lastHeadPos;
    Vector3 velocity;
    double lastTime;
};

static AimVelocityTrack gVelocityTracker[kVelocityTrackerCapacity];
static int gVelocityTrackerCount = 0;

static uint64_t gAimLockTarget = 0;
static int gAimLockLostFrames = 0;
static bool gWasScoping = false;

#pragma mark - Small helpers (VIP parity)

static inline bool AimIsZeroVec(const Vector3 &v) {
    return v.x == 0.0f && v.y == 0.0f && v.z == 0.0f;
}

static inline float AimClamp(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

static double AimMediaTime(void) {
    return CACurrentMediaTime();
}

// VIP GetRotationToLocation — yBias removed (kept removed per VIP comment).
static inline Quaternion GetRotationToLocation(Vector3 target, Vector3 myLoc) {
    Vector3 dir = target - myLoc;
    return Quaternion::LookRotation(dir, Vector3(0, 1, 0));
}

#pragma mark - PRI scalar access (VIP-parity, no group check)

// VIP's GetDataUInt16 reads PRI scalars WITHOUT the ReplicationDataGroup
// type check — it walks Player → PRIDataPool → DataPoolInner → entries[varID]
// → value, then dereferences. The original DS TryGetDataUInt16 added a strict
// group==UInt16 check that rejected the fire/scope slots, breaking trigger
// modes 1/2/3. This helper mirrors VIP exactly so all four trigger modes
// behave identically to the reference build.
static uint16_t AimReadPRIUInt16(uint64_t player, int varID) {
    if (!isValidPtr(player) || varID < 0) return 0;

    // VIP chain: Player + kDataPool(0x70) → +kDataPoolInner(0x10) → +entries[varID]*stride(0x8) + entriesBase(0x20) → +value(0x18)
    uint64_t priDataPool = ReadAddr<uint64_t>(player + GameOffsets::PlayerPRIDataPool);
    if (!isValidPtr(priDataPool)) return 0;

    uint64_t dataArray = ReadAddr<uint64_t>(priDataPool + GameOffsets::ReplicationDataPoolData);
    if (!isValidPtr(dataArray)) return 0;

    // VIP stride is 0x8 (sizeof(uint64_t)) — same as DS ArrayItems stride.
    uint64_t slotAddress = dataArray + GameOffsets::ArrayItems +
                           sizeof(uint64_t) * static_cast<uint64_t>(varID);
    uint64_t replicationData = ReadAddr<uint64_t>(slotAddress);
    if (!isValidPtr(replicationData)) return 0;

    // The scalar lives inline at +0x18 (ReplicationDataValue). If that slot
    // holds a valid pointer (unsafe-pool layout), dereference it first —
    // this matches VIP's behavior of reading through the pointer.
    uint64_t rawStorage = ReadAddr<uint64_t>(replicationData + GameOffsets::ReplicationDataValue);
    if (isValidPtr(rawStorage)) {
        uint16_t indirectValue = ReadAddr<uint16_t>(rawStorage);
        return indirectValue;
    }
    // Inline-union layout: read the low 16 bits of rawStorage (arm64 is
    // little-endian, so the low 2 bytes ARE the uint16_t value).
    return static_cast<uint16_t>(rawStorage & 0xFFFFULL);
}

// VIP's SetDataUInt16 — writes through the same chain without group check.
static bool AimWritePRIUInt16(uint64_t player, int varID, uint16_t value) {
    if (!isValidPtr(player) || varID < 0) return false;

    uint64_t priDataPool = ReadAddr<uint64_t>(player + GameOffsets::PlayerPRIDataPool);
    if (!isValidPtr(priDataPool)) return false;

    uint64_t dataArray = ReadAddr<uint64_t>(priDataPool + GameOffsets::ReplicationDataPoolData);
    if (!isValidPtr(dataArray)) return false;

    uint64_t slotAddress = dataArray + GameOffsets::ArrayItems +
                           sizeof(uint64_t) * static_cast<uint64_t>(varID);
    uint64_t replicationData = ReadAddr<uint64_t>(slotAddress);
    if (!isValidPtr(replicationData)) return false;

    uint64_t rawStorage = ReadAddr<uint64_t>(replicationData + GameOffsets::ReplicationDataValue);
    uint64_t targetAddress = replicationData + GameOffsets::ReplicationDataValue;
    if (isValidPtr(rawStorage)) targetAddress = rawStorage;

    return _write(RemoteWriteDomain::Aim, targetAddress, &value, sizeof(value));
}

// VIP's get_IsFiring / get_IsScoping — direct PRI reads, no group check.
static bool AimGetIsFiring(uint64_t player) {
    return isValidPtr(player) && AimReadPRIUInt16(player, GameOffsets::PriVarFire) == 2;
}

static bool AimGetIsScoping(uint64_t player) {
    return isValidPtr(player) && AimReadPRIUInt16(player, GameOffsets::PriVarScope) != 0;
}

#pragma mark - Aim point selection (VIP GetAimTargetPos)

// VIP bodyDir math + 4 positions + 3D sanity window [0.05, 5.0] m.
static Vector3 GetAimTargetPos(Vector3 head, Vector3 hip, int setting) {
    if (AimIsZeroVec(head) || AimIsZeroVec(hip)) return head;

    float dx = head.x - hip.x;
    float dy = head.y - hip.y;
    float dz = head.z - hip.z;
    float dist3D = sqrtf(dx * dx + dy * dy + dz * dz);
    if (dist3D < 0.05f || dist3D > 5.0f) {
        return Vector3(0, 0, 0);
    }

    Vector3 bodyDir = Vector3(dx, dy, dz);

    switch (setting) {
        case 0:
            return head;
        case 1:
            return Vector3(head.x - bodyDir.x * 0.18f,
                           head.y - bodyDir.y * 0.18f,
                           head.z - bodyDir.z * 0.18f);   // Neck
        case 2:
            return Vector3(head.x - bodyDir.x * 0.30f,
                           head.y - bodyDir.y * 0.30f,
                           head.z - bodyDir.z * 0.30f);   // Chest
        case 3:
            return Vector3(head.x - bodyDir.x * 0.072f,
                           head.y - bodyDir.y * 0.072f,
                           head.z - bodyDir.z * 0.072f);   // Upper Head
        default:
            return head;
    }
}

static uint64_t ReadHipTransform(uint64_t pawn) {
    uint64_t bodyPart = ReadAddr<uint64_t>(pawn + GameOffsets::PlayerHipNode);
    if (!isValidPtr(bodyPart)) return 0;
    return ReadAddr<uint64_t>(bodyPart + GameOffsets::TransformNodeTransform);
}

#pragma mark - Weapon data (VIP chain, dump-verified 1.132.1)

// VIP WeaponData struct + GetWeaponData. Chain: Player.InventoryManager(0x740)
// → itemOnHand(0xA0) → weapon → UGCWeaponRepItem(0x768).
static AimWeaponData GetWeaponData(uint64_t pawn) {
    AimWeaponData wd{0.1f, false, 100.0f, 200.0f}; // VIP defaults
    if (!isValidPtr(pawn)) return wd;

    uint64_t inventory = ReadAddr<uint64_t>(pawn + GameOffsets::PlayerInventoryManager);
    if (!isValidPtr(inventory)) return wd;

    uint64_t weapon = ReadAddr<uint64_t>(inventory + GameOffsets::InventoryItemOnHand);
    if (!isValidPtr(weapon)) return wd;

    uint64_t repItem = ReadAddr<uint64_t>(weapon + GameOffsets::WeaponRepItem);
    if (!isValidPtr(repItem)) return wd;

    wd.fireInterval       = ReadAddr<float>(repItem + GameOffsets::WeaponFireInterval);
    wd.isSingleShot       = ReadAddr<bool>(repItem + GameOffsets::WeaponIsSingleShot);
    wd.fullDamageDistance = ReadAddr<float>(repItem + GameOffsets::WeaponFullDamageDistance);
    wd.range              = ReadAddr<float>(repItem + GameOffsets::WeaponRange);

    // VIP validation clamps — keep implausible reads inert.
    if (wd.fireInterval < 0.01f || wd.fireInterval > 5.0f) wd.fireInterval = 0.1f;
    if (wd.fullDamageDistance < 1.0f || wd.fullDamageDistance > 1000.0f) wd.fullDamageDistance = 100.0f;
    if (wd.range < 1.0f || wd.range > 1000.0f) wd.range = 200.0f;
    return wd;
}

#pragma mark - Velocity sampling + prediction (VIP PredictTargetPosition)

// VIP SampleTargetVelocity: 1) read PhysicalCCT velocity (clamp 100 m/s),
// 2) blend with finite-difference tracker (0.7/0.3 when engine vel present,
// 0.6/0.4 when not). Returns the blended velocity for travel-time prediction.
static Vector3 SampleTargetVelocity(uint64_t pawn, Vector3 currentPos) {
    // 1. Authoritative engine velocity from PhysicalCCT.
    Vector3 gameVel = Vector3(0, 0, 0);
    uint64_t physCCT = ReadAddr<uint64_t>(pawn + GameOffsets::PlayerPhysicalCCT);
    if (isValidPtr(physCCT)) {
        gameVel = ReadAddr<Vector3>(physCCT + GameOffsets::PhysicalCCTVelocity);
        float vmag = sqrtf(gameVel.x * gameVel.x + gameVel.y * gameVel.y + gameVel.z * gameVel.z);
        if (!(vmag == vmag) || vmag > kVelocityMaxMagnitude) gameVel = Vector3(0, 0, 0);
    }

    // 2. Tracker fallback: finite-difference velocity across frames.
    double now = AimMediaTime();
    int idx = -1;
    for (int i = 0; i < gVelocityTrackerCount; i++) {
        if (gVelocityTracker[i].pawn == pawn) { idx = i; break; }
    }
    if (idx == -1) {
        if (gVelocityTrackerCount >= kVelocityTrackerCapacity) return gameVel;
        idx = gVelocityTrackerCount++;
        gVelocityTracker[idx].pawn = pawn;
        gVelocityTracker[idx].lastHeadPos = currentPos;
        gVelocityTracker[idx].velocity = gameVel;
        gVelocityTracker[idx].lastTime = now;
        return gameVel;
    }

    double dt = now - gVelocityTracker[idx].lastTime;
    Vector3 finalVel = gameVel;
    if (dt > 0.001 && dt < 0.5) {
        Vector3 deltaPos = currentPos - gVelocityTracker[idx].lastHeadPos;
        Vector3 calcVel = deltaPos / static_cast<float>(dt);
        if (AimIsZeroVec(gameVel)) {
            finalVel = gVelocityTracker[idx].velocity * 0.6f + calcVel * 0.4f;
        } else {
            finalVel = gameVel * 0.7f + calcVel * 0.3f;
        }
    }

    gVelocityTracker[idx].lastHeadPos = currentPos;
    gVelocityTracker[idx].velocity = finalVel;
    gVelocityTracker[idx].lastTime = now;
    return finalVel;
}

// VIP PredictTargetPosition — distance → travelTime via weapon data, then
// extrapolate currentPos + finalVel * travelTime.
static Vector3 PredictTargetPosition(uint64_t pawn,
                                     Vector3 currentPos,
                                     float distance,
                                     const AimWeaponData &weapon) {
    if (!isValidPtr(pawn)) return currentPos;

    Vector3 finalVel = SampleTargetVelocity(pawn, currentPos);
    if (distance > weapon.range) return currentPos;

    float travelTime = distance / weapon.fullDamageDistance;
    if (travelTime > weapon.fireInterval) travelTime = weapon.fireInterval;
    if (travelTime < 0.0f) travelTime = 0.0f;

    return currentPos + finalVel * travelTime;
}

#pragma mark - Aim steering (VIP set_aim)

// VIP set_aim — writes AuxAimResetTime=0 for instant retarget, widens pitch
// limits to ±89°, handles scope-release transition, then Slerps the rotation
// into both aim slots. Slerp factor: firing=0.97, scoping=0.92, normal=0.85.
//
// Note: VIP does NOT scale t by aimSpeed. The original DS port did, but the
// user reported it didn't behave like VIP — so this is now a byte-for-byte
// match of VIP's set_aim.
static bool AimWriteSteering(uint64_t myPawn,
                             Quaternion rotation,
                             bool isFiring,
                             bool isScoping,
                             bool instant) {
    if (!isValidPtr(myPawn)) return false;

    bool wrote = false;
    float zero = 0.0f;
    wrote |= WriteAddr<float>(RemoteWriteDomain::Aim,
                              myPawn + GameOffsets::PlayerAuxAimResetTime, zero);
    wrote |= WriteAddr<float>(RemoteWriteDomain::Aim,
                              myPawn + GameOffsets::PlayerMinAngleX, -89.0f);
    wrote |= WriteAddr<float>(RemoteWriteDomain::Aim,
                              myPawn + GameOffsets::PlayerMaxAngleX, 89.0f);

    // Scope release: restore the current rotation instead of chasing the
    // stale target quaternion (VIP gWasScoping transition).
    if (gWasScoping && !isScoping) {
        Quaternion currentRot = ReadAddr<Quaternion>(myPawn + GameOffsets::PlayerAimRotation);
        wrote |= WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                       myPawn + GameOffsets::PlayerAimRotation, currentRot);
        wrote |= WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                       myPawn + GameOffsets::PlayerAimRotationAux, currentRot);
        gWasScoping = false;
        return wrote;
    }
    gWasScoping = isScoping;

    Quaternion q = Quaternion::Normalized(rotation);
    Quaternion current = ReadAddr<Quaternion>(myPawn + GameOffsets::PlayerAimRotation);

    if (instant) {
        // Single-shot weapons: snap exactly onto the predicted point.
        wrote |= WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                       myPawn + GameOffsets::PlayerAimRotation, q);
        wrote |= WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                       myPawn + GameOffsets::PlayerAimRotationAux, q);
        return wrote;
    }

    float angle = Quaternion::Angle(current, q);
    if (angle < 0.0005f) return wrote;

    // VIP Slerp factors — firing=0.97, scoping=0.92, normal=0.85.
    // (No aimSpeed scaling in VIP — kept that way for parity.)
    float t = isFiring ? 0.97f
            : isScoping ? 0.92f
                        : 0.85f;

    Quaternion out = Quaternion::Normalized(Quaternion::Slerp(current, q, t));
    wrote |= WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                   myPawn + GameOffsets::PlayerAimRotation, out);
    wrote |= WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                   myPawn + GameOffsets::PlayerAimRotationAux, out);
    return wrote;
}

#pragma mark - Engine

@implementation AimAssistEngine {
    uint32_t _syncCounter;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _syncCounter = 0;
    }
    return self;
}

- (void)reset {
    gAimLockTarget = 0;
    gAimLockLostFrames = 0;
    gWasScoping = false;
    gVelocityTrackerCount = 0;
    memset(gVelocityTracker, 0, sizeof(gVelocityTracker));
}

- (BOOL)isFovVisible {
    return gAimbot && gShowFov;
}

- (float)fovRadius {
    return gAimFov;
}

- (void)syncPreferences {
    // Prefs are cheap to read but the worker ticks up to 30 Hz; sync every
    // 8 ticks (~0.27 s at 30 Hz) so in-game menu changes land quickly while
    // keeping NSUserDefaults traffic negligible.
    if (++_syncCounter < 8) {
        return;
    }
    _syncCounter = 0;

    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    gAimbot          = [d boolForKey:@"renew.aimbot"];
    gShowFov         = [d objectForKey:@"renew.showFov"] ? [d boolForKey:@"renew.showFov"] : YES;
    gAimLine         = [d boolForKey:@"renew.aimLine"];
    gAimIgnoreBot    = [d boolForKey:@"renew.aimIgnoreBot"];
    gAimIgnoreKnock  = [d boolForKey:@"renew.aimIgnoreKnock"];
    gAimCheckVisible = [d objectForKey:@"renew.aimCheckVisible"] ? [d boolForKey:@"renew.aimCheckVisible"] : YES;

    NSInteger pos = [d integerForKey:@"renew.aimPos"];
    gAimPosition = (pos >= 0 && pos <= 3) ? static_cast<int>(pos) : 0;

    NSInteger trigger = [d integerForKey:@"renew.aimTrigger"];
    gTriggerMode = (trigger >= 0 && trigger <= 3) ? static_cast<int>(trigger) : 0;

    float fov = [d floatForKey:@"renew.aimFov"];
    if (fov != 0.0f) gAimFov = AimClamp(fov, kAimFovMin, kAimFovMax);
    else gAimFov = 250.0f;

    float speed = [d floatForKey:@"renew.aimSpeed"];
    if (speed != 0.0f) gAimSpeed = AimClamp(speed, kAimSpeedMin, kAimSpeedMax);
    else gAimSpeed = 1000.0f;

    // Arm the write domain only while aimbot is on. The aim pass itself runs
    // even when writes are disarmed (the FOV circle still renders), but every
    // WriteAddr call below fails closed unless this is armed.
    SetRemoteWriteDomainEnabled(RemoteWriteDomain::Aim, gAimbot);
}

- (AimAssistOutcome)processSnapshot:(ESPFrameSnapshot *)snapshot
                         projection:(const CameraProjection *)projection
                        screenWidth:(float)screenWidth
                       screenHeight:(float)screenHeight {
    AimAssistOutcome outcome = {};
    outcome.showFov = gShowFov;
    outcome.fovRadius = gAimFov;
    outcome.showLine = gAimLine;
    outcome.active = gAimbot;

    if (!gAimbot || !snapshot.isValid || !projection ||
        !(screenWidth > 1.0f) || !(screenHeight > 1.0f)) {
        gAimLockTarget = 0;
        gAimLockLostFrames = 0;
        outcome.active = NO;
        outcome.showFov = NO;
        return outcome;
    }

    uint64_t myPawn = snapshot.localPlayer;
    if (!isValidPtr(myPawn)) {
        gAimLockTarget = 0;
        outcome.active = NO;
        outcome.showFov = NO;
        return outcome;
    }

    const float *matrix = projection->matrix;
    const CameraMatrixLayout layout = projection->layout;
    const CGPoint center = CGPointMake(screenWidth * 0.5f, screenHeight * 0.5f);
    const Vector3 myLoc = snapshot.localPosition;

    // Weapon profile of the LOCAL player — drives travel-time prediction and
    // the single-shot snap branch. (VIP reads the LOCAL player's weapon.)
    const AimWeaponData myWeapon = GetWeaponData(myPawn);

    const float aimFov = gAimFov;
    const float selectRadius = aimFov * 3.0f; // VIP selection window (3x drawn FOV)
    const float selectRadiusSq = selectRadius * selectRadius;

    uint64_t bestTarget = 0;
    Vector3 bestAimPos(0, 0, 0);
    float bestScore = FLT_MAX;
    float bestDistance = FLT_MAX;
    CGPoint bestScreen = center;

    for (ESPPlayerData *p in snapshot.players) {
        if (p.pawn == 0 || !isValidPtr(p.pawn)) continue;
        if (gAimIgnoreBot && p.isBot) continue;
        if (gAimIgnoreKnock && p.isKnocked) continue;
        if (p.distance > kAimMaxDistance || p.distance <= 0.0f) continue;

        // Cheap head projection first; only candidates near the crosshair
        // pay for hip/visibility reads.
        Vector3 w2sHead = WorldToScreen(p.headWorld, matrix, layout,
                                        screenWidth, screenHeight);
        if (!(w2sHead.z > 0.01f)) continue;
        float dxHead = w2sHead.x - center.x;
        float dyHead = w2sHead.y - center.y;
        float headDistSq = dxHead * dxHead + dyHead * dyHead;
        if (headDistSq > selectRadiusSq * 4.0f) continue; // coarse reject (>2x window)

        Vector3 hipWorld = Vector3(0, 0, 0);
        uint64_t hipTransform = ReadHipTransform(p.pawn);
        if (isValidPtr(hipTransform)) hipWorld = getPositionExt(hipTransform);

        Vector3 aimPos = GetAimTargetPos(p.headWorld, hipWorld, gAimPosition);
        if (AimIsZeroVec(aimPos)) continue;

        Vector3 w2sAim = WorldToScreen(aimPos, matrix, layout,
                                       screenWidth, screenHeight);
        if (!(w2sAim.z > 0.01f)) continue;

        float dx = w2sAim.x - center.x;
        float dy = w2sAim.y - center.y;
        float dSq = dx * dx + dy * dy;
        if (dSq > selectRadiusSq) continue;

        if (gAimCheckVisible && !IsPlayerModelVisible(p.pawn)) continue;

        // VIP scoring: screen distance dominates, locked target and
        // close-range enemies get multiplicative priority.
        float score = dSq;
        if (p.pawn == gAimLockTarget) score *= 0.5f;
        if (p.distance < kAimCloseRangeBonus) score *= 0.7f;

        if (score < bestScore) {
            bestScore = score;
            bestDistance = p.distance;
            bestTarget = p.pawn;
            bestAimPos = aimPos;
            bestScreen = CGPointMake(w2sAim.x, w2sAim.y);
        }
    }

    // Lock persistence (VIP: 2 lost frames).
    if (!gAimbot) {
        gAimLockTarget = 0;
        gAimLockLostFrames = 0;
    } else if (bestTarget) {
        gAimLockTarget = bestTarget;
        gAimLockLostFrames = 0;
    } else if (gAimLockTarget) {
        if (++gAimLockLostFrames > kAimLockMaxLostFrames) {
            gAimLockTarget = 0;
            gAimLockLostFrames = 0;
        }
    }

    outcome.hasTarget = (bestTarget != 0 && gAimLockTarget != 0);
    if (outcome.hasTarget) {
        outcome.targetPoint = bestScreen;
        outcome.targetDistance = bestDistance;
    }

    if (!gAimbot) return outcome;

    // VIP trigger mode logic — direct PRI reads (no group check).
    const bool firing = AimGetIsFiring(myPawn);
    const bool scoping = AimGetIsScoping(myPawn);

    bool shouldAim = false;
    if (gTriggerMode == 0)      shouldAim = true;
    else if (gTriggerMode == 1) shouldAim = firing;
    else if (gTriggerMode == 2) shouldAim = scoping;
    else if (gTriggerMode == 3) shouldAim = (firing || scoping);

    if (bestTarget && shouldAim && bestDistance >= 0.2f) {
        // VIP: PredictTargetPosition(bestTarget, bestAimPos, bestDistance, fire)
        // — note VIP passes `fire` (4th arg) but the function ignores it; we
        // pass myWeapon for travel-time computation (matches VIP intent).
        Vector3 finalTarget = PredictTargetPosition(bestTarget, bestAimPos,
                                                    bestDistance, myWeapon);
        if (!AimIsZeroVec(finalTarget)) {
            Quaternion exactQ = GetRotationToLocation(finalTarget, myLoc);

            // VIP: set_aim (Slerp + AuxAimResetTime + angle limits).
            bool wrote = AimWriteSteering(myPawn, exactQ, firing, scoping,
                                          /*instant=*/false);
            outcome.firedRemote |= wrote;

            // VIP single-shot branch (AWM/M590): snap precisely onto the
            // velocity-extrapolated point before the trigger lands.
            if (myWeapon.isSingleShot) {
                // VIP reads target velocity directly from PhysicalCCT.
                Vector3 targetVel = {0, 0, 0};
                uint64_t targetPhys = ReadAddr<uint64_t>(bestTarget + GameOffsets::PlayerPhysicalCCT);
                if (isValidPtr(targetPhys)) {
                    targetVel = ReadAddr<Vector3>(targetPhys + GameOffsets::PhysicalCCTVelocity);
                }

                // VIP: travelTime = distance / fullDamageDistance, clamped by fireInterval.
                float travelTime = bestDistance / myWeapon.fullDamageDistance;
                if (travelTime > myWeapon.fireInterval) travelTime = myWeapon.fireInterval;
                if (travelTime < 0.0f) travelTime = 0.0f;

                Vector3 preciseTarget = bestAimPos + targetVel * travelTime;
                Quaternion preciseQ = GetRotationToLocation(preciseTarget, myLoc);

                // VIP: snap aim exactly (no Slerp, write directly).
                wrote = AimWriteSteering(myPawn, preciseQ, firing, scoping,
                                         /*instant=*/true);
                outcome.firedRemote |= wrote;
            }

            // VIP: while firing, force the exact rotation (hard-write).
            if (firing) {
                Quaternion q = Quaternion::Normalized(exactQ);
                bool forced =
                    WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                          myPawn + GameOffsets::PlayerAimRotation, q) ||
                    WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                          myPawn + GameOffsets::PlayerAimRotationAux, q);
                outcome.firedRemote |= forced;
            }

            // VIP auto-fire: triggerMode == 1 (Fire) OR (triggerMode == 3 && fire).
            // Writes PriVarFire=21 to value 2 (firing state).
            if (gTriggerMode == 1 || (gTriggerMode == 3 && firing)) {
                bool fired = AimWritePRIUInt16(myPawn, GameOffsets::PriVarFire, 2);
                outcome.firedRemote |= fired;
                if (fired) {
                    Quaternion q = Quaternion::Normalized(exactQ);
                    WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                          myPawn + GameOffsets::PlayerAimRotation, q);
                    WriteAddr<Quaternion>(RemoteWriteDomain::Aim,
                                          myPawn + GameOffsets::PlayerAimRotationAux, q);
                }
            }

            gWasScoping = scoping;
        }
    } else {
        // VIP no-target branch: keep current rotation but still zero
        // AuxAimResetTime + widen pitch limits so next acquisition is instant.
        if (gAimbot) {
            Quaternion currentRot = ReadAddr<Quaternion>(myPawn + GameOffsets::PlayerAimRotation);
            bool wrote = AimWriteSteering(myPawn, currentRot, firing, scoping,
                                          /*instant=*/false);
            outcome.firedRemote |= wrote;
        }

        if (gAimLockTarget != 0) {
            gAimLockTarget = 0;
            gAimLockLostFrames = 0;
            outcome.hasTarget = NO;
        }
    }

    return outcome;
}

@end
