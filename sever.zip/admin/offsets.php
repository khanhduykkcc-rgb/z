<?php
/**
 * ADMIN — OFFSETS (Task 17).
 *
 * Kho offset server-authoritative: client không chứa offset, chỉ nhận qua
 * action=offsets khi session license hợp lệ. Trang này để:
 *   • xem bộ offset đang kích hoạt (app đang dùng bản nào, bao nhiêu slot)
 *   • sửa payload JSON + game_version khi game update (không cần build lại app)
 *   • thêm phiên bản mới, bật/tắt, xóa
 *   • TẮT HẾT (deactivate mọi bản) = KILL SWITCH — client không chạy
 *     ESP/Aim cho tới khi bật lại.
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/license_api.php';

require_admin();

require_once __DIR__ . '/../includes/offsets_data.php';

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

/**
 * Validate payload JSON: phải là object name => giá trị hex/thập phân.
 * So khớp bộ khóa với seed mặc định (client TỪ CHỐI payload thiếu slot).
 *
 * @return array{ok:bool, error:string, data:array, slots:int}
 */
function offsets_validate_payload(string $raw): array
{
    $trimmed = trim($raw);
    if ($trimmed === '') {
        return ['ok' => false, 'error' => 'Payload trống.', 'data' => [], 'slots' => 0];
    }
    $decoded = json_decode($trimmed, true);
    if (!is_array($decoded) || $decoded === []) {
        return ['ok' => false, 'error' => 'Payload phải là JSON object {"Name":"0x...","...":...}.', 'data' => [], 'slots' => 0];
    }
    foreach ($decoded as $k => $v) {
        if (!is_string($k) || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', (string) $k)) {
            return ['ok' => false, 'error' => "Tên offset không hợp lệ: {$k}", 'data' => [], 'slots' => 0];
        }
        if (!is_string($v) || !preg_match('/^(0[xX][0-9a-fA-F]+|[0-9]+)$/', $v)) {
            return ['ok' => false, 'error' => "Giá trị của {$k} phải là chuỗi hex (\"0x1A4\") hoặc thập phân (\"420\").", 'data' => [], 'slots' => 0];
        }
    }
    $defaultKeys = array_keys(OffsetsData::defaults());
    $missing = array_diff($defaultKeys, array_keys($decoded));
    if ($missing !== []) {
        $show = array_slice(array_values($missing), 0, 5);
        $more = count($missing) > 5 ? ' …' : '';
        return ['ok' => false,
                'error' => 'Payload thiếu ' . count($missing) . ' offset bắt buộc: ' . implode(', ', $show) . $more,
                'data' => [], 'slots' => 0];
    }
    $extra = array_diff(array_keys($decoded), $defaultKeys);
    if ($extra !== []) {
        return ['ok' => false,
                'error' => 'Payload có offset lạ client không dùng: ' . implode(', ', array_slice(array_values($extra), 0, 5)),
                'data' => [], 'slots' => 0];
    }
    return ['ok' => true, 'error' => '', 'data' => $decoded, 'slots' => count($decoded)];
}

function offsets_fetch_all(): array
{
    try {
        return db_query(
            'SELECT id, game_version, payload, is_active, created_at, updated_at
             FROM license_offsets ORDER BY is_active DESC, id DESC'
        )->fetchAll() ?: [];
    } catch (Throwable $e) {
        LicenseApi::ensureV2Tables(true);
        try {
            return db_query(
                'SELECT id, game_version, payload, is_active, created_at, updated_at
                 FROM license_offsets ORDER BY is_active DESC, id DESC'
            )->fetchAll() ?: [];
        } catch (Throwable $e2) {
            return [];
        }
    }
}

function offsets_fetch_one(int $id): ?array
{
    try {
        $row = db_query(
            'SELECT id, game_version, payload, is_active, created_at, updated_at
             FROM license_offsets WHERE id = ? LIMIT 1',
            [$id]
        )->fetch();
        return is_array($row) ? $row : null;
    } catch (Throwable $e) {
        return null;
    }
}

/* ------------------------------------------------------------------ */
/*  POST actions                                                       */
/* ------------------------------------------------------------------ */

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'save') {
        $id          = (int) ($_POST['id'] ?? 0);
        $gameVersion = trim((string) ($_POST['game_version'] ?? ''));
        $payloadRaw  = (string) ($_POST['payload'] ?? '');
        $isActive    = isset($_POST['is_active']) ? 1 : 0;

        if ($gameVersion === '' || mb_strlen($gameVersion) > 32) {
            set_flash('Game version trống hoặc dài quá 32 ký tự.', 'danger');
            redirect('offsets.php' . ($id > 0 ? '?id=' . $id : ''));
        }
        $check = offsets_validate_payload($payloadRaw);
        if (!$check['ok']) {
            set_flash('Payload không hợp lệ: ' . $check['error'], 'danger');
            redirect('offsets.php' . ($id > 0 ? '?id=' . $id : ''));
        }
        $payloadJson = json_encode($check['data'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (!is_string($payloadJson)) {
            set_flash('Không encode được payload JSON.', 'danger');
            redirect('offsets.php' . ($id > 0 ? '?id=' . $id : ''));
        }

        try {
            if ($id > 0 && offsets_fetch_one($id) !== null) {
                db_query(
                    'UPDATE license_offsets
                     SET game_version = ?, payload = ?, is_active = ?, updated_at = ? WHERE id = ?',
                    [$gameVersion, $payloadJson, $isActive, time(), $id]
                );
                if ($isActive === 1) {
                    db_query('UPDATE license_offsets SET is_active = 0 WHERE id <> ?', [$id]);
                }
                set_flash("Đã lưu bản offset #{$id} ({$check['slots']} slot, game {$gameVersion}).", 'success');
            } else {
                db_query(
                    'INSERT INTO license_offsets (game_version, payload, is_active, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?)',
                    [$gameVersion, $payloadJson, $isActive, time(), time()]
                );
                $newId = (int) db()->lastInsertId();
                if ($isActive === 1 && $newId > 0) {
                    db_query('UPDATE license_offsets SET is_active = 0 WHERE id <> ?', [$newId]);
                }
                set_flash("Đã tạo bản offset #{$newId} ({$check['slots']} slot, game {$gameVersion}).", 'success');
            }
        } catch (Throwable $e) {
            set_flash('Không lưu được — lỗi database (bảng license_offsets có thể chưa được tạo, hãy mở lại trang này một lần nữa để tự tạo).', 'danger');
        }
        redirect('offsets.php');
    }

    if ($action === 'activate') {
        $id = (int) ($_POST['id'] ?? 0);
        try {
            db_query('UPDATE license_offsets SET is_active = 0 WHERE is_active = 1', []);
            $n = db_query('UPDATE license_offsets SET is_active = 1, updated_at = ? WHERE id = ?', [time(), $id])->rowCount();
            set_flash($n > 0 ? "Đã KÍCH HOẠT bản offset #{$id} — client sẽ nhận ở lần fetch offset kế tiếp." : 'Không tìm thấy bản offset.', $n > 0 ? 'success' : 'danger');
        } catch (Throwable $e) {
            set_flash('Không kích hoạt được — lỗi database.', 'danger');
        }
        redirect('offsets.php');
    }

    if ($action === 'deactivate') {
        $id = (int) ($_POST['id'] ?? 0);
        try {
            db_query('UPDATE license_offsets SET is_active = 0, updated_at = ? WHERE id = ?', [time(), $id]);
            set_flash("Đã TẮT bản offset #{$id}. LƯU Ý: nếu không còn bản nào active, toàn bộ client sẽ KHÔNG chạy được ESP/Aim (kill switch).", 'warning');
        } catch (Throwable $e) {
            set_flash('Không tắt được — lỗi database.', 'danger');
        }
        redirect('offsets.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        try {
            db_query('DELETE FROM license_offsets WHERE id = ?', [$id]);
            set_flash("Đã xóa bản offset #{$id}.", 'success');
        } catch (Throwable $e) {
            set_flash('Không xóa được — lỗi database.', 'danger');
        }
        redirect('offsets.php');
    }

    http_response_code(400);
    exit('Unknown action');
}

/* ------------------------------------------------------------------ */
/*  View                                                               */
/* ------------------------------------------------------------------ */

/* Tự tạo bảng + seed (idempotent) trước khi đọc */
LicenseApi::ensureV2Tables();

$rows = offsets_fetch_all();
$editId = (int) ($_GET['id'] ?? 0);
$editing = null;
foreach ($rows as $r) {
    if ((int) $r['id'] === $editId) {
        $editing = $r;
        break;
    }
}
if ($editing === null) {
    /* Mặc định: form "tạo mới" pre-fill từ bản đang active (hoặc seed) */
    $active = null;
    foreach ($rows as $r) {
        if ((int) $r['is_active'] === 1) {
            $active = $r;
            break;
        }
    }
    $editing = [
        'id'           => 0,
        'game_version' => $active['game_version'] ?? OffsetsData::GAME_VERSION,
        'payload'      => $active['payload'] ?? json_encode(OffsetsData::defaults(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        'is_active'    => 0,
        'created_at'   => null,
        'updated_at'   => null,
    ];
}

$activeCount = 0;
foreach ($rows as $r) {
    if ((int) $r['is_active'] === 1) {
        $activeCount++;
    }
}

layout_header('Offsets', 'offsets');
?>
<div class="settings-grid">

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('code', 17); ?> Offsets — cấp cho client đã activate key</h2>
        </div>
        <div class="notice notice-info">
            <?php echo icon('shield', 18); ?>
            <div>
                App <b>không chứa offset</b>. ESP/Aim chỉ chạy khi client fetch offset thành công qua
                <code>action=offsets</code> (session hợp lệ + chữ ký server verify). Sửa ở đây là
                <b>không cần build lại app</b> — client fetch lại ở lần auth/renew kế tiếp.
                <?php if ($activeCount === 0): ?>
                    <br><b style="color:#c0392b;">Hiện KHÔNG có bản nào đang kích hoạt — toàn bộ client đang bị kill switch (ESP/Aim tắt).</b>
                <?php endif; ?>
            </div>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Game version</th>
                <th>Slots</th>
                <th>Trạng thái</th>
                <th>Cập nhật</th>
                <th class="cell-actions">Hành động</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
            <tr><td colspan="6" class="cell-muted">Chưa có bản offset nào (bảng mới tạo — seed mặc định sẽ tự chèn lần request API kế tiếp, hoặc tạo tay bên dưới).</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $r): ?>
            <?php
                $slots = 0;
                $dec = json_decode((string) $r['payload'], true);
                if (is_array($dec)) {
                    $slots = count($dec);
                }
            ?>
            <tr>
                <td class="cell-strong">#<?= (int) $r['id'] ?></td>
                <td><?= e((string) $r['game_version']) ?></td>
                <td><?= (int) $slots ?></td>
                <td>
                    <?php if ((int) $r['is_active'] === 1): ?>
                        <span class="role-chip role-chip-admin"><?php echo icon('shield', 11); ?> Đang dùng</span>
                    <?php else: ?>
                        <span class="cell-muted">Tắt</span>
                    <?php endif; ?>
                </td>
                <td class="cell-muted"><?= format_datetime($r['updated_at'] ? date('Y-m-d H:i:s', (int) $r['updated_at']) : null) ?></td>
                <td class="cell-actions">
                    <a class="btn btn-secondary" href="offsets.php?id=<?= (int) $r['id'] ?>"><?php echo icon('menu', 13); ?> Sửa</a>
                    <?php if ((int) $r['is_active'] !== 1): ?>
                    <form method="post" class="inline-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="activate">
                        <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                        <button type="submit" class="btn btn-primary"><?php echo icon('shield', 13); ?> Kích hoạt</button>
                    </form>
                    <?php else: ?>
                    <form method="post" class="inline-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="deactivate">
                        <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                        <button type="submit" class="btn btn-secondary"><?php echo icon('device', 13); ?> Tắt</button>
                    </form>
                    <?php endif; ?>
                    <form method="post" class="inline-form" data-confirm="Xóa bản offset #<?= (int) $r['id'] ?>?">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                        <button type="submit" class="btn btn-danger"><?php echo icon('warning', 13); ?> Xóa</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('package', 17); ?> <?= $editing['id'] > 0 ? 'Sửa bản offset #' . (int) $editing['id'] : 'Tạo bản offset mới' ?></h2>
        </div>
        <form method="post" class="settings-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) $editing['id'] ?>">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="game_version">Game version</label>
                    <input type="text" id="game_version" name="game_version" class="form-control" maxlength="32"
                           value="<?= e((string) $editing['game_version']) ?>" required>
                    <p class="form-hint">Ví dụ: 1.132.1 — hiển thị chẩn đoán trên client khi áp offset.</p>
                </div>
                <div class="form-group">
                    <label class="form-label toggle-row">
                        <input type="checkbox" name="is_active" value="1"<?= ((int) $editing['is_active'] === 1) ? ' checked' : '' ?>>
                        <span>Kích hoạt ngay (tắt các bản khác)</span>
                    </label>
                    <p class="form-hint">Chỉ 1 bản active tại một thời điểm.</p>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label" for="payload">Payload JSON (<?= count(OffsetsData::defaults()) ?> offset bắt buộc)</label>
                <textarea id="payload" name="payload" class="form-control" rows="14" style="font-family:monospace;font-size:12px;"
                          spellcheck="false" required><?= e((string) $editing['payload']) ?></textarea>
                <p class="form-hint">Định dạng: {"PlayerId":"0x408","PlayerIsDead":"0x7c",…}. Giá trị dạng "0x…" hex hoặc "123" thập phân.
                    Thiếu bất kỳ offset nào trong danh sách bắt buộc → client TỪ CHỐI toàn bộ payload (ESP/Aim không chạy).</p>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo icon('shield', 15); ?> <?= $editing['id'] > 0 ? 'Lưu thay đổi' : 'Tạo bản offset' ?></button>
            <?php if ($editing['id'] > 0): ?>
                <a class="btn btn-secondary" href="offsets.php">Hủy — tạo bản mới</a>
            <?php endif; ?>
        </form>
    </div>

</div>
<?php layout_footer();
