<?php
/**
 * Settings (admin): đổi mật khẩu của chính mình + CẤU HÌNH HỆ THỐNG
 * (hạn mức mặc định cho user mới, mở/tắt đăng ký công khai).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/license_api.php';
require_once __DIR__ . '/../includes/license_crypto.php';

require_admin();

$me = current_user();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'password') {
        $current = (string) ($_POST['current_password'] ?? '');
        $new     = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        try {
            $hash = db_query('SELECT password_hash FROM tbl_users WHERE id = ?', [$me['id']])->fetchColumn();

            if (!password_verify($current, $hash)) {
                set_flash('Mật khẩu hiện tại không đúng.', 'danger');
            } elseif (strlen($new) < 8) {
                set_flash('Mật khẩu mới phải có ít nhất 8 ký tự.', 'danger');
            } elseif ($new !== $confirm) {
                set_flash('Xác nhận mật khẩu mới không khớp.', 'danger');
            } else {
                db_query('UPDATE tbl_users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $me['id']]);
                set_flash('Đã đổi mật khẩu thành công.', 'success');
            }
        } catch (Throwable $e) {
            set_flash('Không đổi được mật khẩu — lỗi hệ thống.', 'danger');
        }
        redirect('settings.php');
    }

    if ($action === 'system') {
        $maxPackages = max(0, min(1000000, (int) ($_POST['default_max_packages'] ?? 3)));
        $maxKeys     = max(0, min(1000000, (int) ($_POST['default_max_keys'] ?? 10)));
        $allowReg    = isset($_POST['allow_registration']) ? '1' : '0';
        $legacyV1    = isset($_POST['legacy_v1_api']) ? '1' : '0';
        $leaseTtl    = max(60, min(7200, (int) ($_POST['license_lease_ttl'] ?? 600)));
        $graceTtl    = max(0, min(86400, (int) ($_POST['license_grace_ttl'] ?? 900)));

        try {
            set_setting('default_max_packages', (string) $maxPackages);
            set_setting('default_max_keys', (string) $maxKeys);
            set_setting('allow_registration', $allowReg);
            set_setting('legacy_v1_api', $legacyV1);
            set_setting('license_lease_ttl', (string) $leaseTtl);
            set_setting('license_grace_ttl', (string) $graceTtl);
            set_flash('Đã lưu cấu hình hệ thống (kể cả license V2).', 'success');
        } catch (Throwable $e) {
            set_flash('Không lưu được cấu hình — lỗi hệ thống.', 'danger');
        }
        redirect('settings.php');
    }

    if ($action === 'rotate_signing_key') {
        try {
            $newPriv = LicenseCrypto::rotate();
            if ($newPriv === null) {
                set_flash('Không sinh được khóa mới — kiểm tra OpenSSL + quyền ghi includes/.', 'danger');
            } else {
                $pub = LicenseCrypto::publicKeyForClient();
                if ($pub !== null) {
                    set_setting(LicenseCrypto::SETTING_PUBKEY, $pub);
                }
                set_flash('Đã ROTATE khóa ký. Mọi client đang chạy sẽ từ chối phản hồi mới → build lại app với public key mới (xem bên dưới) và phát hành.', 'warning');
            }
        } catch (Throwable $e) {
            set_flash('Rotate khóa thất bại.', 'danger');
        }
        redirect('settings.php');
    }

    http_response_code(400);
    exit('Unknown action');
}

try {
    $serverVersion = (string) db_query('SELECT VERSION()')->fetchColumn();
} catch (Throwable $e) {
    $serverVersion = '';
}

$defaults = get_default_limits();

layout_header('Settings', 'settings');
?>
<div class="settings-grid">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('user', 17); ?> Tài khoản của tôi</h2>
        </div>
        <dl class="detail-list detail-list-page">
            <dt>Username</dt><dd class="cell-strong"><?= e($me['username']) ?></dd>
            <dt>Vai trò</dt><dd><span class="role-chip role-chip-admin"><?php echo icon('shield', 11); ?> Admin — toàn quyền</span></dd>
            <dt>Ngày tạo</dt><dd><?= format_datetime($me['created_at']) ?></dd>
            <dt>Đăng nhập lần cuối</dt><dd><?= format_datetime($me['last_login_at']) ?></dd>
        </dl>
        <form method="post" class="settings-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="password">
            <h3 class="form-section-title">Đổi mật khẩu</h3>
            <div class="form-group">
                <label class="form-label" for="current_password">Mật khẩu hiện tại</label>
                <input type="password" id="current_password" name="current_password" class="form-control" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="new_password">Mật khẩu mới</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" minlength="8" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="confirm_password">Xác nhận mật khẩu mới</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" minlength="8" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo icon('shield', 15); ?> Cập nhật mật khẩu</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('settings', 17); ?> Cấu hình hệ thống</h2>
        </div>
        <form method="post" class="settings-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="system">
            <h3 class="form-section-title">Hạn mức mặc định cho user thường</h3>
            <p class="form-hint">Áp dụng cho user không đặt hạn mức riêng (để trống max ở trang Users). Admin không bao giờ bị giới hạn.</p>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Max packages / user</label>
                    <input type="number" name="default_max_packages" class="form-control" min="0" max="1000000" value="<?= (int) $defaults['max_packages'] ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Max keys / user</label>
                    <input type="number" name="default_max_keys" class="form-control" min="0" max="1000000" value="<?= (int) $defaults['max_keys'] ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label toggle-row">
                    <input type="checkbox" name="allow_registration" value="1"<?= get_setting('allow_registration', '1') === '1' ? ' checked' : '' ?>>
                    <span>Cho phép tự đăng ký tài khoản (auth/register.php)</span>
                </label>
                <p class="form-hint">Tắt = chỉ admin mới tạo được tài khoản mới (trong trang Users).</p>
            </div>
            <h3 class="form-section-title">License V2 (server-authoritative)</h3>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Lease TTL (giây)</label>
                    <input type="number" name="license_lease_ttl" class="form-control" min="60" max="7200" value="<?= (int) get_setting('license_lease_ttl', '600') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Grace TTL (giây)</label>
                    <input type="number" name="license_grace_ttl" class="form-control" min="0" max="86400" value="<?= (int) get_setting('license_grace_ttl', '900') ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label toggle-row">
                    <input type="checkbox" name="legacy_v1_api" value="1"<?= get_setting('legacy_v1_api', '1') === '1' ? ' checked' : '' ?>>
                    <span>Cho phép V1 API (action=init/check — unsigned)</span>
                </label>
                <p class="form-hint">TẮT sau khi toàn bộ client đã lên V2 — client cũ sẽ nhận "Unknown action". Không để bật vĩnh viễn.</p>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo icon('check', 15); ?> Lưu cấu hình</button>
        </form>

        <dl class="detail-list detail-list-page" style="margin-top: 18px;">
            <dt>PHP Version</dt><dd><?= e(PHP_VERSION) ?></dd>
            <dt>Database</dt><dd><?= $serverVersion !== '' ? 'MySQL / ' . e($serverVersion) : 'MySQL (PDO)' ?></dd>
            <dt>PDO Driver</dt><dd>mysql (prepared statements)</dd>
            <dt>Session</dt><dd>HttpOnly · SameSite=Lax</dd>
            <dt>CSRF Protection</dt><dd>Enabled trên mọi POST action</dd>
            <dt>API Endpoint</dt><dd><code>/api/connect.php</code> — V2 signed lease</dd>
        </dl>
        <div class="notice notice-info">
            <?php echo icon('shield', 18); ?>
            <div>Mật khẩu lưu bằng <code>password_hash()</code> (bcrypt). API luôn trả JSON hợp lệ và dùng prepared statements cho mọi truy vấn. Phản hồi V2 được ký ECDSA P-256.</div>
        </div>
    </div>
</div>

<div class="card" style="margin-top: 18px;">
    <div class="card-header">
        <h2 class="card-title"><?php echo icon('key', 17); ?> Khóa ký license (ECDSA P-256)</h2>
    </div>
    <?php $clientPub = ''; try { $clientPub = LicenseCrypto::publicKeyForClient() ?? ''; } catch (Throwable $e) { $clientPub = ''; } ?>
    <?php if ($clientPub !== ''): ?>
    <p class="form-hint">Public key hiện tại — dán vào <code>kLicensePublicKeyPEM</code> trong <code>Cofi/HeaderAPI.h</code> của client:</p>
    <pre class="code-box" style="white-space:pre-wrap;user-select:all;padding:12px;"><?= e($clientPub) ?></pre>
    <form method="post" class="settings-form" data-confirm="ROTATE khóa ký? Toàn bộ client đang chạy sẽ từ chối phản hồi mới cho tới khi được build lại với public key MỚI. Chỉ làm khi sẵn sàng phát hành bản cập nhật.">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="rotate_signing_key">
        <button type="submit" class="btn btn-secondary"><?php echo icon('refresh', 15); ?> Rotate khóa ký (phát hành client mới sau đó)</button>
    </form>
    <?php else: ?>
    <div class="notice notice-danger">
        <?php echo icon('warning', 18); ?>
        <div>Không nạp được khóa ký — chạy <code>upgrade.php</code> một lần để sinh khóa, hoặc kiểm tra extension OpenSSL + quyền ghi thư mục <code>includes/</code>.</div>
    </div>
    <?php endif; ?>
</div>
<?php layout_footer();
