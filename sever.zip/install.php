<?php
/**
 * Installer: tạo database tables + tài khoản admin mặc định + cấu hình.
 *
 * Sau khi cài xong, installer tự khóa (lock file + kiểm tra tbl_users)
 * và KHÔNG thể chạy lại. Hãy xóa file này ngay sau khi cài đặt.
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/license_crypto.php';
require_once __DIR__ . '/includes/icons.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

const LOCK_FILE = __DIR__ . '/install.lock';

$lockExists = is_file(LOCK_FILE);
$dbOk       = false;
$dbError    = null;
$alreadyInstalled = false;

try {
    db()->query('SELECT 1');
    $dbOk = true;
    /* Bảng tài khoản thống nhất — đã có tài khoản nào là coi như installed */
    $alreadyInstalled = (int) db_query('SELECT COUNT(*) FROM tbl_users')->fetchColumn() > 0;
} catch (Throwable $e) {
    $dbError = $e->getMessage();
}

$locked = $lockExists || ($dbOk && $alreadyInstalled);

$errors = [];

if (!$locked && $dbOk && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors[] = 'CSRF token không hợp lệ. Tải lại trang và thử lại.';
    } else {
        try {
            foreach (schema_statements() as $statement) {
                db()->exec($statement);
            }

            $userCount = (int) db_query('SELECT COUNT(*) FROM tbl_users')->fetchColumn();
            if ($userCount === 0) {
                db_query(
                    'INSERT INTO tbl_users (username, email, password_hash, role) VALUES (?, NULL, ?, ?)',
                    [DEFAULT_ADMIN_USER, password_hash(DEFAULT_ADMIN_PASS, PASSWORD_DEFAULT), 'admin']
                );
            }

            seed_settings();

            /* V2 license: sinh khóa ký ECDSA P-256 + lưu public key */
            $pub = LicenseCrypto::publicKeyForClient();
            if ($pub === null) {
                $errors[] = 'Không tạo được khóa ký license (ECDSA P-256) — kiểm tra extension OpenSSL. Có thể chạy lại upgrade.php sau.';
            } else {
                set_setting(LicenseCrypto::SETTING_PUBKEY, $pub);
            }

            if (@file_put_contents(LOCK_FILE, date('c')) === false) {
                $errors[] = 'Không ghi được file install.lock — hãy tạo tay file rỗng tên install.lock cùng thư mục.';
            }
        } catch (Throwable $e) {
            $errors[] = 'Cài đặt thất bại: ' . $e->getMessage();
        }
    }

    if (!$errors) {
        $locked = true;
    }
}

/**
 * Seed cấu hình mặc định (idempotent — không ghi đè giá trị đã có).
 */
function seed_settings(): void
{
    $defaults = [
        'default_max_packages' => '3',
        'default_max_keys'     => '10',
        'allow_registration'   => '1',
        /* V2 license protocol */
        'legacy_v1_api'        => '1',
        'license_lease_ttl'    => '600',
        'license_grace_ttl'    => '900',
    ];
    foreach ($defaults as $key => $value) {
        $exists = db_query('SELECT 1 FROM tbl_settings WHERE setting_key = ?', [$key])->fetchColumn();
        if ($exists === false) {
            db_query('INSERT INTO tbl_settings (setting_key, setting_value) VALUES (?, ?)', [$key, $value]);
        }
    }
}

/**
 * Schema giống hệt database/database.sql (bản đầy đủ mới nhất:
 * tài khoản thống nhất theo role + hạn mức + cấu hình hệ thống).
 *
 * @return string[]
 */
function schema_statements(): array
{
    return [
        "CREATE TABLE IF NOT EXISTS tbl_users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(50) NOT NULL,
            email VARCHAR(190) NULL DEFAULT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role ENUM('admin','user') NOT NULL DEFAULT 'user',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            max_packages INT UNSIGNED NULL DEFAULT NULL,
            max_keys INT UNSIGNED NULL DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_login_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_users_username (username),
            UNIQUE KEY uq_users_email (email),
            KEY idx_users_role (role),
            KEY idx_users_active (is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS tbl_settings (
            setting_key VARCHAR(64) NOT NULL,
            setting_value VARCHAR(255) NOT NULL DEFAULT '',
            PRIMARY KEY (setting_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS tbl_projects (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(120) NOT NULL,
            project_token VARCHAR(64) NOT NULL,
            contact_link VARCHAR(255) NOT NULL DEFAULT '',
            is_maintenance TINYINT(1) NOT NULL DEFAULT 0,
            owner_id INT UNSIGNED NULL DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_projects_token (project_token),
            KEY idx_projects_maintenance (is_maintenance),
            KEY idx_projects_owner (owner_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS tbl_tokens (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_id INT UNSIGNED NOT NULL,
            token_code VARCHAR(32) NOT NULL,
            type ENUM('static','dynamic') NOT NULL DEFAULT 'dynamic',
            duration INT UNSIGNED NOT NULL DEFAULT 0,
            expire_date DATETIME NULL,
            max_devices INT UNSIGNED NOT NULL DEFAULT 1,
            status ENUM('active','suspended','revoked') NOT NULL DEFAULT 'active',
            user_id INT UNSIGNED NULL DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_tokens_code (token_code),
            KEY idx_tokens_project (project_id),
            KEY idx_tokens_expire (expire_date),
            KEY idx_tokens_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS tbl_device_history (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            token_id INT UNSIGNED NOT NULL,
            device_uuid VARCHAR(64) NOT NULL,
            device_pub VARCHAR(120) NULL DEFAULT NULL,
            first_used DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_devices_token_uuid (token_id, device_uuid),
            KEY idx_devices_uuid (device_uuid)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS license_sessions (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id CHAR(32) NOT NULL,
            token_id INT UNSIGNED NOT NULL,
            device_uuid VARCHAR(64) NOT NULL,
            device_pub_hash CHAR(16) NOT NULL,
            issued_at INT UNSIGNED NOT NULL,
            last_seen INT UNSIGNED NOT NULL,
            lease_expires_at INT UNSIGNED NOT NULL,
            sequence INT UNSIGNED NOT NULL DEFAULT 1,
            status ENUM('active','revoked','expired') NOT NULL DEFAULT 'active',
            created_at INT UNSIGNED NOT NULL,
            ended_at INT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_sessions_sid (session_id),
            KEY idx_sessions_token (token_id),
            KEY idx_sessions_status (status),
            KEY idx_sessions_lease (lease_expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS license_nonces (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            nonce_hash CHAR(64) NOT NULL,
            kind ENUM('c','s','u') NOT NULL DEFAULT 'c',
            created_at INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_nonces_hash (nonce_hash),
            KEY idx_nonces_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS license_rate (
            bucket VARCHAR(80) NOT NULL,
            count INT UNSIGNED NOT NULL DEFAULT 1,
            window_start INT UNSIGNED NOT NULL,
            PRIMARY KEY (bucket),
            KEY idx_rate_window (window_start)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS license_audit (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            token_id INT UNSIGNED NULL,
            session_id CHAR(32) NULL,
            event VARCHAR(40) NOT NULL,
            ip VARCHAR(45) NOT NULL DEFAULT '',
            device_uuid VARCHAR(64) NOT NULL DEFAULT '',
            detail VARCHAR(255) NOT NULL DEFAULT '',
            created_at INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_audit_token (token_id),
            KEY idx_audit_created (created_at),
            KEY idx_audit_event (event)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
}

function check_item(bool $ok, string $label, string $detail = ''): string
{
    $state = $ok ? 'ok' : 'fail';
    $iconName = $ok ? 'check' : 'x';
    return '<div class="check-row"><span class="check-state ' . $state . '">' . icon($iconName, 14)
        . '</span><span class="check-label">' . e($label)
        . ($detail !== '' ? '<span class="check-detail">' . e($detail) . '</span>' : '')
        . '</span></div>';
}

$phpOk      = version_compare(PHP_VERSION, '7.4.0', '>=');
$pdoOk      = class_exists('PDO');
$driverOk   = extension_loaded('pdo_mysql');
$mbOk       = extension_loaded('mbstring') || function_exists('mb_strlen');
$opensslOk  = function_exists('openssl_sign') && function_exists('openssl_pkey_new');
$pubKeyNote = '';
if ($opensslOk && $locked && $dbOk) {
    try {
        $pk = LicenseCrypto::publicKeyForClient();
        if ($pk !== null) {
            $pubKeyNote = $pk;
        }
    } catch (Throwable $e) {
        $pubKeyNote = '';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cài đặt — API Panel</title>
<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body class="auth-body">
<div class="auth-wrap install-wrap">
    <div class="auth-card">
        <div class="auth-brand">
            <span class="brand-mark brand-mark-lg"><?php echo icon('shield', 24); ?></span>
            <span class="brand-text-lg">API<span class="brand-accent">Panel</span></span>
        </div>

        <?php if ($locked && $dbOk && $alreadyInstalled && empty($_POST)): ?>
        <h1 class="auth-title">Đã cài đặt</h1>
        <p class="auth-sub">Hệ thống đã được cài đặt trước đó. Installer đã khóa và không thể chạy lại.</p>
        <div class="notice notice-warning">
            <?php echo icon('warning', 18); ?>
            <div><strong>Installation completed.</strong><br>Hãy xóa file <code>install.php</code> khỏi server ngay lập tức.</div>
        </div>
        <a class="btn btn-primary btn-block" href="auth/login.php">Đến trang đăng nhập</a>
        <p class="install-note">Nâng cấp từ bản cũ (bảng admins riêng / user chỉ kích hoạt key)? Chạy file <code>upgrade.php</code> một lần.</p>

        <?php elseif ($locked && !empty($_POST) && !$errors): ?>
        <h1 class="auth-title">Cài đặt thành công</h1>
        <div class="notice notice-success">
            <?php echo icon('check', 18); ?>
            <div><strong>Installation completed.</strong><br>Tài khoản admin: <code><?= e(DEFAULT_ADMIN_USER) ?></code> / Mật khẩu: <code><?= e(DEFAULT_ADMIN_PASS) ?></code></div>
        </div>
        <div class="notice notice-warning">
            <?php echo icon('warning', 18); ?>
            <div><strong>Please delete install.php immediately.</strong><br>Installer đã tự khóa, nhưng file này không nên tồn tại trên server sau khi cài đặt.</div>
        </div>
        <?php if ($pubKeyNote !== ''): ?>
        <div class="notice notice-success">
            <?php echo icon('key', 18); ?>
            <div><strong>Public key cho client (HeaderAPI.h):</strong>
                <pre class="install-note" style="white-space:pre-wrap;user-select:all;margin:8px 0 0;"><?= e($pubKeyNote) ?></pre>
                Dán vào <code>kLicensePublicKeyPEM</code> trong <code>Cofi/HeaderAPI.h</code> rồi build client V2.
            </div>
        </div>
        <?php endif; ?>
        <a class="btn btn-primary btn-block" href="auth/login.php">Đăng nhập hệ thống</a>

        <?php else: ?>
        <h1 class="auth-title">Cài đặt hệ thống</h1>
        <p class="auth-sub">Installer sẽ tạo các bảng database, tài khoản admin mặc định và cấu hình hạn mức.</p>

        <?php foreach ($errors as $err): ?>
        <div class="notice notice-danger"><?php echo icon('warning', 18); ?><div><?= e($err) ?></div></div>
        <?php endforeach; ?>

        <?php if (!$dbOk): ?>
        <div class="notice notice-danger">
            <?php echo icon('warning', 18); ?>
            <div>Không kết nối được database bằng thông tin trong <code>config.php</code>. Hãy kiểm tra DB_HOST / DB_USER / DB_PASS / DB_NAME rồi tải lại trang này.</div>
        </div>
        <?php endif; ?>

        <div class="install-checks">
            <h3 class="install-section-title">Kiểm tra môi trường</h3>
            <?= check_item($phpOk, 'PHP version', PHP_VERSION) ?>
            <?= check_item($pdoOk, 'PDO extension') ?>
            <?= check_item($driverOk, 'pdo_mysql driver') ?>
            <?= check_item($mbOk, 'mbstring (đã có polyfill dự phòng)') ?>
            <?= check_item($opensslOk, 'OpenSSL ECDSA P-256 (ký phản hồi V2)') ?>
            <?= check_item($dbOk, 'Database connection', $dbOk ? DB_NAME : 'xem config.php') ?>
        </div>

        <form method="post" class="install-form">
            <?= csrf_field() ?>
            <div class="install-summary">
                <div class="check-row"><span class="check-state ok"><?php echo icon('key', 14); ?></span><span class="check-label">Admin mặc định (role = admin)<span class="check-detail"><?= e(DEFAULT_ADMIN_USER) ?> / <?= e(DEFAULT_ADMIN_PASS) ?></span></span></div>
                <div class="check-row"><span class="check-state ok"><?php echo icon('user', 14); ?></span><span class="check-label">Tables<span class="check-detail">tbl_users, tbl_settings, tbl_projects, tbl_tokens, tbl_device_history</span></span></div>
                <div class="check-row"><span class="check-state ok"><?php echo icon('users', 14); ?></span><span class="check-label">Cơ chế<span class="check-detail">1 đăng nhập chung · admin toàn quyền · user tạo package/key theo hạn mức</span></span></div>
                <div class="check-row"><span class="check-state ok"><?php echo icon('settings', 14); ?></span><span class="check-label">Hạn mức mặc định user<span class="check-detail">3 package · 10 key (đổi được trong Settings)</span></span></div>
            </div>
            <button type="submit" class="btn btn-primary btn-block"<?= $dbOk ? '' : ' disabled' ?>>Chạy cài đặt</button>
        </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
