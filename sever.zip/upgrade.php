<?php
/**
 * Upgrade database từ schema CŨ lên schema MỚI (tài khoản thống nhất)
 * + MIGRATION V2 LICENSE (server-authoritative signed lease):
 *
 *   CŨ: bảng admins riêng + tbl_users cũ (không role/hạn mức)
 *       + tbl_projects không owner_id + user chỉ "kích hoạt key".
 *   MỚI: MỘT bảng tbl_users có role (admin/user) + hạn mức riêng,
 *       tbl_projects.owner_id, tbl_settings, tbl_tokens.user_id.
 *
 * V2 LICENSE (idempotent — chạy nhiều lần không gây hại):
 *   1. Bảng mới: license_sessions, license_nonces, license_rate, license_audit
 *   2. tbl_tokens.status (active/suspended/revoked) — backfill 'active'
 *   3. tbl_device_history.device_pub (public key của thiết bị)
 *   4. Sinh khóa ký ECDSA P-256 (includes/signing_key.php) nếu chưa có
 *      + lưu public key vào tbl_settings để hiển thị cho admin
 *   5. Seed settings: legacy_v1_api, license_lease_ttl, license_grace_ttl
 *
 * Chạy file này MỘT LẦN sau khi upload code mới đè lên bản cũ.
 * Sau khi xong, file tự khóa bằng upgrade.lock (xóa file này như install.php).
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/license_crypto.php';
require_once __DIR__ . '/includes/icons.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

const UPGRADE_LOCK_FILE = __DIR__ . '/upgrade.lock';

$dbOk    = false;
$dbError = null;

try {
    db()->query('SELECT 1');
    $dbOk = true;
} catch (Throwable $e) {
    $dbError = $e->getMessage();
}

/* Helper kiểm tra cột / bảng / index tồn tại (MySQL 5.7 không có IF NOT EXISTS cho ALTER) */

function column_exists(string $table, string $column): bool
{
    return (int) db_query(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
        [$table, $column]
    )->fetchColumn() > 0;
}

function table_exists(string $table): bool
{
    return (int) db_query(
        "SELECT COUNT(*) FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?",
        [$table]
    )->fetchColumn() > 0;
}

$done    = [];
$failed  = [];
$already = is_file(UPGRADE_LOCK_FILE);

if ($dbOk && !$already && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $failed[] = 'CSRF token không hợp lệ. Tải lại trang và thử lại.';
    } else {
        try {
            /* 1a. Bảng tbl_users cũ có thể thiếu cột email (bản rất cũ) */
            if (!column_exists('tbl_users', 'email')) {
                db()->exec('ALTER TABLE tbl_users ADD COLUMN email VARCHAR(190) NULL DEFAULT NULL AFTER username');
                $done[] = 'Đã thêm cột tbl_users.email.';
            }

            /* 1b. Cột role */
            if (!column_exists('tbl_users', 'role')) {
                db()->exec("ALTER TABLE tbl_users ADD COLUMN role ENUM('admin','user') NOT NULL DEFAULT 'user' AFTER password_hash");
                $done[] = 'Đã thêm cột tbl_users.role (admin/user).';
            } else {
                $done[] = 'Cột tbl_users.role đã tồn tại.';
            }

            /* 1c. Cột hạn mức */
            if (!column_exists('tbl_users', 'max_packages')) {
                db()->exec('ALTER TABLE tbl_users ADD COLUMN max_packages INT UNSIGNED NULL DEFAULT NULL AFTER role');
                $done[] = 'Đã thêm cột tbl_users.max_packages.';
            }
            if (!column_exists('tbl_users', 'max_keys')) {
                db()->exec('ALTER TABLE tbl_users ADD COLUMN max_keys INT UNSIGNED NULL DEFAULT NULL AFTER max_packages');
                $done[] = 'Đã thêm cột tbl_users.max_keys.';
            }

            /* 2. Gộp bảng admins cũ vào tbl_users với role='admin' */
            if (table_exists('admins')) {
                $admins = db_query('SELECT username, password_hash FROM admins')->fetchAll();
                $merged = 0;
                foreach ($admins as $adm) {
                    $exists = db_query(
                        'SELECT id FROM tbl_users WHERE username = ? LIMIT 1',
                        [$adm['username']]
                    )->fetchColumn();

                    if ($exists !== false) {
                        /* Trùng tên: nâng quyền tài khoản hiện có, mật khẩu admin cũ thắng */
                        db_query(
                            "UPDATE tbl_users SET role = 'admin', password_hash = ? WHERE id = ?",
                            [$adm['password_hash'], $exists]
                        );
                    } else {
                        db_query(
                            "INSERT INTO tbl_users (username, password_hash, role) VALUES (?, ?, 'admin')",
                            [$adm['username'], $adm['password_hash']]
                        );
                    }
                    $merged++;
                }

                /* Đổi tên bảng cũ để lưu dữ liệu phòng khi cần (không xóa) */
                if (!table_exists('admins_backup')) {
                    db()->exec('RENAME TABLE admins TO admins_backup');
                    $done[] = 'Đã gộp ' . $merged . ' tài khoản admin vào tbl_users (role=admin), bảng cũ đổi tên thành admins_backup.';
                } else {
                    db()->exec('DROP TABLE admins');
                    $done[] = 'Đã gộp ' . $merged . ' tài khoản admin vào tbl_users (role=admin).';
                }
            } else {
                $done[] = 'Không có bảng admins cũ — bỏ qua bước gộp.';
            }

            /* 3. tbl_projects.owner_id */
            if (!column_exists('tbl_projects', 'owner_id')) {
                db()->exec('ALTER TABLE tbl_projects ADD COLUMN owner_id INT UNSIGNED NULL DEFAULT NULL AFTER is_maintenance');
                $done[] = 'Đã thêm cột tbl_projects.owner_id (package cũ giữ NULL = "Hệ thống").';
            }

            /* 4. tbl_tokens.user_id (bản rất cũ có thể chưa có) */
            if (table_exists('tbl_tokens') && !column_exists('tbl_tokens', 'user_id')) {
                db()->exec('ALTER TABLE tbl_tokens ADD COLUMN user_id INT UNSIGNED NULL DEFAULT NULL AFTER max_devices');
                $done[] = 'Đã thêm cột tbl_tokens.user_id (người tạo key).';
            }

            /* 5. Bảng cấu hình + seed */
            db()->exec(
                "CREATE TABLE IF NOT EXISTS tbl_settings (
                    setting_key VARCHAR(64) NOT NULL,
                    setting_value VARCHAR(255) NOT NULL DEFAULT '',
                    PRIMARY KEY (setting_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            $defaults = [
                'default_max_packages' => '3',
                'default_max_keys'     => '10',
                'allow_registration'   => '1',
            ];
            foreach ($defaults as $key => $value) {
                db_query(
                    'INSERT IGNORE INTO tbl_settings (setting_key, setting_value) VALUES (?, ?)',
                    [$key, $value]
                );
            }
            $done[] = 'Bảng tbl_settings sẵn sàng + cấu hình mặc định (3 package / 10 key / mở đăng ký).';

            /* ============ MIGRATION V2 LICENSE ============ */

            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_sessions (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    session_id CHAR(32) NOT NULL,
                    token_id INT UNSIGNED NOT NULL,
                    device_uuid VARCHAR(64) NOT NULL,
                    device_pub_hash CHAR(16) NOT NULL,
                    issued_at INT UNSIGNED NOT NULL,
                    last_seen INT UNSIGNED NOT NULL,
                    lease_expires_at INT UNSIGNED NOT NULL,
                    sequence INT UNSIGNED NOT NULL DEFAULT 1,
                    status ENUM('active','revoked','expired') NOT NULL DEFAULT 'active',
                    created_at INT UNSIGNED NOT NULL,
                    ended_at INT UNSIGNED NULL,
                    PRIMARY KEY (id),
                    UNIQUE KEY uq_sessions_sid (session_id),
                    KEY idx_sessions_token (token_id),
                    KEY idx_sessions_status (status),
                    KEY idx_sessions_lease (lease_expires_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_nonces (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    nonce_hash CHAR(64) NOT NULL,
                    kind ENUM('c','s','u') NOT NULL DEFAULT 'c',
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    UNIQUE KEY uq_nonces_hash (nonce_hash),
                    KEY idx_nonces_created (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_rate (
                    bucket VARCHAR(80) NOT NULL,
                    count INT UNSIGNED NOT NULL DEFAULT 1,
                    window_start INT UNSIGNED NOT NULL,
                    PRIMARY KEY (bucket),
                    KEY idx_rate_window (window_start)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_audit (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    token_id INT UNSIGNED NULL,
                    session_id CHAR(32) NULL,
                    event VARCHAR(40) NOT NULL,
                    ip VARCHAR(45) NOT NULL DEFAULT '',
                    device_uuid VARCHAR(64) NOT NULL DEFAULT '',
                    detail VARCHAR(255) NOT NULL DEFAULT '',
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_audit_token (token_id),
                    KEY idx_audit_created (created_at),
                    KEY idx_audit_event (event)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_offsets (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    game_version VARCHAR(32) NOT NULL DEFAULT '',
                    payload MEDIUMTEXT NOT NULL,
                    is_active TINYINT UNSIGNED NOT NULL DEFAULT 1,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_offsets_active (is_active)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            try {
                $offsCount = (int) db_query('SELECT COUNT(*) FROM license_offsets', [])->fetchColumn();
                if ($offsCount === 0) {
                    require_once __DIR__ . '/includes/offsets_data.php';
                    $offsJson = json_encode(OffsetsData::defaults(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                    if (is_string($offsJson)) {
                        db_query(
                            'INSERT INTO license_offsets
                                 (game_version, payload, is_active, created_at, updated_at)
                             VALUES (?, ?, 1, ?, ?)',
                            [OffsetsData::GAME_VERSION, $offsJson, time(), time()]
                        );
                    }
                }
            } catch (Throwable $eSeed) {
                $failed[] = 'Bảng license_offsets đã tạo nhưng seed offset mặc định thất bại: ' . $eSeed->getMessage();
            }
            $done[] = 'Đã tạo 4 bảng V2 + bảng license_offsets (kho offset server-authoritative, Task 17) và seed offset mặc định.';

            if (table_exists('tbl_tokens') && !column_exists('tbl_tokens', 'status')) {
                db()->exec("ALTER TABLE tbl_tokens ADD COLUMN status ENUM('active','suspended','revoked') NOT NULL DEFAULT 'active' AFTER max_devices");
                db_query("UPDATE tbl_tokens SET status = 'active' WHERE status IS NULL OR status = ''");
                $done[] = 'Đã thêm cột tbl_tokens.status (active/suspended/revoked) — key hiện tại giữ active.';
            }

            if (table_exists('tbl_device_history') && !column_exists('tbl_device_history', 'device_pub')) {
                db()->exec('ALTER TABLE tbl_device_history ADD COLUMN device_pub VARCHAR(120) NULL DEFAULT NULL AFTER device_uuid');
                $done[] = 'Đã thêm cột tbl_device_history.device_pub (khóa công khai của thiết bị).';
            }

            /* Khóa ký: dùng file có sẵn / sinh mới nếu chưa có */
            $pub = LicenseCrypto::publicKeyForClient();
            if ($pub === null) {
                $failed[] = 'Không tạo được khóa ký ECDSA — kiểm tra extension OpenSSL của PHP.';
            } else {
                set_setting(LicenseCrypto::SETTING_PUBKEY, $pub);
                $done[] = 'Khóa ký license sẵn sàng (private trong includes/signing_key.php, public lưu tbl_settings).';
            }

            $v2Defaults = [
                'legacy_v1_api'     => '1',
                'license_lease_ttl' => '600',
                'license_grace_ttl' => '900',
            ];
            foreach ($v2Defaults as $k => $v) {
                db_query('INSERT IGNORE INTO tbl_settings (setting_key, setting_value) VALUES (?, ?)', [$k, $v]);
            }
            $done[] = 'Settings V2: legacy_v1_api=1 (tắt sau khi mọi client đã lên V2) · lease 600s · grace 900s.';

            if (@file_put_contents(UPGRADE_LOCK_FILE, date('c')) === false) {
                $failed[] = 'Không ghi được upgrade.lock — hãy tạo tay file rỗng tên upgrade.lock cùng thư mục.';
            }
        } catch (Throwable $e) {
            $failed[] = 'Nâng cấp thất bại: ' . $e->getMessage();
        }
    }
}

$finished = $already || ($dbOk && !$failed && !empty($done) && is_file(UPGRADE_LOCK_FILE));

/* Public key để dán vào client — hiển thị ở mọi trạng thái finished */
$clientPublicKey = null;
if ($dbOk) {
    try {
        $clientPublicKey = get_setting(LicenseCrypto::SETTING_PUBKEY, '');
        if ($clientPublicKey === '' && class_exists('LicenseCrypto')) {
            $gen = LicenseCrypto::publicKeyForClient();
            if ($gen !== null) {
                $clientPublicKey = $gen;
            }
        }
    } catch (Throwable $e) {
        $clientPublicKey = null;
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nâng cấp — API Panel</title>
<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body class="auth-body">
<div class="auth-wrap install-wrap">
    <div class="auth-card">
        <div class="auth-brand">
            <span class="brand-mark brand-mark-lg"><?php echo icon('shield', 24); ?></span>
            <span class="brand-text-lg">API<span class="brand-accent">Panel</span></span>
        </div>

        <?php if (!$dbOk): ?>
        <h1 class="auth-title">Không kết nối được database</h1>
        <div class="notice notice-danger">
            <?php echo icon('warning', 18); ?>
            <div>Kiểm tra DB_HOST / DB_USER / DB_PASS / DB_NAME trong <code>config.php</code> rồi tải lại trang.</div>
        </div>

        <?php elseif ($finished): ?>
        <h1 class="auth-title">Nâng cấp hoàn tất</h1>
        <div class="notice notice-success">
            <?php echo icon('check', 18); ?>
            <div>Database đã ở schema mới: một bảng <code>tbl_users</code> theo role (admin/user) + hạn mức + <code>tbl_settings</code>.</div>
        </div>
        <?php foreach ($done as $item): ?>
        <div class="check-row"><span class="check-state ok"><?php echo icon('check', 14); ?></span><span class="check-label"><?= e($item) ?></span></div>
        <?php endforeach; ?>
        <div class="notice notice-warning">
            <?php echo icon('warning', 18); ?>
            <div>Hãy xóa file <code>upgrade.php</code> khỏi server sau khi nâng cấp. Bảng <code>admins_backup</code> (nếu có) giữ làm dữ liệu phòng hộ — có thể xóa tay khi chắc chắn mọi thứ chạy tốt.</div>
        </div>
        <?php if ($clientPublicKey): ?>
        <div class="notice notice-success">
            <?php echo icon('key', 18); ?>
            <div><strong>Public key cho client (HeaderAPI.h):</strong>
                <pre class="install-note" style="white-space:pre-wrap;user-select:all;margin:8px 0 0;"><?= e($clientPublicKey) ?></pre>
                Dán vào <code>kLicensePublicKeyPEM</code> trong <code>Cofi/HeaderAPI.h</code> rồi build client V2.
            </div>
        </div>
        <?php endif; ?>
        <a class="btn btn-primary btn-block" href="auth/login.php">Đến trang đăng nhập</a>

        <?php else: ?>
        <h1 class="auth-title">Nâng cấp database</h1>
        <p class="auth-sub">Chuyển sang mô hình tài khoản thống nhất: một bảng user theo role, admin toàn quyền, user thường tự tạo package/key trong hạn mức. Không làm mất dữ liệu.</p>

        <?php foreach ($failed as $err): ?>
        <div class="notice notice-danger"><?php echo icon('warning', 18); ?><div><?= e($err) ?></div></div>
        <?php endforeach; ?>

        <div class="install-checks">
            <h3 class="install-section-title">Sẽ thực hiện</h3>
            <div class="check-row"><span class="check-state ok"><?php echo icon('users', 14); ?></span><span class="check-label">tbl_users thêm role + hạn mức<span class="check-detail">admin / user · max_packages · max_keys</span></span></div>
            <div class="check-row"><span class="check-state ok"><?php echo icon('shield', 14); ?></span><span class="check-label">Gộp bảng admins cũ<span class="check-detail">thành role=admin trong tbl_users (đổi tên thành admins_backup)</span></span></div>
            <div class="check-row"><span class="check-state ok"><?php echo icon('package', 14); ?></span><span class="check-label">tbl_projects thêm owner_id<span class="check-detail">package cũ giữ NULL = "Hệ thống"</span></span></div>
            <div class="check-row"><span class="check-state ok"><?php echo icon('database', 14); ?></span><span class="check-label">tbl_settings + mặc định<span class="check-detail">3 package / 10 key / mở đăng ký</span></span></div>
            <div class="check-row"><span class="check-state ok"><?php echo icon('shield', 14); ?></span><span class="check-label">V2 license protocol<span class="check-detail">4 bảng mới · tbl_tokens.status · device_pub · sinh khóa ký ECDSA P-256</span></span></div>
        </div>

        <form method="post" class="install-form">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-primary btn-block">Chạy nâng cấp</button>
        </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
