<?php
/**
 * API endpoint cho client — PHIÊN BẢN V2 (server-authoritative).
 *
 *   GET  /api/connect.php?action=init&token={PROJECT_TOKEN}
 *        (legacy V1 — giữ cho client cũ, bật/tắt bằng setting legacy_v1_api)
 *   GET  /api/connect.php?action=check&token={}&key={}&uuid={}
 *        (legacy V1 — unsigned, chỉ dùng trong thời gian migration)
 *
 *   POST /api/connect.php  body JSON:
 *        {action:'hello', token}
 *        {action:'auth',  token, key, uuid, device_pub, nonce_c, nonce_s, ts, pop}
 *        {action:'renew', token, session_id, nonce_c, ts, sequence, pop}
 *        {action:'offsets', token, session_id, nonce_c, ts, sequence, pop}
 *        (Task 17 — offset game chỉ cấp cho session hợp lệ; phản hồi
 *         chứa offsets + game_version TRONG CHUỖI ĐÃ KÝ. PoP pop3.)
 *
 * V2: mọi phản hồi là {sig_input, signature} — client PHẢI verify chữ ký
 * ECDSA P-256 bằng public key nhúng trong app trước khi tin bất kỳ giá trị
 * nào. Nonce 1 lần + timestamp + sequence + proof-of-possession chống
 * replay/reorder/clone. Lease ngắn hạn (mặc định 600s) + grace có ký.
 *
 * Luôn trả về JSON hợp lệ, không bao giờ trả HTML lỗi.
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/settings.php';
require_once __DIR__ . '/../includes/license_api.php';

try {
    handle_request();
} catch (Throwable $e) {
    api_error('Server error', true);
}

function handle_request(): void
{
    /* Tự tạo 4 bảng V2 nếu thiếu (idempotent, 1 lần / process PHP) —
     * chống quên chạy upgrade.php sau khi deploy file V2. Không bao giờ
     * throw (im lặng khi thiếu quyền CREATE). */
    LicenseApi::ensureV2Tables();

    LicenseApi::housekeeping();

    /* ---------- POST JSON body (V2) ---------- */
    $body = [];
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $raw = file_get_contents('php://input');
        if (is_string($raw) && strlen($raw) <= 8192) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $body = $decoded;
            }
        }
    }

    $action = (string) ($_GET['action'] ?? ($body['action'] ?? ''));
    $token  = (string) ($_GET['token'] ?? ($body['token'] ?? ''));

    /* Rate limit IP — tầng đầu tiên, mọi action */
    if (!LicenseApi::rateLimit('ip:' . LicenseApi::clientIp(), 120, 60)) {
        api_error('Too many requests');
    }

    /* ---------- V2 ---------- */
    if ($action === 'hello') {
        do_hello($token);
    }
    if ($action === 'auth') {
        do_auth($token, $body);
    }
    if ($action === 'renew') {
        do_renew($token, $body);
    }
    if ($action === 'offsets') {
        do_offsets($token, $body);
    }

    /* ---------- Legacy V1 ---------- */
    if (get_setting('legacy_v1_api', '1') !== '1') {
        api_error('Unknown action');
    }

    if (!LicenseApi::validTokenFormat($token)) {
        api_error('Invalid Package Token', true);
    }

    try {
        $project = db_query(
            'SELECT id, contact_link, is_maintenance FROM tbl_projects WHERE project_token = ? LIMIT 1',
            [$token]
        )->fetch();
    } catch (RuntimeException $e) {
        api_error('Database unavailable', true);
    }

    if ($project === false) {
        api_error('Invalid Package Token', true);
    }

    $contact = (string) $project['contact_link'];

    if ($action === 'init') {
        json_out([
            'status'      => true,
            'contact'     => $contact,
            'maintenance' => (int) $project['is_maintenance'],
        ]);
    }

    if ($action === 'check') {
        do_check_legacy($project, $contact);
    }

    api_error('Unknown action');
}

/* ====================================================================== */
/*  V2 — hello: challenge server (nonce_s) + thông tin gói                */
/* ====================================================================== */

function do_hello(string $token): void
{
    if (!LicenseApi::validTokenFormat($token)) {
        LicenseApi::signedError('hello', '', 'Invalid Package Token', true);
    }

    try {
        $project = db_query(
            'SELECT contact_link, is_maintenance FROM tbl_projects WHERE project_token = ? LIMIT 1',
            [$token]
        )->fetch();
    } catch (RuntimeException $e) {
        LicenseApi::signedError('hello', '', 'Database unavailable', true);
    }

    if ($project === false) {
        LicenseApi::signedError('hello', '', 'Invalid Package Token', true);
    }

    $nonceS = bin2hex(random_bytes(16));
    try {
        LicenseApi::nonceRegister($nonceS, 's');
    } catch (RuntimeException $e) {
        /* nonce store hỏng thật (đã tự chữa không xong) — báo rõ ràng
         * thay vì giả vờ OK rồi để auth chết 'Challenge expired' */
        LicenseApi::signedError('hello', '', 'Database unavailable', true);
    }

    LicenseApi::audit(null, null, 'hello', ['token' => substr($token, 0, 8)]);

    $payload = LicenseApi::signedLease([
        'action'      => 'hello',
        'status'      => '1',
        'message'     => 'OK',
        'nonce_s'     => $nonceS,
        'contact'     => (string) $project['contact_link'],
        'maintenance' => (string) ((int) $project['is_maintenance']),
    ]);
    if ($payload === null) {
        api_error('Server error', true);
    }
    json_out($payload);
}

/* ====================================================================== */
/*  V2 — auth: key + device keypair (PoP) → session + lease ngắn hạn      */
/* ====================================================================== */

function do_auth(string $token, array $body): void
{
    $key       = strtoupper(trim((string) ($body['key'] ?? '')));
    $uuid      = strtolower(trim((string) ($body['uuid'] ?? '')));
    $devicePub = (string) ($body['device_pub'] ?? '');
    $nonceC    = strtolower((string) ($body['nonce_c'] ?? ''));
    $nonceS    = strtolower((string) ($body['nonce_s'] ?? ''));
    $ts        = (int) ($body['ts'] ?? 0);
    $pop       = (string) ($body['pop'] ?? '');

    /* ---- Validation tham số (độ dài + charset + format) ---- */
    if ($token === '' || $key === '' || $uuid === '' || $devicePub === ''
        || $nonceC === '' || $nonceS === '' || $ts === 0 || $pop === '') {
        LicenseApi::signedError('auth', $nonceC, 'Missing params');
    }
    if (!LicenseApi::validTokenFormat($token)
        || !LicenseApi::validKeyFormat($key)
        || !LicenseApi::validUuidFormat($uuid)
        || !LicenseApi::validNonceFormat($nonceC)
        || !LicenseApi::validNonceFormat($nonceS)
        || !LicenseApi::validB64($devicePub, 88, 88)
        || !LicenseApi::validB64($pop, 64, 200)) {
        LicenseApi::signedError('auth', $nonceC, 'Invalid params');
    }

    /* ---- Timestamp freshness (±300s) ---- */
    if (abs(time() - $ts) > LicenseApi::CLOCK_SKEW) {
        LicenseApi::signedError('auth', $nonceC, 'Request expired');
    }

    /* ---- Rate limit: theo key và theo uuid ---- */
    $keyBucket = 'keyfail:' . hash('sha256', $key);
    if (!LicenseApi::rateLimit('uuid:' . hash('sha256', $uuid), 30, 60)
        || !LicenseApi::rateLimit($keyBucket, 12, 60)) {
        LicenseApi::audit(null, null, 'auth_ratelimited', ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, 'Too many requests');
    }

    /* ---- Nonce client: 1 lần duy nhất (chống replay request) ---- */
    try {
        $nonceFresh = LicenseApi::nonceRegister($nonceC, 'c');
    } catch (RuntimeException $e) {
        LicenseApi::signedError('auth', $nonceC, 'Database unavailable', true);
    }
    if (!$nonceFresh) {
        LicenseApi::audit(null, null, 'auth_replay', ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, 'Replay detected');
    }

    /* ---- Challenge nonce_s phải do server phát hành, còn hạn ---- */
    try {
        $challengeOk = LicenseApi::nonceServerValid($nonceS);
    } catch (RuntimeException $e) {
        LicenseApi::signedError('auth', $nonceC, 'Database unavailable', true);
    }
    if (!$challengeOk) {
        LicenseApi::signedError('auth', $nonceC, 'Challenge expired');
    }
    LicenseApi::nonceConsume($nonceS);   /* single-use */

    /* ---- Project token ---- */
    try {
        $project = db_query(
            'SELECT id, contact_link, is_maintenance FROM tbl_projects WHERE project_token = ? LIMIT 1',
            [$token]
        )->fetch();
    } catch (RuntimeException $e) {
        LicenseApi::signedError('auth', $nonceC, 'Database unavailable', true);
    }
    if ($project === false) {
        LicenseApi::signedError('auth', $nonceC, 'Invalid Package Token', true);
    }
    $contact = (string) $project['contact_link'];

    /* ---- Maintenance: trả contact để client hiện màn bảo trì ---- */
    if ((int) $project['is_maintenance'] === 1) {
        LicenseApi::signedError('auth', $nonceC, 'System Maintenance', false, $contact);
    }

    /* ---- Key ---- */
    try {
        $tokenRow = db_query(
            'SELECT id, type, duration, expire_date, max_devices, status FROM tbl_tokens
             WHERE token_code = ? AND project_id = ? LIMIT 1',
            [$key, $project['id']]
        )->fetch();
    } catch (RuntimeException $e) {
        LicenseApi::signedError('auth', $nonceC, 'Database unavailable', true);
    }

    if ($tokenRow === false) {
        LicenseApi::rateBump($keyBucket);
        LicenseApi::audit(null, null, 'auth_fail', ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, 'Key invalid for this package');
    }

    if ((string) $tokenRow['status'] === 'revoked') {
        LicenseApi::audit((int) $tokenRow['id'], null, 'auth_revoked', ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, 'Key revoked', false, $contact);
    }
    if ((string) $tokenRow['status'] === 'suspended') {
        LicenseApi::audit((int) $tokenRow['id'], null, 'auth_suspended', ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, 'Key suspended', false, $contact);
    }

    /* ---- Proof-of-possession: chữ ký bằng private key của THIẾT BỊ ---- */
    $popMsg = 'pop1|' . $devicePub . '|' . $nonceC . '|' . $ts;
    if (!LicenseCrypto::verifyDevicePop($popMsg, $pop, $devicePub)) {
        LicenseApi::audit((int) $tokenRow['id'], null, 'auth_pop_fail', ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, 'Device verification failed');
    }

    /* ---- Dynamic key: kích hoạt lần đầu ATOMIC ---- */
    if ($tokenRow['type'] === 'dynamic' && $tokenRow['expire_date'] === null) {
        $expire = date('Y-m-d H:i:s', strtotime('+' . (int) $tokenRow['duration'] . ' days'));
        $n = db_query(
            'UPDATE tbl_tokens SET expire_date = ? WHERE id = ? AND expire_date IS NULL',
            [$expire, $tokenRow['id']]
        )->rowCount();
        if ($n > 0) {
            LicenseApi::audit((int) $tokenRow['id'], null, 'dynamic_activated', ['uuid' => $uuid]);
        }
        /* $n == 0: request khác đã kích hoạt — đọc lại giá trị thật */
        $tokenRow['expire_date'] = db_query(
            'SELECT expire_date FROM tbl_tokens WHERE id = ? LIMIT 1',
            [$tokenRow['id']]
        )->fetchColumn();
    }

    $now = date('Y-m-d H:i:s');
    if ($tokenRow['expire_date'] !== null && $tokenRow['expire_date'] < $now) {
        LicenseApi::audit((int) $tokenRow['id'], null, 'auth_expired', ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, 'Key expired', false, $contact);
    }

    /* ---- Claim thiết bị (transaction + row lock + PoP đã verify) ---- */
    $claim = LicenseApi::claimDevice((int) $tokenRow['id'], $uuid, $devicePub, (int) $tokenRow['max_devices']);
    if (!$claim['ok']) {
        LicenseApi::rateBump($keyBucket);
        LicenseApi::audit((int) $tokenRow['id'], null, 'device_' . str_replace(' ', '_', $claim['reason']), ['uuid' => $uuid]);
        LicenseApi::signedError('auth', $nonceC, $claim['reason'], false, $contact);
    }

    /* ---- Tạo session + lease ---- */
    try {
        $lease = LicenseApi::createSession((int) $tokenRow['id'], $uuid, $devicePub, $key, $tokenRow);
    } catch (Throwable $e) {
        LicenseApi::signedError('auth', $nonceC, 'Server error');
    }

    $daysLeft = (int) floor((strtotime((string) $tokenRow['expire_date']) - strtotime($now)) / 86400);
    if ($daysLeft < 0) {
        $daysLeft = 0;
    }

    LicenseApi::audit((int) $tokenRow['id'], $lease['session_id'], 'auth_ok', ['uuid' => $uuid]);

    $payload = LicenseApi::signedLease([
        'action'         => 'auth',
        'status'         => '1',
        'message'        => 'Active',
        'session_id'     => $lease['session_id'],
        'nonce_c'        => $nonceC,
        'license_fp'     => $lease['license_fp'],
        'device_binding' => $lease['device_binding'],
        'sequence'       => $lease['sequence'],
        'issued_at'      => $lease['issued_at'],
        'expires_at'     => $lease['expires_at'],
        'key_type'       => (string) $tokenRow['type'],
        'expiry'         => (string) ($tokenRow['expire_date'] ?? ''),
        'days_left'      => (string) $daysLeft,
        'contact'        => $contact,
        'maintenance'    => '0',
        'permissions'    => '{"esp":1}',
    ]);
    if ($payload === null) {
        api_error('Server error', true);
    }
    json_out($payload);
}

/* ====================================================================== */
/*  V2 — renew: gia hạn lease, kiểm tra lại toàn bộ trạng thái            */
/* ====================================================================== */

function do_renew(string $token, array $body): void
{
    $sessionId = strtolower((string) ($body['session_id'] ?? ''));
    $nonceC    = strtolower((string) ($body['nonce_c'] ?? ''));
    $ts        = (int) ($body['ts'] ?? 0);
    $sequence  = (int) ($body['sequence'] ?? 0);
    $pop       = (string) ($body['pop'] ?? '');

    if ($sessionId === '' || $nonceC === '' || $ts === 0 || $sequence < 1 || $pop === '') {
        LicenseApi::signedError('renew', $nonceC, 'Missing params');
    }
    if (!LicenseApi::validSessionFormat($sessionId)
        || !LicenseApi::validNonceFormat($nonceC)
        || !LicenseApi::validB64($pop, 64, 200)) {
        LicenseApi::signedError('renew', $nonceC, 'Invalid params');
    }
    if (abs(time() - $ts) > LicenseApi::CLOCK_SKEW) {
        LicenseApi::signedError('renew', $nonceC, 'Request expired');
    }
    if (!LicenseApi::rateLimit('ip:' . LicenseApi::clientIp(), 120, 60)) {
        api_error('Too many requests');
    }
    try {
        $nonceFresh = LicenseApi::nonceRegister($nonceC, 'c');
    } catch (RuntimeException $e) {
        LicenseApi::signedError('renew', $nonceC, 'Database unavailable', true);
    }
    if (!$nonceFresh) {
        LicenseApi::audit(null, $sessionId, 'renew_replay', []);
        LicenseApi::signedError('renew', $nonceC, 'Replay detected');
    }

    /* ---- Nạp session + key + project + device trong 1 query ---- */
    try {
        $row = db_query(
            'SELECT s.session_id, s.token_id, s.device_uuid, s.device_pub_hash, s.sequence,
                    s.lease_expires_at, s.status,
                    t.token_code, t.status AS key_status, t.expire_date, t.type, t.project_id,
                    p.contact_link, p.is_maintenance, p.project_token,
                    d.device_pub
             FROM license_sessions s
             JOIN tbl_tokens t ON t.id = s.token_id
             JOIN tbl_projects p ON p.id = t.project_id
             LEFT JOIN tbl_device_history d ON d.token_id = s.token_id AND d.device_uuid = s.device_uuid
             WHERE s.session_id = ? LIMIT 1',
            [$sessionId]
        )->fetch();
    } catch (RuntimeException $e) {
        LicenseApi::signedError('renew', $nonceC, 'Database unavailable');
    }

    if ($row === false || $row['device_pub'] === null) {
        LicenseApi::signedError('renew', $nonceC, 'Session expired');
    }

    /* Token phải vẫn thuộc project đang dùng (client gửi kèm để đối chiếu) */
    if ($token !== '' && !hash_equals((string) $row['project_token'], $token)) {
        LicenseApi::signedError('renew', $nonceC, 'Session expired');
    }

    /* ---- PoP: chứng minh thiết bị vẫn nắm private key ---- */
    $popMsg = 'pop2|' . $sessionId . '|' . $nonceC . '|' . $ts . '|' . $sequence;
    if (!LicenseCrypto::verifyDevicePop($popMsg, $pop, (string) $row['device_pub'])) {
        LicenseApi::audit((int) $row['token_id'], $sessionId, 'renew_pop_fail', ['uuid' => $row['device_uuid']]);
        /* PoP sai → nghi ngờ clone → hủy session ngay. Dùng message
         * "Device verification failed" để client lockdown + re-auth (không
         * xóa key vì key chưa chắc bị thu hồi). */
        LicenseApi::revokeSessionsOfDevice((int) $row['token_id'], (string) $row['device_uuid']);
        LicenseApi::signedError('renew', $nonceC, 'Device verification failed');
    }

    $contact = (string) $row['contact_link'];

    if ((int) $row['is_maintenance'] === 1) {
        LicenseApi::signedError('renew', $nonceC, 'System Maintenance', false, $contact);
    }
    if ((string) $row['key_status'] === 'revoked') {
        LicenseApi::signedError('renew', $nonceC, 'Key revoked', false, $contact);
    }
    if ((string) $row['key_status'] === 'suspended') {
        LicenseApi::signedError('renew', $nonceC, 'Key suspended', false, $contact);
    }

    $now = date('Y-m-d H:i:s');
    if ($row['expire_date'] !== null && $row['expire_date'] < $now) {
        LicenseApi::audit((int) $row['token_id'], $sessionId, 'renew_expired', []);
        LicenseApi::signedError('renew', $nonceC, 'Key expired', false, $contact);
    }

    /* ---- Gia hạn ---- */
    $result = LicenseApi::renewSession($row, $sequence);
    if (!$result['ok']) {
        LicenseApi::audit((int) $row['token_id'], $sessionId, 'renew_' . str_replace(' ', '_', $result['reason']), []);
        LicenseApi::signedError('renew', $nonceC, $result['reason'], false, $contact);
    }

    $lease  = $result['lease'];
    $daysLeft = (int) floor((strtotime((string) $row['expire_date']) - strtotime($now)) / 86400);
    if ($daysLeft < 0) {
        $daysLeft = 0;
    }

    LicenseApi::audit((int) $row['token_id'], $sessionId, 'renew_ok', ['seq' => $lease['sequence']]);

    $payload = LicenseApi::signedLease([
        'action'         => 'renew',
        'status'         => '1',
        'message'        => 'Active',
        'session_id'     => $lease['session_id'],
        'nonce_c'        => $nonceC,
        'license_fp'     => $lease['license_fp'],
        'device_binding' => $lease['device_binding'],
        'sequence'       => $lease['sequence'],
        'issued_at'      => $lease['issued_at'],
        'expires_at'     => $lease['expires_at'],
        'key_type'       => (string) $row['type'],
        'expiry'         => (string) ($row['expire_date'] ?? ''),
        'days_left'      => (string) $daysLeft,
        'contact'        => $contact,
        'maintenance'    => '0',
        'permissions'    => '{"esp":1}',
    ]);
    if ($payload === null) {
        api_error('Server error', true);
    }
    json_out($payload);
}

/* ====================================================================== */
/*  V2 — offsets: cấp offset game cho session hợp lệ (Task 17)            */
/* ======================================================================= */

function do_offsets(string $token, array $body): void
{
    $sessionId = strtolower((string) ($body['session_id'] ?? ''));
    $nonceC    = strtolower((string) ($body['nonce_c'] ?? ''));
    $ts        = (int) ($body['ts'] ?? 0);
    $sequence  = (int) ($body['sequence'] ?? 0);
    $pop       = (string) ($body['pop'] ?? '');

    if ($sessionId === '' || $nonceC === '' || $ts === 0 || $sequence < 1 || $pop === '') {
        LicenseApi::signedError('offsets', $nonceC, 'Missing params');
    }
    if (!LicenseApi::validSessionFormat($sessionId)
        || !LicenseApi::validNonceFormat($nonceC)
        || !LicenseApi::validB64($pop, 64, 200)) {
        LicenseApi::signedError('offsets', $nonceC, 'Invalid params');
    }
    if (abs(time() - $ts) > LicenseApi::CLOCK_SKEW) {
        LicenseApi::signedError('offsets', $nonceC, 'Request expired');
    }
    if (!LicenseApi::rateLimit('ip:' . LicenseApi::clientIp(), 120, 60)) {
        api_error('Too many requests');
    }
    try {
        $nonceFresh = LicenseApi::nonceRegister($nonceC, 'c');
    } catch (RuntimeException $e) {
        LicenseApi::signedError('offsets', $nonceC, 'Database unavailable');
    }
    if (!$nonceFresh) {
        LicenseApi::audit(null, $sessionId, 'offsets_replay', []);
        LicenseApi::signedError('offsets', $nonceC, 'Replay detected');
    }

    /* ---- Nạp session + key + project + device (1 query như renew) ---- */
    try {
        $row = db_query(
            'SELECT s.session_id, s.token_id, s.device_uuid, s.device_pub_hash, s.sequence,
                    s.lease_expires_at, s.status,
                    t.token_code, t.status AS key_status, t.expire_date, t.type, t.project_id,
                    p.contact_link, p.is_maintenance, p.project_token,
                    d.device_pub
             FROM license_sessions s
             JOIN tbl_tokens t ON t.id = s.token_id
             JOIN tbl_projects p ON p.id = t.project_id
             LEFT JOIN tbl_device_history d ON d.token_id = s.token_id AND d.device_uuid = s.device_uuid
             WHERE s.session_id = ? LIMIT 1',
            [$sessionId]
        )->fetch();
    } catch (RuntimeException $e) {
        LicenseApi::signedError('offsets', $nonceC, 'Database unavailable');
    }

    if ($row === false || $row['device_pub'] === null) {
        LicenseApi::signedError('offsets', $nonceC, 'Session expired');
    }

    if ($token !== '' && !hash_equals((string) $row['project_token'], $token)) {
        LicenseApi::signedError('offsets', $nonceC, 'Session expired');
    }

    /* ---- PoP pop3 (có action trong chuỗi — khác pop1/pop2) ---- */
    $popMsg = 'pop3|offsets|' . $sessionId . '|' . $nonceC . '|' . $ts . '|' . $sequence;
    if (!LicenseCrypto::verifyDevicePop($popMsg, $pop, (string) $row['device_pub'])) {
        LicenseApi::audit((int) $row['token_id'], $sessionId, 'offsets_pop_fail', ['uuid' => $row['device_uuid']]);
        /* PoP sai → nghi clone → hủy session như renew */
        LicenseApi::revokeSessionsOfDevice((int) $row['token_id'], (string) $row['device_uuid']);
        LicenseApi::signedError('offsets', $nonceC, 'Device verification failed');
    }

    $contact = (string) $row['contact_link'];

    if ((int) $row['is_maintenance'] === 1) {
        LicenseApi::signedError('offsets', $nonceC, 'System Maintenance', false, $contact);
    }
    if ((string) $row['key_status'] === 'revoked') {
        LicenseApi::signedError('offsets', $nonceC, 'Key revoked', false, $contact);
    }
    if ((string) $row['key_status'] === 'suspended') {
        LicenseApi::signedError('offsets', $nonceC, 'Key suspended', false, $contact);
    }

    $now = date('Y-m-d H:i:s');
    if ($row['expire_date'] !== null && $row['expire_date'] < $now) {
        LicenseApi::audit((int) $row['token_id'], $sessionId, 'offsets_expired', []);
        LicenseApi::signedError('offsets', $nonceC, 'Key expired', false, $contact);
    }

    /* ---- Kiểm tra offset TRƯỚC KHI renew (để từ chối không lệch
     * sequence — client nhận Rejected và tự retry/kill-switch) ---- */
    $offs = LicenseApi::activeOffsets();
    if ($offs === null) {
        LicenseApi::audit((int) $row['token_id'], $sessionId, 'offsets_unavailable', []);
        LicenseApi::signedError('offsets', $nonceC, 'Offsets unavailable');
    }

    /* ---- Gia hạn lease (sequence +1) + kèm offset ĐÃ KÝ ---- */
    $result = LicenseApi::renewSession($row, $sequence);
    if (!$result['ok']) {
        LicenseApi::audit((int) $row['token_id'], $sessionId, 'offsets_' . str_replace(' ', '_', $result['reason']), []);
        LicenseApi::signedError('offsets', $nonceC, $result['reason'], false, $contact);
    }

    $lease = $result['lease'];
    $daysLeft = (int) floor((strtotime((string) $row['expire_date']) - strtotime($now)) / 86400);
    if ($daysLeft < 0) {
        $daysLeft = 0;
    }

    $slots = 0;
    $decoded = json_decode((string) $offs['payload'], true);
    if (is_array($decoded)) {
        $slots = count($decoded);
    }
    LicenseApi::audit((int) $row['token_id'], $sessionId, 'offsets_ok',
                       ['v' => $offs['game_version'], 'slots' => $slots]);

    $payload = LicenseApi::signedLease([
        'action'         => 'offsets',
        'status'         => '1',
        'message'        => 'OK',
        'session_id'     => $lease['session_id'],
        'nonce_c'        => $nonceC,
        'license_fp'     => $lease['license_fp'],
        'device_binding' => $lease['device_binding'],
        'sequence'       => $lease['sequence'],
        'issued_at'      => $lease['issued_at'],
        'expires_at'     => $lease['expires_at'],
        'key_type'       => (string) $row['type'],
        'expiry'         => (string) ($row['expire_date'] ?? ''),
        'days_left'      => (string) $daysLeft,
        'contact'        => $contact,
        'maintenance'    => '0',
        'permissions'    => '{"esp":1}',
        'game_version'   => (string) $offs['game_version'],
        'offsets'        => (string) $offs['payload'],
    ]);
    if ($payload === null) {
        api_error('Server error', true);
    }
    json_out($payload);
}

/* ====================================================================== */
/*  Legacy V1 — check (unsigned, migration only)                           */
/* ====================================================================== */

function do_check_legacy(array $project, string $contact): void
{
    $key  = strtoupper(trim((string) ($_GET['key'] ?? '')));
    $uuid = strtolower(trim((string) ($_GET['uuid'] ?? '')));

    if ($key === '' || $uuid === '') {
        api_error('Missing params');
    }
    if (!LicenseApi::validKeyFormat($key) || !LicenseApi::validUuidFormat($uuid)) {
        api_error('Key invalid for this package');
    }
    if (!LicenseApi::rateLimit('keyfail:' . hash('sha256', $key), 6, 60)
        || !LicenseApi::rateLimit('uuid:' . hash('sha256', $uuid), 30, 60)) {
        api_error('Too many requests');
    }

    try {
        $tokenRow = db_query(
            'SELECT id, type, duration, expire_date, max_devices, status FROM tbl_tokens
             WHERE token_code = ? AND project_id = ? LIMIT 1',
            [$key, $project['id']]
        )->fetch();
    } catch (RuntimeException $e) {
        api_error('Database unavailable', true);
    }

    if ($tokenRow === false) {
        api_error('Key invalid for this package');
    }

    if ((string) $tokenRow['status'] === 'revoked') {
        api_error('Key revoked', false, $contact);
    }
    if ((string) $tokenRow['status'] === 'suspended') {
        api_error('Key suspended', false, $contact);
    }

    if ((int) $project['is_maintenance'] === 1) {
        api_error('System Maintenance', true, $contact);
    }

    $now = date('Y-m-d H:i:s');

    if ($tokenRow['type'] === 'dynamic' && $tokenRow['expire_date'] === null) {
        $expire = date('Y-m-d H:i:s', strtotime('+' . (int) $tokenRow['duration'] . ' days'));
        db_query(
            'UPDATE tbl_tokens SET expire_date = ? WHERE id = ? AND expire_date IS NULL',
            [$expire, $tokenRow['id']]
        );
        $tokenRow['expire_date'] = db_query(
            'SELECT expire_date FROM tbl_tokens WHERE id = ? LIMIT 1',
            [$tokenRow['id']]
        )->fetchColumn();
    }

    if ($tokenRow['expire_date'] !== null && $tokenRow['expire_date'] < $now) {
        api_error('Key expired', false, $contact);
    }

    /* V1 không có device_pub → chỉ claim dạng rỗng; thiết bị đã từng dùng
     * V2 (có keypair) sẽ bị từ chối để không downgrade được. */
    $claim = LicenseApi::claimDevice((int) $tokenRow['id'], $uuid, '', (int) $tokenRow['max_devices'], true);
    if (!$claim['ok']) {
        api_error($claim['reason'], false, $contact);
    }

    $daysLeft = (int) floor((strtotime((string) $tokenRow['expire_date']) - strtotime($now)) / 86400);
    if ($daysLeft < 0) {
        $daysLeft = 0;
    }

    json_out([
        'status'    => true,
        'message'   => 'Active',
        'expiry'    => $tokenRow['expire_date'],
        'days_left' => $daysLeft,
        'contact'   => $contact,
    ]);
}
