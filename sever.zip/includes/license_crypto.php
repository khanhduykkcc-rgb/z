<?php
/**
 * LICENSE CRYPTO — sinh / nạp khóa ký ECDSA P-256 + ký / xác minh phản hồi V2.
 *
 * NGUYÊN TẮC:
 *   • Private key ký CHỈ tồn tại trên server (file includes/signing_key.php,
 *     denied truy cập HTTP qua .htaccess). KHÔNG BAO GIỜ đưa vào client.
 *   • Client chỉ nhúng PUBLIC KEY (PEM) trong HeaderAPI.h để verify.
 *   • Mọi phản hồi V2 được ký trên chuỗi canonical `sig_input`
 *     (các cặp key=value nối bằng '|'), client verify chữ ký RỒI MỚI tin.
 *
 * Chuỗi ký là duy nhất cho mỗi phản hồi nhờ nonce / sequence / server_time.
 */

declare(strict_types=1);

final class LicenseCrypto
{
    /** Thuật toán: ECDSA trên prime256v1, hash SHA-256 (DER signature). */
    const ALGO = OPENSSL_ALGO_SHA256;

    /** File chứa private key (trong includes/, đã deny HTTP). */
    const KEY_FILE = __DIR__ . '/signing_key.php';

    /** Giá trị setting lưu public key PEM (để admin xem / đối chiếu). */
    const SETTING_PUBKEY = 'license_public_key';

    private static ?string $privatePem = null;
    private static ?string $publicPem  = null;

    /* ------------------------------------------------------------------ */
    /*  Khóa                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Nạp private key. Nếu chưa có file key thì TẠO MỚI (một lần) và ghi
     * vào includes/signing_key.php + lưu public key vào tbl_settings.
     * Trả về null nếu không dùng được openssl → caller phải fail-closed.
     */
    public static function privateKey(): ?string
    {
        if (self::$privatePem !== null) {
            return self::$privatePem;
        }

        if (is_file(self::KEY_FILE)) {
            $pem = self::loadKeyFile();
            if ($pem !== null && self::pemUsable($pem, true)) {
                self::$privatePem = $pem;
                return $pem;
            }
            return null; /* file hỏng — fail closed, không tự sinh đè */
        }

        return self::generateAndStore();
    }

    /**
     * Public key PEM tương ứng (dùng nội bộ / hiển thị admin).
     */
    public static function publicKey(): ?string
    {
        if (self::$publicPem !== null) {
            return self::$publicPem;
        }
        $priv = self::privateKey();
        if ($priv === null) {
            return null;
        }
        $details = openssl_pkey_get_details(openssl_pkey_get_private($priv));
        if (!is_array($details) || !isset($details['key'])) {
            return null;
        }
        self::$publicPem = (string) $details['key'];
        return self::$publicPem;
    }

    /**
     * Trả về public key dạng PEM đã trim để dán vào HeaderAPI.h (khanhduy).
     * Gọi từ upgrade.php sau khi sinh khóa.
     */
    public static function publicKeyForClient(): ?string
    {
        $pem = self::publicKey();
        if ($pem === null) {
            return null;
        }
        return trim(preg_replace('/\s+/', "\n", trim($pem)));
    }

    /**
     * Sinh cặp khóa mới GHI ĐÈ (chỉ gọi từ upgrade khi admin yêu cầu
     * rotate — mọi client cũ sẽ cần build mới với public key mới).
     */
    public static function rotate(): ?string
    {
        if (is_file(self::KEY_FILE) && !@unlink(self::KEY_FILE)) {
            return null;
        }
        self::$privatePem = null;
        self::$publicPem  = null;
        return self::generateAndStore();
    }

    /* ------------------------------------------------------------------ */
    /*  Ký / xác minh                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * Ký $message bằng private key → DER signature (ECDSA-SHA256).
     */
    public static function sign(string $message): ?string
    {
        $priv = self::privateKey();
        if ($priv === null) {
            return null;
        }
        $sig = '';
        $ok = openssl_sign($message, $sig, $priv, self::ALGO);
        return $ok ? $sig : null;
    }

    /**
     * Xác minh chữ ký DER trên $message bằng PEM public key (dùng cho test
     * nội bộ / verify PoP của thiết bị).
     */
    public static function verify(string $message, string $derSignature, string $publicPem): bool
    {
        $pub = openssl_pkey_get_public($publicPem);
        if ($pub === false) {
            return false;
        }
        return openssl_verify($message, $derSignature, $pub, self::ALGO) === 1;
    }

    /**
     * Xác minh proof-of-possession: client gửi device_pub = base64 của
     * điểm EC thô 65 bytes (04||X||Y). Bọc thành SPKI PEM rồi verify.
     */
    public static function verifyDevicePop(string $message, string $popB64, string $devicePubB64): bool
    {
        $raw = base64_decode($devicePubB64, true);
        if ($raw === false || strlen($raw) !== 65 || $raw[0] !== "\x04") {
            return false;
        }
        $sig = base64_decode($popB64, true);
        if ($sig === false || strlen($sig) < 8 || strlen($sig) > 200) {
            return false;
        }

        /* SPKI header cố định của P-256 + 65-byte point */
        $spki  = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $raw;
        $pem   = "-----BEGIN PUBLIC KEY-----\n"
               . chunk_split(base64_encode($spki), 64, "\n")
               . "-----END PUBLIC KEY-----\n";

        return self::verify($message, $sig, $pem);
    }

    /* ------------------------------------------------------------------ */
    /*  Canonical sig_input                                               */
    /* ------------------------------------------------------------------ */

    /**
     * Chuỗi canonical được ký: cặp key=value nối '|', THỨ TỰ CỐ ĐỊNH.
     * Client chỉ tin các giá trị đọc từ chuỗi này (sau khi verify chữ ký).
     *
     * @param array $fields khóa => giá trị (giá trị được làm sạch: bỏ '|' và xuống dòng)
     */
    public static function buildSigInput(array $fields): string
    {
        $parts = [];
        foreach ($fields as $k => $v) {
            $v = str_replace(["|", "\n", "\r"], ' ', (string) $v);
            $parts[] = $k . '=' . $v;
        }
        return implode('|', $parts);
    }

    /**
     * Gói phản hồi V2: {sig_input, signature} — client verify rồi mới dùng.
     * Fail-closed: không ký được → trả null, caller xuất api_error JSON thường.
     */
    public static function signResponse(array $fields): ?array
    {
        $sigInput = self::buildSigInput($fields);
        $sig = self::sign($sigInput);
        if ($sig === null) {
            return null;
        }
        return [
            'sig_input' => $sigInput,
            'signature' => base64_encode($sig),
        ];
    }

    /* ------------------------------------------------------------------ */
    /*  Nội bộ                                                            */
    /* ------------------------------------------------------------------ */

    private static function loadKeyFile(): ?string
    {
        $pem = include self::KEY_FILE;
        return is_string($pem) ? $pem : null;
    }

    private static function generateAndStore(): ?string
    {
        $res = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        if ($res === false) {
            return null;
        }
        $ok = openssl_pkey_export($res, $pem);
        if (!$ok) {
            return null;
        }

        $details = openssl_pkey_get_details($res);
        if (!is_array($details) || !isset($details['key'])) {
            return null;
        }
        $pub = (string) $details['key'];

        $php = "<?php\n/* PRIVATE — không commit, không chia sẻ. Sinh bởi upgrade.php. */\nreturn "
             . var_export($pem, true) . ";\n";
        if (@file_put_contents(self::KEY_FILE, $php, LOCK_EX) === false) {
            return null; /* không ghi được file → không dùng khóa này */
        }
        @chmod(self::KEY_FILE, 0600);

        self::$privatePem = $pem;
        self::$publicPem  = $pub;
        return $pem;
    }

    private static function pemUsable(string $pem, bool $private): bool
    {
        $key = $private ? openssl_pkey_get_private($pem) : openssl_pkey_get_public($pem);
        if ($key === false) {
            return false;
        }
        $details = openssl_pkey_get_details($key);
        if (!is_array($details)) {
            return false;
        }
        /* EC P-256 = 3 (OPENSSL_KEYTYPE_EC) + 256 bits */
        return ($details['type'] ?? -1) === OPENSSL_KEYTYPE_EC
            && (int) ($details['bits'] ?? 0) === 256;
    }
}
