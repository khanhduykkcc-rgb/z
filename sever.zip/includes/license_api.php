<?php
/**
 * LICENSE API CORE — validation, rate-limit, replay protection, session/lease,
 * device binding (proof-of-possession), audit logging.
 *
 * Server là AUTHORITY duy nhất:
 *   • Mọi authorization chỉ tồn tại dưới dạng lease ngắn hạn CÓ CHỮ KÝ.
 *   • Nonce dùng 1 lần + timestamp + sequence → chống replay/reorder.
 *   • Thiết bị bị khóa chặt vào keypair (Secure Enclave phía client,
 *     private key không rời thiết bị — server chỉ thấy public key).
 *
 * Không có bất kỳ secret nào của server rời khỏi file này trừ public key.
 */

declare(strict_types=1);

require_once __DIR__ . '/license_crypto.php';

final class LicenseApi
{
    /* ----------------------------- Hằng số ----------------------------- */

    const PROTOCOL_VERSION   = 2;

    /** Lease mặc định (giây) — có thể override bằng tbl_settings. */
    const LEASE_TTL_DEFAULT  = 600;

    /** Grace mặc định (giây) cho phép client dùng tiếp khi mất mạng. */
    const GRACE_TTL_DEFAULT  = 900;

    /** Chênh lệch đồng hồ tối đa được chấp nhận trong request (giây). */
    const CLOCK_SKEW         = 300;

    /** Tuổi tối đa của nonce (giây). */
    const NONCE_TTL          = 600;

    /** Fingerprint salt — sinh 1 lần khi migration, lưu tbl_settings. */
    const SETTING_FP_SALT    = 'license_fp_salt';

    /* ------------------------------ IPv4/6 ------------------------------ */

    public static function clientIp(): string
    {
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        if ($ip === '' && PHP_SAPI === 'cli') {
            return '127.0.0.1';
        }
        return $ip;
    }

    /* --------------------------- Validation ----------------------------- */

    /** Key: XXXX-XXXX-XXXX-XXXX theo alphabet server (bỏ ký tự dễ nhầm). */
    public static function validKeyFormat(string $key): bool
    {
        return (bool) preg_match('/^[A-Z0-9]{4}(-[A-Z0-9]{4}){3}$/', $key);
    }

    /** UUID: 8-4-4-4-12 hex (IDFV) hoặc 32 hex thường. */
    public static function validUuidFormat(string $uuid): bool
    {
        return (bool) preg_match('/^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$/', $uuid)
            || (bool) preg_match('/^[0-9A-Fa-f]{32}$/', $uuid);
    }

    /** Project token: 32 hex. */
    public static function validTokenFormat(string $token): bool
    {
        return (bool) preg_match('/^[0-9a-fA-F]{32}$/', $token);
    }

    /** Nonce hex 32 ký tự (16 bytes). */
    public static function validNonceFormat(string $nonce): bool
    {
        return (bool) preg_match('/^[0-9a-fA-F]{32}$/', $nonce);
    }

    /** Session id hex 32 ký tự. */
    public static function validSessionFormat(string $sid): bool
    {
        return (bool) preg_match('/^[0-9a-fA-F]{32}$/', $sid);
    }

    /** Base64 chuẩn (device_pub / pop / signature). */
    public static function validB64(string $value, int $minLen, int $maxLen): bool
    {
        $len = strlen($value);
        if ($len < $minLen || $len > $maxLen) {
            return false;
        }
        return (bool) preg_match('/^[A-Za-z0-9+\/]+={0,2}$/', $value);
    }

    /* ---------------------------- Rate limit ---------------------------- */

    /**
     * Buckets nhiều tầng: IP, IP-fail, key-fail, uuid. Dùng bảng DB
     * (shared hosting không chắc có APCu/Redis) + cửa sổ 60 giây.
     *
     * @param string $bucket   ví dụ 'ip:1.2.3.4', 'keyfail:<sha256>'
     * @param int    $limit    số request tối đa trong cửa sổ
     * @param int    $window   chiều dài cửa sổ (giây)
     */
    public static function rateLimit(string $bucket, int $limit, int $window): bool
    {
        $now = time();
        try {
            /* UPSERT: reset nếu cửa sổ cũ, ngược lại tăng đếm. */
            db_query(
                'INSERT INTO license_rate (bucket, count, window_start)
                 VALUES (?, 1, ?)
                 ON DUPLICATE KEY UPDATE
                    count      = IF(window_start <= ?, 1, count + 1),
                    window_start = IF(window_start <= ?, VALUES(window_start), window_start)',
                [$bucket, $now, $now - $window, $now - $window]
            );
            $row = db_query(
                'SELECT count, window_start FROM license_rate WHERE bucket = ? LIMIT 1',
                [$bucket]
            )->fetch();
            return is_array($row) && (int) $row['count'] <= $limit;
        } catch (Throwable $e) {
            /* Bảng chưa migrate → không chặn (fail-open cho legacy),
             * các kiểm tra khác vẫn bảo vệ. */
            return true;
        }
    }

    public static function rateBump(string $bucket): void
    {
        try {
            db_query(
                'UPDATE license_rate SET count = count + 1 WHERE bucket = ?',
                [$bucket]
            );
        } catch (Throwable $e) {
            /* bỏ qua */
        }
    }

    /* ------------------------ Schema self-heal (V2) -------------------- */

    /**
     * Tự tạo 4 bảng V2 + 2 CỘT V2 trên bảng cũ nếu thiếu (idempotent —
     * CREATE TABLE IF NOT EXISTS + ALTER có kiểm tra information_schema,
     * DDL khớp hệt upgrade.php). Chạy 1 lần / process PHP (static guard);
     * $force = true để chạy lại sau khi vừa gặp lỗi bảng.
     *
     * Bối cảnh bug: server deploy file V2 nhưng CHƯA chạy upgrade.php →
     * license_nonces không tồn tại → hello INSERT lỗi bị nuốt (giả vờ OK)
     * → auth không tìm thấy challenge → mọi key đều 'Challenge expired'.
     *
     * Bối cảnh bug #2 ("Database error khi nhập key ĐÚNG"): self-heal cũ
     * chỉ tạo 4 bảng MỚI, bỏ sót 2 cột của bảng CŨ — claimDevice
     * SELECT/INSERT tbl_device_history.device_pub → PDOException 42S22 →
     * 'Database error' CHỈ khi key hợp lệ (key giả bị chặn từ bước trước,
     * không bao giờ chạm vào claimDevice).
     *
     * Hoàn toàn im lặng khi thất bại (thiếu quyền CREATE/ALTER...) — lỗi
     * thật sẽ được bộc lộ rõ ràng ở claimDevice/nonceRegister.
     */
    public static function ensureV2Tables(bool $force = false): void
    {
        static $ensured = false;
        if ($ensured && !$force) {
            return;
        }
        $ensured = true;
        try {
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_sessions (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    session_id CHAR(32) NOT NULL,
                    token_id INT UNSIGNED NOT NULL,
                    device_uuid VARCHAR(64) NOT NULL,
                    device_pub_hash CHAR(16) NOT NULL,
                    issued_at INT UNSIGNED NOT NULL,
                    last_seen INT UNSIGNED NOT NULL,
                    lease_expires_at INT UNSIGNED NOT NULL,
                    sequence INT UNSIGNED NOT NULL DEFAULT 1,
                    status ENUM('active','revoked','expired') NOT NULL DEFAULT 'active',
                    created_at INT UNSIGNED NOT NULL,
                    ended_at INT UNSIGNED NULL,
                    PRIMARY KEY (id),
                    UNIQUE KEY uq_sessions_sid (session_id),
                    KEY idx_sessions_token (token_id),
                    KEY idx_sessions_status (status),
                    KEY idx_sessions_lease (lease_expires_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_nonces (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    nonce_hash CHAR(64) NOT NULL,
                    kind ENUM('c','s','u') NOT NULL DEFAULT 'c',
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    UNIQUE KEY uq_nonces_hash (nonce_hash),
                    KEY idx_nonces_created (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_rate (
                    bucket VARCHAR(80) NOT NULL,
                    count INT UNSIGNED NOT NULL DEFAULT 1,
                    window_start INT UNSIGNED NOT NULL,
                    PRIMARY KEY (bucket),
                    KEY idx_rate_window (window_start)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_audit (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    token_id INT UNSIGNED NULL,
                    session_id CHAR(32) NULL,
                    event VARCHAR(40) NOT NULL,
                    ip VARCHAR(45) NOT NULL DEFAULT '',
                    device_uuid VARCHAR(64) NOT NULL DEFAULT '',
                    detail VARCHAR(255) NOT NULL DEFAULT '',
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_audit_token (token_id),
                    KEY idx_audit_created (created_at),
                    KEY idx_audit_event (event)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );

            /* Task 17 — kho offset server-authoritative: client KHÔNG chứa
             * offset; chỉ nhận qua action=offsets khi session hợp lệ. Bảng
             * trống → seed 1 lần từ includes/offsets_data.php. */
            db()->exec(
                "CREATE TABLE IF NOT EXISTS license_offsets (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    game_version VARCHAR(32) NOT NULL DEFAULT '',
                    payload MEDIUMTEXT NOT NULL,
                    is_active TINYINT UNSIGNED NOT NULL DEFAULT 1,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_offsets_active (is_active)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            try {
                $offsCount = (int) db_query('SELECT COUNT(*) FROM license_offsets', [])->fetchColumn();
                if ($offsCount === 0) {
                    require_once __DIR__ . '/offsets_data.php';
                    $offsJson = json_encode(
                        OffsetsData::defaults(),
                        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
                    );
                    if (is_string($offsJson)) {
                        db_query(
                            'INSERT INTO license_offsets
                                 (game_version, payload, is_active, created_at, updated_at)
                             VALUES (?, ?, 1, ?, ?)',
                            [OffsetsData::GAME_VERSION, $offsJson, time(), time()]
                        );
                        error_log('[license] offsets: seeded defaults v' . OffsetsData::GAME_VERSION);
                    }
                }
            } catch (Throwable $eSeed) {
                /* seed lỗi (quyền ghi...) — activeOffsets() sẽ fallback file */
            }

            /* 2 cột V2 trên bảng CŨ (bug #2 — 'Database error khi nhập key
             * đúng'): DDL + UPDATE hồi sinh khớp hệt upgrade.php. Idempotent
             * nhờ kiểm tra information_schema trước khi ALTER. */
            self::addColumnIfMissing(
                'tbl_tokens',
                'status',
                "ALTER TABLE tbl_tokens ADD COLUMN status ENUM('active','suspended','revoked')
                 NOT NULL DEFAULT 'active' AFTER max_devices"
            );
            try {
                db_query("UPDATE tbl_tokens SET status = 'active' WHERE status IS NULL OR status = ''", []);
            } catch (Throwable $e) {
                /* cột vừa thêm đã có DEFAULT 'active' — bỏ qua */
            }
            self::addColumnIfMissing(
                'tbl_device_history',
                'device_pub',
                'ALTER TABLE tbl_device_history ADD COLUMN device_pub VARCHAR(120)
                 NULL DEFAULT NULL AFTER device_uuid'
            );
        } catch (Throwable $e) {
            /* thiếu quyền CREATE / DB không ổn định — giữ im lặng,
             * lỗi nghiệp vụ sẽ bộc lộ ở claimDevice/nonceRegister */
        }
    }

    /**
     * ALTER TABLE ADD COLUMN chỉ khi cột chưa tồn tại (kiểm tra qua
     * information_schema — không phụ thuộc helper của upgrade.php).
     * Im lặng khi thất bại (thiếu bảng gốc / thiếu quyền ALTER).
     */
    private static function addColumnIfMissing(string $table, string $column, string $alterSql): void
    {
        try {
            $exists = db_query(
                'SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$table, $column]
            )->fetchColumn();
            if ((int) $exists === 0) {
                db()->exec($alterSql);
                error_log("[license] self-heal: added column {$table}.{$column}");
            }
        } catch (Throwable $e) {
            /* im lặng — caller bộc lộ lỗi rõ ràng hơn */
        }
    }

    /* --------------------------- Replay nonce --------------------------- */

    /**
     * Đăng ký nonce (client hoặc server) — INSERT unique.
     * Trả về false CHỈ khi nonce đã DÙNG (duplicate = replay).
     * Lỗi hạ tầng (bảng thiếu/hỏng) → tự chữa bảng 1 lần rồi INSERT lại;
     * vẫn lỗi → RuntimeException (caller xuất 'Database unavailable').
     *
     * SỬA BUG NGHIÊM TRỌNG: bản cũ nuốt mọi lỗi non-duplicate (return true)
     * → hello OK dù nonce KHÔNG được lưu → auth luôn 'Challenge expired'
     * ngay cả với key hợp lệ (đã tái hiện trực tiếp trên server đang chạy).
     */
    public static function nonceRegister(string $nonce, string $kind): bool
    {
        $hash = hash('sha256', strtolower($nonce));
        $sql  = 'INSERT INTO license_nonces (nonce_hash, kind, created_at) VALUES (?, ?, ?)';
        $args = [$hash, $kind, time()];
        try {
            db_query($sql, $args);
            return true;
        } catch (PDOException $e) {
            if ((int) $e->getCode() === 23000) {
                return false;   /* duplicate → replay */
            }
            /* bảng thiếu/hỏng → rơi xuống phần tự chữa bên dưới */
        } catch (Throwable $e) {
            throw new RuntimeException('nonce store unavailable');
        }

        /* Tự chữa schema đúng 1 lần rồi INSERT lại */
        self::ensureV2Tables(true);
        try {
            db_query($sql, $args);
            return true;
        } catch (PDOException $e2) {
            if ((int) $e2->getCode() === 23000) {
                return false;   /* race: request khác vừa chèn cùng hash */
            }
            throw new RuntimeException('nonce store unavailable');
        }
    }

    /**
     * Kiểm tra nonce_s do server phát hành còn hiệu lực (kind 's',
     * chưa quá NONCE_TTL). Dùng khi client echo challenge.
     *
     * SỬA BUG: bản cũ catch(Throwable) → return false → mọi lỗi hạ tầng
     * đều bị báo nhầm thành 'Challenge expired'. Giờ: row không tồn tại /
     * quá hạn → false (đúng nghĩa); lỗi hạ tầng → tự chữa + RuntimeException
     * (caller xuất 'Database unavailable' — chẩn đoán đúng bệnh).
     */
    public static function nonceServerValid(string $nonce): bool
    {
        $hash = hash('sha256', strtolower($nonce));
        $sql  = "SELECT created_at FROM license_nonces WHERE nonce_hash = ? AND kind = 's' LIMIT 1";
        try {
            $ts = db_query($sql, [$hash])->fetchColumn();
        } catch (Throwable $e) {
            self::ensureV2Tables(true);   /* tự chữa 1 lần */
            try {
                $ts = db_query($sql, [$hash])->fetchColumn();
            } catch (Throwable $e2) {
                throw new RuntimeException('nonce store unavailable');
            }
        }
        return $ts !== false && (time() - (int) $ts) <= self::NONCE_TTL;
    }

    /** Đánh dấu nonce_s đã dùng (single-use). Best-effort: lỗi → tự chữa
     *  bảng 1 lần rồi thử lại; vẫn lỗi thì bỏ qua (nonce chỉ hết hạn muộn
     *  hơn một chút — không ảnh hưởng tính đúng đắn của auth). */
    public static function nonceConsume(string $nonce): void
    {
        $hash = hash('sha256', strtolower($nonce));
        $sql  = "UPDATE license_nonces SET kind = 'u' WHERE nonce_hash = ?";
        try {
            db_query($sql, [$hash]);
        } catch (Throwable $e) {
            try {
                self::ensureV2Tables(true);
                db_query($sql, [$hash]);
            } catch (Throwable $e2) {
                /* bỏ qua */
            }
        }
    }

    /** Dọn dẹp xác suất — chạy ~10% request để bảng không phình. */
    public static function housekeeping(): void
    {
        if (random_int(1, 10) !== 1) {
            return;
        }
        try {
            db_query('DELETE FROM license_nonces WHERE created_at < ?', [time() - 900]);
            db_query('DELETE FROM license_rate WHERE window_start < ?', [time() - 3600]);
            db_query('DELETE FROM license_audit WHERE created_at < ?', [time() - 2592000]);
        } catch (Throwable $e) {
            /* bỏ qua */
        }
    }

    /* ------------------------------- Audit ------------------------------ */

    public static function audit(?int $tokenId, ?string $sessionId, string $event, array $extra = []): void
    {
        try {
            db_query(
                'INSERT INTO license_audit (token_id, session_id, event, ip, device_uuid, detail, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [
                    $tokenId,
                    $sessionId,
                    mb_substr($event, 0, 40),
                    mb_substr(self::clientIp(), 0, 45),
                    mb_substr((string) ($extra['uuid'] ?? ''), 0, 64),
                    mb_substr(json_encode($extra, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '', 0, 255),
                    time(),
                ]
            );
        } catch (Throwable $e) {
            /* audit không được phép làm hỏng request */
        }
    }

    /* ----------------------------- Settings ----------------------------- */

    public static function leaseTtl(): int
    {
        $v = (int) get_setting('license_lease_ttl', (string) self::LEASE_TTL_DEFAULT);
        return max(60, min(7200, $v));
    }

    public static function graceTtl(): int
    {
        $v = (int) get_setting('license_grace_ttl', (string) self::GRACE_TTL_DEFAULT);
        return max(0, min(86400, $v));
    }

    public static function fpSalt(): string
    {
        $salt = get_setting(self::SETTING_FP_SALT, '');
        if ($salt === '') {
            $salt = bin2hex(random_bytes(16));
            set_setting(self::SETTING_FP_SALT, $salt);
        }
        return $salt;
    }

    /* ---------------------------- Fingerprint --------------------------- */

    /** 16 hex đầu của SHA256(salt + token_code) — không lộ token nội bộ. */
    public static function licenseFp(string $tokenCode): string
    {
        return substr(hash('sha256', self::fpSalt() . ':' . $tokenCode), 0, 16);
    }

    /** 16 hex đầu của SHA256(device_pub) — server & client tính giống nhau. */
    public static function deviceBinding(string $devicePubB64): string
    {
        return substr(hash('sha256', 'dev:' . $devicePubB64), 0, 16);
    }

    /* --------------------------- Lease signing -------------------------- */

    /**
     * Dựng + ký payload lease cho client. Trả về mảng JSON để json_out
     * hoặc null nếu không ký được (fail closed).
     *
     * @param array $fields các trường nghiệp vụ (status, session_id, ...)
     */
    public static function signedLease(array $fields): ?array
    {
        $fields['pv']         = (string) self::PROTOCOL_VERSION;
        $fields['server_time'] = (string) time();
        $fields['lease_ttl']  = (string) self::leaseTtl();
        $fields['grace_ttl']  = (string) self::graceTtl();

        /* Thứ tự trường cố định — client parse theo chuỗi này */
        $order = [
            'pv', 'action', 'status', 'message', 'session_id', 'nonce_c', 'nonce_s',
            'issued_at', 'expires_at', 'server_time', 'lease_ttl', 'grace_ttl',
            'license_fp', 'device_binding', 'sequence', 'key_type', 'expiry',
            'days_left', 'contact', 'maintenance', 'permissions',
        ];
        $ordered = [];
        foreach ($order as $k) {
            if (array_key_exists($k, $fields)) {
                $ordered[$k] = $fields[$k];
            }
        }
        foreach ($fields as $k => $v) {
            if (!array_key_exists($k, $ordered)) {
                $ordered[$k] = $v; /* trường ngoài danh sách vẫn được ký */
            }
        }

        return LicenseCrypto::signResponse($ordered);
    }

    /**
     * Phản hồi lỗi V2 — vẫn được ký (client verify trước khi hiển thị).
     */
    public static function signedError(string $action, string $nonceC, string $message, bool $forceExit = false, ?string $contact = null): void
    {
        $fields = [
            'action'  => $action,
            'status'  => '0',
            'message' => $message,
            'nonce_c' => $nonceC,
        ];
        if ($contact !== null) {
            $fields['contact'] = $contact;
        }
        if ($forceExit) {
            $fields['force_exit'] = '1';
        }
        $payload = self::signedLease($fields);
        if ($payload === null) {
            api_error('Server error', $forceExit, $contact); /* không ký được → lỗi thường */
            return;
        }
        json_out($payload);
    }

    /* ------------------------- Device management ------------------------ */

    /**
     * Claim thiết bị BÊN TRONG TRANSACTION (row lock trên tbl_tokens) —
     * 2 request đồng thời không thể cùng vượt max_devices, dynamic key
     * không thể kích hoạt 2 lần.
     *
     * $allowEmpty = true chỉ dành cho legacy V1 (không có keypair):
     *   • thiết bị đã gắn keypair (V2) → TỪ CHỐI (không cho downgrade)
     *   • thiết bị mới / chưa gắn → đăng ký với device_pub rỗng
     *
     * Trả về:
     *   ['ok'=>true]                                 — đã đăng ký / đăng ký mới
     *   ['ok'=>false,'reason'=>...]                  — vượt limit / lỗi
     *
     * SỬA BUG "Database error khi nhập key ĐÚNG": lỗi hạ tầng (cột
     * tbl_device_history.device_pub thiếu vì chưa chạy upgrade.php →
     * SQLSTATE 42S22) → TỰ CHỮA SCHEMA (ensureV2Tables thêm cột) rồi
     * THỬ LẠI đúng 1 lần. Vẫn lỗi → ghi error_log kèm thông điệp MySQL
     * thật + trả 'Database error (SQLSTATE)' để chẩn đoán từ xa.
     */
    public static function claimDevice(int $tokenId, string $uuid, string $devicePubB64, int $maxDevices, bool $allowEmpty = false): array
    {
        try {
            return self::claimDeviceOnce($tokenId, $uuid, $devicePubB64, $maxDevices, $allowEmpty);
        } catch (Throwable $e) {
            $db = db();
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            /* Lỗi hạ tầng → tự chữa schema 1 lần rồi thử lại (cột thiếu,
             * bảng thiếu — không áp dụng cho lỗi nghiệp vụ). */
            error_log('[license] claimDevice retry: ' . $e->getMessage());
            self::ensureV2Tables(true);
            try {
                return self::claimDeviceOnce($tokenId, $uuid, $devicePubB64, $maxDevices, $allowEmpty);
            } catch (Throwable $e2) {
                $db2 = db();
                if ($db2->inTransaction()) {
                    $db2->rollBack();
                }
                error_log('[license] claimDevice failed: ' . $e2->getMessage());
                $code = ($e2 instanceof PDOException) ? trim((string) $e2->getCode()) : '';
                return ['ok' => false, 'reason' => ($code !== '' ? "Database error ({$code})" : 'Database error')];
            }
        }
    }

    /**
     * Thân claimDevice — throw lỗi hạ tầng để wrapper tự chữa + retry;
     * lỗi nghiệp vụ trả về như thường (không retry).
     */
    private static function claimDeviceOnce(int $tokenId, string $uuid, string $devicePubB64, int $maxDevices, bool $allowEmpty): array
    {
        $db = db();
        $db->beginTransaction();
        try {
            /* Serialize mọi claim của cùng 1 key */
            db_query('SELECT id FROM tbl_tokens WHERE id = ? FOR UPDATE', [$tokenId])->fetchColumn();

            $exists = db_query(
                'SELECT id, device_pub FROM tbl_device_history WHERE token_id = ? AND device_uuid = ? LIMIT 1',
                [$tokenId, $uuid]
            )->fetch();

            if (is_array($exists)) {
                $stored = (string) ($exists['device_pub'] ?? '');
                if ($stored === '') {
                    if ($devicePubB64 !== '') {
                        /* Thiết bị cũ (V1) — nâng cấp: gắn keypair lần đầu gặp */
                        db_query('UPDATE tbl_device_history SET device_pub = ? WHERE id = ?', [$devicePubB64, $exists['id']]);
                    }
                    $db->commit();
                    return ['ok' => true];
                }
                if ($devicePubB64 === '' && $allowEmpty) {
                    /* Legacy: thiết bị đã gắn keypair → từ chối downgrade */
                    $db->rollBack();
                    return ['ok' => false, 'reason' => 'Device mismatch'];
                }
                if (!hash_equals($stored, $devicePubB64)) {
                    /* Cùng UUID nhưng keypair khác → thiết bị bị clone/spoof.
                     * Từ chối: private key thật không thể rời thiết bị. */
                    $db->rollBack();
                    return ['ok' => false, 'reason' => 'Device mismatch'];
                }
                $db->commit();
                return ['ok' => true];
            }

            $used = (int) db_query(
                'SELECT COUNT(*) FROM tbl_device_history WHERE token_id = ?',
                [$tokenId]
            )->fetchColumn();

            if ($used >= $maxDevices) {
                $db->rollBack();
                return ['ok' => false, 'reason' => 'Max devices reached'];
            }

            db_query(
                'INSERT INTO tbl_device_history (token_id, device_uuid, device_pub) VALUES (?, ?, ?)',
                [$tokenId, $uuid, $devicePubB64]
            );
            $db->commit();
            return ['ok' => true];
        } catch (PDOException $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            /* Unique violation do race khác → coi như đã đăng ký */
            if ((int) $e->getCode() === 23000) {
                return ['ok' => true];
            }
            /* Lỗi hạ tầng khác → propagate để wrapper tự chữa schema + retry */
            throw $e;
        }
    }

    /* --------------------------- Session/lease -------------------------- */

    /**
     * Tạo session + lease mới (đã kiểm tra mọi điều kiện nghiệp vụ).
     * Hủy session cũ của cùng thiết bị (1 active session / device).
     */
    public static function createSession(int $tokenId, string $uuid, string $devicePubB64, string $tokenCode, array $tokenRow): array
    {
        $sid     = bin2hex(random_bytes(16));
        $now     = time();
        $leaseTtl = self::leaseTtl();

        try {
            db_query('UPDATE license_sessions SET status = \'revoked\', ended_at = ?
                      WHERE token_id = ? AND device_uuid = ? AND status = \'active\'', [$now, $tokenId, $uuid]);
        } catch (Throwable $e) {
            /* bỏ qua */
        }

        db_query(
            'INSERT INTO license_sessions
                (session_id, token_id, device_uuid, device_pub_hash, issued_at,
                 last_seen, lease_expires_at, sequence, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, 1, \'active\', ?)',
            [
                $sid, $tokenId, $uuid, self::deviceBinding($devicePubB64),
                $now, $now, $now + $leaseTtl, $now,
            ]
        );

        return [
            'session_id'     => $sid,
            'issued_at'      => (string) $now,
            'expires_at'     => (string) ($now + $leaseTtl),
            'sequence'       => '1',
            'license_fp'     => self::licenseFp($tokenCode),
            'device_binding' => self::deviceBinding($devicePubB64),
        ];
    }

    /**
     * Kiểm tra + gia hạn session. Trả về:
     *   ['ok'=>true, 'lease'=>[...]]  — lease mới đã ký ở tầng trên
     *   ['ok'=>false,'reason'=>...]   — revoked / expired / sequence / device
     */
    public static function renewSession(array $sessionRow, int $clientSequence): array
    {
        $now = time();

        if ($sessionRow['status'] !== 'active') {
            return ['ok' => false, 'reason' => $sessionRow['status'] === 'revoked' ? 'Key revoked' : 'Session expired'];
        }

        /* Sequence request phải khớp giá trị server đang giữ — request cũ
         * (replay/reorder) sẽ lệch và bị từ chối. */
        $serverSeq = (int) $sessionRow['sequence'];
        if ($clientSequence !== $serverSeq) {
            return ['ok' => false, 'reason' => 'Sequence mismatch'];
        }

        /* Cho phép gia hạn trong lease + grace (khóa chức năng phía client
         * là việc của client sau grace — server chỉ giữ trạng thái trung thực). */
        $grace = $now - (int) $sessionRow['lease_expires_at'];
        if ($grace > self::graceTtl() + 60) {
            db_query('UPDATE license_sessions SET status = \'expired\', ended_at = ? WHERE session_id = ?', [$now, $sessionRow['session_id']]);
            return ['ok' => false, 'reason' => 'Session expired'];
        }

        $leaseTtl = self::leaseTtl();
        $newSeq   = $serverSeq + 1;
        db_query(
            'UPDATE license_sessions
             SET lease_expires_at = ?, last_seen = ?, sequence = ? WHERE session_id = ?',
            [$now + $leaseTtl, $now, $newSeq, $sessionRow['session_id']]
        );

        return [
            'ok' => true,
            'lease' => [
                'session_id'     => (string) $sessionRow['session_id'],
                'issued_at'      => (string) $now,
                'expires_at'     => (string) ($now + $leaseTtl),
                'sequence'       => (string) $newSeq,
                'license_fp'     => self::licenseFp((string) $sessionRow['token_code']),
                'device_binding' => (string) $sessionRow['device_pub_hash'],
            ],
        ];
    }

    /**
     * Hủy mọi session của một key (revoke key / force reauth / reset devices).
     */
    public static function revokeSessionsOfToken(int $tokenId, string $event): void
    {
        try {
            $n = db_query(
                'UPDATE license_sessions SET status = \'revoked\', ended_at = ? WHERE token_id = ? AND status = \'active\'',
                [time(), $tokenId]
            )->rowCount();
            if ($n > 0) {
                self::audit($tokenId, null, $event, ['sessions' => $n]);
            }
        } catch (Throwable $e) {
            /* bỏ qua */
        }
    }

    /**
     * Hủy session của một thiết bị cụ thể (reset device / remove device).
     */
    public static function revokeSessionsOfDevice(int $tokenId, string $uuid): void
    {
        try {
            db_query(
                'UPDATE license_sessions SET status = \'revoked\', ended_at = ?
                 WHERE token_id = ? AND device_uuid = ? AND status = \'active\'',
                [time(), $tokenId, $uuid]
            );
        } catch (Throwable $e) {
            /* bỏ qua */
        }
    }

    /* -------------------------- Offsets (Task 17) ----------------------- */

    /**
     * Bộ offset ĐANG KÍCH HOẠT mới nhất (is_active=1, id DESC LIMIT 1).
     *
     * Trả về ['id','game_version','payload'] hoặc null khi:
     *   • DB trả kết quả nhưng KHÔNG có bản ghi active — đây là KILL
     *     SWITCH của admin (tắt hết offset → client không chạy ESP/Aim).
     *
     * DB hỏng hẳn (2 lần) → fallback seed file offsets_data.php để client
     * hợp lệ không chết oan (session load đã chặn trước đó phần lớn TH).
     */
    public static function activeOffsets(): ?array
    {
        $sql = 'SELECT id, game_version, payload FROM license_offsets
                 WHERE is_active = 1 ORDER BY id DESC LIMIT 1';
        $dbBroken = false;
        try {
            $row = db_query($sql, [])->fetch();
        } catch (Throwable $e) {
            self::ensureV2Tables(true);
            try {
                $row = db_query($sql, [])->fetch();
            } catch (Throwable $e2) {
                $row = false;
                $dbBroken = true;
            }
        }

        if (is_array($row) && is_string($row['payload'] ?? null) && $row['payload'] !== '') {
            return [
                'id'           => (int) $row['id'],
                'game_version' => (string) $row['game_version'],
                'payload'      => (string) $row['payload'],
            ];
        }
        if ($row === false && $dbBroken) {
            /* DB không đọc được — fallback seed file (availability) */
            require_once __DIR__ . '/offsets_data.php';
            $json = json_encode(
                OffsetsData::defaults(),
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            );
            if (is_string($json)) {
                return ['id' => 0, 'game_version' => OffsetsData::GAME_VERSION, 'payload' => $json];
            }
            return null;
        }
        /* DB OK nhưng không bản ghi active → kill switch của admin (null) */
        return null;
    }
}
