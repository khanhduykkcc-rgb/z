<?php
/**
 * OFFSETS DATA — seed mặc định cho bảng license_offsets (Task 17).
 *
 * Đây là "kho offset" server-authoritative: client KHÔNG hề chứa các giá
 * trị này. App chỉ nhận offset qua action=offsets sau khi key + thiết bị
 * + session được server xác minh (chữ ký ECDSA, device_binding, lease).
 *
 * Sinh tự động từ GameOffsets.h gốc bởi scripts/gen_offsets_seed.py —
 * KHÔNG tự tay sửa file này; muốn cập nhật khi game đổi bản thì vào
 * admin → Offsets (sửa trực tiếp trong DB, không cần deploy lại).
 *
 * Format mỗi giá trị: chuỗi hex "0x..." hoặc thập phân — client parse
 * bằng strtoull(base 0). Tên khóa PHẢI khớp tên hằng trong
 * Core/GameOffsets.h của app (Registry sẽ từ chối payload thiếu slot).
 */

declare(strict_types=1);

final class OffsetsData
{
    public const GAME_VERSION = '1.132.1';

    /** @return array<string,string> name => hex string */
    public static function defaults(): array
    {
        return [
    'GameFacadeTypeInfo' => '0xbb46a50',
    'GameVarDefTypeInfo' => '0xbb46af8',
    'Il2CppClassStaticFields' => '0xb8',
    'GameFacadeCurrentGame' => '0x0',
    'GameFacadeCurrentMatchGame' => '0x8',
    'GameFacadeIsObserver' => '0x153',
    'GameFacadeIsMatchStarted' => '0x209',
    'BaseGameHasInited' => '0x80',
    'BaseGameHasLoadingFailed' => '0x81',
    'BaseGameHasFixedUpdated' => '0x82',
    'BaseGameSceneLoaded' => '0x83',
    'BaseGameIsPaused' => '0x84',
    'BaseGameIsMatchEnd' => '0x8c',
    'MatchGameMatch' => '0x90',
    'MatchGameGRIDataPool' => '0xd0',
    'MatchGameCameraControllerManager' => '0xd8',
    'CameraControllerManagerGameCamera' => '0x20',
    'CameraControllerManagerAltCamera' => '0x28',
    'MatchLocalPlayer' => '0xd8',
    'MatchShortIdToPlayers' => '0x148',
    'EntityIsRecycle' => '0x28',
    'EntityCachedTransform' => '0x58',
    'EntityPRIReceivedFirstTime' => '0x68',
    'PlayerPRIDataPool' => '0x70',
    'PlayerIsDead' => '0x7c',
    'PlayerUGCStartFiring' => '0x259',
    'PlayerIsInZeppelin' => '0x2ec',
    'PlayerLastStartFireTime' => '0x37c',
    'PlayerMainCameraTransform' => '0x3e8',
    'PlayerId' => '0x408',
    'PlayerNickName' => '0x490',
    'PlayerOriginalNickName' => '0x498',
    'PlayerIsClientBot' => '0x4a0',
    'PlayerAvatarInitialized' => '0x4c0',
    'PlayerIsInVehicle' => '0x4f8',
    'PlayerAimRotation' => '0x614',
    'PlayerAimRotationAux' => '0x628',
    'PlayerModelVisibilityState' => '0xad0',
    'PlayerIsKnockedDownBleed' => '0x1258',
    'PlayerIsKnockDownBleedingFromGS' => '0x1259',
    'PlayerCurrentAimRotation' => '0x1a8c',
    'PlayerBeingRescuredState' => '0x1ca2',
    'PlayerPhysXData' => '0x1d48',
    'PhysXStateClassRef' => '0x20',
    'PhysXGhgState' => '0x10',
    'PlayerHeadNode' => '0x6a0',
    'PlayerHipNode' => '0x6a8',
    'PlayerLeftAnkleNode' => '0x6d8',
    'PlayerRightAnkleNode' => '0x6e0',
    'PlayerLeftToeNode' => '0x6e8',
    'PlayerRightToeNode' => '0x6f0',
    'PlayerLeftShoulderNode' => '0x708',
    'PlayerRightShoulderNode' => '0x710',
    'PlayerRightHandNode' => '0x718',
    'PlayerLeftHandNode' => '0x720',
    'PlayerRightForeArmNode' => '0x728',
    'PlayerLeftForeArmNode' => '0x730',
    'PlayerSpineBone' => '0x9e8',
    'PlayerHeadBone' => '0xa00',
    'PlayerHipsBone' => '0xa08',
    'GameVarDefSensitivityBlock' => '0x1140',
    'GameVarDefRotationSensitivityMax' => '0x1144',
    'GameVarDefAimRotationSensitivityMin' => '0x1148',
    'GameVarDefAimRotationSensitivityMax' => '0x114c',
    'PlayerAuxAimResetTime' => '0xe38',
    'PlayerMinAngleX' => '0xe3c',
    'PlayerMaxAngleX' => '0xe40',
    'PlayerPhysicalCCT' => '0x268',
    'PhysicalCCTVelocity' => '0x17c',
    'PlayerInventoryManager' => '0x740',
    'InventoryItemOnHand' => '0xa0',
    'WeaponRepItem' => '0x768',
    'WeaponRange' => '0x1f4',
    'WeaponFireInterval' => '0x1f8',
    'WeaponFullDamageDistance' => '0x208',
    'WeaponIsSingleShot' => '0x27c',
    'DictionaryEntries' => '0x18',
    'DictionaryCount' => '0x20',
    'ArrayLength' => '0x18',
    'ArrayItems' => '0x20',
    'BytePlayerEntryValue' => '0x10',
    'BytePlayerEntrySize' => '0x18',
    'StringLength' => '0x10',
    'StringFirstChar' => '0x14',
    'ReplicationDataPoolData' => '0x10',
    'ReplicationDataGroup' => '0x10',
    'ReplicationDataValue' => '0x18',
    'TransformNodeTransform' => '0x10',
    'PriVarScope' => '0xc',
    'PriVarFire' => '0x15',
    'ReplicationGroupUInt8' => '0x1',
    'ReplicationGroupUInt16' => '0x3',
    'ReplicationGroupUInt32' => '0x5',
    'PhysXPoseSkyDiving' => '0x5',
    'PhysXPoseKnockDown' => '0x8',
    'PhysXPoseParachuteFalling' => '0x1f',
    'UnityObjectCachedPtr' => '0x10',
    'TransformAccess' => '0x38',
    'TransformIndex' => '0x40',
    'TransformData' => '0x18',
    'TransformParents' => '0x20',
    'BitArrayBooleanValue' => '0x10',
    'BitArrayBooleanInitialValue' => '0x14',
    'BitArrayBooleanMode' => '0x18',
    'BitArrayBooleanAndTrue' => '0x0',
    'BitArrayBooleanOrTrue' => '0x1',
        ];
    }
}
