/* users.js — trang Users (admin): mở modal sửa tài khoản với dữ liệu sẵn. */

(function () {
    'use strict';

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('[data-edit-user]');
        if (!btn) { return; }

        var data;
        try { data = JSON.parse(btn.getAttribute('data-edit-user')); } catch (err) { return; }
        if (!data) { return; }

        var set = function (id, value) {
            var el = document.getElementById(id);
            if (el) { el.value = value; }
        };

        set('euId', data.id);
        set('euUsername', data.username || '');
        set('euEmail', data.email || '');
        set('euRole', data.role === 'admin' ? 'admin' : 'user');
        set('euMaxPackages', data.max_packages || '');
        set('euMaxKeys', data.max_keys || '');

        var modal = document.getElementById('editUserModal');
        if (modal) { modal.hidden = false; }
    });
})();
