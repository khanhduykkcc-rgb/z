/* packages.js — trang Packages: mở modal sửa package với dữ liệu sẵn. */

(function () {
    'use strict';

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('[data-edit-package]');
        if (!btn) { return; }

        var data;
        try { data = JSON.parse(btn.getAttribute('data-edit-package')); } catch (err) { return; }
        if (!data) { return; }

        var id = document.getElementById('epId');
        var name = document.getElementById('epName');
        var contact = document.getElementById('epContact');

        if (id) { id.value = data.id; }
        if (name) { name.value = data.name || ''; }
        if (contact) { contact.value = data.contact || ''; }

        var modal = document.getElementById('editPackageModal');
        if (modal) { modal.hidden = false; }
    });
})();
