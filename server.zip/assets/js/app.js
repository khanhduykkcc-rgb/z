/* =====================================================================
   app.js — core: sidebar, modal, toast, confirm, copy, mask, loading
   Không dùng inline handler — mọi thứ gắn qua addEventListener.
   ===================================================================== */

(function () {
    'use strict';

    /* ------------------------------ Toast ---------------------------- */

    var ICONS = {
        success: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
        danger: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 4.2 2.8 17.5A2 2 0 0 0 4.5 20.5h15a2 2 0 0 0 1.7-3L13.7 4.2a2 2 0 0 0-3.4 0Z"/><path d="M12 10v4"/><path d="M12 17.2v.1"/></svg>'
    };

    function showToast(message, type) {
        var stack = document.getElementById('toastStack');
        if (!stack) { return; }

        var toast = document.createElement('div');
        toast.className = 'toast toast-' + (type === 'danger' ? 'danger' : 'success');
        toast.innerHTML = ICONS[type === 'danger' ? 'danger' : 'success']
            + '<span></span>';
        toast.lastElementChild.textContent = message;
        stack.appendChild(toast);

        setTimeout(function () {
            toast.classList.add('toast-hide');
            setTimeout(function () { toast.remove(); }, 260);
        }, 3500);
    }

    /* ----------------------------- Sidebar --------------------------- */

    document.addEventListener('click', function (event) {
        var toggle = event.target.closest('[data-sidebar-toggle]');
        if (toggle) {
            document.body.classList.toggle('sidebar-open');
            return;
        }
        if (event.target.closest('[data-sidebar-close]')) {
            document.body.classList.remove('sidebar-open');
        }
    });

    /* ------------------------------ Modal ---------------------------- */

    function openModal(id) {
        var modal = document.getElementById(id);
        if (!modal) { return; }
        modal.hidden = false;
        var focusable = modal.querySelector('input, select, button');
        if (focusable) { focusable.focus(); }
    }

    function closeModal(modal) {
        modal.hidden = true;
    }

    document.addEventListener('click', function (event) {
        var opener = event.target.closest('[data-modal-open]');
        if (opener) {
            openModal(opener.getAttribute('data-modal-open'));
            return;
        }

        var closer = event.target.closest('[data-modal-close]');
        if (closer) {
            closeModal(closer.closest('.modal-backdrop'));
            return;
        }

        if (event.target.classList && event.target.classList.contains('modal-backdrop')) {
            closeModal(event.target);
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') { return; }
        document.querySelectorAll('.modal-backdrop:not([hidden])').forEach(closeModal);
    });

    /* ----------------------------- Confirm --------------------------- */

    var pendingForm = null;

    document.addEventListener('submit', function (event) {
        var form = event.target;

        if (form.hasAttribute('data-confirm') && !form.dataset.confirmed) {
            event.preventDefault();
            pendingForm = form;

            var text = document.getElementById('confirmText');
            if (text) { text.textContent = form.getAttribute('data-confirm'); }

            var modal = document.getElementById('confirmModal');
            if (modal) { modal.hidden = false; }
        }

        if (form.hasAttribute('data-loading') && form.checkValidity()) {
            form.querySelectorAll('button[type="submit"]').forEach(function (btn) {
                btn.classList.add('is-loading');
                btn.disabled = true;
            });
        }
    });

    document.addEventListener('click', function (event) {
        var accept = event.target.closest('#confirmAccept');
        if (!accept) { return; }

        var modal = document.getElementById('confirmModal');
        if (modal) { modal.hidden = true; }

        if (pendingForm) {
            pendingForm.dataset.confirmed = '1';
            pendingForm.submit();
            pendingForm = null;
        }
    });

    /* ------------------------------ Copy ----------------------------- */

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('[data-copy]');
        if (!btn) { return; }

        var value = btn.getAttribute('data-copy');
        var done = function () { showToast('Đã copy: ' + value, 'success'); };

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(value).then(done, function () { fallbackCopy(value, done); });
        } else {
            fallbackCopy(value, done);
        }
    });

    function fallbackCopy(value, done) {
        var input = document.createElement('textarea');
        input.value = value;
        input.setAttribute('readonly', '');
        input.style.position = 'fixed';
        input.style.left = '-9999px';
        document.body.appendChild(input);
        input.select();
        try { document.execCommand('copy'); done(); } catch (err) { /* bỏ qua */ }
        input.remove();
    }

    /* --------------------------- Token mask --------------------------- */

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('[data-toggle-mask]');
        if (!btn) { return; }

        var box = btn.closest('.key-cell').querySelector('.token-box');
        if (!box) { return; }

        var masked = box.getAttribute('data-masked');
        var full = box.getAttribute('data-full');
        box.textContent = box.textContent === masked ? full : masked;
    });

    /* ------------------------------ Flash ---------------------------- */

    var flash = document.querySelector('.flash-data[data-flash]');
    if (flash) {
        try {
            var data = JSON.parse(flash.getAttribute('data-flash'));
            if (data && data.message) {
                showToast(data.message, data.type === 'danger' ? 'danger' : 'success');
            }
        } catch (err) { /* flash hỏng thì bỏ qua */ }
    }
})();
