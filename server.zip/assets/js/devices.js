/* devices.js — trang Devices: tự submit filter khi đổi package. */

(function () {
    'use strict';

    document.querySelectorAll('.filter-bar select').forEach(function (select) {
        select.addEventListener('change', function () {
            select.form.submit();
        });
    });
})();
