/* =====================================================================
   landing.js — Trang chủ: navbar scroll, mobile menu, API tabs,
   copy button, reveal-on-scroll. Không phụ thuộc thư viện ngoài.
   ===================================================================== */

(function () {
    'use strict';

    /* --------------------- Navbar shadow khi scroll --------------------- */

    var navbar = document.getElementById('navbar');

    function onScroll() {
        if (!navbar) { return; }
        if (window.scrollY > 8) {
            navbar.classList.add('is-scrolled');
        } else {
            navbar.classList.remove('is-scrolled');
        }
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    /* ------------------------- Mobile menu toggle ------------------------- */

    var toggle = document.getElementById('navToggle');

    if (toggle && navbar) {
        toggle.addEventListener('click', function () {
            var open = navbar.classList.toggle('is-open');
            toggle.setAttribute('aria-label', open ? 'Đóng menu' : 'Mở menu');
        });

        /* Đóng menu khi bấm link (mượt trên mobile) */
        navbar.querySelectorAll('.nav-links a').forEach(function (link) {
            link.addEventListener('click', function () {
                navbar.classList.remove('is-open');
            });
        });
    }

    /* ------------------------------ API tabs ------------------------------ */

    var tabs = document.querySelectorAll('.api-tab');
    var codeInit = document.getElementById('codeInit');
    var codeCheck = document.getElementById('codeCheck');
    var codeName = document.getElementById('codeName');

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            tabs.forEach(function (t) { t.classList.remove('is-active'); });
            tab.classList.add('is-active');

            var isInit = tab.getAttribute('data-tab') === 'init';
            if (codeInit) { codeInit.hidden = !isInit; }
            if (codeCheck) { codeCheck.hidden = isInit; }
            if (codeName) {
                codeName.textContent = isInit
                    ? 'GET api/connect.php?action=init'
                    : 'GET api/connect.php?action=check';
            }
        });
    });

    /* ----------------------------- Copy button ----------------------------- */

    var copyBtn = document.getElementById('copyBtn');

    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            var visible = !codeInit.hidden ? codeInit : codeCheck;
            if (!visible) { return; }

            /* Lấy text thô (bỏ cú pháp highlight) */
            var text = visible.textContent || '';

            var done = function () {
                var label = copyBtn.querySelector(':scope > * + *') || null;
                copyBtn.classList.add('is-copied');
                var old = copyBtn.lastChild;
                if (old && old.nodeType === 3) {
                    var original = old.textContent;
                    old.textContent = ' Đã copy!';
                    setTimeout(function () {
                        old.textContent = original;
                        copyBtn.classList.remove('is-copied');
                    }, 1600);
                }
            };

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done, function () {});
            } else {
                var ta = document.createElement('textarea');
                ta.value = text;
                ta.setAttribute('readonly', '');
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); done(); } catch (err) { /* bỏ qua */ }
                ta.remove();
            }
        });
    }

    /* --------------------------- Reveal on scroll --------------------------- */

    var reduceMotion = window.matchMedia
        && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    var revealEls = document.querySelectorAll('.reveal');

    if (reduceMotion || !('IntersectionObserver' in window)) {
        revealEls.forEach(function (el) { el.classList.add('is-visible'); });
    } else {
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

        revealEls.forEach(function (el) { observer.observe(el); });
    }
})();
