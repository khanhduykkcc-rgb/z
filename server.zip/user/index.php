<?php
/**
 * Dashboard USER: tổng quan package/key của mình + hiển thị hạn mức
 * (max_packages / max_keys do admin đặt, để trống = mặc định hệ thống).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_login();

$me     = current_user();
$limits = effective_limits($me);
$myId   = (int) $me['id'];

$stats = [
    'my_packages'    => count_user_packages($myId),
    'my_keys'        => count_user_keys($myId),
    'active_keys'    => 0,
    'expired_keys'   => 0,
    'my_devices'     => 0,
];

try {
    $row = db_query(
        'SELECT
            (SELECT COUNT(*) FROM tbl_tokens WHERE user_id = ? AND (expire_date IS NULL OR expire_date >= NOW())) AS active_keys,
            (SELECT COUNT(*) FROM tbl_tokens WHERE user_id = ? AND expire_date IS NOT NULL AND expire_date < NOW()) AS expired_keys,
            (SELECT COUNT(*) FROM tbl_device_history dh JOIN tbl_tokens t ON t.id = dh.token_id WHERE t.user_id = ?) AS my_devices',
        [$myId, $myId, $myId]
    )->fetch();
    if ($row) {
        $stats['active_keys']  = (int) $row['active_keys'];
        $stats['expired_keys'] = (int) $row['expired_keys'];
        $stats['my_devices']   = (int) $row['my_devices'];
    }

    $recentKeys = db_query(
        'SELECT t.token_code, t.type, t.expire_date, t.created_at, p.name AS package_name
         FROM tbl_tokens t
         JOIN tbl_projects p ON p.id = t.project_id
         WHERE t.user_id = ?
         ORDER BY t.id DESC
         LIMIT 6',
        [$myId]
    )->fetchAll();
} catch (Throwable $e) {
    $recentKeys = [];
}

function quota_bar(float $pct): string
{
    $pct = max(0.0, min(100.0, $pct));
    $state = $pct >= 100.0 ? ' quota-full' : ($pct >= 70.0 ? ' quota-warn' : '');
    return '<div class="quota-bar"><div class="quota-fill' . $state . '" style="width:' . $pct . '%"></div></div>';
}

function user_status_badge(array $row): string
{
    switch (key_status($row)) {
        case 'active':
            return '<span class="badge badge-success">Active</span>';
        case 'pending':
            return '<span class="badge badge-warning">Pending</span>';
        default:
            return '<span class="badge badge-danger">Expired</span>';
    }
}

layout_header('Dashboard', 'dashboard', 'user');
?>
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-icon tile-blue"><?php echo icon('package', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Packages của tôi</span>
            <span class="stat-value"><?= limit_label($stats['my_packages'], $limits !== null ? $limits['max_packages'] : null) ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-violet"><?php echo icon('key', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Keys của tôi</span>
            <span class="stat-value"><?= limit_label($stats['my_keys'], $limits !== null ? $limits['max_keys'] : null) ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-green"><?php echo icon('check', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Key đang hoạt động</span>
            <span class="stat-value"><?= $stats['active_keys'] ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-red"><?php echo icon('key-off', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Key đã hết hạn</span>
            <span class="stat-value"><?= $stats['expired_keys'] ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-amber"><?php echo icon('device', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Thiết bị đang dùng</span>
            <span class="stat-value"><?= $stats['my_devices'] ?></span>
        </div>
    </div>
</div>

<?php if ($limits !== null): ?>
<div class="card quota-card">
    <div class="card-header">
        <h2 class="card-title"><?php echo icon('zap', 17); ?> Hạn mức tài khoản</h2>
        <?php if ($stats['my_packages'] >= $limits['max_packages'] || $stats['my_keys'] >= $limits['max_keys']): ?>
        <span class="badge badge-warning">Sắp chạm giới hạn</span>
        <?php endif; ?>
    </div>
    <div class="quota-grid">
        <div class="quota-item">
            <div class="quota-head">
                <span><?php echo icon('package', 14); ?> Packages</span>
                <span class="limit-meta"><?= limit_label($stats['my_packages'], $limits['max_packages']) ?></span>
            </div>
            <?= quota_bar($limits['max_packages'] > 0 ? $stats['my_packages'] / $limits['max_packages'] * 100 : 100) ?>
        </div>
        <div class="quota-item">
            <div class="quota-head">
                <span><?php echo icon('key', 14); ?> Keys</span>
                <span class="limit-meta"><?= limit_label($stats['my_keys'], $limits['max_keys']) ?></span>
            </div>
            <?= quota_bar($limits['max_keys'] > 0 ? $stats['my_keys'] / $limits['max_keys'] * 100 : 100) ?>
        </div>
    </div>
    <p class="form-hint">Cần thêm hạn mức? Liên hệ quản trị viên qua mục Liên hệ trong mỗi key. Vượt giới hạn thì không tạo thêm được package/key mới.</p>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><?php echo icon('key', 17); ?> Keys mới nhất của bạn</h2>
        <a class="btn btn-secondary btn-sm" href="keys.php">Xem tất cả</a>
    </div>
    <?php if (empty($recentKeys)): ?>
    <div class="empty-state">
        <?php echo icon('key', 34); ?>
        <p>Bạn chưa có key nào. Tạo package trước, rồi tạo key trong package đó.</p>
        <a class="btn btn-primary btn-sm" href="packages.php">Tạo package đầu tiên</a>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>Key</th><th>Package</th><th>Trạng thái</th><th>Ngày tạo</th></tr></thead>
            <tbody>
            <?php foreach ($recentKeys as $row): ?>
                <tr>
                    <td><code class="code-box"><?= e($row['token_code']) ?></code></td>
                    <td><?= e($row['package_name']) ?></td>
                    <td><?= user_status_badge($row) ?></td>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php layout_footer();
