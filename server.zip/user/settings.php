<?php
/**
 * TÀI KHOẢN (user): xem thông tin + hạn mức + đổi mật khẩu của chính mình.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_login();

$me     = current_user();
$limits = effective_limits($me);

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();

    $current = (string) ($_POST['current_password'] ?? '');
    $new     = (string) ($_POST['new_password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');

    try {
        $hash = db_query('SELECT password_hash FROM tbl_users WHERE id = ?', [$me['id']])->fetchColumn();

        if (!password_verify($current, $hash)) {
            set_flash('Mật khẩu hiện tại không đúng.', 'danger');
        } elseif (strlen($new) < 8) {
            set_flash('Mật khẩu mới phải có ít nhất 8 ký tự.', 'danger');
        } elseif ($new !== $confirm) {
            set_flash('Xác nhận mật khẩu mới không khớp.', 'danger');
        } else {
            db_query('UPDATE tbl_users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $me['id']]);
            set_flash('Đã đổi mật khẩu thành công.', 'success');
        }
    } catch (Throwable $e) {
        set_flash('Không đổi được mật khẩu — lỗi hệ thống.', 'danger');
    }
    redirect('settings.php');
}

layout_header('Tài khoản', 'settings', 'user');
?>
<div class="settings-grid">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('user', 17); ?> Tài khoản của tôi</h2>
        </div>
        <dl class="detail-list detail-list-page">
            <dt>Username</dt><dd class="cell-strong"><?= e($me['username']) ?></dd>
            <dt>Email</dt><dd><?= e($me['email'] ?? '—') ?></dd>
            <dt>Vai trò</dt><dd><span class="role-chip"><?php echo icon('user', 11); ?> User</span></dd>
            <dt>Ngày đăng ký</dt><dd><?= format_datetime($me['created_at']) ?></dd>
            <dt>Đăng nhập lần cuối</dt><dd><?= format_datetime($me['last_login_at']) ?></dd>
        </dl>
        <form method="post" class="settings-form">
            <?= csrf_field() ?>
            <h3 class="form-section-title">Đổi mật khẩu</h3>
            <div class="form-group">
                <label class="form-label" for="current_password">Mật khẩu hiện tại</label>
                <input type="password" id="current_password" name="current_password" class="form-control" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="new_password">Mật khẩu mới</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" minlength="8" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="confirm_password">Xác nhận mật khẩu mới</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" minlength="8" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo icon('shield', 15); ?> Cập nhật mật khẩu</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('zap', 17); ?> Hạn mức của tôi</h2>
        </div>
        <?php if ($limits === null): ?>
        <div class="notice notice-info">
            <?php echo icon('shield', 18); ?>
            <div>Tài khoản của bạn không bị giới hạn.</div>
        </div>
        <?php else: ?>
        <dl class="detail-list detail-list-page">
            <dt>Max packages</dt>
            <dd><?= $limits['max_packages'] === 0 ? '<span class="badge badge-danger">Không được tạo</span>' : (int) $limits['max_packages'] . ' package' ?></dd>
            <dt>Max keys</dt>
            <dd><?= $limits['max_keys'] === 0 ? '<span class="badge badge-danger">Không được tạo</span>' : (int) $limits['max_keys'] . ' key' ?></dd>
            <dt>Đang dùng</dt>
            <dd><?= limit_label(count_user_packages((int) $me['id']), $limits['max_packages']) ?> package ·
                <?= limit_label(count_user_keys((int) $me['id']), $limits['max_keys']) ?> key</dd>
        </dl>
        <div class="notice notice-info">
            <?php echo icon('info', 18); ?>
            <div>Hạn mức do quản trị viên đặt cho tài khoản của bạn. Vượt giới hạn thì không tạo thêm package/key được — liên hệ admin qua link Liên hệ trong mỗi key nếu cần nâng hạn mức.</div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php layout_footer();
