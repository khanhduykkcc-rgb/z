<?php
/**
 * XÁC THỰC THỐNG NHẤT — một bảng tbl_users duy nhất cho mọi tài khoản:
 *   role = 'admin' : toàn quyền (quản lý user, mọi package/key, giới hạn)
 *   role = 'user'  : tự tạo package/key của mình trong hạn mức
 *
 * Cả admin lẫn user đăng nhập cùng một form ở auth/login.php —
 * hệ thống tự phân vai sau khi kiểm tra mật khẩu.
 *
 * Session: $_SESSION['user_id'], $_SESSION['user_role'], ...
 */

declare(strict_types=1);

function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }

    static $user = null;
    if ($user === null) {
        try {
            $user = db_query(
                'SELECT id, username, email, role, is_active, max_packages, max_keys,
                        created_at, last_login_at
                 FROM tbl_users WHERE id = ? AND is_active = 1 LIMIT 1',
                [$_SESSION['user_id']]
            )->fetch();
        } catch (Throwable $e) {
            $user = false;
        }
        if ($user === false) {
            $user = null;
        }
    }
    return $user;
}

function current_role(): string
{
    return (string) ($_SESSION['user_role'] ?? 'user');
}

function is_admin(): bool
{
    return is_logged_in() && current_role() === 'admin';
}

/**
 * Guard chung: chưa đăng nhập → về trang login.
 * current_user() lọc is_active = 1 nên user vừa bị KHÓA cũng bị đá
 * ra ngay ở request kế tiếp (không phải chờ đăng nhập lại).
 */
function require_login(): void
{
    if (is_logged_in() && current_user() === null) {
        /* Tài khoản vừa bị khóa / xóa giữa phiên — hủy session luôn */
        logout_current();
    }
    if (!is_logged_in()) {
        redirect('../auth/login.php');
    }
}

/**
 * Guard trang admin: phải đăng nhập VÀ role = admin.
 * User thường vô tình vào link admin → đá về dashboard của mình.
 */
function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        redirect('../user/index.php');
    }
}

/**
 * Trang đích sau đăng nhập theo vai trò.
 */
function dashboard_url_for(string $role): string
{
    return $role === 'admin' ? '../admin/index.php' : '../user/index.php';
}

/**
 * Đăng nhập — tra MỘT bảng tbl_users, trả về:
 *   'ok'     — thành công (session đã ghi, phân vai xong)
 *   'error'  — sai thông tin (thông điệp chung, chống user enumeration)
 *   'banned' — tài khoản bị khóa
 */
function attempt_login(string $username, string $password): string
{
    try {
        $user = db_query(
            'SELECT id, password_hash, role, is_active FROM tbl_users
             WHERE username = ? OR email = ? LIMIT 1',
            [trim($username), trim($username)]
        )->fetch();
    } catch (Throwable $e) {
        /* Bảng tbl_users chưa tồn tại (DB cũ chưa upgrade) */
        return 'error';
    }

    if ($user === false || !password_verify($password, $user['password_hash'])) {
        return 'error';
    }
    if ((int) $user['is_active'] !== 1) {
        return 'banned';
    }

    session_regenerate_id(true);
    $_SESSION['user_id']       = (int) $user['id'];
    $_SESSION['user_role']     = (string) $user['role'];
    $_SESSION['user_name']     = trim($username);
    $_SESSION['logged_in_at']  = time();

    try {
        db_query('UPDATE tbl_users SET last_login_at = NOW() WHERE id = ?', [$user['id']]);
    } catch (Throwable $e) {
        /* last_login chỉ là thống kê — bỏ qua nếu lỗi */
    }

    return 'ok';
}

/**
 * Đăng ký tài khoản USER THƯỜNG (role cố định 'user' — không ai tự
 * phong admin qua form). Tôn trọng cài đặt allow_registration.
 */
function register_user(string $username, string $email, string $password, string $confirm): array
{
    $username = trim($username);
    $email    = trim($email);

    if ($username === '' || mb_strlen($username) < 3 || mb_strlen($username) > 50) {
        return ['ok' => false, 'error' => 'Tên đăng nhập phải từ 3 đến 50 ký tự.'];
    }
    if (!preg_match('/^[A-Za-z0-9_.-]+$/', $username)) {
        return ['ok' => false, 'error' => 'Tên đăng nhập chỉ gồm chữ, số, dấu chấm, gạch dưới và gạch ngang.'];
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
        return ['ok' => false, 'error' => 'Email không hợp lệ.'];
    }
    if (strlen($password) < 8) {
        return ['ok' => false, 'error' => 'Mật khẩu phải có ít nhất 8 ký tự.'];
    }
    if ($password !== $confirm) {
        return ['ok' => false, 'error' => 'Xác nhận mật khẩu không khớp.'];
    }

    if (get_setting('allow_registration', '1') !== '1') {
        return ['ok' => false, 'error' => 'Đăng ký hiện đang bị tắt. Vui lòng liên hệ quản trị viên.'];
    }

    try {
        $dup = db_query(
            'SELECT 1 FROM tbl_users WHERE username = ? OR email = ? LIMIT 1',
            [$username, $email]
        )->fetchColumn();
        if ($dup !== false) {
            return ['ok' => false, 'error' => 'Tên đăng nhập hoặc email đã được sử dụng.'];
        }

        db_query(
            'INSERT INTO tbl_users (username, email, password_hash, role) VALUES (?, ?, ?, ?)',
            [$username, $email, password_hash($password, PASSWORD_DEFAULT), 'user']
        );
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => 'Không tạo được tài khoản — lỗi hệ thống. Vui lòng thử lại sau.'];
    }

    return ['ok' => true];
}

/**
 * Đăng xuất toàn bộ phiên (một tài khoản một phiên — khỏi phân vai).
 */
function logout_current(): void
{
    $_SESSION = [];
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    session_destroy();
}

/**
 * Giới hạn tốc độ đăng nhập: sau 5 lần sai liên tiếp trong 15 phút,
 * mỗi lần thử tiếp theo phải chờ 30 giây.
 */
function login_throttle(string $username): bool
{
    $key = 'login_fail_' . md5(strtolower($username));
    $now = time();
    $fails = $_SESSION[$key] ?? ['count' => 0, 'first' => $now];

    if ($now - $fails['first'] > 900) {
        $fails = ['count' => 0, 'first' => $now];
    }

    $_SESSION[$key] = $fails;

    return $fails['count'] >= 5 && ($now - ($fails['last'] ?? 0)) < 30;
}

function record_login_failure(string $username): void
{
    $key = 'login_fail_' . md5(strtolower($username));
    $fails = $_SESSION[$key] ?? ['count' => 0, 'first' => time()];
    $fails['count']++;
    $fails['last'] = time();
    $_SESSION[$key] = $fails;
}

function clear_login_failures(string $username): void
{
    unset($_SESSION['login_fail_' . md5(strtolower($username))]);
}
