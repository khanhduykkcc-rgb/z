<?php
/**
 * Cấu hình hệ thống (tbl_settings) + HẠN MỨC user.
 *
 * Nguyên tắc hạn mức:
 *   • Admin KHÔNG bị giới hạn bao giờ.
 *   • User bị giới hạn bởi cột riêng của mình (max_packages / max_keys).
 *   • Cột riêng = NULL → dùng mặc định hệ thống trong tbl_settings.
 *   • Giá trị 0 hiểu là "không được tạo gì" (chặn hết).
 */

declare(strict_types=1);

/* ------------------------- Cấu hình hệ thống ------------------------- */

function get_setting(string $key, string $default = ''): string
{
    static $cache = null;

    if ($cache === null) {
        $cache = [];
        try {
            $rows = db_query('SELECT setting_key, setting_value FROM tbl_settings')->fetchAll();
            foreach ($rows as $row) {
                $cache[(string) $row['setting_key']] = (string) $row['setting_value'];
            }
        } catch (Throwable $e) {
            /* Bảng chưa có (DB cũ) — dùng default */
        }
    }

    return $cache[$key] ?? $default;
}

function set_setting(string $key, string $value): void
{
    /* UPDATE trước, INSERT sau — tránh cú pháp riêng của MySQL, chạy được
     * cả trên MariaDB/MySQL lẫn môi trường test SQLite. */
    $stmt = db_query('UPDATE tbl_settings SET setting_value = ? WHERE setting_key = ?', [$value, $key]);
    if ($stmt->rowCount() === 0) {
        try {
            db_query('INSERT INTO tbl_settings (setting_key, setting_value) VALUES (?, ?)', [$key, $value]);
        } catch (Throwable $e) {
            /* Race: vừa được ghi bởi request khác — bỏ qua */
        }
    }
}

/* ----------------------------- Hạn mức ------------------------------- */

/**
 * Giới hạn mặc định toàn hệ thống cho user thường.
 */
function get_default_limits(): array
{
    return [
        'max_packages' => max(0, (int) get_setting('default_max_packages', '3')),
        'max_keys'     => max(0, (int) get_setting('default_max_keys', '10')),
    ];
}

/**
 * Hạn mức THỰC TẾ của một user (theo mảng fetched từ tbl_users):
 *   admin          → không giới hạn (null)
 *   cột riêng NULL → mặc định hệ thống
 */
function effective_limits(?array $user): ?array
{
    if ($user === null || ($user['role'] ?? 'user') === 'admin') {
        return null; /* admin: vô hạn */
    }

    $defaults = get_default_limits();

    return [
        'max_packages' => $user['max_packages'] !== null
            ? max(0, (int) $user['max_packages'])
            : $defaults['max_packages'],
        'max_keys' => $user['max_keys'] !== null
            ? max(0, (int) $user['max_keys'])
            : $defaults['max_keys'],
    ];
}

function count_user_packages(int $userId): int
{
    try {
        return (int) db_query(
            'SELECT COUNT(*) FROM tbl_projects WHERE owner_id = ?',
            [$userId]
        )->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function count_user_keys(int $userId): int
{
    try {
        return (int) db_query(
            'SELECT COUNT(*) FROM tbl_tokens WHERE user_id = ?',
            [$userId]
        )->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Kiểm tra + thông báo lỗi khi user muốn tạo thêm package.
 */
function check_package_quota(array $user): ?string
{
    $limits = effective_limits($user);
    if ($limits === null) {
        return null; /* admin thoải mái */
    }
    if (count_user_packages((int) $user['id']) >= $limits['max_packages']) {
        return 'Bạn đã đạt giới hạn ' . $limits['max_packages'] . ' package. '
            . 'Liên hệ quản trị viên nếu cần thêm.';
    }
    return null;
}

/**
 * Kiểm tra + thông báo lỗi khi user muốn tạo thêm key.
 */
function check_key_quota(array $user): ?string
{
    $limits = effective_limits($user);
    if ($limits === null) {
        return null;
    }
    if (count_user_keys((int) $user['id']) >= $limits['max_keys']) {
        return 'Bạn đã đạt giới hạn ' . $limits['max_keys'] . ' key. '
            . 'Liên hệ quản trị viên nếu cần thêm.';
    }
    return null;
}

/**
 * Chuỗi hiển thị hạn mức: "3 / 10" hoặc "5 / ∞".
 */
function limit_label(int $used, ?int $limit): string
{
    return $limit === null ? $used . ' / ∞' : $used . ' / ' . $limit;
}
