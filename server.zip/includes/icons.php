<?php
/**
 * Hệ thống icon dùng chung — 100% SVG tự viết, không phụ thuộc
 * icon ngoài/CDN/image. Đồng nhất: viewBox 24x24, stroke currentColor,
 * stroke-width 2, round caps & joins.
 */

declare(strict_types=1);

function icon(string $name, int $size = 18): string
{
    static $paths = [
        'dashboard'   => '<rect x="3" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5"/>',
        'key'         => '<circle cx="8" cy="15" r="4.5"/><path d="M11.2 11.8 20.5 2.5"/><path d="M17 6l3 3"/><path d="M14.5 8.5l3 3"/>',
        'package'     => '<path d="M21 8.2v7.6a2 2 0 0 1-1 1.7l-7 3.9a2 2 0 0 1-2 0l-7-3.9a2 2 0 0 1-1-1.7V8.2a2 2 0 0 1 1-1.7l7-3.9a2 2 0 0 1 2 0l7 3.9a2 2 0 0 1 1 1.7Z"/><path d="M3.5 7.3 12 12l8.5-4.7"/><path d="M12 12v9.5"/>',
        'device'      => '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>',
        'settings'    => '<path d="M4 7h9"/><path d="M17.5 7H20"/><circle cx="15" cy="7" r="2.2"/><path d="M4 17h3"/><path d="M11.5 17H20"/><circle cx="9.5" cy="17" r="2.2"/>',
        'user'        => '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
        'logout'      => '<path d="M14.5 4.5H6a1.5 1.5 0 0 0-1.5 1.5v12A1.5 1.5 0 0 0 6 19.5h8.5"/><path d="M17 8.5l3.5 3.5L17 15.5"/><path d="M9.5 12h11"/>',
        'search'      => '<circle cx="11" cy="11" r="7"/><path d="m20.5 20.5-4.6-4.6"/>',
        'plus'        => '<path d="M12 5v14"/><path d="M5 12h14"/>',
        'trash'       => '<path d="M4 7h16"/><path d="M9.5 4.5h5"/><path d="M6.5 7l.8 12a2 2 0 0 0 2 1.9h5.4a2 2 0 0 0 2-1.9l.8-12"/><path d="M10 11v6"/><path d="M14 11v6"/>',
        'edit'        => '<path d="M4 20h4.5L20 8.5a2.1 2.1 0 0 0-3-3L5.5 17 4 20Z"/><path d="m14.5 7 3 3"/>',
        'check'       => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
        'warning'     => '<path d="M10.3 4.2 2.8 17.5A2 2 0 0 0 4.5 20.5h15a2 2 0 0 0 1.7-3L13.7 4.2a2 2 0 0 0-3.4 0Z"/><path d="M12 10v4"/><path d="M12 17.2v.1"/>',
        'server'      => '<rect x="3" y="4" width="18" height="6.5" rx="1.5"/><rect x="3" y="13.5" width="18" height="6.5" rx="1.5"/><path d="M7 7.2v.1"/><path d="M7 16.7v.1"/>',
        'x'           => '<path d="M6 6l12 12"/><path d="M18 6 6 18"/>',
        'copy'        => '<rect x="9" y="9" width="11.5" height="11.5" rx="2"/><path d="M5.5 15H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v.5"/>',
        'eye'         => '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3"/>',
        'eye-off'     => '<path d="M10.6 5.8A8.7 8.7 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a16.5 16.5 0 0 1-3.2 3.9M6.4 7.5A16 16 0 0 0 2.5 12S6 18.5 12 18.5a8.6 8.6 0 0 0 4-1"/><path d="M9.9 10a3 3 0 0 0 4.2 4.2"/><path d="M4 4l16 16"/>',
        'refresh'     => '<path d="M20 5.5v5h-5"/><path d="M19.4 10.5A8 8 0 1 0 12 20a8 8 0 0 0 6.9-4"/>',
        'maintenance' => '<path d="M14.5 6.5a4 4 0 0 0 5.3 5.3l-8.8 8.8a2.3 2.3 0 0 1-3.3-3.3l8.8-8.8Z"/><path d="m14.5 6.5 2-2a4 4 0 0 1 5.3 5.3l-2 2"/><path d="M6 3.5 4.5 5 7 7.5l1-1v-2h-2Z"/>',
        'shield'      => '<path d="M12 2.5 4.5 5.5v6c0 4.7 3.2 8.2 7.5 10 4.3-1.8 7.5-5.3 7.5-10v-6L12 2.5Z"/><path d="m8.8 11.8 2.3 2.3 4.1-4.1"/>',
        'clock'       => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>',
        'calendar'    => '<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M8 3v4"/><path d="M16 3v4"/><path d="M3.5 10h17"/>',
        'chevron'     => '<path d="m6.5 9.5 5.5 5.5 5.5-5.5"/>',
        'menu'        => '<path d="M4 6.5h16"/><path d="M4 12h16"/><path d="M4 17.5h16"/>',
        'external'    => '<path d="M13.5 5.5H18.5V10.5"/><path d="M18.5 5.5 11 13"/><path d="M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10"/>',
        'info'        => '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5"/><path d="M12 7.8v.1"/>',
        'database'    => '<ellipse cx="12" cy="5.5" rx="8" ry="3"/><path d="M4 5.5v13c0 1.7 3.6 3 8 3s8-1.3 8-3v-13"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
        'key-off'     => '<circle cx="8" cy="15" r="4.5"/><path d="M11.2 11.8 20.5 2.5"/><path d="M17 6l3 3"/><path d="m3 3 18 18"/>',
        'lock'        => '<rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/><path d="M12 14.5v2"/>',
        'users'       => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 19.5a6.5 6.5 0 0 1 13 0"/><path d="M16 5a3.5 3.5 0 0 1 0 7"/><path d="M17.5 13.5a6.5 6.5 0 0 1 4 6"/>',
        'zap'         => '<path d="M13 2.5 4 14h6l-1 7.5 9-11.5h-6l1-7.5Z"/>',
        'code'        => '<path d="m8 6-6 6 6 6"/><path d="m16 6 6 6-6 6"/><path d="m13.5 4-3 16"/>',
        'send'        => '<path d="M21 3.5 10.5 14"/><path d="M21 3.5 14 21l-3.5-7L3 10.5 21 3.5Z"/>',
    ];

    if (!isset($paths[$name])) {
        return '';
    }

    return '<svg class="icon icon-' . e($name) . '" width="' . $size . '" height="' . $size
        . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
        . 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths[$name] . '</svg>';
}
