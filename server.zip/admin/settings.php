<?php
/**
 * Settings (admin): đổi mật khẩu của chính mình + CẤU HÌNH HỆ THỐNG
 * (hạn mức mặc định cho user mới, mở/tắt đăng ký công khai).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_admin();

$me = current_user();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'password') {
        $current = (string) ($_POST['current_password'] ?? '');
        $new     = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        try {
            $hash = db_query('SELECT password_hash FROM tbl_users WHERE id = ?', [$me['id']])->fetchColumn();

            if (!password_verify($current, $hash)) {
                set_flash('Mật khẩu hiện tại không đúng.', 'danger');
            } elseif (strlen($new) < 8) {
                set_flash('Mật khẩu mới phải có ít nhất 8 ký tự.', 'danger');
            } elseif ($new !== $confirm) {
                set_flash('Xác nhận mật khẩu mới không khớp.', 'danger');
            } else {
                db_query('UPDATE tbl_users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $me['id']]);
                set_flash('Đã đổi mật khẩu thành công.', 'success');
            }
        } catch (Throwable $e) {
            set_flash('Không đổi được mật khẩu — lỗi hệ thống.', 'danger');
        }
        redirect('settings.php');
    }

    if ($action === 'system') {
        $maxPackages = max(0, min(1000000, (int) ($_POST['default_max_packages'] ?? 3)));
        $maxKeys     = max(0, min(1000000, (int) ($_POST['default_max_keys'] ?? 10)));
        $allowReg    = isset($_POST['allow_registration']) ? '1' : '0';

        try {
            set_setting('default_max_packages', (string) $maxPackages);
            set_setting('default_max_keys', (string) $maxKeys);
            set_setting('allow_registration', $allowReg);
            set_flash('Đã lưu cấu hình hệ thống.', 'success');
        } catch (Throwable $e) {
            set_flash('Không lưu được cấu hình — lỗi hệ thống.', 'danger');
        }
        redirect('settings.php');
    }

    http_response_code(400);
    exit('Unknown action');
}

try {
    $serverVersion = (string) db_query('SELECT VERSION()')->fetchColumn();
} catch (Throwable $e) {
    $serverVersion = '';
}

$defaults = get_default_limits();

layout_header('Settings', 'settings');
?>
<div class="settings-grid">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('user', 17); ?> Tài khoản của tôi</h2>
        </div>
        <dl class="detail-list detail-list-page">
            <dt>Username</dt><dd class="cell-strong"><?= e($me['username']) ?></dd>
            <dt>Vai trò</dt><dd><span class="role-chip role-chip-admin"><?php echo icon('shield', 11); ?> Admin — toàn quyền</span></dd>
            <dt>Ngày tạo</dt><dd><?= format_datetime($me['created_at']) ?></dd>
            <dt>Đăng nhập lần cuối</dt><dd><?= format_datetime($me['last_login_at']) ?></dd>
        </dl>
        <form method="post" class="settings-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="password">
            <h3 class="form-section-title">Đổi mật khẩu</h3>
            <div class="form-group">
                <label class="form-label" for="current_password">Mật khẩu hiện tại</label>
                <input type="password" id="current_password" name="current_password" class="form-control" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="new_password">Mật khẩu mới</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" minlength="8" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="confirm_password">Xác nhận mật khẩu mới</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" minlength="8" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo icon('shield', 15); ?> Cập nhật mật khẩu</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('settings', 17); ?> Cấu hình hệ thống</h2>
        </div>
        <form method="post" class="settings-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="system">
            <h3 class="form-section-title">Hạn mức mặc định cho user thường</h3>
            <p class="form-hint">Áp dụng cho user không đặt hạn mức riêng (để trống max ở trang Users). Admin không bao giờ bị giới hạn.</p>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Max packages / user</label>
                    <input type="number" name="default_max_packages" class="form-control" min="0" max="1000000" value="<?= (int) $defaults['max_packages'] ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Max keys / user</label>
                    <input type="number" name="default_max_keys" class="form-control" min="0" max="1000000" value="<?= (int) $defaults['max_keys'] ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label toggle-row">
                    <input type="checkbox" name="allow_registration" value="1"<?= get_setting('allow_registration', '1') === '1' ? ' checked' : '' ?>>
                    <span>Cho phép tự đăng ký tài khoản (auth/register.php)</span>
                </label>
                <p class="form-hint">Tắt = chỉ admin mới tạo được tài khoản mới (trong trang Users).</p>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo icon('check', 15); ?> Lưu cấu hình</button>
        </form>

        <dl class="detail-list detail-list-page" style="margin-top: 18px;">
            <dt>PHP Version</dt><dd><?= e(PHP_VERSION) ?></dd>
            <dt>Database</dt><dd><?= $serverVersion !== '' ? 'MySQL / ' . e($serverVersion) : 'MySQL (PDO)' ?></dd>
            <dt>PDO Driver</dt><dd>mysql (prepared statements)</dd>
            <dt>Session</dt><dd>HttpOnly · SameSite=Lax</dd>
            <dt>CSRF Protection</dt><dd>Enabled trên mọi POST action</dd>
            <dt>API Endpoint</dt><dd><code>/api/connect.php</code></dd>
        </dl>
        <div class="notice notice-info">
            <?php echo icon('shield', 18); ?>
            <div>Mật khẩu lưu bằng <code>password_hash()</code> (bcrypt). API luôn trả JSON hợp lệ và dùng prepared statements cho mọi truy vấn.</div>
        </div>
    </div>
</div>
<?php layout_footer();
