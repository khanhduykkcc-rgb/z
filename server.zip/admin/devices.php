<?php
/**
 * Danh sách thiết bị đã kích hoạt key — một query JOIN duy nhất,
 * số thiết bị mỗi key dùng aggregate subquery (không N+1).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_admin();

$q          = trim((string) ($_GET['q'] ?? ''));
$pkgFilter  = (int) ($_GET['package'] ?? 0);

$where  = [];
$params = [];

if ($q !== '') {
    $where[]  = '(dh.device_uuid LIKE ? OR t.token_code LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}
if ($pkgFilter > 0) {
    $where[]  = 't.project_id = ?';
    $params[] = $pkgFilter;
}

$sql = 'SELECT dh.device_uuid, dh.first_used,
               t.token_code, t.type, t.expire_date,
               p.name AS package_name,
               COALESCE(dc.device_count, 0) AS device_count
        FROM tbl_device_history dh
        JOIN tbl_tokens t ON t.id = dh.token_id
        JOIN tbl_projects p ON p.id = t.project_id
        LEFT JOIN (SELECT token_id, COUNT(*) AS device_count FROM tbl_device_history GROUP BY token_id) dc
            ON dc.token_id = dh.token_id'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY dh.first_used DESC, dh.id DESC';

$devices = db_query($sql, $params)->fetchAll();
$projects = db_query('SELECT id, name FROM tbl_projects ORDER BY name')->fetchAll();

function device_status_badge(array $row): string
{
    switch (key_status($row)) {
        case 'active':
            return '<span class="badge badge-success">Active</span>';
        case 'pending':
            return '<span class="badge badge-warning">Pending</span>';
        default:
            return '<span class="badge badge-danger">Expired</span>';
    }
}

layout_header('Devices', 'devices');
?>
<div class="page-toolbar">
    <form class="filter-bar" method="get">
        <div class="search-box">
            <?php echo icon('search', 16); ?>
            <input type="text" name="q" class="form-control" placeholder="Tìm UUID hoặc key..." value="<?= e($q) ?>">
        </div>
        <select name="package" class="form-control form-control-sm">
            <option value="">Tất cả package</option>
            <?php foreach ($projects as $p): ?>
            <option value="<?= (int) $p['id'] ?>"<?= $pkgFilter === (int) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-secondary btn-sm">Lọc</button>
        <?php if ($q !== '' || $pkgFilter > 0): ?>
        <a href="devices.php" class="btn btn-ghost btn-sm">Xóa lọc</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <?php if (!$devices): ?>
    <div class="empty-state">
        <?php echo icon('device', 36); ?>
        <p>Chưa có thiết bị nào khớp bộ lọc.</p>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Key</th><th>Package</th><th>Device UUID</th>
                    <th>First Used</th><th>Thiết bị đang dùng key</th><th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($devices as $row): ?>
                <tr>
                    <td><code class="code-box"><?= e($row['token_code']) ?></code></td>
                    <td><?= e($row['package_name']) ?></td>
                    <td class="mono text-muted"><?= e($row['device_uuid']) ?></td>
                    <td class="text-muted"><?= format_datetime($row['first_used']) ?></td>
                    <td><span class="device-count"><?= (int) $row['device_count'] ?></span></td>
                    <td><?= device_status_badge($row) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php layout_footer(['devices.js']); ?>
