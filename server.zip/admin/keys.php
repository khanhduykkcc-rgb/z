<?php
/**
 * Quản lý Key (admin): tạo, xóa, tìm kiếm, lọc, xem chi tiết.
 * Static key: hạn cố định. Dynamic key: hạn tính từ lần kích hoạt đầu.
 * Mọi key đều thuộc về người tạo (user_id) — admin thấy và thao tác TẤT CẢ
 * key của mọi người; user thường chỉ thấy của mình (user/keys.php).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_admin();

$me = current_user();

/* ------------------------------ Actions ------------------------------ */

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $projectId  = (int) ($_POST['project_id'] ?? 0);
        $type       = (($_POST['type'] ?? '') === 'static') ? 'static' : 'dynamic';
        $maxDevices = max(1, min(100, (int) ($_POST['max_devices'] ?? 1)));
        $expireDate = null;
        $duration   = 0;
        $error      = null;

        try {
            $projectExists = db_query('SELECT 1 FROM tbl_projects WHERE id = ?', [$projectId])->fetchColumn();
            if ($projectExists === false) {
                $error = 'Package không tồn tại — hãy tạo package trước khi tạo key.';
            } elseif ($type === 'static') {
                $expireDate = parse_datetime_local((string) ($_POST['expire_date'] ?? ''));
                if ($expireDate === null) {
                    $error = 'Ngày hết hạn không hợp lệ.';
                }
            } else {
                $duration = (int) ($_POST['duration'] ?? 0);
                if ($duration < 1 || $duration > 3650) {
                    $error = 'Số ngày sử dụng phải từ 1 đến 3650.';
                }
            }

            if ($error !== null) {
                set_flash($error, 'danger');
            } else {
                $code = generate_key_code();
                db_query(
                    'INSERT INTO tbl_tokens (project_id, token_code, type, duration, expire_date, max_devices, user_id)
                     VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [$projectId, $code, $type, $duration, $expireDate, $maxDevices, (int) $me['id']]
                );
                set_flash('Đã tạo key: ' . $code, 'success');
            }
        } catch (Throwable $e) {
            set_flash('Không tạo được key — lỗi hệ thống. Hãy kiểm tra database đã cài đúng schema mới nhất.', 'danger');
        }
        redirect('keys.php');
    }

    if ($action === 'delete') {
        try {
            db_query('DELETE FROM tbl_tokens WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
            set_flash('Đã xóa key.', 'success');
        } catch (Throwable $e) {
            set_flash('Không xóa được key — lỗi hệ thống.', 'danger');
        }
        redirect('keys.php');
    }

    http_response_code(400);
    exit('Unknown action');
}

/* --------------------------- Filters + list --------------------------- */

$q        = trim((string) ($_GET['q'] ?? ''));
$type     = in_array($_GET['type'] ?? '', ['static', 'dynamic'], true) ? $_GET['type'] : '';
$status   = in_array($_GET['status'] ?? '', ['active', 'expired', 'pending'], true) ? $_GET['status'] : '';
$pkgFilter = (int) ($_GET['package'] ?? 0);

$where  = [];
$params = [];

if ($q !== '') {
    $where[]  = 't.token_code LIKE ?';
    $params[] = '%' . $q . '%';
}
if ($type !== '') {
    $where[]  = 't.type = ?';
    $params[] = $type;
}
if ($pkgFilter > 0) {
    $where[]  = 't.project_id = ?';
    $params[] = $pkgFilter;
}
if ($status === 'active') {
    $where[] = '(t.expire_date IS NULL OR t.expire_date >= NOW())';
} elseif ($status === 'expired') {
    $where[] = 't.expire_date IS NOT NULL AND t.expire_date < NOW()';
} elseif ($status === 'pending') {
    $where[] = 't.expire_date IS NULL';
}

$sql = 'SELECT t.id, t.token_code, t.type, t.duration, t.expire_date, t.max_devices, t.created_at,
               p.name AS package_name,
               u.username AS owner_name,
               COALESCE(d.device_count, 0) AS device_count
        FROM tbl_tokens t
        JOIN tbl_projects p ON p.id = t.project_id
        LEFT JOIN tbl_users u ON u.id = t.user_id
        LEFT JOIN (SELECT token_id, COUNT(*) AS device_count FROM tbl_device_history GROUP BY token_id) d
            ON d.token_id = t.id'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY t.id DESC';

$keys = [];
try {
    $keys = db_query($sql, $params)->fetchAll();
} catch (Throwable $e) {
    /* DB cũ chưa có bảng tbl_users → bỏ JOIN owner, dùng query tương thích */
    $sqlCompat = str_replace('LEFT JOIN tbl_users u ON u.id = t.user_id', '', $sql);
    $sqlCompat = str_replace("\n               u.username AS owner_name,", '', $sqlCompat);
    try {
        $keys = db_query($sqlCompat, $params)->fetchAll();
    } catch (Throwable $e2) {
        $keys = [];
    }
}

$projects = db_query('SELECT id, name FROM tbl_projects ORDER BY name')->fetchAll();

function expiry_label(array $row): string
{
    if ($row['type'] === 'dynamic' && empty($row['expire_date'])) {
        return '<span class="text-muted">Chưa kích hoạt</span>';
    }
    return e(format_datetime($row['expire_date']));
}

function status_badge(array $row): string
{
    switch (key_status($row)) {
        case 'active':
            return '<span class="badge badge-success">Active</span>';
        case 'pending':
            return '<span class="badge badge-warning">Pending</span>';
        default:
            return '<span class="badge badge-danger">Expired</span>';
    }
}

layout_header('Keys', 'keys');
?>
<div class="page-toolbar">
    <form class="filter-bar" method="get">
        <div class="search-box">
            <?php echo icon('search', 16); ?>
            <input type="text" name="q" class="form-control" placeholder="Tìm key..." value="<?= e($q) ?>">
        </div>
        <select name="package" class="form-control form-control-sm">
            <option value="">Tất cả package</option>
            <?php foreach ($projects as $p): ?>
            <option value="<?= (int) $p['id'] ?>"<?= $pkgFilter === (int) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="type" class="form-control form-control-sm">
            <option value="">Loại key</option>
            <option value="static"<?= $type === 'static' ? ' selected' : '' ?>>Static</option>
            <option value="dynamic"<?= $type === 'dynamic' ? ' selected' : '' ?>>Dynamic</option>
        </select>
        <select name="status" class="form-control form-control-sm">
            <option value="">Trạng thái</option>
            <option value="active"<?= $status === 'active' ? ' selected' : '' ?>>Active</option>
            <option value="pending"<?= $status === 'pending' ? ' selected' : '' ?>>Pending</option>
            <option value="expired"<?= $status === 'expired' ? ' selected' : '' ?>>Expired</option>
        </select>
        <button type="submit" class="btn btn-secondary btn-sm">Lọc</button>
        <?php if ($q !== '' || $type !== '' || $status !== '' || $pkgFilter > 0): ?>
        <a href="keys.php" class="btn btn-ghost btn-sm">Xóa lọc</a>
        <?php endif; ?>
    </form>
    <button type="button" class="btn btn-primary" data-modal-open="createKeyModal">
        <?php echo icon('plus', 16); ?> Tạo Key
    </button>
</div>

<div class="card">
    <?php if (!$keys): ?>
    <div class="empty-state">
        <?php echo icon('key', 36); ?>
        <p>Không có key nào khớp. Tạo key mới hoặc đổi bộ lọc.</p>
        <button type="button" class="btn btn-primary btn-sm" data-modal-open="createKeyModal">Tạo Key đầu tiên</button>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Key</th><th>Package</th><th>Type</th><th>Expiry</th>
                    <th>Duration</th><th>Devices</th><th>Status</th><th>Created At</th><th class="th-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($keys as $row): ?>
                <tr>
                    <td>
                        <div class="key-cell">
                            <code class="code-box"><?= e($row['token_code']) ?></code>
                            <button type="button" class="icon-btn icon-btn-xs" data-copy="<?= e($row['token_code']) ?>" title="Copy">
                                <?php echo icon('copy', 13); ?>
                            </button>
                        </div>
                    </td>
                    <td><?= e($row['package_name']) ?></td>
                    <td><span class="badge badge-neutral"><?= e($row['type']) ?></span></td>
                    <td><?= expiry_label($row) ?></td>
                    <td class="text-muted"><?= $row['type'] === 'dynamic' ? (int) $row['duration'] . ' ngày' : '—' ?></td>
                    <td><span class="device-count"><?= (int) $row['device_count'] ?> / <?= (int) $row['max_devices'] ?></span></td>
                    <td><?= status_badge($row) ?></td>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    <td class="td-actions">
                        <button type="button" class="icon-btn" data-view-key="<?= e(json_encode([
                            'code'        => $row['token_code'],
                            'package'     => $row['package_name'],
                            'type'        => $row['type'],
                            'duration'    => (int) $row['duration'],
                            'expiry'      => format_datetime($row['expire_date']),
                            'devices'     => (int) $row['device_count'] . ' / ' . (int) $row['max_devices'],
                            'created'     => format_datetime($row['created_at']),
                            'owner'       => ($row['owner_name'] ?? null) !== null ? (string) $row['owner_name'] : 'Hệ thống',
                        ])) ?>" title="Xem chi tiết">
                            <?php echo icon('eye', 15); ?>
                        </button>
                        <form method="post" class="inline-form" data-confirm="Xóa key <?= e($row['token_code']) ?>? Thiết bị liên quan cũng sẽ bị xóa.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn icon-btn-danger" title="Xóa">
                                <?php echo icon('trash', 15); ?>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<div class="modal-backdrop" id="createKeyModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="createKeyTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="createKeyTitle"><?php echo icon('key', 18); ?> Tạo Key mới</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label class="form-label">Package</label>
                <select name="project_id" class="form-control" required>
                    <?php foreach ($projects as $p): ?>
                    <option value="<?= (int) $p['id'] ?>"><?= e($p['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Loại key</label>
                <select name="type" id="keyType" class="form-control" required>
                    <option value="static">Static — hạn cố định</option>
                    <option value="dynamic">Dynamic — tính từ lần kích hoạt đầu</option>
                </select>
            </div>
            <div class="form-group" id="staticField">
                <label class="form-label">Ngày hết hạn</label>
                <input type="datetime-local" name="expire_date" class="form-control" required>
            </div>
            <div class="form-group" id="dynamicField" hidden>
                <label class="form-label">Số ngày sử dụng</label>
                <input type="number" name="duration" class="form-control" min="1" max="3650" placeholder="30">
                <div class="preset-row">
                    <button type="button" class="chip" data-preset="30">30 days</button>
                    <button type="button" class="chip" data-preset="60">60 days</button>
                    <button type="button" class="chip" data-preset="90">90 days</button>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Số thiết bị tối đa</label>
                <input type="number" name="max_devices" class="form-control" value="1" min="1" max="100" required>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary"><?php echo icon('plus', 15); ?> Tạo Key</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-backdrop" id="viewKeyModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="viewKeyTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="viewKeyTitle"><?php echo icon('eye', 18); ?> Chi tiết Key</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <div class="modal-body">
            <div class="key-detail-code">
                <code id="vkCode" class="code-box code-box-lg"></code>
                <button type="button" class="icon-btn" id="vkCopy"><?php echo icon('copy', 15); ?></button>
            </div>
            <dl class="detail-list">
                <dt>Package</dt><dd id="vkPackage"></dd>
                <dt>Type</dt><dd id="vkType"></dd>
                <dt>Duration</dt><dd id="vkDuration"></dd>
                <dt>Expiry</dt><dd id="vkExpiry"></dd>
                <dt>Devices</dt><dd id="vkDevices"></dd>
                <dt>Created At</dt><dd id="vkCreated"></dd>
                <dt>Owner</dt><dd id="vkOwner"></dd>
            </dl>
        </div>
    </div>
</div>
<?php layout_footer(['keys.js']); ?>
