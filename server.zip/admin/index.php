<?php
/**
 * Dashboard overview — toàn bộ số liệu lấy trực tiếp từ database.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';

require_admin();

$stats = db_query(
    "SELECT
        (SELECT COUNT(*) FROM tbl_tokens) AS total_keys,
        (SELECT COUNT(*) FROM tbl_tokens WHERE expire_date IS NULL OR expire_date >= NOW()) AS active_keys,
        (SELECT COUNT(*) FROM tbl_tokens WHERE expire_date IS NOT NULL AND expire_date < NOW()) AS expired_keys,
        (SELECT COUNT(*) FROM tbl_projects) AS total_packages,
        (SELECT COUNT(*) FROM tbl_users) AS total_users,
        (SELECT COUNT(*) FROM tbl_users WHERE role = 'user' AND is_active = 1) AS active_users,
        (SELECT COUNT(*) FROM tbl_device_history) AS total_devices,
        (SELECT COUNT(*) FROM tbl_projects WHERE is_maintenance = 1) AS maintenance_packages"
)->fetch();

$recentKeys = db_query(
    'SELECT t.token_code, t.type, t.expire_date, t.created_at, p.name AS package_name
     FROM tbl_tokens t
     JOIN tbl_projects p ON p.id = t.project_id
     ORDER BY t.id DESC
     LIMIT 6'
)->fetchAll();

$recentDevices = db_query(
    'SELECT dh.device_uuid, dh.first_used, t.token_code, p.name AS package_name
     FROM tbl_device_history dh
     JOIN tbl_tokens t ON t.id = dh.token_id
     JOIN tbl_projects p ON p.id = t.project_id
     ORDER BY dh.id DESC
     LIMIT 6'
)->fetchAll();

function key_status_badge(array $row): string
{
    switch (key_status($row)) {
        case 'active':
            return '<span class="badge badge-success">Active</span>';
        case 'pending':
            return '<span class="badge badge-warning">Pending</span>';
        default:
            return '<span class="badge badge-danger">Expired</span>';
    }
}

layout_header('Dashboard', 'dashboard');
?>
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-icon tile-blue"><?php echo icon('key', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Total Keys</span>
            <span class="stat-value"><?= (int) $stats['total_keys'] ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-green"><?php echo icon('check', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Active Keys</span>
            <span class="stat-value"><?= (int) $stats['active_keys'] ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-red"><?php echo icon('key-off', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Expired Keys</span>
            <span class="stat-value"><?= (int) $stats['expired_keys'] ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-violet"><?php echo icon('package', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Total Packages</span>
            <span class="stat-value"><?= (int) $stats['total_packages'] ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-violet"><?php echo icon('users', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Users</span>
            <span class="stat-value"><?= (int) $stats['total_users'] ?></span>
            <span class="stat-sub text-muted"><?= (int) $stats['active_users'] ?> đang hoạt động</span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-amber"><?php echo icon('device', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Total Devices</span>
            <span class="stat-value"><?= (int) $stats['total_devices'] ?></span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon tile-slate"><?php echo icon('maintenance', 20); ?></div>
        <div class="stat-body">
            <span class="stat-label">Maintenance Status</span>
            <?php if ((int) $stats['maintenance_packages'] > 0): ?>
            <span class="stat-value stat-value-sm"><span class="badge badge-warning"><?= (int) $stats['maintenance_packages'] ?> package đang bảo trì</span></span>
            <?php else: ?>
            <span class="stat-value stat-value-sm"><span class="badge badge-success">All operational</span></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="panel-grid">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('key', 17); ?> Keys mới nhất</h2>
            <a class="btn btn-secondary btn-sm" href="keys.php">Xem tất cả</a>
        </div>
        <?php if (!$recentKeys): ?>
        <div class="empty-state">
            <?php echo icon('key', 34); ?>
            <p>Chưa có key nào. Tạo key đầu tiên trong trang Keys.</p>
        </div>
        <?php else: ?>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>Key</th><th>Package</th><th>Trạng thái</th><th>Ngày tạo</th></tr></thead>
                <tbody>
                <?php foreach ($recentKeys as $row): ?>
                    <tr>
                        <td><code class="code-box"><?= e($row['token_code']) ?></code></td>
                        <td><?= e($row['package_name']) ?></td>
                        <td><?= key_status_badge($row) ?></td>
                        <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php echo icon('device', 17); ?> Thiết bị mới nhất</h2>
            <a class="btn btn-secondary btn-sm" href="devices.php">Xem tất cả</a>
        </div>
        <?php if (!$recentDevices): ?>
        <div class="empty-state">
            <?php echo icon('device', 34); ?>
            <p>Chưa có thiết bị nào kích hoạt key.</p>
        </div>
        <?php else: ?>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>Key</th><th>Package</th><th>Device UUID</th><th>Lần đầu dùng</th></tr></thead>
                <tbody>
                <?php foreach ($recentDevices as $row): ?>
                    <tr>
                        <td><code class="code-box"><?= e($row['token_code']) ?></code></td>
                        <td><?= e($row['package_name']) ?></td>
                        <td class="mono text-muted"><?= e($row['device_uuid']) ?></td>
                        <td class="text-muted"><?= format_datetime($row['first_used']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php layout_footer(); ?>
