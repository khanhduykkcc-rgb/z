<?php
/**
 * Cấu hình hệ thống. Không có side-effect ở đây — kết nối DB diễn ra
 * theo yêu cầu trong includes/database.php.
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'khanhduy_key');
define('DB_PASS', 'khanhduy123456789');
define('DB_NAME', 'khanhduy_key1');

/* Tên session của admin dashboard */
define('SESSION_NAME', 'APSESSID');

/* Tài khoản admin mặc định do install.php tạo */
define('DEFAULT_ADMIN_USER', 'khanhduy');
define('DEFAULT_ADMIN_PASS', 'khanhduy2010');
