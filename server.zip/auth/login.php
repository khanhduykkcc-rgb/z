<?php
/**
 * CỔNG ĐĂNG NHẬP THỐNG NHẤT — dùng chung cho MỌI tài khoản:
 *   role = admin → dashboard admin (toàn quyền)
 *   role = user  → dashboard user (tự tạo package/key trong hạn mức)
 * Không có "nơi đăng nhập riêng của admin" — chỉ khác vai trò tài khoản.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/icons.php';

if (is_logged_in()) {
    redirect(dashboard_url_for(current_role()));
}

$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Phiên làm việc hết hạn. Thử lại.';
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Vui lòng nhập đầy đủ tài khoản và mật khẩu.';
        } elseif (login_throttle($username)) {
            $error = 'Đăng nhập sai quá nhiều lần. Vui lòng chờ 30 giây rồi thử lại.';
        } else {
            $result = attempt_login($username, $password);
            if ($result === 'ok') {
                clear_login_failures($username);
                redirect(dashboard_url_for(current_role()));
            }
            if ($result === 'banned') {
                record_login_failure($username);
                $error = 'Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên.';
            } else {
                record_login_failure($username);
                $error = 'Tài khoản hoặc mật khẩu không đúng.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Đăng nhập — API Panel</title>
<link rel="stylesheet" href="../assets/css/app.css">
<link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body class="auth-body">
<div class="auth-wrap">
    <div class="auth-card">
        <div class="auth-brand">
            <span class="brand-mark brand-mark-lg"><?php echo icon('shield', 24); ?></span>
            <span class="brand-text-lg">API<span class="brand-accent">Panel</span></span>
        </div>

        <h1 class="auth-title">Đăng nhập</h1>
        <p class="auth-sub">Admin và user dùng chung một cổng đăng nhập — hệ thống tự nhận vai trò tài khoản.</p>

        <?php if ($error !== ''): ?>
        <div class="notice notice-danger">
            <?php echo icon('warning', 18); ?>
            <div><?= e($error) ?></div>
        </div>
        <?php endif; ?>

        <form method="post" class="auth-form" autocomplete="off">
            <?= csrf_field() ?>
            <div class="form-group">
                <label class="form-label" for="username">Tên đăng nhập hoặc Email</label>
                <input type="text" class="form-control" id="username" name="username"
                       value="<?= e($_POST['username'] ?? '') ?>" required autofocus>
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Mật khẩu</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
        </form>

        <?php if (get_setting('allow_registration', '1') === '1'): ?>
        <div class="auth-divider"><span>chưa có tài khoản?</span></div>
        <a class="btn btn-register btn-block" href="register.php">
            <?php echo icon('user', 16); ?> Đăng ký tài khoản
        </a>
        <?php endif; ?>
        <p class="auth-note">Tài khoản user được tạo package và key trong hạn mức do admin đặt.</p>
    </div>
</div>
</body>
</html>
