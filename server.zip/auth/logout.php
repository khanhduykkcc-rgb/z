<?php
/**
 * Đăng xuất — chỉ chấp nhận POST kèm CSRF token.
 * Một phiên một tài khoản nên không cần phân vai: phá sạch session.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    logout_current();
}

redirect('../auth/login.php');
