<?php
/**
 * Upgrade database từ schema CŨ lên schema MỚI (tài khoản thống nhất):
 *
 *   CŨ: bảng admins riêng + tbl_users cũ (không role/hạn mức)
 *       + tbl_projects không owner_id + user chỉ "kích hoạt key".
 *   MỚI: MỘT bảng tbl_users có role (admin/user) + hạn mức riêng,
 *       tbl_projects.owner_id, tbl_settings, tbl_tokens.user_id = người tạo key.
 *
 * Các bước (đều idempotent — chạy nhiều lần không gây hại):
 *   1. tbl_users: thêm cột role, max_packages, max_keys (nếu thiếu)
 *   2. Gộp bảng admins cũ vào tbl_users với role='admin'
 *      (trùng username → tài khoản tbl_users được nâng lên admin, mật khẩu admin cũ thắng)
 *   3. tbl_projects: thêm owner_id (giữ NULL = "Hệ thống" cho package cũ)
 *   4. tbl_tokens: thêm user_id nếu thiếu (bản rất cũ)
 *   5. Tạo tbl_settings + seed cấu hình mặc định
 *   6. Đổi tên bảng admins → admins_backup (không xóa — an toàn dữ liệu)
 *
 * Chạy file này MỘT LẦN sau khi upload code mới đè lên bản cũ.
 * Sau khi xong, file tự khóa bằng upgrade.lock (xóa file này như install.php).
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/icons.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

const UPGRADE_LOCK_FILE = __DIR__ . '/upgrade.lock';

$dbOk    = false;
$dbError = null;

try {
    db()->query('SELECT 1');
    $dbOk = true;
} catch (Throwable $e) {
    $dbError = $e->getMessage();
}

/* Helper kiểm tra cột / bảng / index tồn tại (MySQL 5.7 không có IF NOT EXISTS cho ALTER) */

function column_exists(string $table, string $column): bool
{
    return (int) db_query(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
        [$table, $column]
    )->fetchColumn() > 0;
}

function table_exists(string $table): bool
{
    return (int) db_query(
        "SELECT COUNT(*) FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?",
        [$table]
    )->fetchColumn() > 0;
}

$done    = [];
$failed  = [];
$already = is_file(UPGRADE_LOCK_FILE);

if ($dbOk && !$already && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $failed[] = 'CSRF token không hợp lệ. Tải lại trang và thử lại.';
    } else {
        try {
            /* 1a. Bảng tbl_users cũ có thể thiếu cột email (bản rất cũ) */
            if (!column_exists('tbl_users', 'email')) {
                db()->exec('ALTER TABLE tbl_users ADD COLUMN email VARCHAR(190) NULL DEFAULT NULL AFTER username');
                $done[] = 'Đã thêm cột tbl_users.email.';
            }

            /* 1b. Cột role */
            if (!column_exists('tbl_users', 'role')) {
                db()->exec("ALTER TABLE tbl_users ADD COLUMN role ENUM('admin','user') NOT NULL DEFAULT 'user' AFTER password_hash");
                $done[] = 'Đã thêm cột tbl_users.role (admin/user).';
            } else {
                $done[] = 'Cột tbl_users.role đã tồn tại.';
            }

            /* 1c. Cột hạn mức */
            if (!column_exists('tbl_users', 'max_packages')) {
                db()->exec('ALTER TABLE tbl_users ADD COLUMN max_packages INT UNSIGNED NULL DEFAULT NULL AFTER role');
                $done[] = 'Đã thêm cột tbl_users.max_packages.';
            }
            if (!column_exists('tbl_users', 'max_keys')) {
                db()->exec('ALTER TABLE tbl_users ADD COLUMN max_keys INT UNSIGNED NULL DEFAULT NULL AFTER max_packages');
                $done[] = 'Đã thêm cột tbl_users.max_keys.';
            }

            /* 2. Gộp bảng admins cũ vào tbl_users với role='admin' */
            if (table_exists('admins')) {
                $admins = db_query('SELECT username, password_hash FROM admins')->fetchAll();
                $merged = 0;
                foreach ($admins as $adm) {
                    $exists = db_query(
                        'SELECT id FROM tbl_users WHERE username = ? LIMIT 1',
                        [$adm['username']]
                    )->fetchColumn();

                    if ($exists !== false) {
                        /* Trùng tên: nâng quyền tài khoản hiện có, mật khẩu admin cũ thắng */
                        db_query(
                            "UPDATE tbl_users SET role = 'admin', password_hash = ? WHERE id = ?",
                            [$adm['password_hash'], $exists]
                        );
                    } else {
                        db_query(
                            "INSERT INTO tbl_users (username, password_hash, role) VALUES (?, ?, 'admin')",
                            [$adm['username'], $adm['password_hash']]
                        );
                    }
                    $merged++;
                }

                /* Đổi tên bảng cũ để lưu dữ liệu phòng khi cần (không xóa) */
                if (!table_exists('admins_backup')) {
                    db()->exec('RENAME TABLE admins TO admins_backup');
                    $done[] = 'Đã gộp ' . $merged . ' tài khoản admin vào tbl_users (role=admin), bảng cũ đổi tên thành admins_backup.';
                } else {
                    db()->exec('DROP TABLE admins');
                    $done[] = 'Đã gộp ' . $merged . ' tài khoản admin vào tbl_users (role=admin).';
                }
            } else {
                $done[] = 'Không có bảng admins cũ — bỏ qua bước gộp.';
            }

            /* 3. tbl_projects.owner_id */
            if (!column_exists('tbl_projects', 'owner_id')) {
                db()->exec('ALTER TABLE tbl_projects ADD COLUMN owner_id INT UNSIGNED NULL DEFAULT NULL AFTER is_maintenance');
                $done[] = 'Đã thêm cột tbl_projects.owner_id (package cũ giữ NULL = "Hệ thống").';
            }

            /* 4. tbl_tokens.user_id (bản rất cũ có thể chưa có) */
            if (table_exists('tbl_tokens') && !column_exists('tbl_tokens', 'user_id')) {
                db()->exec('ALTER TABLE tbl_tokens ADD COLUMN user_id INT UNSIGNED NULL DEFAULT NULL AFTER max_devices');
                $done[] = 'Đã thêm cột tbl_tokens.user_id (người tạo key).';
            }

            /* 5. Bảng cấu hình + seed */
            db()->exec(
                "CREATE TABLE IF NOT EXISTS tbl_settings (
                    setting_key VARCHAR(64) NOT NULL,
                    setting_value VARCHAR(255) NOT NULL DEFAULT '',
                    PRIMARY KEY (setting_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
            $defaults = [
                'default_max_packages' => '3',
                'default_max_keys'     => '10',
                'allow_registration'   => '1',
            ];
            foreach ($defaults as $key => $value) {
                db_query(
                    'INSERT IGNORE INTO tbl_settings (setting_key, setting_value) VALUES (?, ?)',
                    [$key, $value]
                );
            }
            $done[] = 'Bảng tbl_settings sẵn sàng + cấu hình mặc định (3 package / 10 key / mở đăng ký).';

            if (@file_put_contents(UPGRADE_LOCK_FILE, date('c')) === false) {
                $failed[] = 'Không ghi được upgrade.lock — hãy tạo tay file rỗng tên upgrade.lock cùng thư mục.';
            }
        } catch (Throwable $e) {
            $failed[] = 'Nâng cấp thất bại: ' . $e->getMessage();
        }
    }
}

$finished = $already || ($dbOk && !$failed && !empty($done) && is_file(UPGRADE_LOCK_FILE));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nâng cấp — API Panel</title>
<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body class="auth-body">
<div class="auth-wrap install-wrap">
    <div class="auth-card">
        <div class="auth-brand">
            <span class="brand-mark brand-mark-lg"><?php echo icon('shield', 24); ?></span>
            <span class="brand-text-lg">API<span class="brand-accent">Panel</span></span>
        </div>

        <?php if (!$dbOk): ?>
        <h1 class="auth-title">Không kết nối được database</h1>
        <div class="notice notice-danger">
            <?php echo icon('warning', 18); ?>
            <div>Kiểm tra DB_HOST / DB_USER / DB_PASS / DB_NAME trong <code>config.php</code> rồi tải lại trang.</div>
        </div>

        <?php elseif ($finished): ?>
        <h1 class="auth-title">Nâng cấp hoàn tất</h1>
        <div class="notice notice-success">
            <?php echo icon('check', 18); ?>
            <div>Database đã ở schema mới: một bảng <code>tbl_users</code> theo role (admin/user) + hạn mức + <code>tbl_settings</code>.</div>
        </div>
        <?php foreach ($done as $item): ?>
        <div class="check-row"><span class="check-state ok"><?php echo icon('check', 14); ?></span><span class="check-label"><?= e($item) ?></span></div>
        <?php endforeach; ?>
        <div class="notice notice-warning">
            <?php echo icon('warning', 18); ?>
            <div>Hãy xóa file <code>upgrade.php</code> khỏi server sau khi nâng cấp. Bảng <code>admins_backup</code> (nếu có) giữ làm dữ liệu phòng hộ — có thể xóa tay khi chắc chắn mọi thứ chạy tốt.</div>
        </div>
        <a class="btn btn-primary btn-block" href="auth/login.php">Đến trang đăng nhập</a>

        <?php else: ?>
        <h1 class="auth-title">Nâng cấp database</h1>
        <p class="auth-sub">Chuyển sang mô hình tài khoản thống nhất: một bảng user theo role, admin toàn quyền, user thường tự tạo package/key trong hạn mức. Không làm mất dữ liệu.</p>

        <?php foreach ($failed as $err): ?>
        <div class="notice notice-danger"><?php echo icon('warning', 18); ?><div><?= e($err) ?></div></div>
        <?php endforeach; ?>

        <div class="install-checks">
            <h3 class="install-section-title">Sẽ thực hiện</h3>
            <div class="check-row"><span class="check-state ok"><?php echo icon('users', 14); ?></span><span class="check-label">tbl_users thêm role + hạn mức<span class="check-detail">admin / user · max_packages · max_keys</span></span></div>
            <div class="check-row"><span class="check-state ok"><?php echo icon('shield', 14); ?></span><span class="check-label">Gộp bảng admins cũ<span class="check-detail">thành role=admin trong tbl_users (đổi tên thành admins_backup)</span></span></div>
            <div class="check-row"><span class="check-state ok"><?php echo icon('package', 14); ?></span><span class="check-label">tbl_projects thêm owner_id<span class="check-detail">package cũ giữ NULL = "Hệ thống"</span></span></div>
            <div class="check-row"><span class="check-state ok"><?php echo icon('database', 14); ?></span><span class="check-label">tbl_settings + mặc định<span class="check-detail">3 package / 10 key / mở đăng ký</span></span></div>
        </div>

        <form method="post" class="install-form">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-primary btn-block">Chạy nâng cấp</button>
        </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
