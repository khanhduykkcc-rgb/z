<?php
/**
 * Helper dùng chung: escape output, CSRF, sinh token an toàn,
 * JSON response cho API, flash message, redirect.
 */

declare(strict_types=1);

/* ------------------------------------------------------------------
 * Polyfill mb_strlen: nhiều shared hosting không bật extension
 * mbstring → gọi mb_strlen() gây Fatal Error (trắng trang) khi tạo
 * package. Nếu thiếu, dùng strlen như phương án dự phòng (chấp nhận
 * đếm theo byte cho tên tiếng Việt — vẫn an toàn cho giới hạn 120).
 * ------------------------------------------------------------------ */
if (!function_exists('mb_strlen')) {
    function mb_strlen(string $string, ?string $encoding = null): int
    {
        return strlen($string);
    }
}
if (!function_exists('mb_strtolower')) {
    function mb_strtolower(string $string, ?string $encoding = null): string
    {
        return strtolower($string);
    }
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function require_method(string $method): void
{
    if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== strtoupper($method)) {
        http_response_code(405);
        exit('Method not allowed');
    }
}

/* ----------------------------- CSRF ----------------------------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function csrf_verify(?string $token): bool
{
    return is_string($token)
        && !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

function csrf_verify_request(): void
{
    if (csrf_verify($_POST['csrf_token'] ?? null)) {
        return;
    }

    /* Đừng đổ trang trắng chữ "Invalid CSRF token" — thường là session
     * hết hạn (không phải tấn công). Tạo token mới rồi quay về trang
     * cũ kèm thông báo tiếng Việt để người dùng thử lại. */
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    set_flash('Phiên làm việc hết hạn (token bảo mật không khớp). Vui lòng thử lại.', 'danger');

    $back = basename((string) ($_SERVER['SCRIPT_NAME'] ?? 'index.php'));
    redirect($back);
}

/* --------------------------- Token gen --------------------------- */

/**
 * Sinh token bằng bộ sinh ngẫu nhiên an toàn mật mã.
 * Dùng cho project token (32 hex chars) — không bao giờ dùng str_shuffle.
 */
function generate_secure_token(int $bytes = 16): string
{
    return bin2hex(random_bytes($bytes));
}

/**
 * Chuẩn hóa link liên hệ: người dùng hay gõ "t.me/abc" thiếu scheme.
 * Tự thêm https:// trước khi kiểm tra, tránh báo lỗi URL không hợp lệ.
 */
function normalize_url(string $raw): string
{
    $value = trim($raw);
    if ($value === '') {
        return '';
    }
    if (!preg_match('#^https?://#i', $value)) {
        $value = 'https://' . $value;
    }
    return $value;
}

/**
 * Parse giá trị datetime-local gửi từ trình duyệt — chấp nhận cả
 * "Y-m-dTH:i" (chuẩn) lẫn "Y-m-dTH:i:s" (một số trình duyệt/ngôn ngữ).
 */
function parse_datetime_local(string $raw): ?string
{
    $value = trim($raw);
    if ($value === '') {
        return null;
    }
    foreach (['Y-m-d\TH:i:s', 'Y-m-d\TH:i'] as $format) {
        $dt = DateTime::createFromFormat($format, $value);
        if ($dt instanceof DateTime) {
            $errors = DateTime::getLastErrors();
            $bad = is_array($errors) ? (($errors['warning_count'] ?? 0) + ($errors['error_count'] ?? 0)) : 0;
            if ($bad === 0) {
                return $dt->format('Y-m-d H:i:s');
            }
        }
    }
    return null;
}

/**
 * Sinh mã key dạng XXXX-XXXX-XXXX-XXXX từ CSPRNG, đảm bảo chưa tồn tại.
 */
function generate_key_code(): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $max      = strlen($alphabet) - 1;

    do {
        $code = '';
        for ($i = 0; $i < 16; $i++) {
            if ($i > 0 && $i % 4 === 0) {
                $code .= '-';
            }
            $code .= $alphabet[random_int(0, $max)];
        }
        $exists = db_query(
            'SELECT 1 FROM tbl_tokens WHERE token_code = ? LIMIT 1',
            [$code]
        )->fetchColumn();
    } while ($exists !== false);

    return $code;
}

/* ------------------------ Flash message ------------------------- */

function set_flash(string $message, string $type = 'success'): void
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function take_flash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/* --------------------------- API JSON ---------------------------- */

/**
 * Xuất JSON cho API endpoint và dừng. Đây là lối ra duy nhất của
 * connect.php — không bao giờ để PHP warning/notice phá JSON.
 */
function json_out(array $payload, int $status = 200): void
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function api_error(string $message, bool $forceExit = false, ?string $contact = null): void
{
    $payload = ['status' => false, 'message' => $message];
    if ($forceExit) {
        $payload['force_exit'] = true;
    }
    if ($contact !== null) {
        $payload['contact'] = $contact;
    }
    json_out($payload);
}

/* ------------------------- Format helpers ------------------------ */

function format_datetime(?string $value): string
{
    if (empty($value)) {
        return '—';
    }
    $ts = strtotime($value);
    return $ts === false ? '—' : date('d/m/Y H:i', $ts);
}

/**
 * Trạng thái key: suspended / revoked (cột status — V2) ưu tiên trước,
 * rồi mới đến pending (dynamic chưa kích hoạt), active, expired.
 * Expiry luôn do thời gian SERVER quyết định, không phải client.
 */
function key_status(array $row): string
{
    $status = (string) ($row['status'] ?? 'active');
    if ($status === 'suspended' || $status === 'revoked') {
        return $status;
    }
    if (empty($row['expire_date'])) {
        return 'pending';
    }
    return strtotime((string) $row['expire_date']) > time() ? 'active' : 'expired';
}
