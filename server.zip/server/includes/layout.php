<?php
/**
 * Layout dùng chung cho MỌI trang dashboard (admin lẫn user):
 * sidebar + topbar + flash toast. Nav đổi theo ngữ cảnh:
 *   context = 'admin' : Dashboard, Keys, Packages, Devices, Users, Settings
 *   context = 'user'  : Dashboard, Keys của tôi, Packages của tôi, Thiết bị, Tài khoản
 * Dùng chung một bộ CSS dashboard nên trải nghiệm đồng nhất.
 */

declare(strict_types=1);

require_once __DIR__ . '/icons.php';

/**
 * URL asset cho các trang nằm sâu 1 cấp so với web root (admin/, user/).
 * Luôn trả về đường dẫn ../assets/... — nếu dùng đường dẫn tương đối
 * "assets/..." thì trình duyệt sẽ resolve thành /admin/assets/... (404).
 */
function asset_version(string $path): string
{
    $file = __DIR__ . '/../' . $path;
    $version = is_file($file) ? (string) filemtime($file) : '1';
    return '../' . $path . '?v=' . $version;
}

function layout_header(string $title, string $active, string $context = 'admin'): void
{
    $user  = current_user();
    $flash = take_flash();

    if ($context === 'admin') {
        $nav = [
            'dashboard' => ['admin/index.php', 'Dashboard', 'dashboard'],
            'keys'      => ['admin/keys.php', 'Keys', 'key'],
            'packages'  => ['admin/packages.php', 'Packages', 'package'],
            'devices'   => ['admin/devices.php', 'Devices', 'device'],
            'users'     => ['admin/users.php', 'Users', 'users'],
            'security'  => ['admin/security.php', 'Security', 'lock'],
            'audit'     => ['admin/audit.php', 'Audit Logs', 'database'],
            'settings'  => ['admin/settings.php', 'Settings', 'settings'],
        ];
    } else {
        $nav = [
            'dashboard' => ['user/index.php', 'Dashboard', 'dashboard'],
            'keys'      => ['user/keys.php', 'Keys của tôi', 'key'],
            'packages'  => ['user/packages.php', 'Packages của tôi', 'package'],
            'devices'   => ['user/devices.php', 'Thiết bị', 'device'],
            'settings'  => ['user/settings.php', 'Tài khoản', 'settings'],
        ];
    }

    $isAdmin = ($user['role'] ?? 'user') === 'admin';
    ?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?> — API Panel<?= $context === 'user' ? ' User' : '' ?></title>
<link rel="stylesheet" href="<?= e(asset_version('assets/css/app.css')) ?>">
<link rel="stylesheet" href="<?= e(asset_version('assets/css/dashboard.css')) ?>">
<link rel="stylesheet" href="<?= e(asset_version('assets/css/responsive.css')) ?>">
</head>
<body class="app-body">
<div class="app-shell">
    <div class="sidebar-backdrop" data-sidebar-close></div>
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <span class="brand-mark"><?php echo icon('shield', 20); ?></span>
            <span class="brand-text">API<span class="brand-accent">Panel</span></span>
        </div>
        <nav class="sidebar-nav">
            <?php foreach ($nav as $key => [$href, $label, $iconName]): ?>
            <a href="../<?= e($href) ?>" class="nav-link<?= $active === $key ? ' is-active' : '' ?>">
                <?php echo icon($iconName, 19); ?><span><?= e($label) ?></span>
            </a>
            <?php endforeach; ?>
        </nav>
        <div class="sidebar-footer">
            <div class="sidebar-user">
                <span class="avatar"><?php echo icon('user', 17); ?></span>
                <span class="sidebar-user-name"><?= e($user['username'] ?? '') ?></span>
                <span class="role-chip<?= $isAdmin ? ' role-chip-admin' : '' ?>"><?php echo icon($isAdmin ? 'shield' : 'user', 11); ?> <?= $isAdmin ? 'Admin' : 'User' ?></span>
            </div>
            <form method="post" action="../auth/logout.php" class="logout-form">
                <?= csrf_field() ?>
                <button type="submit" class="nav-link nav-logout">
                    <?php echo icon('logout', 18); ?><span>Logout</span>
                </button>
            </form>
        </div>
    </aside>
    <div class="app-main">
        <header class="topbar">
            <button type="button" class="icon-btn sidebar-toggle" data-sidebar-toggle aria-label="Menu">
                <?php echo icon('menu', 20); ?>
            </button>
            <h1 class="topbar-title"><?= e($title) ?></h1>
            <div class="topbar-right">
                <span class="role-chip<?= $isAdmin ? ' role-chip-admin' : '' ?>"><?php echo icon($isAdmin ? 'shield' : 'user', 11); ?> <?= $isAdmin ? 'Admin' : 'User' ?></span>
                <span class="avatar avatar-sm"><?php echo icon('user', 15); ?></span>
                <span class="topbar-user"><?= e($user['username'] ?? '') ?></span>
            </div>
        </header>
        <main class="content">
        <?php if ($flash): ?>
        <div class="flash-data" data-flash="<?= e(json_encode($flash)) ?>"></div>
        <?php endif; ?>
<?php
}

function layout_footer(array $scripts = []): void
{
    ?>
        </main>
    </div>
</div>
<div class="modal-backdrop" id="confirmModal" hidden>
    <div class="modal modal-sm" role="dialog" aria-modal="true" aria-labelledby="confirmTitle">
        <div class="modal-icon modal-icon-danger"><?php echo icon('warning', 22); ?></div>
        <h3 class="modal-title" id="confirmTitle">Xác nhận</h3>
        <p class="modal-text" id="confirmText"></p>
        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
            <button type="button" class="btn btn-danger" id="confirmAccept">Xác nhận</button>
        </div>
    </div>
</div>
<div class="toast-stack" id="toastStack"></div>
<script src="<?= e(asset_version('assets/js/app.js')) ?>"></script>
<?php foreach ($scripts as $script): ?>
<script src="<?= e(asset_version('assets/js/' . $script)) ?>"></script>
<?php endforeach; ?>
</body>
</html>
<?php
}
