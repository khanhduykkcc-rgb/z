<?php
/**
 * DeviceModel — gắn kết thiết bị với key (privacy-conscious).
 *
 * Thiết kế theo spec mục 8:
 *   - device_id do client sinh (hash dữ liệu tối thiểu của máy, không PII),
 *     hoặc do host app tiêm (iOS: identifierForVendor).
 *   - Server lưu: token_id, device_uuid, first_used, last_seen.
 *   - Giới hạn số thiết bị DO SERVER quyết định; client không được can thiệp.
 *
 * Chống race (2 thiết bị kích hoạt 1 key cùng lúc ở slot cuối):
 *   đăng ký bằng INSERT ... SELECT có điều kiện đếm — MỘT câu lệnh
 *   nguyên tử, chạy đúng trên cả MySQL và SQLite.
 */

declare(strict_types=1);

/** Tìm device đã đăng ký cho key; null nếu chưa. */
function device_find(int $tokenId, string $uuid): ?array
{
    $row = db_query(
        'SELECT id, token_id, device_uuid, first_used, last_seen
         FROM tbl_device_history
         WHERE token_id = ? AND device_uuid = ?
         LIMIT 1',
        [$tokenId, $uuid]
    )->fetch();

    return $row === false ? null : $row;
}

/** Số thiết bị đã dùng key. */
function device_count(int $tokenId): int
{
    try {
        return (int) db_query(
            'SELECT COUNT(*) FROM tbl_device_history WHERE token_id = ?',
            [$tokenId]
        )->fetchColumn();
    } catch (Throwable $e) {
        return PHP_INT_MAX; /* DB lỗi → coi như đầy thiết bị (fail-closed) */
    }
}

/**
 * Cập nhật last_seen của thiết bị (best-effort, không throw).
 */
function device_touch(int $deviceId): void
{
    try {
        db_query(
            'UPDATE tbl_device_history SET last_seen = ? WHERE id = ?',
            [date('Y-m-d H:i:s'), $deviceId]
        );
    } catch (Throwable $ignore) {
    }
}

/**
 * Đăng ký thiết bị cho key — CHỈ chạy trong transaction của AuthPipeline.
 *
 * @return array{status:'new'|'exists'|'limit', id:?int}
 *   new   : vừa đăng ký (id = device id)
 *   exists: thiết bị đã từng dùng key này (id = device id)
 *   limit : vượt max_devices → từ chối
 */
function device_register(int $tokenId, string $uuid, int $maxDevices): array
{
    /* Đã từng đăng ký? */
    $existing = device_find($tokenId, $uuid);
    if ($existing !== null) {
        return ['status' => 'exists', 'id' => (int) $existing['id']];
    }

    /* INSERT có điều kiện đếm — nguyên tử, chống race ở slot cuối */
    $inserted = db_query(
        'INSERT INTO tbl_device_history (token_id, device_uuid)
         SELECT ?, ?
         WHERE (SELECT COUNT(*) FROM tbl_device_history WHERE token_id = ?) < ?',
        [$tokenId, $uuid, $tokenId, $maxDevices]
    );

    if ($inserted->rowCount() === 1) {
        return ['status' => 'new', 'id' => (int) db()->lastInsertId()];
    }

    /* rowCount 0: hoặc vừa bị request khác chiếm slot, hoặc unique trùng */
    $again = device_find($tokenId, $uuid);
    if ($again !== null) {
        return ['status' => 'exists', 'id' => (int) $again['id']];
    }

    return ['status' => 'limit', 'id' => null];
}
