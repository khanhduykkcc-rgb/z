<?php
/**
 * SessionModel — session/lease ngắn hạn sau khi key được xác thực.
 *
 * Mô hình (spec mục 10-11):
 *   authenticate thành công → cấp session {id, secret, lease expires}.
 *   Client định kỳ check → server XÁC THỰC LẠI TOÀN BỘ (key, package,
 *   device, expiry) rồi GIA HẠN lease.
 *   Hết lease mà không renew được → AUTH_EXPIRED phía client (không có
 *   trạng thái authorized vô thời hạn).
 *
 * session_secret: chỉ server và client chủ session biết (truyền một lần
 * trong response có chữ ký). Dùng làm khóa HMAC (NaCl crypto_auth =
 * HMAC-SHA-512-256) cho các request check/renew/revoke.
 */

declare(strict_types=1);

/**
 * Tạo session mới — chạy trong transaction của AuthPipeline.
 *
 * @return array{id:string, secret:string, expires:string}
 */
function session_create(int $keyId, int $deviceId, ?int $userId, string $ip, int $leaseSecs, int $maxConcurrent): array
{
    $id     = bin2hex(random_bytes(32));      /* 64 hex */
    $secret = bin2hex(random_bytes(32));      /* 64 hex */
    $now    = time();
    $expires = date('Y-m-d H:i:s', $now + max(60, $leaseSecs));

    /* Chặn bùng nổ session: số session active của key không vượt maxConcurrent.
     * INSERT ... SELECT có điều kiện — nguyên tử trên cả MySQL/SQLite. */
    $ok = db_query(
        'INSERT INTO tbl_sessions (session_id, key_id, device_id, user_id, session_secret, issued_at, last_seen, expires_at, status, ip)
         SELECT ?, ?, ?, ?, ?, ?, ?, ?, \'active\', ?
         WHERE (SELECT COUNT(*) FROM tbl_sessions WHERE key_id = ? AND status = \'active\') < ?',
        [$id, $keyId, $deviceId, $userId, $secret, date('Y-m-d H:i:s', $now), date('Y-m-d H:i:s', $now), $expires, $ip, $keyId, max(1, $maxConcurrent)]
    );

    if ($ok->rowCount() !== 1) {
        throw new RuntimeException('session_concurrent_limit');
    }

    return ['id' => $id, 'secret' => $secret, 'expires' => $expires];
}

/** Tìm session; tự đánh dấu expired nếu đã quá hạn. */
function session_find(string $sessionId): ?array
{
    $row = db_query(
        'SELECT s.session_id, s.key_id, s.device_id, s.user_id, s.session_secret,
                s.issued_at, s.last_seen, s.expires_at, s.status, s.ip,
                t.project_id, t.token_code, t.type AS key_type, t.status AS key_status,
                t.expire_date AS key_expire
         FROM tbl_sessions s
         JOIN tbl_tokens t ON t.id = s.key_id
         WHERE s.session_id = ?
         LIMIT 1',
        [$sessionId]
    )->fetch();

    if ($row === false) {
        return null;
    }

    if ($row['status'] === 'active' && strtotime((string) $row['expires_at']) <= time()) {
        session_mark_expired($sessionId);
        $row['status'] = 'expired';
    }

    return $row;
}

function session_mark_expired(string $sessionId): void
{
    try {
        db_query(
            "UPDATE tbl_sessions SET status = 'expired' WHERE session_id = ? AND status = 'active'",
            [$sessionId]
        );
    } catch (Throwable $ignore) {
    }
}

/** Gia hạn lease (sau khi mọi kiểm tra đã PASS). Trả về hạn mới. */
function session_renew(string $sessionId, int $leaseSecs): string
{
    $expires = date('Y-m-d H:i:s', time() + max(60, $leaseSecs));
    db_query(
        "UPDATE tbl_sessions
         SET expires_at = ?, last_seen = ?, status = 'active'
         WHERE session_id = ?",
        [$expires, date('Y-m-d H:i:s'), $sessionId]
    );
    return $expires;
}

function session_revoke(string $sessionId): void
{
    db_query(
        "UPDATE tbl_sessions SET status = 'revoked' WHERE session_id = ?",
        [$sessionId]
    );
}

/** Đánh dấu hết hạn hàng loạt (sweep thỉnh thoảng — cho thống kê). */
function session_sweep_expired(): void
{
    try {
        if (random_int(1, 50) === 1) {
            db_query(
                "UPDATE tbl_sessions SET status = 'expired' WHERE status = 'active' AND expires_at <= ?",
                [date('Y-m-d H:i:s')]
            );
        }
    } catch (Throwable $ignore) {
    }
}

/** Số session active của key. */
function session_count_active(int $keyId): int
{
    try {
        return (int) db_query(
            "SELECT COUNT(*) FROM tbl_sessions WHERE key_id = ? AND status = 'active'",
            [$keyId]
        )->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Tính MAC request của client (crypto_auth = HMAC-SHA-512-256 của NaCl).
 * PHP tương đương: 32 byte đầu của hash_hmac('sha512', msg, key).
 */
function session_mac(string $message, string $sessionSecretHex): string
{
    /* NaCl crypto_auth = HMAC-SHA-512 cắt lấy 32 byte đầu → 64 hex */
    return substr(hash_hmac('sha512', $message, hex2bin($sessionSecretHex), false), 0, 64);
}

/** So sánh MAC không lộ timing (hash_equals trên hex). */
function session_mac_verify(string $expectedHex, string $givenHex): bool
{
    if (!preg_match('/^[0-9a-f]{64}$/', $givenHex)) {
        return false;
    }
    return hash_equals(strtolower($expectedHex), strtolower($givenHex));
}

/**
 * Chuỗi canonical request mà client dùng để tính MAC — cố định bộ trường
 * (sorted) để 2 phía giống nhau: action, nonce, req_id, session_id, ts.
 *
 * V3 — INTEGRITY REPORT TRONG HEARTBEAT MAC:
 * Client mới luôn gửi kèm 6 trường sec_* (sec_dbg/sec_dump/sec_func/
 * sec_mem/sec_vpn/sec_ctr). Các trường CÓ GIÁ TRỊ KHÁC RỖNG được đưa vào
 * canonical → nằm TRONG MAC → không thể strip/sửa nếu không có
 * session_secret (strip = MAC sai = DENY mac_invalid).
 * Client cũ không gửi sec_* → canonical y hệt format cũ (backcompat).
 * QUY TẮC PHẢI KHỚP C++ (api_client.cpp + canonical.cpp): chỉ thêm trường
 * có giá trị khác rỗng.
 */
function session_request_mac_message(array $request): string
{
    $fields = [
        'action'     => self_or($request, 'action', ''),
        'nonce'      => self_or($request, 'nonce', ''),
        'req_id'     => self_or($request, 'req_id', ''),
        'session_id' => self_or($request, 'session_id', ''),
        'ts'         => self_or($request, 'ts', ''),
    ];
    foreach (['sec_dbg', 'sec_dump', 'sec_func', 'sec_mem', 'sec_vpn', 'sec_ctr'] as $k) {
        $v = self_or($request, $k, '');
        if ($v !== '' && is_string($v)) {
            $fields[$k] = $v;
        } elseif ($v !== '' && is_int($v)) {
            $fields[$k] = (string) $v;
        }
    }
    return Crypto::canonical($fields);
}

/**
 * V3 — Đọc + xác thực integrity report từ request (các trường sec_*).
 *
 * Trả về array:
 *   'present'  => bool  — client có gửi report không (client mới = true)
 *   'valid'    => bool  — định dạng đúng (số 0-999, chuỗi ngắn)
 *   'values'   => array giá trị chuẩn hóa (int)
 *   'violations' => array mã vi phạm ['debug','dump','tamper_func','tamper_mem','vpn']
 *
 * Lưu ý: các trường này đã được MAC bảo vệ (session request) hoặc chỉ mang
 * tính tham khảo (authenticate — client cũ có thể không gửi). Report SAI
 * ĐỊNH DẠNG ở session request = client đã bị sửa đổi → coi là tamper.
 */
function security_report_parse(array $request): array
{
    $keys = ['sec_dbg', 'sec_dump', 'sec_func', 'sec_mem', 'sec_vpn', 'sec_ctr'];
    $out = ['present' => false, 'valid' => true, 'values' => [], 'violations' => []];

    foreach ($keys as $k) {
        $raw = $request[$k] ?? null;
        if ($raw === null || $raw === '') {
            continue;
        }
        $out['present'] = true;
        /* Định dạng hợp lệ: số thập phân 0..999 (client gửi string) */
        if (is_int($raw)) {
            $raw = (string) $raw;
        }
        if (!is_string($raw) || !preg_match('/^\d{1,3}$/', $raw)) {
            $out['valid'] = false;
            $out['values'][$k] = -1;
            continue;
        }
        $out['values'][$k] = (int) $raw;
    }

    if (!$out['present'] || !$out['valid']) {
        return $out;
    }

    $v = $out['values'];
    if (($v['sec_dbg'] ?? 0) >= 2) {
        $out['violations'][] = 'debug';
    }
    if (($v['sec_dump'] ?? 0) >= 2) {
        $out['violations'][] = 'dump';
    }
    if (($v['sec_func'] ?? 0) > 0) {
        $out['violations'][] = 'tamper_func';
    }
    if (($v['sec_mem'] ?? 0) >= 2) {
        $out['violations'][] = 'tamper_mem';
    }
    if (($v['sec_vpn'] ?? 0) >= 1) {
        $out['violations'][] = 'vpn';
    }
    return $out;
}
