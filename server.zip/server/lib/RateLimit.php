<?php
/**
 * RateLimit — bộ giới hạn tần suất fixed-window dựa trên DB.
 *
 * Thiết kế:
 *   - Bucket = tổ hợp endpoint + định danh (IP / key / session / username).
 *   - 1 bucket = 1 hàng trong tbl_rate_limits (bucket, window_start, hits).
 *   - Cửa sổ tính theo mốc: floor(time / window) * window.
 *   - FAIL-OPEN khi DB lỗi: việc giới hạn là lớp bảo vệ cộng thêm —
 *     mất nó không được làm chết xác thực chính (đã ghi security event).
 *   - Không khóa cả hệ thống vì một IP: bucket luôn theo combo cụ thể.
 *
 * Các ngưỡng cấu hình được trong tbl_settings (xem AuthPipeline::setting()).
 */

declare(strict_types=1);

/**
 * Tăng bộ đếm bucket và trả về true nếu VẪN ĐƯỢC PHÉP thực hiện request.
 *
 * @param string $bucket    khóa bucket, vd "auth:ip:1.2.3.4"
 * @param int    $max       số request tối đa trong 1 cửa sổ
 * @param int    $windowSecs độ dài cửa sổ (giây)
 */
function rl_allow(string $bucket, int $max, int $windowSecs): bool
{
    try {
        $window = (int) (time() / max(1, $windowSecs)) * max(1, $windowSecs);

        $stmt = db_query(
            'UPDATE tbl_rate_limits SET hits = hits + 1 WHERE bucket = ? AND window_start = ?',
            [$bucket, $window]
        );

        if ($stmt->rowCount() === 0) {
            try {
                db_query(
                    'INSERT INTO tbl_rate_limits (bucket, window_start, hits) VALUES (?, ?, 1)',
                    [$bucket, $window]
                );
                return true; /* hit đầu tiên trong cửa sổ */
            } catch (Throwable $race) {
                /* Race: bucket vừa được tạo bởi request khác → cập nhật lại */
                db_query(
                    'UPDATE tbl_rate_limits SET hits = hits + 1 WHERE bucket = ? AND window_start = ?',
                    [$bucket, $window]
                );
            }
        }

        $hits = (int) db_query(
            'SELECT hits FROM tbl_rate_limits WHERE bucket = ? AND window_start = ?',
            [$bucket, $window]
        )->fetchColumn();

        /* Dọn dừa thỉnh thoảng (~2% request) — không mỗi lần gọi */
        if (random_int(1, 50) === 1) {
            try {
                db_query('DELETE FROM tbl_rate_limits WHERE window_start < ?', [time() - 86400]);
            } catch (Throwable $ignore) {
            }
        }

        return $hits <= $max;
    } catch (Throwable $e) {
        /* Fail-open + ghi chú để theo dõi */
        error_log('[RateLimit] unavailable (fail-open): ' . $e->getMessage());
        return true;
    }
}

/**
 * Hủy tác động của lần đếm vừa rồi (dùng khi request bị từ chối trước khi
 * xử lý thực sự — tránh phạt client vì lỗi cấu hình phía server).
 * Không bắt buộc phải thành công.
 */
function rl_rollback(string $bucket, int $windowSecs): void
{
    try {
        $window = (int) (time() / max(1, $windowSecs)) * max(1, $windowSecs);
        db_query(
            'UPDATE tbl_rate_limits SET hits = hits - 1
             WHERE bucket = ? AND window_start = ? AND hits > 0',
            [$bucket, $window]
        );
    } catch (Throwable $ignore) {
    }
}
