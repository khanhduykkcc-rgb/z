<?php
/**
 * Api v2 — envelope request/response cho giao thức TAKEY-V2.
 *
 * Mọi response (kể cả lỗi) đều là JSON envelope có chữ ký:
 *   {
 *     "proto": "TAKEY-V2",
 *     "status": "ok" | "denied" | "error",
 *     "code":   "ok" | "key_expired" | ...,
 *     "data":   { ...string:string... },
 *     "meta":   { "req_id": ..., "nonce": ..., "srv_nonce": ..., "ts": ... },
 *     "sig":    "<hex chữ ký ECDSA P-256 trên chuỗi canonical>"
 *   }
 *
 * Nguyên tắc:
 *   - data chỉ chứa giá trị string → client xử lý đồng nhất.
 *   - meta.req_id / meta.nonce là ECHO của request → client đối chiếu,
 *     chống replay response cũ cho request mới.
 *   - meta.ts là unix time của server → client kiểm tra độ lệch ±300s.
 *   - KHÔNG bao giờ đặt secret (session_secret, private key...) vào envelope
 *     ngoài trường hợp hợp lệ: authenticate trả session_secret MỘT lần cho
 *     chủ sở hữu key vừa được xác thực đầy đủ.
 */

declare(strict_types=1);

require_once __DIR__ . '/Crypto.php';

define('TAKEY_V2_PROTO', 'TAKEY-V2');

/** Đọc JSON body → array; null nếu không parse được. */
function api_v2_input(): ?array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '') {
        return null;
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

/** Địa chỉ IP client (tin cậy ở mức proxy front-doors phổ biến). */
function api_client_ip(): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    if ($ip === '' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        /* Chỉ dùng XFF đầu tiên — phía trước phải là reverse proxy của bạn */
        $parts = explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip    = trim($parts[0]);
    }
    return $ip !== '' ? $ip : 'unknown';
}

/**
 * Xuất envelope có chữ ký rồi exit.
 *
 * @param string $status  "ok" | "denied" | "error"
 * @param string $code    mã máy (vd: key_expired, replay_detected...)
 * @param array  $data    dữ liệu string-to-string
 * @param array  $request request gốc (để echo req_id/nonce)
 * @param int    $http    HTTP status
 */
function api_v2_respond(string $status, string $code, array $data, ?array $request, int $http): void
{
    $meta = [
        'req_id'    => self_or($request, 'req_id', ''),
        'nonce'     => self_or($request, 'nonce', ''),
        'srv_nonce' => bin2hex(random_bytes(16)),
        'ts'        => (string) time(),
    ];

    $dataMap = stringify_map($data);

    $envelope = [
        'proto'  => TAKEY_V2_PROTO,
        'status' => $status,
        'code'   => $code,
        'meta'   => $meta,
    ];

    /* Ký trên toàn bộ trường dữ liệu + meta (trừ sig) — một nguồn duy nhất */
    $signFields = array_merge(
        ['proto' => TAKEY_V2_PROTO, 'status' => $status, 'code' => $code],
        $dataMap,
        $meta
    );

    /* data rỗng phải là {} chứ không phải [] (PHP array rỗng encode thành []) */
    $envelope['data'] = $dataMap === [] ? new stdClass() : $dataMap;

    try {
        $envelope['sig'] = Crypto::sign(Crypto::canonical($signFields));
        $envelope['alg'] = Crypto::ALG;
    } catch (Throwable $e) {
        /* Không ký được (storage không ghi được) → lỗi server rõ ràng,
         * tuyệt đối không trả envelope không chữ ký dạng "ok". */
        $envelope = [
            'proto'  => TAKEY_V2_PROTO,
            'status' => 'error',
            'code'   => 'signing_unavailable',
            'data'   => new stdClass(),
            'meta'   => $meta,
        ];
        $http = 500;
    }

    http_response_code($http);
    header('Content-Type: application/json; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    echo json_encode($envelope, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/** Helper: lấy giá trị string an toàn từ mảng request. */
function self_or(?array $request, string $key, string $default): string
{
    $value = $request[$key] ?? $default;
    return is_string($value) ? $value : (is_int($value) ? (string) $value : $default);
}

/** Ép mọi giá trị về string cho map data. */
function stringify_map(array $map): array
{
    $out = [];
    foreach ($map as $k => $v) {
        if ($v === null) {
            continue;
        }
        $out[(string) $k] = is_bool($v) ? ($v ? '1' : '0') : (string) $v;
    }
    return $out;
}
