<?php
/**
 * KeyModel — vòng đời key (server là nguồn sự thật duy nhất về expiry).
 *
 * Trạng thái key (cột status):
 *   active    : key đang dùng được
 *   suspended : admin tạm ngưng — mọi xác thực bị từ chối, session bị thu hồi
 *   revoked   : đã thu hồi vĩnh viễn
 * Hết hạn (expired) KHÔNG phải một giá trị status — nó là kết quả so sánh
 * expire_date với thời gian server (động, không lưu cứng).
 *
 * Dynamic key: expire_date NULL đến lần kích hoạt đầu tiên. Thời điểm kích
 * hoạt DO SERVER ghi trong transaction — client không gửi "now" của mình.
 */

declare(strict_types=1);

/** Tìm key theo mã + package; trả về hàng đầy đủ hoặc null. */
function key_find(string $code, int $projectId): ?array
{
    $row = db_query(
        'SELECT id, project_id, token_code, type, duration, expire_date, max_devices, user_id, status, created_at
         FROM tbl_tokens
         WHERE token_code = ? AND project_id = ?
         LIMIT 1',
        [$code, $projectId]
    )->fetch();

    return $row === false ? null : $row;
}

/** Key có còn hiệu lực về thời gian? (dynamic chưa kích hoạt = còn) */
function key_is_expired(array $token): bool
{
    $expire = $token['expire_date'] ?? null;
    if ($expire === null || $expire === '') {
        return false;
    }
    return strtotime((string) $expire) <= time();
}

/** Hạn chót tính tại thời điểm now (để dynamic hiện "now + duration"). */
function key_projected_expiry(array $token): ?string
{
    if ($token['type'] === 'dynamic' && ($token['expire_date'] ?? null) === null) {
        return date('Y-m-d H:i:s', time() + (int) $token['duration'] * 86400);
    }
    return $token['expire_date'] ?? null;
}

/** Số ngày còn lại (0 nếu hết/negative). */
function key_days_left(array $token): int
{
    $expire = $token['expire_date'] ?? null;
    if ($expire === null || $expire === '') {
        $expire = key_projected_expiry($token);
        if ($expire === null) {
            return 0;
        }
    }
    $days = (int) floor((strtotime((string) $expire) - time()) / 86400);
    return max(0, $days);
}

/**
 * Thu hồi mọi session đang chạy của một key (dùng khi suspend/revoke/delete).
 */
function key_revoke_sessions(int $keyId): void
{
    try {
        db_query(
            "UPDATE tbl_sessions SET status = 'revoked' WHERE key_id = ? AND status = 'active'",
            [$keyId]
        );
    } catch (Throwable $e) {
        error_log('[KeyModel] cannot revoke sessions: ' . $e->getMessage());
    }
}
