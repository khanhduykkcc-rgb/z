<?php
/**
 * AuthPipeline — pipeline xác thực nhiều bước, server-authoritative (PASS 2).
 *
 * SƠ ĐỒ STAGE (đối chiếu spec mục 3):
 *   S01 Client initialization          → phía client (auth_pipeline.cpp)
 *   S02 Configuration validation       → schema request + cửa sổ timestamp
 *   S03 Package validation             → tồn tại + không bảo trì
 *   S04 Key format validation          → regex định dạng
 *   S05 Server-side key lookup         → SELECT theo (code, project)
 *   S06 Key status validation          → active / suspended / revoked
 *   S07 Expiry validation              → server là nguồn thời gian duy nhất
 *   S08 Device binding validation      → thiết bị đã biết / được phép mới
 *   S09 Device limit validation        → đếm < max_devices
 *   S10 Session creation               → TRANSACTION (lock + re-verify)
 *   S11 Challenge / nonce validation   → single-use nonce + MAC request
 *   S12 Response authenticity          → envelope luôn ký bằng ECDSA
 *   S13 Session/lease validation       → tồn tại + active + chưa hết hạn
 *   S14 Final authorization            → re-validate toàn bộ rồi gia hạn
 *
 * Mọi stage thất bại → DENIED (fail-closed) + security event.
 * KHÔNG có đường tắt: kết quả "ok" chỉ được tạo sau khi toàn bộ stage
 * liên quan pass, bên trong transaction có khóa.
 */

declare(strict_types=1);

require_once __DIR__ . '/Crypto.php';
require_once __DIR__ . '/KeyModel.php';
require_once __DIR__ . '/DeviceModel.php';
require_once __DIR__ . '/SessionModel.php';
require_once __DIR__ . '/Nonce.php';
require_once __DIR__ . '/Audit.php';
require_once __DIR__ . '/RateLimit.php';
require_once __DIR__ . '/Api.php';

/** Ngoại lệ từ chối có kiểm soát — endpoint bắt và trả envelope denied. */
class AuthDeniedException extends RuntimeException
{
    public $apiCode;
    public $http;
    public $extra;

    public function __construct(string $apiCode, int $http = 403, array $extra = [])
    {
        parent::__construct($apiCode);
        $this->apiCode = $apiCode;
        $this->http    = $http;
        $this->extra   = $extra;
    }
}

final class AuthPipeline
{
    /** @var bool chế độ dry-run cho Key Debugging của admin (không ghi DB) */
    private $dryRun;

    /** @var array trace các stage [n, key, label, ok, reason] */
    public $stages = [];

    public function __construct(bool $dryRun = false)
    {
        $this->dryRun = $dryRun;
    }

    /* ============================ Settings ============================ */

    private function setting(string $key, int $default): int
    {
        $v = get_setting($key, (string) $default);
        return max(1, (int) $v);
    }

    /** V3 — policy bool (0/1) từ tbl_settings, mặc định theo tham số. */
    private function setting_bool(string $key, bool $default): bool
    {
        $v = get_setting($key, $default ? '1' : '0');
        return ((int) $v) === 1;
    }

    private function leaseSeconds(): int
    {
        return $this->setting('session_lease_seconds', 600);
    }

    private function maxDrift(): int
    {
        return $this->setting('request_max_drift_seconds', 300);
    }

    /* ======================= Stage primitives ======================== */

    private function stage(int $n, string $key, string $label, bool $ok, string $failReason = ''): bool
    {
        $this->stages[] = [
            'n'      => $n,
            'key'    => $key,
            'label'  => $label,
            'ok'     => $ok,
            'reason' => $ok ? '' : $failReason,
        ];
        return $ok;
    }

    private function deny(string $code, int $http, array $extra = []): void
    {
        throw new AuthDeniedException($code, $http, $extra);
    }

    /* ========================= S02: schema =========================== */

    /** @var array request đã qua schema */
    private $req = [];

    private function checkSchema(array $request, array $requiredFields): void
    {
        $ok = $this->stage(2, 'schema', 'Request schema', is_array($request), 'Body không phải JSON object');
        if (!$ok) {
            $this->deny('bad_request', 400);
        }

        foreach ($requiredFields as $field) {
            $value = $request[$field] ?? null;
            /* ts được phép là JSON number hoặc string — mọi trường khác phải là string */
            $valid = is_string($value) && $value !== ''
                || ($field === 'ts' && (is_int($value) || is_float($value)));
            if (!$valid) {
                $this->stage(2, 'schema', 'Request schema', false, 'Thiếu hoặc sai kiểu trường: ' . $field);
                $this->deny('bad_request', 400);
            }
        }

        if (self_or($request, 'proto', '') !== TAKEY_V2_PROTO) {
            $this->stage(2, 'schema', 'Request schema', false, 'Sai proto (cần ' . TAKEY_V2_PROTO . ')');
            $this->deny('bad_request', 400);
        }

        /* Timestamp window — chống request cũ bị lăng xê */
        $ts = (int) (self_or($request, 'ts', '0'));
        $drift = abs(time() - $ts);
        if ($ts <= 0 || $drift > $this->maxDrift()) {
            $this->stage(2, 'timestamp', 'Cửa sổ thời gian', false, 'Lệch ' . $drift . 's (tối đa ' . $this->maxDrift() . 's)');
            security_event('auth.stale_timestamp', 'warning', ['details' => 'drift=' . $drift . 's']);
            $this->deny('stale_timestamp', 400);
        }
        $this->stage(2, 'timestamp', 'Cửa sổ thời gian', true);

        $this->req = $request;
    }

    /* ==================== S03: package validation ==================== */

    private function findPackage(string $token): array
    {
        try {
            $project = db_query(
                'SELECT id, name, contact_link, is_maintenance FROM tbl_projects WHERE project_token = ? LIMIT 1',
                [$token]
            )->fetch();
        } catch (Throwable $e) {
            $this->stage(3, 'package', 'Package', false, 'Database lỗi');
            $this->deny('server_error', 500);
        }

        if ($project === false) {
            $this->stage(3, 'package', 'Package', false, 'Package token không tồn tại');
            security_event('auth.failed', 'warning', ['details' => 'package_invalid']);
            $this->deny('package_invalid', 403);
        }
        $this->stage(3, 'package', 'Package', true);
        return $project;
    }

    /* ==================== S04: key format ============================ */

    private function checkKeyFormat(string $key): void
    {
        $ok = (bool) preg_match('/^[A-Z0-9]{4}(-[A-Z0-9]{4}){3}$/', $key);
        if (!$this->stage(4, 'key_format', 'Định dạng key', $ok, 'Key không đúng dạng XXXX-XXXX-XXXX-XXXX')) {
            $this->deny('key_format', 400);
        }
    }

    /* ==================== S05: key lookup ============================ */

    private function findKey(string $code, int $projectId): array
    {
        $token = key_find($code, $projectId);
        if ($token === null) {
            $this->stage(5, 'key_lookup', 'Key trong database', false, 'Không tìm thấy key cho package này');
            security_event('auth.failed', 'warning', ['details' => 'key_not_found']);
            $this->deny('key_not_found', 403);
        }
        $this->stage(5, 'key_lookup', 'Key trong database', true);

        /* Rate limit theo key — chống dò/brute một key cụ thể (dry-run bỏ qua
         * để admin debug không đốt hạn mức của client thật) */
        if (!$this->dryRun && !rl_allow('authk:' . (int) $token['id'], $this->setting('rl_auth_key_max', 20), 300)) {
            security_event('ratelimit.triggered', 'warning', ['key_id' => (int) $token['id'], 'details' => 'authk bucket']);
            $this->deny('rate_limited', 429);
        }

        return $token;
    }

    /* ==================== S06: key status ============================ */

    private function checkKeyStatus(array $token): void
    {
        $status = (string) ($token['status'] ?? 'active');
        $ok = $this->stage(6, 'key_status', 'Trạng thái key', $status === 'active',
            $status === 'revoked' ? 'Key đã bị thu hồi' : 'Key đang bị tạm ngưng');

        if ($ok) {
            return;
        }

        security_event('auth.key_denied', 'warning', [
            'key_id'  => (int) $token['id'],
            'details' => 'status=' . $status,
        ]);
        key_revoke_sessions((int) $token['id']);
        $this->deny($status === 'revoked' ? 'key_revoked' : 'key_suspended', 403);
    }

    /* ==================== S07: expiry =============================== */

    private function checkExpiry(array $token): void
    {
        $expired = key_is_expired($token);
        if (!$this->stage(7, 'expiry', 'Thời hạn key', !$expired,
            'Key đã hết hạn lúc ' . (string) $token['expire_date'])) {
            security_event('auth.key_denied', 'warning', [
                'key_id'  => (int) $token['id'],
                'details' => 'expired',
            ]);
            $this->deny('key_expired', 403);
        }
    }

    /* ============== S08 + S09: device binding & limit ================= */

    /**
     * Đánh giá device ngoài transaction (fast path + dry-run).
     * Kết quả cuối vẫn do device_register trong transaction quyết định.
     */
    private function checkDevice(array $token, string $deviceId): void
    {
        $maxDevices = max(1, (int) $token['max_devices']);
        $existing = device_find((int) $token['id'], $deviceId);

        if ($existing !== null) {
            $this->stage(8, 'device_binding', 'Gắn kết thiết bị', true, 'đã đăng ký từ ' . (string) $existing['first_used']);
            $this->stage(9, 'device_limit', 'Giới hạn thiết bị', true, (int) $existing['id'] . '');
            return;
        }

        $used = device_count((int) $token['id']);
        $allowed = $used < $maxDevices;
        $this->stage(8, 'device_binding', 'Gắn kết thiết bị', true, 'thiết bị mới');
        if (!$this->stage(9, 'device_limit', 'Giới hạn thiết bị', $allowed,
            'Đã dùng ' . $used . '/' . $maxDevices . ' thiết bị')) {
            security_event('auth.device_limit', 'warning', [
                'key_id'  => (int) $token['id'],
                'details' => 'used=' . $used . ' max=' . $maxDevices,
            ]);
            $this->deny('device_limit', 403);
        }
    }

    /* ==================== S10: session creation ====================== */

    /**
     * Transaction tạo session. Mọi ghi đều nằm trong đây — thất bại bất kỳ
     * bước nào → ROLLBACK toàn bộ (spec mục 14).
     */
    private function createSession(array $token, array $project, string $deviceId, string $ip): array
    {
        $keyId = (int) $token['id'];
        $maxDevices = max(1, (int) $token['max_devices']);
        $lease = $this->leaseSeconds();

        $pdo = db();
        $lock = '';
        if (db_is_mysql()) {
            $lock = ' FOR UPDATE'; /* MySQL/InnoDB: khóa hàng key khi ghi */
        }

        $pdo->beginTransaction();
        try {
            /* Đọc lại key với khóa (nếu hỗ trợ) — đối tác vừa đổi trạng thái? */
            $fresh = db_query(
                'SELECT status, expire_date, max_devices FROM tbl_tokens WHERE id = ? LIMIT 1' . $lock,
                [$keyId]
            )->fetch();

            if ($fresh === false) {
                throw new AuthDeniedException('key_not_found', 403);
            }
            if ((string) $fresh['status'] !== 'active') {
                throw new AuthDeniedException($fresh['status'] === 'revoked' ? 'key_revoked' : 'key_suspended', 403);
            }
            if ($fresh['expire_date'] !== null && strtotime((string) $fresh['expire_date']) <= time()) {
                throw new AuthDeniedException('key_expired', 403);
            }

            /* Đăng ký thiết bị (nguyên tử, chống race slot cuối) */
            $device = device_register($keyId, $deviceId, max(1, (int) $fresh['max_devices']));
            if ($device['status'] === 'limit') {
                security_event('auth.device_limit', 'warning', [
                    'key_id'  => $keyId,
                    'details' => 'race: slot bị chiếm trong transaction',
                ]);
                throw new AuthDeniedException('device_limit', 403);
            }
            if ($device['status'] === 'new') {
                security_event('device.registered', 'info', [
                    'key_id'    => $keyId,
                    'device_id' => (int) $device['id'],
                    'details'   => 'device mới dùng key ' . mask_key((string) $token['token_code']),
                ]);
            }

            /* Dynamic key: SERVER ghi mốc kích hoạt — không tin giờ client */
            $activatedNow = false;
            if ($token['type'] === 'dynamic' && $fresh['expire_date'] === null) {
                $expiry = date('Y-m-d H:i:s', time() + (int) $token['duration'] * 86400);
                $upd = db_query(
                    'UPDATE tbl_tokens SET expire_date = ? WHERE id = ? AND expire_date IS NULL',
                    [$expiry, $keyId]
                );
                $activatedNow = $upd->rowCount() === 1;
            }

            /* Một thiết bị giữ đúng 1 session active của key này */
            db_query(
                "UPDATE tbl_sessions SET status = 'revoked'
                 WHERE key_id = ? AND device_id = ? AND status = 'active'",
                [$keyId, (int) $device['id']]
            );

            $session = session_create(
                $keyId,
                (int) $device['id'],
                $token['user_id'] !== null ? (int) $token['user_id'] : null,
                $ip,
                $lease,
                $maxDevices
            );

            if ($device['status'] === 'exists') {
                device_touch((int) $device['id']);
            }

            $pdo->commit();

            $this->stage(10, 'session', 'Tạo session', true, 'lease ' . $lease . 's');

            audit_log('key.activated', 'api', $token['user_id'] !== null ? (int) $token['user_id'] : null,
                'key', mask_key((string) $token['token_code']),
                [
                    'device'    => substr($deviceId, 0, 12) . '…',
                    'activated' => $activatedNow ? 'first' : 'renewed',
                    'session'   => mask_session($session['id']),
                ]);

            return $session;
        } catch (AuthDeniedException $e) {
            $pdo->rollBack();
            $this->stage(10, 'session', 'Tạo session', false, $e->apiCode);
            throw $e;
        } catch (Throwable $e) {
            $pdo->rollBack();
            $this->stage(10, 'session', 'Tạo session', false, 'Transaction lỗi: ' . $e->getMessage());
            error_log('[AuthPipeline] txn: ' . $e->getMessage());
            $this->deny('server_error', 500);
        }

        return []; /* unreachable */
    }

    /* ======================== INIT (hello) =========================== */

    /**
     * action=init: đổi lấy thông tin server + public key + challenge.
     * Không cần key. Response có chữ ký để client tin cậy public key.
     */
    public function hello(array $request): array
    {
        $this->checkSchema($request, ['req_id', 'nonce', 'ts', 'package_token']);
        $ip = api_client_ip();

        if ($this->dryRun) {
            $this->stage(2, 'nonce', 'Nonce single-use', true, 'dry-run bỏ qua');
        } elseif (!nonce_consume(self_or($request, 'nonce', ''), 'hello', null, $this->setting('challenge_ttl_seconds', 600))) {
            $this->stage(2, 'nonce', 'Nonce single-use', false, 'Nonce đã dùng hoặc không hợp lệ');
            security_event('auth.replay_detected', 'critical', ['details' => 'hello nonce reused']);
            $this->deny('replay_detected', 409);
        } else {
            $this->stage(2, 'nonce', 'Nonce single-use', true);
        }

        $project = $this->findPackage(self_or($request, 'package_token', ''));
        $challenge = nonce_issue_challenge($this->setting('challenge_ttl_seconds', 600));

        return [
            'alg'           => Crypto::ALG,
            'server_pub'    => Crypto::publicKeyHex(),
            'lease_seconds' => (string) $this->leaseSeconds(),
            'challenge_ttl' => (string) $this->setting('challenge_ttl_seconds', 600),
            'challenge'     => $challenge,
            'maintenance'   => (string) ((int) $project['is_maintenance']),
            'contact'       => (string) $project['contact_link'],
            'package'       => (string) $project['name'],
        ];
    }

    /* ====================== AUTHENTICATE ============================= */

    public function authenticate(array $request): array
    {
        $this->checkSchema($request, ['req_id', 'nonce', 'ts', 'package_token', 'key', 'device_id', 'challenge']);
        $ip = api_client_ip();

        /* S05a — challenge từ init phải còn hiệu lực và chưa dùng */
        if ($this->dryRun) {
            $this->stage(11, 'challenge', 'Challenge từ init', true, 'dry-run bỏ qua');
        } elseif (!nonce_consume_challenge(self_or($request, 'challenge', ''))) {
            $this->stage(11, 'challenge', 'Challenge từ init', false, 'Challenge không hợp lệ / đã dùng / hết hạn');
            security_event('auth.bad_challenge', 'warning', ['details' => 'challenge reused or invalid']);
            $this->deny('bad_challenge', 401);
        } else {
            $this->stage(11, 'challenge', 'Challenge từ init', true);
        }

        /* S11 — nonce của request này phải chưa từng dùng */
        if ($this->dryRun) {
            $this->stage(11, 'nonce', 'Nonce single-use', true, 'dry-run bỏ qua');
        } elseif (!nonce_consume(self_or($request, 'nonce', ''), 'request', null, $this->setting('challenge_ttl_seconds', 600))) {
            $this->stage(11, 'nonce', 'Nonce single-use', false, 'Nonce đã dùng — replay?');
            security_event('auth.replay_detected', 'critical', ['details' => 'authenticate nonce reused']);
            $this->deny('replay_detected', 409);
        } else {
            $this->stage(11, 'nonce', 'Nonce single-use', true);
        }

        $project = $this->findPackage(self_or($request, 'package_token', ''));

        if ((int) $project['is_maintenance'] === 1) {
            $this->stage(3, 'maintenance', 'Bảo trì package', false, 'Package đang bảo trì');
            security_event('auth.failed', 'info', ['details' => 'package_maintenance']);
            $this->deny('package_maintenance', 403, ['contact' => (string) $project['contact_link']]);
        }
        $this->stage(3, 'maintenance', 'Bảo trì package', true);

        $this->checkKeyFormat(self_or($request, 'key', ''));
        $token = $this->findKey(self_or($request, 'key', ''), (int) $project['id']);
        $this->checkKeyStatus($token);
        $this->checkExpiry($token);
        $this->checkDevice($token, self_or($request, 'device_id', ''));

        /* S06.5 — INTEGRITY REPORT (V3) — client mới gửi sec_* kèm
         * authenticate. Không có MAC ở bước này (chưa có session secret)
         * nhưng report giúp chặn client xấu NGAY TỪ KHÂU CẤP SESSION —
         * không phải đợi heartbeat đầu tiên. Miễn MAC strip: request
         * không có MAC → kẻ tấn công có thể bỏ sec_* ở đây, nhưng session
         * heartbeat ĐẦU TIÊN sẽ bắt buộc report trong MAC → bị phát hiện
         * trong vòng lease/3. Defense-in-depth đúng chuẩn MASTG. */
        $report = security_report_parse($request);
        if ($report['present'] && $report['valid']) {
            $violations  = $report['violations'];
            $blockDebug  = $this->setting_bool('security_block_debug', true);
            $blockVpn    = $this->setting_bool('security_block_vpn', true);
            $blockTamper = $this->setting_bool('security_block_tamper', true);

            $hard = [];
            foreach ($violations as $vi) {
                $isHard = ($vi === 'vpn' && $blockVpn)
                       || ($vi === 'debug' && $blockDebug)
                       || ($vi === 'dump' && $blockTamper)
                       || ($vi === 'tamper_func' && $blockTamper)
                       || ($vi === 'tamper_mem' && $blockTamper);
                if ($isHard) {
                    $hard[] = $vi;
                }
            }
            if (!empty($hard)) {
                $this->stage(6, 'security', 'Integrity report', false,
                    'Vi phạm: ' . implode(',', $hard));
                security_event('auth.client_integrity', 'critical', [
                    'details' => 'blocked at authenticate: ' . implode(',', $hard),
                ]);
                $this->deny('security_violation', 403,
                    ['contact' => (string) $project['contact_link']]);
            }
            $this->stage(6, 'security', 'Integrity report', true, 'clean');
        }

        if ($this->dryRun) {
            /* Dry-run dừng trước khi ghi DB — dùng cho Key Debugging UI */
            return ['dry_run' => true, 'trace' => $this->stages];
        }

        $session = $this->createSession($token, $project, self_or($request, 'device_id', ''), $ip);

        return [
            'session_id'     => $session['id'],
            'session_secret' => $session['secret'],
            'lease_expires'  => $session['expires'],
            'key_expires'    => (string) (key_projected_expiry($token) ?? ''),
            'key_type'       => (string) $token['type'],
            'days_left'      => (string) key_days_left($token),
            'contact'        => (string) $project['contact_link'],
            'maintenance'    => '0',
        ];
    }

    /* ================== SESSION CHECK / RENEW / REVOKE =============== */

    public function sessionRequest(array $request): array
    {
        $action = self_or($request, 'action', '');
        if (!in_array($action, ['check', 'renew', 'revoke'], true)) {
            $this->deny('bad_request', 400);
        }

        $this->checkSchema($request, ['req_id', 'nonce', 'ts', 'session_id', 'mac']);

        /* S11 — nonce single-use cho từng request session */
        $sessionId = self_or($request, 'session_id', '');
        if (!nonce_consume(self_or($request, 'nonce', ''), 'request', $sessionId, $this->setting('challenge_ttl_seconds', 600))) {
            $this->stage(11, 'nonce', 'Nonce single-use', false, 'Nonce đã dùng — replay?');
            security_event('auth.replay_detected', 'critical', ['details' => 'session request nonce reused']);
            $this->deny('replay_detected', 409);
        }
        $this->stage(11, 'nonce', 'Nonce single-use', true);

        /* S13 — session tồn tại + còn hiệu lực */
        $session = session_find($sessionId);
        if ($session === null) {
            $this->stage(13, 'session', 'Session', false, 'Không tồn tại');
            security_event('auth.session_invalid', 'warning', ['details' => 'not found']);
            $this->deny('session_invalid', 401);
        }
        if ($session['status'] !== 'active') {
            $this->stage(13, 'session', 'Session', false, 'Trạng thái: ' . (string) $session['status']);
            security_event('auth.session_invalid', 'warning', ['details' => 'status=' . (string) $session['status']]);
            $this->deny($session['status'] === 'expired' ? 'session_expired' : 'session_invalid', 401);
        }
        $this->stage(13, 'session', 'Session', true, 'lease đến ' . (string) $session['expires_at']);

        /* S11b — MAC request (HMAC-SHA-512-256 với session_secret).
         * V3: canonical của MAC giờ BAO GỒM các trường sec_* (nếu client gửi)
         * → report không thể strip/sửa trên đường đi. */
        $expected = session_mac(session_request_mac_message($request), (string) $session['session_secret']);
        if (!session_mac_verify($expected, self_or($request, 'mac', ''))) {
            $this->stage(11, 'mac', 'MAC request', false, 'Chữ ký request không khớp session_secret');
            security_event('auth.mac_invalid', 'critical', ['details' => 'session ' . mask_session($sessionId)]);
            $this->deny('mac_invalid', 401);
        }
        $this->stage(11, 'mac', 'MAC request', true);

        /* S13b — INTEGRITY REPORT POLICY (V3 — SERVER QUYẾT ĐỊNH TOÀN BỘ):
         * Client tổng hợp 5 lớp bảo mật (anti-VPN/anti-debug/anti-dump/
         * func-integrity/memory-integrity) và báo cáo qua sec_* trong MAC.
         * Server đọc report + áp policy security_block_*:
         *   - VPN/proxy detected  → deny (mặc định BẬT theo yêu cầu)
         *   - debugger/dump/tamper→ deny + REVOKE session ngay lập tức
         *   - report sai định dạng → client đã bị sửa → deny + revoke
         * Client KHÔNG tự quyết định — mọi verdict là của server tại đây. */
        $report = security_report_parse($request);
        if ($report['present']) {
            if (!$report['valid']) {
                $this->stage(13, 'security', 'Integrity report', false, 'Report sai định dạng — client bị sửa đổi');
                security_event('auth.client_integrity', 'critical', [
                    'details' => 'malformed sec_* report (MAC-verified)',
                ]);
                session_revoke($sessionId);
                $this->deny('security_violation', 403);
            }

            $violations   = $report['violations'];
            $blockDebug   = $this->setting_bool('security_block_debug', true);
            $blockVpn     = $this->setting_bool('security_block_vpn', true);
            $blockTamper  = $this->setting_bool('security_block_tamper', true);

            $hard = []; /* vi phạm bị chặn */
            $soft = []; /* vi phạm chỉ ghi nhận */
            foreach ($violations as $vi) {
                $isHard = ($vi === 'vpn' && $blockVpn)
                       || ($vi === 'debug' && $blockDebug)
                       || ($vi === 'dump' && $blockTamper)
                       || ($vi === 'tamper_func' && $blockTamper)
                       || ($vi === 'tamper_mem' && $blockTamper);
                if ($isHard) {
                    $hard[] = $vi;
                } else {
                    $soft[] = $vi;
                }
            }

            if (!empty($soft)) {
                security_event('auth.client_integrity_flag', 'warning', [
                    'details' => 'soft flags: ' . implode(',', $soft),
                ]);
            }

            if (!empty($hard)) {
                $this->stage(13, 'security', 'Integrity report', false,
                    'Vi phạm: ' . implode(',', $hard));
                security_event('auth.client_integrity', 'critical', [
                    'details' => 'blocked: ' . implode(',', $hard),
                    'key_id'  => (int) $session['key_id'],
                ]);
                /* Thu hồi NGAY — client xấu không giữ lease dù chỉ 1 giây */
                session_revoke($sessionId);
                $this->deny('security_violation', 403);
            }
            $this->stage(13, 'security', 'Integrity report', true,
                'report OK (ctr=' . (string) ($report['values']['sec_ctr'] ?? 0) . ')');
        } else {
            /* Client cũ: không có sec_* — cho qua (backcompat), revoke không xảy ra.
             * Admin muốn ép client mới: bật setting bên dưới = 1. */
            $requireReport = $this->setting_bool('security_require_report', false);
            if ($requireReport) {
                $this->stage(13, 'security', 'Integrity report', false, 'Client không gửi report (yêu cầu bật security_require_report)');
                $this->deny('client_outdated', 403);
            }
            $this->stage(13, 'security', 'Integrity report', true, 'legacy client — không có report');
        }

        /* S12/S14 — re-validate toàn bộ quyền của session:
         * key còn active? chưa hết hạn? package còn? thiết bị còn? */
        try {
            $project = db_query(
                'SELECT id, is_maintenance, contact_link FROM tbl_projects WHERE id = ? LIMIT 1',
                [(int) $session['project_id']]
            )->fetch();
        } catch (Throwable $e) {
            $project = false;
        }

        if ($project === false) {
            $this->stage(14, 'revalidate', 'Xác thực lại quyền', false, 'Package đã bị xóa');
            $this->deny('package_invalid', 403);
        }
        if ((int) $project['is_maintenance'] === 1) {
            $this->stage(14, 'revalidate', 'Xác thực lại quyền', false, 'Package đang bảo trì');
            $this->deny('package_maintenance', 403, ['contact' => (string) $project['contact_link']]);
        }
        if ((string) $session['key_status'] !== 'active') {
            $this->stage(14, 'revalidate', 'Xác thực lại quyền', false, 'Key ' . (string) $session['key_status']);
            $this->deny((string) $session['key_status'] === 'revoked' ? 'key_revoked' : 'key_suspended', 403);
        }
        if ($session['key_expire'] !== null && strtotime((string) $session['key_expire']) <= time()) {
            $this->stage(14, 'revalidate', 'Xác thực lại quyền', false, 'Key hết hạn');
            $this->deny('key_expired', 403);
        }

        $deviceExists = db_query(
            'SELECT 1 FROM tbl_device_history WHERE id = ? AND token_id = ? LIMIT 1',
            [(int) $session['device_id'], (int) $session['key_id']]
        )->fetchColumn();
        if ($deviceExists === false) {
            $this->stage(14, 'revalidate', 'Xác thực lại quyền', false, 'Thiết bị đã bị gỡ khỏi key');
            $this->deny('device_invalid', 403);
        }
        $this->stage(14, 'revalidate', 'Xác thực lại quyền', true);

        /* Hành động */
        if ($action === 'revoke') {
            session_revoke($sessionId);
            return ['revoked' => '1'];
        }

        session_sweep_expired();
        $expires = session_renew($sessionId, $this->leaseSeconds());
        device_touch((int) $session['device_id']);

        return [
            'lease_expires' => $expires,
            'key_expires'   => (string) ($session['key_expire'] ?? ''),
            'days_left'     => (string) key_days_left($session),
            'contact'       => (string) $project['contact_link'],
        ];
    }

    /* ================== DRY-RUN cho Key Debugging UI ================= */

    /**
     * Chạy pipeline đọc-cho-biết (admin dashboard): KHÔNG ghi DB, không
     * tiêu nonce, không tạo session, không kích hoạt dynamic.
     * Device dạng "hypothetical": truyền device_id cụ thể để test thiết bị
     * đã biết, bỏ trống để mô phỏng thiết bị mới.
     */
    public static function debugValidate(string $tokenCode, string $packageToken, string $deviceId = ''): array
    {
        $pipeline = new self(true);
        $request = [
            'proto'         => TAKEY_V2_PROTO,
            'action'        => 'authenticate',
            'req_id'        => bin2hex(random_bytes(8)),
            'nonce'         => bin2hex(random_bytes(16)),
            'ts'            => (string) time(),
            'package_token' => $packageToken,
            'key'           => $tokenCode,
            'device_id'     => $deviceId !== '' ? $deviceId : 'debug-hypothetical-device',
            'challenge'     => 'debug-bypass',
        ];

        try {
            $pipeline->authenticate($request);
            return ['ok' => true, 'stages' => $pipeline->stages, 'reason' => ''];
        } catch (AuthDeniedException $e) {
            return ['ok' => false, 'stages' => $pipeline->stages, 'reason' => $e->apiCode];
        } catch (Throwable $e) {
            return ['ok' => false, 'stages' => $pipeline->stages, 'reason' => 'server_error'];
        }
    }
}

/** MySQL hay không — quyết định có dùng SELECT ... FOR UPDATE. */
function db_is_mysql(): bool
{
    static $mysql = null;
    if ($mysql === null) {
        try {
            $mysql = strpos((string) db()->getAttribute(PDO::ATTR_DRIVER_NAME), 'mysql') !== false;
        } catch (Throwable $e) {
            $mysql = false;
        }
    }
    return $mysql;
}
