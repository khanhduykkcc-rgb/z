<?php
/**
 * Crypto — lớp chữ ký server (PASS 2).
 *
 * Thuật toán: ECDSA P-256 + SHA-256 (thư viện openssl của PHP — audited).
 *
 * Lý do chọn (xem research/RESEARCH_REPORT.md):
 *   - PHP openssl_sign() KHÔNG hỗ trợ Ed25519 (đã kiểm chứng trên PHP 8.4),
 *     ext-sodium thường không bật trên XAMPP shared host.
 *   - ECDSA P-256: 128-bit security, openssl có sẵn 100%.
 *   - Client verify bằng micro-ecc (BSD 2-clause, vendored).
 *
 * Private key nằm trên server (server/storage/keys/), được bảo vệ:
 *   - .htaccess deny-all (Apache/XAMPP mặc định)
 *   - permission 0600
 *   - KHÔNG bao giờ gửi private key ra ngoài.
 *
 * Chuỗi canonical (2 phía PHP + C++ phải build GIỐNG HỆT NHAU):
 *   "TAKEY-SIG-1\n"
 *   với mỗi trường (sắp xếp theo tên, byte-order tăng dần):
 *       strlen(tên) ":" tên "=" strlen(giá_trị) ":" giá_trị "\n"
 *   → không còn ambiguity về thứ tự field / whitespace / encoding.
 */

declare(strict_types=1);

final class Crypto
{
    public const ALG          = 'ecdsa-p256';
    private const CANONICAL_V = 'TAKEY-SIG-1';

    /** @var string|null PEM private key */
    private static $privatePem = null;

    /** @var string|null public key dạng hex x||y (128 ký tự) */
    private static $publicHex = null;

    /* ------------------------- Canonical ------------------------- */

    /**
     * Build chuỗi canonical từ map trường (bỏ qua khóa 'sig').
     * Mọi giá trị được ép về string; bool → "0"/"1".
     */
    public static function canonical(array $fields): string
    {
        unset($fields['sig']);
        ksort($fields, SORT_STRING);

        $out = self::CANONICAL_V . "\n";
        foreach ($fields as $name => $value) {
            $name  = (string) $name;
            $value = is_bool($value) ? ($value ? '1' : '0') : (string) $value;
            $out  .= strlen($name) . ':' . $name . '=' . strlen($value) . ':' . $value . "\n";
        }
        return $out;
    }

    /**
     * Ký chuỗi canonical → chữ ký DER (ECDSA P-256 + SHA-256), trả về hex.
     * Throw RuntimeException nếu key chưa sẵn sàng hoặc openssl lỗi.
     */
    public static function sign(string $message): string
    {
        self::ensureKey();

        $ok = openssl_sign($message, $signature, self::$privatePem, OPENSSL_ALGO_SHA256);
        if ($ok !== true) {
            throw new RuntimeException('Signing failed');
        }
        return bin2hex($signature);
    }

    /** Public key dạng hex x||y — đưa cho client để verify (không phải bí mật). */
    public static function publicKeyHex(): string
    {
        self::ensureKey();
        return self::$publicHex;
    }

    /* ---------------------- Quản lý key file ---------------------- */

    private static function keyPath(): string
    {
        return __DIR__ . '/../storage/keys/signing_key.pem';
    }

    /**
     * Nạp private key từ file; nếu chưa có thì sinh mới.
     * Sinh key mới là một lần duy nhất — client luôn nhận public key
     * hiện thời qua init nên không phá tính liên tục.
     */
    private static function ensureKey(): void
    {
        if (self::$privatePem !== null) {
            return;
        }

        $dir  = dirname(self::keyPath());
        $file = self::keyPath();

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
            self::writeGuardFiles($dir);
        }

        if (is_file($file) && is_readable($file)) {
            $pem = (string) file_get_contents($file);
            if (self::loadPem($pem)) {
                @chmod($file, 0600);
                return;
            }
        }

        /* Sinh cặp khóa mới */
        $res = openssl_pkey_new([
            'curve_name'        => 'prime256v1',
            'private_key_type'  => OPENSSL_KEYTYPE_EC,
        ]);
        if ($res === false) {
            throw new RuntimeException('Cannot generate signing key: ' . (string) openssl_error_string());
        }

        if (!openssl_pkey_export($res, $pemOut)) {
            throw new RuntimeException('Cannot export signing key');
        }

        if (@file_put_contents($file, $pemOut, LOCK_EX) === false) {
            throw new RuntimeException('Cannot persist signing key (storage/keys not writable)');
        }
        @chmod($file, 0600);

        if (!self::loadPem($pemOut)) {
            throw new RuntimeException('Generated key is invalid');
        }

        /* Ghi audit khi vừa sinh signing key lần đầu */
        if (function_exists('audit_log')) {
            audit_log('signing_key.generated', 'system', null, 'signing_key', self::ALG, []);
        }
    }

    private static function loadPem(string $pem): bool
    {
        $res = openssl_pkey_get_private($pem);
        if ($res === false) {
            return false;
        }
        $det = openssl_pkey_get_details($res);
        if ($det === false || empty($det['ec']['x']) || empty($det['ec']['y'])) {
            return false;
        }
        self::$privatePem = $pem;
        /* Lưu ý: $det['ec']['x'/'y'] là BINARY — phải bin2hex trước khi nối */
        self::$publicHex  = bin2hex($det['ec']['x']) . bin2hex($det['ec']['y']);
        return true;
    }

    /**
     * Chặn truy cập trực tiếp thư mục keys trên Apache.
     * (README khuyến nghị nginx: deny tất cả request tới /storage/.)
     */
    private static function writeGuardFiles(string $dir): void
    {
        $ht  = $dir . '/.htaccess';
        if (!is_file($ht)) {
            @file_put_contents($ht, "Require all denied\n\n# Apache 2.2 fallback\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n");
        }
        $rootGuard = dirname($dir) . '/.htaccess';
        if (!is_file($rootGuard)) {
            @file_put_contents($rootGuard, "Require all denied\n");
        }
    }
}
