<?php
/**
 * Nonce — chống replay phía server (PASS 2 spec mục 5).
 *
 * Mọi request v2 phải mang một nonce do client sinh bằng CSPRNG (32 byte hex).
 * Server lưu SHA-256 của nonce với TTL:
 *   - request nonce (client sinh)  : INSERT — trùng → replay_detected.
 *   - challenge (server sinh ở init): INSERT scope=challenge, client phải
 *     echo lại ở authenticate, bị DELETE khi tiêu thụ (single-use, có TTL).
 *
 * Vì sao lưu hash: bảng phục vụ chống trùng lặp — không cần đọc lại giá trị
 * gốc, hash giúp đều độ dài + tránh lưu dữ liệu client thô.
 */

declare(strict_types=1);

/**
 * Tiêu thụ một nonce của client. Trả về true nếu nonce này CHƯA từng dùng
 * trong TTL (và ghi nhận nó). False = replay hoặc DB lỗi an toàn (fail-closed
 * cho tính năng này vì chống replay là điều kiện bắt buộc của xác thực).
 */
function nonce_consume(string $nonce, string $scope, ?string $sessionId, int $ttlSecs): bool
{
    $nonce = strtolower(trim($nonce));
    if (!preg_match('/^[0-9a-f]{16,128}$/', $nonce)) {
        return false; /* định dạng sai — coi như request rác */
    }

    $hash = hash('sha256', $nonce);
    $now  = time();

    try {
        db_query(
            'INSERT INTO tbl_nonces (nonce_hash, scope, session_id, created_at, expires_at)
             VALUES (?, ?, ?, ?, ?)',
            [
                $hash,
                $scope,
                $sessionId,
                date('Y-m-d H:i:s', $now),
                date('Y-m-d H:i:s', $now + max(60, $ttlSecs)),
            ]
        );
        nonce_cleanup_maybe();
        return true;
    } catch (Throwable $e) {
        /* Trùng khóa chính → nonce đã dùng (hoặc DB lỗi) → từ chối */
        return false;
    }
}

/**
 * Sinh challenge mới (server nonce) cho init — ghi vào bảng, TTL ngắn.
 */
function nonce_issue_challenge(int $ttlSecs): string
{
    $nonce = bin2hex(random_bytes(16));
    $now   = time();

    try {
        db_query(
            'INSERT INTO tbl_nonces (nonce_hash, scope, session_id, created_at, expires_at)
             VALUES (?, ?, NULL, ?, ?)',
            [
                hash('sha256', $nonce),
                'challenge',
                date('Y-m-d H:i:s', $now),
                date('Y-m-d H:i:s', $now + max(60, $ttlSecs)),
            ]
        );
    } catch (Throwable $e) {
        /* Cực hiếm: trùng hash 128-bit. Sinh lại một lần. */
        $nonce = bin2hex(random_bytes(16));
        try {
            db_query(
                'INSERT INTO tbl_nonces (nonce_hash, scope, session_id, created_at, expires_at)
                 VALUES (?, ?, NULL, ?, ?)',
                [
                    hash('sha256', $nonce),
                    'challenge',
                    date('Y-m-d H:i:s', $now),
                    date('Y-m-d H:i:s', $now + max(60, $ttlSecs)),
                ]
            );
        } catch (Throwable $ignore) {
            /* Vẫn trả nonce — client sẽ thất bại ở bước consume nếu DB hỏng */
        }
    }

    nonce_cleanup_maybe();
    return $nonce;
}

/**
 * Xác thực + tiêu thụ challenge mà client echo từ init.
 * true = challenge hợp lệ (tồn tại, chưa dùng, chưa hết hạn).
 */
function nonce_consume_challenge(string $challenge): bool
{
    $challenge = strtolower(trim($challenge));
    if (!preg_match('/^[0-9a-f]{16,128}$/', $challenge)) {
        return false;
    }

    $hash = hash('sha256', $challenge);

    try {
        /* DELETE trả về số dòng bị xóa — single-use tự nhiên,
         * an toàn race: chỉ một request xóa được dòng này. */
        $stmt = db_query(
            "DELETE FROM tbl_nonces
             WHERE nonce_hash = ? AND scope = 'challenge'
               AND expires_at > ?",
            [$hash, date('Y-m-d H:i:s')]
        );
        return $stmt->rowCount() === 1;
    } catch (Throwable $e) {
        return false;
    }
}

/** Dọn nonce hết hạn ~2% số lần gọi. */
function nonce_cleanup_maybe(): void
{
    try {
        if (random_int(1, 50) === 1) {
            db_query('DELETE FROM tbl_nonces WHERE expires_at < ?', [date('Y-m-d H:i:s')]);
        }
    } catch (Throwable $ignore) {
    }
}
