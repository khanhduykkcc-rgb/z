<?php
/**
 * Audit — ghi log hành vi quản trị (tbl_audit_logs) và sự kiện bảo mật
 * (tbl_security_events) cho dashboard.
 *
 * Nguyên tắc:
 *   - KHÔNG BAO GIỜ ghi bí mật: mật khẩu, hash, session_secret, PEM,
 *     private key. Key code bị che bớt (mask_key).
 *   - Ghi log KHÔNG được làm chết request nghiệp vụ → mọi hàm nuốt lỗi
 *     (try/catch + error_log).
 *   - Bảng chưa tồn tại (DB chưa upgrade) → bỏ qua im lặng, hệ thống
 *     vẫn chạy bình thường.
 */

declare(strict_types=1);

/** Che bớt key code: "ABCD-EFGH-IJKL-MNOP" → "ABCD-…-MNOP" */
function mask_key(?string $code): ?string
{
    if ($code === null || $code === '') {
        return $code;
    }
    $head = substr($code, 0, 4);
    $tail = substr($code, -4);
    return $head . '…' . $tail;
}

/** Che session id: 64 hex đầu → 8 ký tự + "…" */
function mask_session(?string $id): ?string
{
    if ($id === null || $id === '') {
        return $id;
    }
    return substr($id, 0, 8) . '…';
}

/**
 * Ghi một dòng audit log.
 *
 * @param string      $event       tên sự kiện chuẩn (vd: key.created)
 * @param string      $actorType   admin | user | system | api
 * @param int|null    $actorId     id của tbl_users (null = hệ thống/api)
 * @param string|null $targetType  kiểu đối tượng (key, package, user, device...)
 * @param string|null $targetLabel nhãn hiển thị (đã che bí mật)
 * @param array       $details     chi tiết dạng string=>string (đã lọc)
 */
function audit_log(
    string $event,
    string $actorType,
    ?int $actorId,
    ?string $targetType,
    ?string $targetLabel,
    array $details = []
): void {
    try {
        $clean = [];
        foreach ($details as $k => $v) {
            $clean[(string) $k] = is_scalar($v) ? (string) $v : json_encode($v);
        }
        db_query(
            'INSERT INTO tbl_audit_logs (event, actor_type, actor_id, target_type, target_label, details, ip, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $event,
                $actorType,
                $actorId,
                $targetType,
                $targetLabel !== null ? mb_substr($targetLabel, 0, 120) : null,
                mb_substr(json_encode($clean, JSON_UNESCAPED_UNICODE), 0, 500),
                php_sapi_name() === 'cli' ? null : api_client_ip_safe(),
                date('Y-m-d H:i:s'),
            ]
        );
    } catch (Throwable $e) {
        error_log('[Audit] skip: ' . $e->getMessage());
    }
}

/**
 * Ghi một sự kiện bảo mật (hiển thị ở trang Security).
 *
 * @param string $event    tên sự kiện (auth.failed, auth.replay_detected...)
 * @param string $severity info | warning | critical
 * @param array  $ctx      {ip, key_id, device_id, details}
 */
function security_event(string $event, string $severity = 'info', array $ctx = []): void
{
    try {
        db_query(
            'INSERT INTO tbl_security_events (event, severity, ip, key_id, device_id, details, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            [
                $event,
                in_array($severity, ['info', 'warning', 'critical'], true) ? $severity : 'info',
                isset($ctx['ip']) ? (string) $ctx['ip'] : (php_sapi_name() === 'cli' ? null : api_client_ip_safe()),
                isset($ctx['key_id']) ? (int) $ctx['key_id'] : null,
                isset($ctx['device_id']) ? (int) $ctx['device_id'] : null,
                isset($ctx['details']) ? mb_substr((string) $ctx['details'], 0, 500) : null,
                date('Y-m-d H:i:s'),
            ]
        );
    } catch (Throwable $e) {
        error_log('[SecurityEvent] skip: ' . $e->getMessage());
    }
}

/** api_client_ip() không phải lúc nào cũng được nạp (trang dashboard) */
function api_client_ip_safe(): string
{
    if (function_exists('api_client_ip')) {
        return api_client_ip();
    }
    return (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
}

/* ------------------- Nhãn hiển thị sự kiện (dashboard) ------------------- */

function audit_event_label(string $event): string
{
    static $labels = [
        'admin.login'            => 'Admin đăng nhập',
        'admin.login_failed'     => 'Admin đăng nhập sai',
        'admin.logout'           => 'Admin đăng xuất',
        'user.login'             => 'User đăng nhập',
        'user.login_failed'      => 'User đăng nhập sai',
        'user.logout'            => 'User đăng xuất',
        'user.registered'        => 'Đăng ký tài khoản',
        'user.created'           => 'Tạo tài khoản',
        'user.updated'           => 'Sửa tài khoản',
        'user.banned'            => 'Khóa tài khoản',
        'user.unbanned'          => 'Mở khóa tài khoản',
        'user.deleted'           => 'Xóa tài khoản',
        'user.password_reset'    => 'Reset mật khẩu',
        'package.created'        => 'Tạo package',
        'package.updated'        => 'Sửa package',
        'package.deleted'        => 'Xóa package',
        'package.maintenance_on' => 'Bật bảo trì',
        'package.maintenance_off' => 'Tắt bảo trì',
        'key.created'            => 'Tạo key',
        'key.updated'            => 'Sửa key',
        'key.deleted'            => 'Xóa key',
        'key.suspended'          => 'Tạm ngưng key',
        'key.unsuspended'        => 'Mở khóa key',
        'key.revoked'            => 'Thu hồi key',
        'key.debug_validated'    => 'Kiểm tra key (debug)',
        'device.removed'         => 'Gỡ thiết bị',
        'settings.updated'       => 'Cập nhật cấu hình',
        'signing_key.generated'  => 'Sinh signing key',
        'security.viewed'        => 'Xem trang Security',
        'upgrade.ran'            => 'Chạy nâng cấp DB',
    ];
    return $labels[$event] ?? $event;
}

function security_event_label(string $event): string
{
    static $labels = [
        'auth.failed'          => 'Xác thực thất bại',
        'auth.replay_detected' => 'Phát hiện replay request',
        'auth.mac_invalid'     => 'MAC request không hợp lệ',
        'auth.stale_timestamp' => 'Timestamp quá cũ',
        'auth.bad_challenge'   => 'Challenge không hợp lệ',
        'auth.key_denied'      => 'Key bị từ chối',
        'auth.device_limit'    => 'Vượt giới hạn thiết bị',
        'auth.session_invalid' => 'Session không hợp lệ',
        'ratelimit.triggered'  => 'Rate limit kích hoạt',
        'legacy.denied'        => 'API legacy từ chối',
    ];
    return $labels[$event] ?? $event;
}
