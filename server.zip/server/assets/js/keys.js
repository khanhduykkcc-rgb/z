/* keys.js — trang Keys: toggle loại key, preset số ngày, view modal,
   tự submit filter khi đổi select. */

(function () {
    'use strict';

    var typeSelect = document.getElementById('keyType');
    var staticField = document.getElementById('staticField');
    var dynamicField = document.getElementById('dynamicField');

    function syncTypeFields() {
        if (!typeSelect) { return; }
        var isDynamic = typeSelect.value === 'dynamic';

        if (staticField) {
            staticField.hidden = isDynamic;
            /* QUAN TRỌNG: input required nằm trong container bị ẩn vẫn chặn
               submit form (browser báo "not focusable" nhưng không hiện gì).
               Phải gỡ required khi ẩn, gắn lại khi hiện. */
            var expireInput = staticField.querySelector('input[name="expire_date"]');
            if (expireInput) { expireInput.required = !isDynamic; }
        }

        if (dynamicField) {
            dynamicField.hidden = !isDynamic;
            var durationInput = dynamicField.querySelector('input[name="duration"]');
            if (durationInput) { durationInput.required = isDynamic; }
        }
    }

    if (typeSelect) {
        typeSelect.addEventListener('change', syncTypeFields);
        syncTypeFields();
        /* Chạy lại khi modal mở để chắc chắn trạng thái khớp với select */
        document.addEventListener('click', function (event) {
            if (event.target.closest('[data-modal-open="createKeyModal"]')) {
                syncTypeFields();
            }
        });
    }

    document.querySelectorAll('.chip[data-preset]').forEach(function (chip) {
        chip.addEventListener('click', function () {
            var input = document.querySelector('#dynamicField input[name="duration"]');
            if (input) { input.value = chip.getAttribute('data-preset'); }
        });
    });

    /* ------------------------ View key modal ------------------------- */

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('[data-view-key]');
        if (!btn) { return; }

        var data;
        try { data = JSON.parse(btn.getAttribute('data-view-key')); } catch (err) { return; }
        if (!data) { return; }

        var set = function (id, value) {
            var el = document.getElementById(id);
            if (el) { el.textContent = value; }
        };

        set('vkCode', data.code || '');
        set('vkPackage', data.package || '');
        set('vkType', data.type === 'static' ? 'Static — hạn cố định' : 'Dynamic — tính từ lần kích hoạt');
        set('vkDuration', data.type === 'dynamic' ? data.duration + ' ngày' : '—');
        set('vkExpiry', data.expiry || '—');
        set('vkDevices', data.devices || '—');
        set('vkCreated', data.created || '—');
        set('vkOwner', data.owner ? data.owner : 'Chưa có user nào kích hoạt');

        var modal = document.getElementById('viewKeyModal');
        if (modal) { modal.hidden = false; }
    });

    var vkCopy = document.getElementById('vkCopy');
    if (vkCopy) {
        vkCopy.addEventListener('click', function () {
            var code = document.getElementById('vkCode');
            if (!code || !code.textContent) { return; }
            var value = code.textContent;
            var done = function () { showToast('Đã copy key', 'success'); };

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(value).then(done, function () {});
            }
        });
    }

    function showToast(message, type) {
        var stack = document.getElementById('toastStack');
        if (!stack) { return; }
        var toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.innerHTML = '<span></span>';
        toast.lastElementChild.textContent = message;
        stack.appendChild(toast);
        setTimeout(function () {
            toast.classList.add('toast-hide');
            setTimeout(function () { toast.remove(); }, 260);
        }, 3500);
    }

    /* --------------------- Filter: auto submit ----------------------- */

    document.querySelectorAll('.filter-bar select').forEach(function (select) {
        select.addEventListener('change', function () {
            select.form.submit();
        });
    });

    /* ---------------- V2: Key Debugging (dry-run pipeline) ------------ */

    var debugKeyId = null;

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('[data-debug-key]');
        if (!btn) { return; }

        debugKeyId = btn.getAttribute('data-debug-key');
        var modal = document.getElementById('debugKeyModal');
        var result = document.getElementById('debugKeyResult');
        if (result) { result.hidden = true; }
        if (modal) { modal.hidden = false; }
    });

    var debugForm = document.getElementById('debugKeyForm');
    if (debugForm) {
        debugForm.addEventListener('submit', function (event) {
            event.preventDefault();
            if (!debugKeyId) { return; }

            var csrf = debugForm.closest('.modal-body');
            var tokenEl = document.querySelector('#debugKeyModal input[name="csrf_token"]');
            var result = document.getElementById('debugKeyResult');
            var verdict = result ? result.querySelector('.stage-trace-verdict') : null;
            var list = result ? result.querySelector('.stage-trace-list') : null;

            if (verdict) {
                verdict.className = 'stage-trace-verdict';
                verdict.textContent = 'Đang chạy pipeline...';
            }
            if (list) { list.innerHTML = ''; }
            if (result) { result.hidden = false; }

            var body = new URLSearchParams();
            body.set('action', 'debug_validate');
            body.set('id', debugKeyId);
            body.set('device_id', (document.getElementById('debugDeviceId') || {}).value || '');
            if (tokenEl) { body.set('csrf_token', tokenEl.value); }

            fetch('keys.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: body.toString(),
                credentials: 'same-origin'
            }).then(function (res) {
                return res.json();
            }).then(function (data) {
                if (!data || data.status !== true) {
                    if (verdict) {
                        verdict.className = 'stage-trace-verdict verdict-fail';
                        verdict.textContent = (data && data.message) || 'Không kiểm tra được key.';
                    }
                    return;
                }

                if (verdict) {
                    verdict.className = 'stage-trace-verdict ' + (data.ok ? 'verdict-ok' : 'verdict-fail');
                    verdict.textContent = data.ok
                        ? 'AUTHORIZED — key này sẽ vượt qua toàn bộ ' + (data.stages ? data.stages.length : 0) + ' bước kiểm tra.'
                        : 'DENIED — dừng ở mã: ' + (data.reason || 'unknown');
                }

                if (list && data.stages) {
                    data.stages.forEach(function (stage) {
                        var row = document.createElement('div');
                        row.className = 'stage-row ' + (stage.ok ? 'pass' : 'fail');

                        var no = document.createElement('span');
                        no.className = 'stage-no';
                        no.textContent = 'S' + String(stage.n).padStart(2, '0');

                        var mark = document.createElement('span');
                        mark.className = 'stage-mark';
                        mark.textContent = stage.ok ? '✓' : '✕';

                        var label = document.createElement('span');
                        label.className = 'stage-label';
                        label.textContent = stage.label || stage.key;
                        if (stage.reason) {
                            var reason = document.createElement('span');
                            reason.className = 'stage-reason';
                            reason.textContent = stage.reason;
                            label.appendChild(reason);
                        }

                        row.appendChild(no);
                        row.appendChild(mark);
                        row.appendChild(label);
                        list.appendChild(row);
                    });
                }
            }).catch(function () {
                if (verdict) {
                    verdict.className = 'stage-trace-verdict verdict-fail';
                    verdict.textContent = 'Lỗi mạng khi chạy kiểm tra.';
                }
            });
        });
    }
})();
