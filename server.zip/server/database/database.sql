-- =====================================================================
-- TemplateAPIKEY — Database FULL (schema + dữ liệu khởi tạo)
-- MySQL 5.7+ / MariaDB 10.2+
--
-- MÔ HÌNH TÀI KHOẢN THỐNG NHẤT:
--   • MỘT bảng tbl_users duy nhất cho mọi tài khoản.
--   • role = 'admin' : toàn quyền — quản lý mọi package, key, thiết bị,
--     quản lý tài khoản user và đặt giới hạn.
--   • role = 'user'  : tự tạo package + key của riêng mình, bị giới hạn
--     bởi hạn mức (max_packages / max_keys — NULL = dùng mặc định hệ thống).
--   • Đăng nhập chung một nơi: auth/login.php tự nhận vai trò.
--
-- Import file này qua phpMyAdmin là hệ thống chạy được ngay
-- (đã kèm tài khoản admin mặc định + cấu hình giới hạn mặc định).
-- Tài khoản mặc định:  khanhduy  /  khanhduy2010
-- (đổi mật khẩu ngay sau khi đăng nhập lần đầu)
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- V2 (PASS 2): 5 bảng mới cho session/nonce/security/audit/rate
DROP TABLE IF EXISTS tbl_sessions;
DROP TABLE IF EXISTS tbl_nonces;
DROP TABLE IF EXISTS tbl_security_events;
DROP TABLE IF EXISTS tbl_audit_logs;
DROP TABLE IF EXISTS tbl_rate_limits;
DROP TABLE IF EXISTS tbl_device_history;
DROP TABLE IF EXISTS tbl_tokens;
DROP TABLE IF EXISTS tbl_projects;
DROP TABLE IF EXISTS tbl_settings;
DROP TABLE IF EXISTS tbl_users;

CREATE TABLE tbl_users (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username      VARCHAR(50)  NOT NULL,
    email         VARCHAR(190) NULL DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM ('admin', 'user') NOT NULL DEFAULT 'user',
    is_active     TINYINT(1)   NOT NULL DEFAULT 1,
    max_packages  INT UNSIGNED NULL DEFAULT NULL,
    max_keys      INT UNSIGNED NULL DEFAULT NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at DATETIME     NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_username (username),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role (role),
    KEY idx_users_active (is_active)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2) Bảng CẤU HÌNH HỆ THỐNG (key-value)
--    default_max_packages ... hạn mức package mặc định cho user mới
--    default_max_keys ....... hạn mức key mặc định cho user mới
--    allow_registration ..... 1 = cho phép tự đăng ký, 0 = chỉ admin tạo
-- ---------------------------------------------------------------------
CREATE TABLE tbl_settings (
    setting_key   VARCHAR(64)  NOT NULL,
    setting_value VARCHAR(255) NOT NULL DEFAULT '',
    PRIMARY KEY (setting_key)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3) Bảng PACKAGE (project). project_token do CSPRNG sinh (32 hex).
--    owner_id = người tạo package (NULL = package cũ trước khi nâng cấp).
--    Xóa user → toàn bộ package user đó tạo (kèm key + thiết bị) bị xóa theo.
-- ---------------------------------------------------------------------
CREATE TABLE tbl_projects (
    id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name           VARCHAR(120) NOT NULL,
    project_token  VARCHAR(64)  NOT NULL,
    contact_link   VARCHAR(255) NOT NULL DEFAULT '',
    is_maintenance TINYINT(1)   NOT NULL DEFAULT 0,
    owner_id       INT UNSIGNED NULL DEFAULT NULL,
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_projects_token (project_token),
    KEY idx_projects_maintenance (is_maintenance),
    KEY idx_projects_owner (owner_id),
    CONSTRAINT fk_projects_owner
        FOREIGN KEY (owner_id) REFERENCES tbl_users (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 4) Bảng KEY (license).
--    type = 'static'  : expire_date cố định, đặt ngay khi tạo.
--    type = 'dynamic' : expire_date NULL đến lần kích hoạt đầu tiên,
--                       khi đó server ghi expire_date = now + duration.
--    user_id = NGƯỜI TẠO KEY (chủ key). Admin tạo key nào thì key đó
--    thuộc admin; user tạo key trong package của mình thì thuộc user đó.
-- ---------------------------------------------------------------------
CREATE TABLE tbl_tokens (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_id  INT UNSIGNED NOT NULL,
    token_code  VARCHAR(32)  NOT NULL,
    type        ENUM ('static', 'dynamic') NOT NULL DEFAULT 'dynamic',
    duration    INT UNSIGNED NOT NULL DEFAULT 0,
    expire_date DATETIME     NULL,
    max_devices INT UNSIGNED NOT NULL DEFAULT 1,
    status      ENUM ('active', 'suspended', 'revoked') NOT NULL DEFAULT 'active',
    user_id     INT UNSIGNED NULL DEFAULT NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tokens_code (token_code),
    KEY idx_tokens_project (project_id),
    KEY idx_tokens_expire (expire_date),
    KEY idx_tokens_status (status),
    KEY idx_tokens_user (user_id),
    CONSTRAINT fk_tokens_project
        FOREIGN KEY (project_id) REFERENCES tbl_projects (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_tokens_user
        FOREIGN KEY (user_id) REFERENCES tbl_users (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 5) Bảng THIẾT BỊ đã dùng key. UNIQUE (token_id, device_uuid) chống
--    trùng lặp thiết bị và chống race condition khi kích hoạt.
-- ---------------------------------------------------------------------
CREATE TABLE tbl_device_history (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    token_id    INT UNSIGNED NOT NULL,
    device_uuid VARCHAR(64)  NOT NULL,
    first_used  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen   DATETIME     NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_devices_token_uuid (token_id, device_uuid),
    KEY idx_devices_uuid (device_uuid),
    CONSTRAINT fk_devices_token
        FOREIGN KEY (token_id) REFERENCES tbl_tokens (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 6) SESSION / LEASE (V2 — PASS 2). Cấp sau khi key + device được xác
--    thực đầy đủ trong transaction. session_secret chỉ server và client
--    chủ session biết — khóa HMAC (NaCl crypto_auth) cho check/renew/revoke.
--    Một thiết bị giữ đúng 1 session active của một key.
-- ---------------------------------------------------------------------
CREATE TABLE tbl_sessions (
    session_id     CHAR(64)     NOT NULL,
    key_id         INT UNSIGNED NOT NULL,
    device_id      INT UNSIGNED NOT NULL,
    user_id        INT UNSIGNED NULL DEFAULT NULL,
    session_secret CHAR(64)     NOT NULL,
    issued_at      DATETIME     NOT NULL,
    last_seen      DATETIME     NOT NULL,
    expires_at     DATETIME     NOT NULL,
    status         ENUM ('active', 'expired', 'revoked') NOT NULL DEFAULT 'active',
    ip             VARCHAR(45)  NULL,
    PRIMARY KEY (session_id),
    KEY idx_sessions_key (key_id),
    KEY idx_sessions_device (device_id),
    KEY idx_sessions_expires (expires_at),
    CONSTRAINT fk_sessions_key
        FOREIGN KEY (key_id) REFERENCES tbl_tokens (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sessions_device
        FOREIGN KEY (device_id) REFERENCES tbl_device_history (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 7) NONCE đã dùng (V2) — chống replay. Lưu SHA-256 của nonce.
--    scope: 'hello' (init) | 'challenge' (server sinh) | 'request'.
-- ---------------------------------------------------------------------
CREATE TABLE tbl_nonces (
    nonce_hash CHAR(64) NOT NULL,
    scope      ENUM ('hello', 'challenge', 'request') NOT NULL,
    session_id CHAR(64) NULL,
    created_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    PRIMARY KEY (nonce_hash),
    KEY idx_nonces_expiry (expires_at)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 8) SỰ KIỆN BẢO MẬT (V2) — hiển thị ở trang admin Security.
-- ---------------------------------------------------------------------
CREATE TABLE tbl_security_events (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    event      VARCHAR(50)  NOT NULL,
    severity   ENUM ('info', 'warning', 'critical') NOT NULL DEFAULT 'info',
    ip         VARCHAR(45)  NULL,
    key_id     INT UNSIGNED NULL,
    device_id  INT UNSIGNED NULL,
    details    VARCHAR(500) NULL,
    created_at DATETIME     NOT NULL,
    PRIMARY KEY (id),
    KEY idx_sec_event (event),
    KEY idx_sec_created (created_at),
    KEY idx_sec_severity (severity)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 9) AUDIT LOG (V2) — hành vi quản trị, hiển thị ở trang admin Audit.
--    Tầng lib/Audit.php đã che key/session — không bí mật nào được ghi.
-- ---------------------------------------------------------------------
CREATE TABLE tbl_audit_logs (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    event        VARCHAR(50)  NOT NULL,
    actor_type   ENUM ('admin', 'user', 'system', 'api') NOT NULL,
    actor_id     INT UNSIGNED NULL,
    target_type  VARCHAR(20)  NULL,
    target_label VARCHAR(120) NULL,
    details      VARCHAR(500) NULL,
    ip           VARCHAR(45)  NULL,
    created_at   DATETIME     NOT NULL,
    PRIMARY KEY (id),
    KEY idx_audit_event (event),
    KEY idx_audit_created (created_at),
    KEY idx_audit_actor (actor_type, actor_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 10) RATE LIMIT (V2) — fixed window. bucket = "endpoint:định danh".
-- ---------------------------------------------------------------------
CREATE TABLE tbl_rate_limits (
    bucket       VARCHAR(80)  NOT NULL,
    window_start INT UNSIGNED NOT NULL,
    hits         INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (bucket),
    KEY idx_rl_window (window_start)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- DỮ LIỆU KHỞI TẠO
-- =====================================================================

-- Tài khoản ADMIN mặc định:  khanhduy / khanhduy2010  (bcrypt hash)
-- Không giới hạn gì cả (NULL = không áp hạn mức, admin không bị giới hạn).
INSERT INTO tbl_users (username, email, password_hash, role, is_active, max_packages, max_keys)
VALUES ('khanhduy', NULL, '$2y$12$rvfAzXhdz3eqDVHcH7evr.MOqTLHplBhHk3YtybNTlARD2u71nTU6', 'admin', 1, NULL, NULL);

-- Cấu hình giới hạn mặc định cho user thường + mở đăng ký
INSERT INTO tbl_settings (setting_key, setting_value) VALUES
    ('default_max_packages', '3'),
    ('default_max_keys',     '10'),
    ('allow_registration',   '1'),
    ('session_lease_seconds',     '600'),
    ('request_max_drift_seconds', '300'),
    ('challenge_ttl_seconds',     '600'),
    ('rl_auth_key_max',           '20'),
    ('rl_login_max',              '8'),
    ('rl_register_max',           '5'),
    ('security_block_vpn',        '1'),
    ('security_block_debug',      '1'),
    ('security_block_tamper',     '1'),
    ('security_require_report',   '0');

-- =====================================================================
-- GHI CHÚ PHIÊN BẢN / NÂNG CẤP:
--   • Nếu cài mới: import file này (hoặc chạy install.php — schema + seed
--     giống hệt) là xong.
--   • Nếu đang chạy bản cũ (có bảng admins riêng, user chỉ kích hoạt key):
--     KHÔNG import file này (sẽ mất dữ liệu cũ) — upload code mới rồi mở
--     upgrade.php một lần để chuyển dữ liệu sang schema mới.
--   • Admin không bị giới hạn hạn mức. User bị giới hạn bởi
--     max_packages / max_keys của riêng mình, nếu NULL thì lấy
--     default_max_packages / default_max_keys trong tbl_settings.
-- =====================================================================
