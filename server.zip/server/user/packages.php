<?php
/**
 * PACKAGES CỦA TÔI (user): tự tạo / sửa / xóa package trong HẠN MỨC
 * do admin đặt (max_packages riêng hoặc mặc định hệ thống).
 * Package Token sinh bằng CSPRNG. Mỗi user chỉ thấy package của mình.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../lib/Audit.php';

require_login();

$me     = current_user();
$myId   = (int) $me['id'];
$limits = effective_limits($me);

/* ------------------------------ Actions ------------------------------ */

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name    = trim((string) ($_POST['name'] ?? ''));
        $contact = normalize_url((string) ($_POST['contact'] ?? ''));

        try {
            $quotaError = check_package_quota($me);
            if ($quotaError !== null) {
                set_flash($quotaError, 'danger');
            } elseif ($name === '' || mb_strlen($name) > 120) {
                set_flash('Tên package không hợp lệ (1–120 ký tự).', 'danger');
            } elseif ($contact !== '' && !filter_var($contact, FILTER_VALIDATE_URL)) {
                set_flash('Link liên hệ phải là URL hợp lệ (VD: https://t.me/...).', 'danger');
            } else {
                db_query(
                    'INSERT INTO tbl_projects (name, project_token, contact_link, owner_id) VALUES (?, ?, ?, ?)',
                    [$name, generate_secure_token(16), $contact, $myId]
                );
                set_flash('Đã tạo package "' . $name . '".', 'success');
                audit_log('package.created', 'user', (int) current_user()['id'], 'package', $name, []);
            }
        } catch (Throwable $e) {
            set_flash('Không tạo được package — lỗi hệ thống.', 'danger');
        }
        redirect('packages.php');
    }

    if ($action === 'edit') {
        $id      = (int) ($_POST['id'] ?? 0);
        $name    = trim((string) ($_POST['name'] ?? ''));
        $contact = normalize_url((string) ($_POST['contact'] ?? ''));

        try {
            /* Chỉ được sửa package CỦA MÌNH */
            $own = db_query('SELECT id FROM tbl_projects WHERE id = ? AND owner_id = ?', [$id, $myId])->fetchColumn();
            if ($own === false) {
                set_flash('Package không tồn tại hoặc không phải của bạn.', 'danger');
            } elseif ($name === '' || mb_strlen($name) > 120) {
                set_flash('Tên package không hợp lệ (1–120 ký tự).', 'danger');
            } elseif ($contact !== '' && !filter_var($contact, FILTER_VALIDATE_URL)) {
                set_flash('Link liên hệ phải là URL hợp lệ.', 'danger');
            } else {
                db_query('UPDATE tbl_projects SET name = ?, contact_link = ? WHERE id = ? AND owner_id = ?', [$name, $contact, $id, $myId]);
                set_flash('Đã cập nhật package.', 'success');
                audit_log('package.updated', 'user', (int) current_user()['id'], 'package', $name, []);
            }
        } catch (Throwable $e) {
            set_flash('Không cập nhật được package — lỗi hệ thống.', 'danger');
        }
        redirect('packages.php');
    }

    if ($action === 'toggle_maintenance') {
        $id = (int) ($_POST['id'] ?? 0);
        try {
            $res = db_query(
                'UPDATE tbl_projects SET is_maintenance = 1 - is_maintenance WHERE id = ? AND owner_id = ?',
                [$id, $myId]
            );
            set_flash($res->rowCount() > 0 ? 'Đã chuyển trạng thái maintenance.' : 'Không tìm thấy package.', $res->rowCount() > 0 ? 'success' : 'danger');
        } catch (Throwable $e) {
            set_flash('Không chuyển được trạng thái — lỗi hệ thống.', 'danger');
        }
        redirect('packages.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        try {
            $res = db_query('DELETE FROM tbl_projects WHERE id = ? AND owner_id = ?', [$id, $myId]);
            set_flash($res->rowCount() > 0 ? 'Đã xóa package (kèm key + thiết bị).' : 'Không tìm thấy package.', $res->rowCount() > 0 ? 'success' : 'danger');
            if ($res->rowCount() > 0) {
                audit_log('package.deleted', 'user', (int) current_user()['id'], 'package', '#' . $id, []);
            }
        } catch (Throwable $e) {
            set_flash('Không xóa được package — lỗi hệ thống.', 'danger');
        }
        redirect('packages.php');
    }

    http_response_code(400);
    exit('Unknown action');
}

/* ------------------------------- List -------------------------------- */

$packages = db_query(
    'SELECT p.id, p.name, p.project_token, p.contact_link, p.is_maintenance, p.created_at,
            (SELECT COUNT(*) FROM tbl_tokens t WHERE t.project_id = p.id) AS key_count
     FROM tbl_projects p
     WHERE p.owner_id = ?
     ORDER BY p.id DESC',
    [$myId]
)->fetchAll();

$quotaFull = $limits !== null && count($packages) >= $limits['max_packages'];

layout_header('Packages của tôi', 'packages', 'user');
?>
<div class="page-toolbar">
    <div class="quota-inline">
        <?php echo icon('package', 15); ?>
        <span><?= limit_label(count($packages), $limits !== null ? $limits['max_packages'] : null) ?> package</span>
        <?php if ($quotaFull): ?>
        <span class="badge badge-warning">Đã đạt giới hạn</span>
        <?php endif; ?>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="createPackageModal"<?= $quotaFull ? ' disabled title="Đã đạt giới hạn package"' : '' ?>>
        <?php echo icon('plus', 16); ?> Tạo Package
    </button>
</div>

<div class="card">
    <?php if (!$packages): ?>
    <div class="empty-state">
        <?php echo icon('package', 36); ?>
        <p><?php if ($quotaFull && $limits !== null && $limits['max_packages'] === 0): ?>Tài khoản của bạn không được phép tạo package. Liên hệ quản trị viên.<?php else: ?>Bạn chưa có package nào. Tạo package để bắt đầu tạo key.<?php endif; ?></p>
        <?php if (!$quotaFull || ($limits !== null && $limits['max_packages'] > 0 && count($packages) < $limits['max_packages'])): ?>
        <button type="button" class="btn btn-primary btn-sm" data-modal-open="createPackageModal">Tạo Package đầu tiên</button>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Package Name</th><th>Package Token</th><th>Contact</th>
                    <th>Keys</th><th>Maintenance</th><th>Created At</th><th class="th-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($packages as $row): ?>
                <tr>
                    <td class="cell-strong"><?= e($row['name']) ?></td>
                    <td>
                        <div class="key-cell">
                            <code class="code-box token-box" data-masked="<?= e(substr($row['project_token'], 0, 6) . '••••••••••••••••' . substr($row['project_token'], -4)) ?>" data-full="<?= e($row['project_token']) ?>"><?= e(substr($row['project_token'], 0, 6) . '••••••••••••••••' . substr($row['project_token'], -4)) ?></code>
                            <button type="button" class="icon-btn icon-btn-xs" data-toggle-mask title="Hiện/ẩn token">
                                <?php echo icon('eye', 13); ?>
                            </button>
                            <button type="button" class="icon-btn icon-btn-xs" data-copy="<?= e($row['project_token']) ?>" title="Copy">
                                <?php echo icon('copy', 13); ?>
                            </button>
                        </div>
                    </td>
                    <td>
                        <?php if ($row['contact_link'] !== ''): ?>
                        <a class="table-link" href="<?= e($row['contact_link']) ?>" target="_blank" rel="noopener noreferrer">
                            <?php echo icon('external', 13); ?> Liên hệ
                        </a>
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="device-count"><?= (int) $row['key_count'] ?></span></td>
                    <td>
                        <?php if ((int) $row['is_maintenance'] === 1): ?>
                        <span class="badge badge-warning"><?php echo icon('maintenance', 12); ?> ON</span>
                        <?php else: ?>
                        <span class="badge badge-success">OFF</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    <td class="td-actions">
                        <form method="post" class="inline-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="toggle_maintenance">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="btn btn-ghost btn-sm" title="Bật/tắt bảo trì (tạm dừng mọi client của package này)">
                                <?php echo icon('maintenance', 14); ?>
                            </button>
                        </form>
                        <button type="button" class="icon-btn" data-edit-package="<?= e(json_encode([
                            'id'      => (int) $row['id'],
                            'name'    => $row['name'],
                            'contact' => $row['contact_link'],
                        ])) ?>" title="Sửa">
                            <?php echo icon('edit', 15); ?>
                        </button>
                        <form method="post" class="inline-form" data-confirm="Xóa package &quot;<?= e($row['name']) ?>&quot;? Toàn bộ key và thiết bị của package này sẽ bị xóa theo.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn icon-btn-danger" title="Xóa">
                                <?php echo icon('trash', 15); ?>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<div class="modal-backdrop" id="createPackageModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="createPackageTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="createPackageTitle"><?php echo icon('package', 18); ?> Tạo Package mới</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label class="form-label">Package Name</label>
                <input type="text" name="name" class="form-control" maxlength="120" placeholder="VD: My iOS App" required>
            </div>
            <div class="form-group">
                <label class="form-label">Contact (URL hỗ trợ, không bắt buộc)</label>
                <input type="text" name="contact" class="form-control" placeholder="t.me/... hoặc https://..." inputmode="url">
                <p class="form-hint">Có thể nhập thiếu https:// — hệ thống tự thêm.</p>
            </div>
            <p class="form-hint">Package Token được sinh tự động bằng bộ sinh ngẫu nhiên an toàn — dùng nó trong client để gọi API.</p>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary"><?php echo icon('plus', 15); ?> Tạo Package</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-backdrop" id="editPackageModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="editPackageTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="editPackageTitle"><?php echo icon('edit', 18); ?> Sửa Package</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="epId">
            <div class="form-group">
                <label class="form-label">Package Name</label>
                <input type="text" name="name" id="epName" class="form-control" maxlength="120" required>
            </div>
            <div class="form-group">
                <label class="form-label">Contact</label>
                <input type="text" name="contact" id="epContact" class="form-control" placeholder="t.me/... hoặc https://..." inputmode="url">
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
            </div>
        </form>
    </div>
</div>
<?php layout_footer(['packages.js']); ?>
