<?php
/**
 * Đăng ký tài khoản USER THƯỜNG (role = 'user').
 * Tài khoản đăng ký tự nhiên không bao giờ là admin — admin chỉ được
 * tạo bởi install/seed hoặc trong trang Users của admin.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/icons.php';
require_once __DIR__ . '/../lib/Audit.php';
require_once __DIR__ . '/../lib/RateLimit.php';

if (is_logged_in()) {
    redirect(dashboard_url_for(current_role()));
}

$registrationOpen = get_setting('allow_registration', '1') === '1';
$error            = '';

if (!$registrationOpen) {
    /* Không cho POST khi đăng ký đã bị tắt */
} elseif (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Phiên làm việc hết hạn. Thử lại.';
    } elseif (!rl_allow('reg:' . (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), max(1, (int) get_setting('rl_register_max', '5')), 3600)) {
        /* V2: rate limit đăng ký theo IP (fail-open khi DB lỗi) */
        security_event('ratelimit.triggered', 'warning', ['details' => 'register bucket']);
        $error = 'Quá nhiều lần đăng ký từ máy của bạn — thử lại sau.';
    } else {
        $result = register_user(
            (string) ($_POST['username'] ?? ''),
            (string) ($_POST['email'] ?? ''),
            (string) ($_POST['password'] ?? ''),
            (string) ($_POST['confirm_password'] ?? '')
        );

        if ($result['ok']) {
            audit_log('user.registered', 'system', null, 'user', (string) ($_POST['username'] ?? ''), []);
            /* Đăng nhập luôn sau khi đăng ký thành công */
            attempt_login((string) ($_POST['username'] ?? ''), (string) ($_POST['password'] ?? ''));
            redirect(dashboard_url_for(current_role()));
        }
        $error = $result['error'] ?? 'Không đăng ký được tài khoản.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Đăng ký — API Panel</title>
<link rel="stylesheet" href="../assets/css/app.css">
<link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body class="auth-body">
<div class="auth-wrap">
    <div class="auth-card">
        <div class="auth-brand">
            <span class="brand-mark brand-mark-lg"><?php echo icon('shield', 24); ?></span>
            <span class="brand-text-lg">API<span class="brand-accent">Panel</span></span>
        </div>

        <h1 class="auth-title">Tạo tài khoản</h1>

        <?php if (!$registrationOpen): ?>
        <p class="auth-sub">Đăng ký tài khoản mới hiện đang bị tắt.</p>
        <div class="notice notice-warning">
            <?php echo icon('lock', 18); ?>
            <div>Quản trị viên đã đóng đăng ký. Nếu cần tài khoản, hãy liên hệ admin để được tạo trực tiếp.</div>
        </div>
        <a class="btn btn-secondary btn-block" href="login.php"><?php echo icon('shield', 15); ?> Về trang đăng nhập</a>
        <?php else: ?>
        <p class="auth-sub">Đăng ký để tự tạo package và key của riêng bạn — trong hạn mức do quản trị viên đặt.</p>

        <?php if ($error !== ''): ?>
        <div class="notice notice-danger">
            <?php echo icon('warning', 18); ?>
            <div><?= e($error) ?></div>
        </div>
        <?php endif; ?>

        <form method="post" class="auth-form" autocomplete="off">
            <?= csrf_field() ?>
            <div class="form-group">
                <label class="form-label" for="username">Tên đăng nhập</label>
                <input type="text" class="form-control" id="username" name="username"
                       value="<?= e($_POST['username'] ?? '') ?>"
                       minlength="3" maxlength="50" pattern="[A-Za-z0-9_.\-]+"
                       placeholder="VD: nguyenvan_a" required autofocus>
                <p class="form-hint">3–50 ký tự: chữ, số, dấu chấm, gạch dưới, gạch ngang.</p>
            </div>
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email"
                       value="<?= e($_POST['email'] ?? '') ?>"
                       maxlength="190" placeholder="ban@example.com" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Mật khẩu</label>
                <input type="password" class="form-control" id="password" name="password"
                       minlength="8" required>
                <p class="form-hint">Ít nhất 8 ký tự.</p>
            </div>
            <div class="form-group">
                <label class="form-label" for="confirm_password">Xác nhận mật khẩu</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                       minlength="8" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Đăng ký</button>
        </form>

        <div class="auth-switch">
            <span>Đã có tài khoản?</span>
            <a href="login.php">Đăng nhập</a>
        </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
