<?php
/**
 * Đăng xuất — chỉ chấp nhận POST kèm CSRF token.
 * Một phiên một tài khoản nên không cần phân vai: phá sạch session.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../lib/Audit.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $me = current_user();
    if ($me !== null) {
        audit_log(
            ($me['role'] ?? 'user') === 'admin' ? 'admin.logout' : 'user.logout',
            (string) ($me['role'] ?? 'user'),
            (int) $me['id'],
            'user',
            (string) $me['username'],
            []
        );
    }
    logout_current();
}

redirect('../auth/login.php');
