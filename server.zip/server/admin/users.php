<?php
/**
 * QUẢN LÝ TÀI KHOẢN (chỉ admin):
 *   - Xem danh sách mọi tài khoản + mức độ sử dụng hạn mức
 *   - Tạo tài khoản mới (chọn role + hạn mức riêng)
 *   - Sửa: username, email, role, hạn mức, đặt lại mật khẩu
 *   - Khóa / mở khóa, xóa (kèm toàn bộ package + key user đó tạo)
 *
 * An toàn: không thể tự khóa / tự xóa / tự hạ role của chính mình.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../lib/Audit.php';

require_admin();

$selfId = (int) ($_SESSION['user_id'] ?? 0);

/* ------------------------------ Actions ------------------------------ */

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $username    = trim((string) ($_POST['username'] ?? ''));
        $email       = trim((string) ($_POST['email'] ?? ''));
        $password    = (string) ($_POST['password'] ?? '');
        $role        = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        $maxPackages = parse_limit($_POST['max_packages'] ?? '');
        $maxKeys     = parse_limit($_POST['max_keys'] ?? '');

        try {
            if ($username === '' || mb_strlen($username) < 3 || mb_strlen($username) > 50
                || !preg_match('/^[A-Za-z0-9_.-]+$/', $username)) {
                set_flash('Tên đăng nhập không hợp lệ (3–50 ký tự: chữ, số, . _ -).', 'danger');
            } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                set_flash('Email không hợp lệ.', 'danger');
            } elseif (strlen($password) < 8) {
                set_flash('Mật khẩu phải có ít nhất 8 ký tự.', 'danger');
            } elseif ($role === 'user' && $maxPackages !== null && $maxPackages === 0 && $maxKeys !== null && $maxKeys === 0) {
                set_flash('Hạn mức 0 package và 0 key nghĩa là user không được tạo gì — hãy đặt ít nhất một giá trị > 0.', 'danger');
            } else {
                $dup = db_query(
                    'SELECT 1 FROM tbl_users WHERE username = ? OR (? <> \'\' AND email = ?) LIMIT 1',
                    [$username, $email, $email]
                )->fetchColumn();
                if ($dup !== false) {
                    set_flash('Tên đăng nhập hoặc email đã tồn tại.', 'danger');
                } else {
                    db_query(
                        'INSERT INTO tbl_users (username, email, password_hash, role, max_packages, max_keys)
                         VALUES (?, ?, ?, ?, ?, ?)',
                        [$username, $email !== '' ? $email : null, password_hash($password, PASSWORD_DEFAULT), $role, $maxPackages, $maxKeys]
                    );
                    set_flash('Đã tạo tài khoản "' . $username . '" (' . $role . ').', 'success');
                audit_log('user.created', 'admin', (int) $me['id'], 'user', $username, ['role' => $role]);
                }
            }
        } catch (Throwable $e) {
            set_flash('Không tạo được tài khoản — lỗi hệ thống.', 'danger');
        }
        redirect('users.php');
    }

    if ($action === 'edit') {
        $id          = (int) ($_POST['id'] ?? 0);
        $username    = trim((string) ($_POST['username'] ?? ''));
        $email       = trim((string) ($_POST['email'] ?? ''));
        $newPassword = (string) ($_POST['new_password'] ?? '');
        $maxPackages = parse_limit($_POST['max_packages'] ?? '');
        $maxKeys     = parse_limit($_POST['max_keys'] ?? '');

        try {
            $target = db_query('SELECT id, role FROM tbl_users WHERE id = ?', [$id])->fetch();
            if ($target === false) {
                set_flash('Tài khoản không tồn tại.', 'danger');
            } else {
                $role = ($_POST['role'] ?? $target['role']) === 'admin' ? 'admin' : 'user';

                /* Không cho tự hạ role của chính mình */
                if ($id === $selfId && $role !== 'admin') {
                    set_flash('Không thể tự hạ vai trò của chính mình xuống user.', 'danger');
                } elseif ($username === '' || mb_strlen($username) < 3 || mb_strlen($username) > 50
                    || !preg_match('/^[A-Za-z0-9_.-]+$/', $username)) {
                    set_flash('Tên đăng nhập không hợp lệ (3–50 ký tự: chữ, số, . _ -).', 'danger');
                } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    set_flash('Email không hợp lệ.', 'danger');
                } elseif ($newPassword !== '' && strlen($newPassword) < 8) {
                    set_flash('Mật khẩu mới phải có ít nhất 8 ký tự.', 'danger');
                } else {
                    $dup = db_query(
                        'SELECT 1 FROM tbl_users WHERE (username = ? OR (? <> \'\' AND email = ?)) AND id <> ? LIMIT 1',
                        [$username, $email, $email, $id]
                    )->fetchColumn();
                    if ($dup !== false) {
                        set_flash('Tên đăng nhập hoặc email đã được tài khoản khác dùng.', 'danger');
                    } else {
                        db_query(
                            'UPDATE tbl_users SET username = ?, email = ?, role = ?, max_packages = ?, max_keys = ? WHERE id = ?',
                            [$username, $email !== '' ? $email : null, $role, $maxPackages, $maxKeys, $id]
                        );
                        if ($newPassword !== '') {
                            db_query(
                                'UPDATE tbl_users SET password_hash = ? WHERE id = ?',
                                [password_hash($newPassword, PASSWORD_DEFAULT), $id]
                            );
                        }
                        set_flash('Đã cập nhật tài khoản "' . $username . '"' . ($newPassword !== '' ? ' + mật khẩu mới.' : '.'), 'success');
                        audit_log('user.updated', 'admin', (int) $me['id'], 'user', $username, $newPassword !== '' ? ['password_reset' => '1', 'role' => $role] : ['role' => $role]);
                    }
                }
            }
        } catch (Throwable $e) {
            set_flash('Không cập nhật được tài khoản — lỗi hệ thống.', 'danger');
        }
        redirect('users.php');
    }

    if ($action === 'toggle_active') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id === $selfId) {
            set_flash('Không thể tự khóa chính mình.', 'danger');
        } else {
            try {
                db_query('UPDATE tbl_users SET is_active = 1 - is_active WHERE id = ?', [$id]);
                set_flash('Đã chuyển trạng thái tài khoản.', 'success');
                $newState = db_query('SELECT is_active FROM tbl_users WHERE id = ?', [$id])->fetchColumn();
                audit_log(((int) $newState === 1) ? 'user.unbanned' : 'user.banned', 'admin', (int) $me['id'], 'user', '#' . $id, []);
            } catch (Throwable $e) {
                set_flash('Không chuyển được trạng thái — lỗi hệ thống.', 'danger');
            }
        }
        redirect('users.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id === $selfId) {
            set_flash('Không thể tự xóa chính mình.', 'danger');
        } else {
            try {
                /* Xóa user → package + key + thiết bị user đó tạo bị xóa theo (FK CASCADE) */
                db_query('DELETE FROM tbl_users WHERE id = ?', [$id]);
                set_flash('Đã xóa tài khoản cùng toàn bộ package/key user đó tạo.', 'success');
                audit_log('user.deleted', 'admin', (int) $me['id'], 'user', '#' . $id, []);
            } catch (Throwable $e) {
                set_flash('Không xóa được tài khoản — lỗi hệ thống.', 'danger');
            }
        }
        redirect('users.php');
    }

    http_response_code(400);
    exit('Unknown action');
}

/**
 * Parse hạn mức từ form: rỗng = NULL (dùng mặc định), 0 = chặn hết.
 */
function parse_limit(string $raw): ?int
{
    $raw = trim($raw);
    if ($raw === '') {
        return null;
    }
    $val = (int) $raw;
    return ($val < 0) ? 0 : min(1000000, $val);
}

/* ------------------------------- List -------------------------------- */

$q     = trim((string) ($_GET['q'] ?? ''));
$role  = in_array($_GET['role'] ?? '', ['admin', 'user'], true) ? $_GET['role'] : '';
$status = in_array($_GET['status'] ?? '', ['active', 'banned'], true) ? $_GET['status'] : '';

$where  = [];
$params = [];
if ($q !== '') {
    $where[]  = '(u.username LIKE ? OR u.email LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}
if ($role !== '') {
    $where[]  = 'u.role = ?';
    $params[] = $role;
}
if ($status === 'active') {
    $where[] = 'u.is_active = 1';
} elseif ($status === 'banned') {
    $where[] = 'u.is_active = 0';
}

$defaults = get_default_limits();

$users = [];
$schemaError = false;
try {
    $users = db_query(
        'SELECT u.id, u.username, u.email, u.role, u.is_active, u.max_packages, u.max_keys,
                u.created_at, u.last_login_at,
                COALESCE(p.package_count, 0) AS package_count,
                COALESCE(k.key_count, 0) AS key_count
         FROM tbl_users u
         LEFT JOIN (SELECT owner_id, COUNT(*) AS package_count FROM tbl_projects WHERE owner_id IS NOT NULL GROUP BY owner_id) p
             ON p.owner_id = u.id
         LEFT JOIN (SELECT user_id, COUNT(*) AS key_count FROM tbl_tokens WHERE user_id IS NOT NULL GROUP BY user_id) k
             ON k.user_id = u.id'
        . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
        . ' ORDER BY u.id ASC',
        $params
    )->fetchAll();
} catch (Throwable $e) {
    $schemaError = true;
}

function limit_cell(int $used, ?int $own, int $default): string
{
    $limit = $own ?? $default;
    $state = $used >= $limit ? ' limit-full' : ($used >= $limit * 0.7 ? ' limit-warn' : '');
    return '<span class="limit-meta' . $state . '">' . $used . ' / ' . $limit . '</span>';
}

layout_header('Users', 'users');
?>
<?php if ($schemaError): ?>
<div class="notice notice-danger">
    <?php echo icon('warning', 18); ?>
    <div>Database chưa có bảng <code>tbl_users</code> đúng schema mới. Mở file <a href="../upgrade.php"><code>upgrade.php</code></a> một lần để nâng cấp (không mất dữ liệu), rồi quay lại trang này.</div>
</div>
<?php endif; ?>

<div class="page-toolbar">
    <form class="filter-bar" method="get">
        <div class="search-box">
            <?php echo icon('search', 16); ?>
            <input type="text" name="q" class="form-control" placeholder="Tìm user hoặc email..." value="<?= e($q) ?>">
        </div>
        <select name="role" class="form-control form-control-sm">
            <option value="">Mọi vai trò</option>
            <option value="admin"<?= $role === 'admin' ? ' selected' : '' ?>>Admin</option>
            <option value="user"<?= $role === 'user' ? ' selected' : '' ?>>User</option>
        </select>
        <select name="status" class="form-control form-control-sm">
            <option value="">Mọi trạng thái</option>
            <option value="active"<?= $status === 'active' ? ' selected' : '' ?>>Active</option>
            <option value="banned"<?= $status === 'banned' ? ' selected' : '' ?>>Banned</option>
        </select>
        <button type="submit" class="btn btn-secondary btn-sm">Lọc</button>
        <?php if ($q !== '' || $role !== '' || $status !== ''): ?>
        <a href="users.php" class="btn btn-ghost btn-sm">Xóa lọc</a>
        <?php endif; ?>
    </form>
    <button type="button" class="btn btn-primary" data-modal-open="createUserModal">
        <?php echo icon('plus', 16); ?> Tạo tài khoản
    </button>
</div>

<div class="card">
    <?php if (!$users): ?>
    <div class="empty-state">
        <?php echo icon('users', 36); ?>
        <p>Không có tài khoản nào khớp.</p>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Tài khoản</th><th>Vai trò</th><th>Packages</th><th>Keys</th>
                    <th>Trạng thái</th><th>Đăng ký</th><th>Đăng nhập cuối</th><th class="th-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $row): ?>
                <?php $isSelf = (int) $row['id'] === $selfId; ?>
                <tr>
                    <td>
                        <div class="user-cell">
                            <span class="avatar avatar-sm"><?php echo icon('user', 14); ?></span>
                            <span class="cell-strong"><?= e($row['username']) ?><?= $isSelf ? ' <span class="text-muted">(bạn)</span>' : '' ?></span>
                        </div>
                        <?php if (!empty($row['email'])): ?>
                        <div class="text-muted user-email-sub"><?= e($row['email']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($row['role'] === 'admin'): ?>
                        <span class="role-chip role-chip-admin"><?php echo icon('shield', 11); ?> Admin</span>
                        <?php else: ?>
                        <span class="role-chip"><?php echo icon('user', 11); ?> User</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($row['role'] === 'admin'): ?>
                        <span class="text-muted"><?= (int) $row['package_count'] ?> (∞)</span>
                        <?php else: ?>
                        <?= limit_cell((int) $row['package_count'], $row['max_packages'] !== null ? (int) $row['max_packages'] : null, $defaults['max_packages']) ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($row['role'] === 'admin'): ?>
                        <span class="text-muted"><?= (int) $row['key_count'] ?> (∞)</span>
                        <?php else: ?>
                        <?= limit_cell((int) $row['key_count'], $row['max_keys'] !== null ? (int) $row['max_keys'] : null, $defaults['max_keys']) ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ((int) $row['is_active'] === 1): ?>
                        <span class="badge badge-success">Active</span>
                        <?php else: ?>
                        <span class="badge badge-danger">Banned</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    <td class="text-muted"><?= format_datetime($row['last_login_at']) ?></td>
                    <td class="td-actions">
                        <button type="button" class="icon-btn" data-edit-user="<?= e(json_encode([
                            'id'           => (int) $row['id'],
                            'username'     => $row['username'],
                            'email'        => (string) ($row['email'] ?? ''),
                            'role'         => $row['role'],
                            'max_packages' => $row['max_packages'] !== null ? (string) $row['max_packages'] : '',
                            'max_keys'     => $row['max_keys'] !== null ? (string) $row['max_keys'] : '',
                        ])) ?>" title="Sửa tài khoản / hạn mức">
                            <?php echo icon('edit', 15); ?>
                        </button>
                        <?php if (!$isSelf): ?>
                        <form method="post" class="inline-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="toggle_active">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="btn btn-ghost btn-sm" title="<?= (int) $row['is_active'] === 1 ? 'Khóa tài khoản' : 'Mở khóa tài khoản' ?>">
                                <?php echo icon('lock', 14); ?> <?= (int) $row['is_active'] === 1 ? 'Ban' : 'Unban' ?>
                            </button>
                        </form>
                        <form method="post" class="inline-form" data-confirm="Xóa tài khoản &quot;<?= e($row['username']) ?>&quot;? Toàn bộ package, key và thiết bị user này tạo cũng sẽ bị xóa theo.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn icon-btn-danger" title="Xóa">
                                <?php echo icon('trash', 15); ?>
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<div class="modal-backdrop" id="createUserModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="createUserTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="createUserTitle"><?php echo icon('users', 18); ?> Tạo tài khoản mới</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label class="form-label">Tên đăng nhập</label>
                <input type="text" name="username" class="form-control" minlength="3" maxlength="50" pattern="[A-Za-z0-9_.\-]+" placeholder="VD: reseller01" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email (không bắt buộc)</label>
                <input type="email" name="email" class="form-control" maxlength="190" placeholder="user@example.com">
            </div>
            <div class="form-group">
                <label class="form-label">Mật khẩu</label>
                <input type="text" name="password" class="form-control" minlength="8" placeholder="Ít nhất 8 ký tự" required autocomplete="off">
            </div>
            <div class="form-group">
                <label class="form-label">Vai trò</label>
                <select name="role" class="form-control" id="cuRole" required>
                    <option value="user" selected>User — tạo package/key trong hạn mức</option>
                    <option value="admin">Admin — toàn quyền</option>
                </select>
            </div>
            <div class="form-row" id="cuLimits">
                <div class="form-group">
                    <label class="form-label">Max packages</label>
                    <input type="number" name="max_packages" class="form-control" min="0" max="1000000" placeholder="mặc định: <?= $defaults['max_packages'] ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Max keys</label>
                    <input type="number" name="max_keys" class="form-control" min="0" max="1000000" placeholder="mặc định: <?= $defaults['max_keys'] ?>">
                </div>
            </div>
            <p class="form-hint">Để trống hạn mức = dùng mặc định hệ thống (<?= $defaults['max_packages'] ?> package / <?= $defaults['max_keys'] ?> key). Nhập 0 = cấm tạo. Admin không bị giới hạn.</p>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary"><?php echo icon('plus', 15); ?> Tạo tài khoản</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-backdrop" id="editUserModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="editUserTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="editUserTitle"><?php echo icon('edit', 18); ?> Sửa tài khoản</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="euId">
            <div class="form-group">
                <label class="form-label">Tên đăng nhập</label>
                <input type="text" name="username" id="euUsername" class="form-control" minlength="3" maxlength="50" pattern="[A-Za-z0-9_.\-]+" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" id="euEmail" class="form-control" maxlength="190" placeholder="user@example.com">
            </div>
            <div class="form-group">
                <label class="form-label">Vai trò</label>
                <select name="role" id="euRole" class="form-control" required>
                    <option value="user">User — tạo package/key trong hạn mức</option>
                    <option value="admin">Admin — toàn quyền</option>
                </select>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Max packages</label>
                    <input type="number" name="max_packages" id="euMaxPackages" class="form-control" min="0" max="1000000" placeholder="mặc định: <?= $defaults['max_packages'] ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Max keys</label>
                    <input type="number" name="max_keys" id="euMaxKeys" class="form-control" min="0" max="1000000" placeholder="mặc định: <?= $defaults['max_keys'] ?>">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Đặt lại mật khẩu (để trống = giữ nguyên)</label>
                <input type="text" name="new_password" class="form-control" minlength="8" placeholder="Chỉ nhập khi muốn đổi mật khẩu" autocomplete="off">
            </div>
            <p class="form-hint">Hạn mức để trống = mặc định hệ thống. Nhập 0 = cấm tạo. Admin không bị giới hạn.</p>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
            </div>
        </form>
    </div>
</div>
<?php layout_footer(['users.js']); ?>
