<?php
/**
 * Audit Logs (admin) — hành vi quản trị hệ thống (PASS 2 spec mục 16).
 *
 * Ghi lại: đăng nhập/xuất, tạo/sửa/xóa key, package, user, device,
 * thay đổi cấu hình... KHÔNG chứa bí mật (key bị che, không có hash).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../lib/Audit.php';

require_admin();

$range = in_array($_GET['range'] ?? '7d', ['today', '7d', '30d', 'all'], true) ? ($_GET['range'] ?? '7d') : '7d';
$q     = trim((string) ($_GET['q'] ?? ''));

$where  = [];
$params = [];

if ($range === 'today') {
    $where[]  = 'created_at >= ?';
    $params[] = date('Y-m-d 00:00:00');
} elseif ($range === '7d') {
    $where[]  = 'created_at >= ?';
    $params[] = date('Y-m-d H:i:s', time() - 7 * 86400);
} elseif ($range === '30d') {
    $where[]  = 'created_at >= ?';
    $params[] = date('Y-m-d H:i:s', time() - 30 * 86400);
}

if ($q !== '') {
    $where[]  = '(event LIKE ? OR target_label LIKE ? OR details LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}

$sql = 'SELECT event, actor_type, actor_id, target_type, target_label, details, ip, created_at
        FROM tbl_audit_logs'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY id DESC
       LIMIT 300';

$logs = [];
$tableMissing = false;
try {
    $logs = db_query($sql, $params)->fetchAll();
} catch (Throwable $e) {
    $tableMissing = true;
}

function actor_badge(string $type): string
{
    if ($type === 'admin') {
        return '<span class="badge badge-danger">Admin</span>';
    }
    if ($type === 'user') {
        return '<span class="badge badge-info">User</span>';
    }
    if ($type === 'api') {
        return '<span class="badge badge-neutral">API</span>';
    }
    return '<span class="badge badge-neutral">System</span>';
}

function range_link2(string $label, string $value, string $current): string
{
    $cls = 'chip' . ($current === $value ? ' chip-active' : '');
    return '<a class="' . $cls . '" href="audit.php?range=' . $value . '">' . e($label) . '</a>';
}

layout_header('Audit Logs', 'audit');
?>
<div class="page-toolbar">
    <div class="range-tabs">
        <?= range_link2('Hôm nay', 'today', $range) ?>
        <?= range_link2('7 ngày', '7d', $range) ?>
        <?= range_link2('30 ngày', '30d', $range) ?>
        <?= range_link2('Tất cả', 'all', $range) ?>
    </div>
    <form class="filter-bar" method="get">
        <input type="hidden" name="range" value="<?= e($range) ?>">
        <div class="search-box">
            <?php echo icon('search', 16); ?>
            <input type="text" name="q" class="form-control" placeholder="Tìm sự kiện / đối tượng..." value="<?= e($q) ?>">
        </div>
        <button type="submit" class="btn btn-secondary btn-sm">Lọc</button>
    </form>
</div>

<div class="card">
    <?php if ($tableMissing): ?>
    <div class="empty-state">
        <?php echo icon('warning', 36); ?>
        <p>Chưa có bảng audit log. Chạy <code>upgrade.php</code> một lần để nâng cấp database lên schema V2.</p>
    </div>
    <?php elseif (!$logs): ?>
    <div class="empty-state">
        <?php echo icon('database', 36); ?>
        <p>Chưa có bản ghi nào trong khoảng này.</p>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Thời gian</th><th>Sự kiện</th><th>Người thực hiện</th><th>Đối tượng</th><th>Chi tiết</th><th>IP</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($logs as $row): ?>
                <tr>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    <td><span class="ev-name"><?= e(audit_event_label((string) $row['event'])) ?></span><span class="ev-code"><?= e($row['event']) ?></span></td>
                    <td><?= actor_badge((string) $row['actor_type']) ?> <span class="text-muted">#<?= (int) ($row['actor_id'] ?? 0) ?></span></td>
                    <td>
                        <?php if ($row['target_type'] !== null): ?>
                        <span class="badge badge-neutral"><?= e((string) $row['target_type']) ?></span>
                        <?= e((string) ($row['target_label'] ?? '')) ?>
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted ev-details"><?= e((string) ($row['details'] ?? '—')) ?></td>
                    <td class="text-muted"><?= e((string) ($row['ip'] ?? '—')) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php layout_footer(); ?>
