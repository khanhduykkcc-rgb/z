<?php
/**
 * Security (admin) — sự kiện bảo mật hệ thống (PASS 2 spec mục 18).
 *
 * Hiển thị: xác thực thất bại, replay, MAC sai, session hết hạn,
 * vượt giới hạn thiết bị, rate limit... với filter thời gian + severity.
 * Không hiển thị bí mật nào (tầng lib/Audit.php đã che key/session).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../lib/Audit.php';

require_admin();

$range = in_array($_GET['range'] ?? '7d', ['today', '7d', '30d', 'all'], true) ? ($_GET['range'] ?? '7d') : '7d';
$sev   = in_array($_GET['sev'] ?? '', ['info', 'warning', 'critical'], true) ? $_GET['sev'] : '';
$ev    = trim((string) ($_GET['ev'] ?? ''));

$where  = [];
$params = [];

if ($range === 'today') {
    $where[]  = 'created_at >= ?';
    $params[] = date('Y-m-d 00:00:00');
} elseif ($range === '7d') {
    $where[]  = 'created_at >= ?';
    $params[] = date('Y-m-d H:i:s', time() - 7 * 86400);
} elseif ($range === '30d') {
    $where[]  = 'created_at >= ?';
    $params[] = date('Y-m-d H:i:s', time() - 30 * 86400);
}

if ($sev !== '') {
    $where[]  = 'severity = ?';
    $params[] = $sev;
}
if ($ev !== '') {
    $where[]  = 'event LIKE ?';
    $params[] = '%' . $ev . '%';
}

$sql = 'SELECT event, severity, ip, key_id, device_id, details, created_at
        FROM tbl_security_events'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY id DESC
       LIMIT 200';

$events = [];
$tableMissing = false;
try {
    $events = db_query($sql, $params)->fetchAll();
} catch (Throwable $e) {
    $tableMissing = true; /* DB chưa upgrade */
}

/* Thống kê nhanh theo severity trong khoảng đang xem */
$stats = ['critical' => 0, 'warning' => 0, 'info' => 0];
foreach ($events as $row) {
    $stats[(string) $row['severity']] = ($stats[(string) $row['severity']] ?? 0) + 1;
}

function severity_badge(string $sev): string
{
    if ($sev === 'critical') {
        return '<span class="badge badge-danger">Critical</span>';
    }
    if ($sev === 'warning') {
        return '<span class="badge badge-warning">Warning</span>';
    }
    return '<span class="badge badge-neutral">Info</span>';
}

function range_link(string $label, string $value, string $current): string
{
    $cls = 'chip' . ($current === $value ? ' chip-active' : '');
    return '<a class="' . $cls . '" href="security.php?range=' . $value . '">' . e($label) . '</a>';
}

layout_header('Security', 'security');
?>
<div class="page-toolbar">
    <div class="range-tabs">
        <?= range_link('Hôm nay', 'today', $range) ?>
        <?= range_link('7 ngày', '7d', $range) ?>
        <?= range_link('30 ngày', '30d', $range) ?>
        <?= range_link('Tất cả', 'all', $range) ?>
    </div>
    <form class="filter-bar" method="get">
        <input type="hidden" name="range" value="<?= e($range) ?>">
        <select name="sev" class="form-control form-control-sm">
            <option value="">Mọi mức</option>
            <option value="critical"<?= $sev === 'critical' ? ' selected' : '' ?>>Critical</option>
            <option value="warning"<?= $sev === 'warning' ? ' selected' : '' ?>>Warning</option>
            <option value="info"<?= $sev === 'info' ? ' selected' : '' ?>>Info</option>
        </select>
        <div class="search-box">
            <?php echo icon('search', 16); ?>
            <input type="text" name="ev" class="form-control" placeholder="Lọc sự kiện..." value="<?= e($ev) ?>">
        </div>
        <button type="submit" class="btn btn-secondary btn-sm">Lọc</button>
    </form>
</div>

<div class="stat-grid stat-grid-3">
    <div class="stat-card stat-danger">
        <div class="stat-icon"><?php echo icon('warning', 22); ?></div>
        <div class="stat-body">
            <span class="stat-value"><?= (int) $stats['critical'] ?></span>
            <span class="stat-label">Critical</span>
        </div>
    </div>
    <div class="stat-card stat-warning">
        <div class="stat-icon"><?php echo icon('lock', 22); ?></div>
        <div class="stat-body">
            <span class="stat-value"><?= (int) $stats['warning'] ?></span>
            <span class="stat-label">Warning</span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon"><?php echo icon('check', 22); ?></div>
        <div class="stat-body">
            <span class="stat-value"><?= (int) $stats['info'] ?></span>
            <span class="stat-label">Info</span>
        </div>
    </div>
</div>

<div class="card">
    <?php if ($tableMissing): ?>
    <div class="empty-state">
        <?php echo icon('warning', 36); ?>
        <p>Chưa có bảng sự kiện bảo mật. Chạy <code>upgrade.php</code> một lần để nâng cấp database lên schema V2.</p>
    </div>
    <?php elseif (!$events): ?>
    <div class="empty-state">
        <?php echo icon('shield', 36); ?>
        <p>Không có sự kiện bảo mật nào trong khoảng này — hệ thống đang sạch.</p>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Thời gian</th><th>Sự kiện</th><th>Mức</th><th>IP</th><th>Key</th><th>Chi tiết</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($events as $row): ?>
                <tr>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    <td><span class="ev-name"><?= e(security_event_label((string) $row['event'])) ?></span><span class="ev-code"><?= e($row['event']) ?></span></td>
                    <td><?= severity_badge((string) $row['severity']) ?></td>
                    <td class="text-muted"><?= e((string) ($row['ip'] ?? '—')) ?></td>
                    <td class="text-muted"><?= $row['key_id'] !== null ? '#' . (int) $row['key_id'] : '—' ?></td>
                    <td class="text-muted ev-details"><?= e((string) ($row['details'] ?? '—')) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php layout_footer(); ?>
