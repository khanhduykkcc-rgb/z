<?php
/**
 * Quản lý Package (admin): tạo, sửa, xóa, bật/tắt maintenance.
 * Mọi package đều có owner (người tạo). Admin thấy và thao tác TẤT CẢ
 * package của mọi người; user thường chỉ thấy của mình (user/packages.php).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../lib/Audit.php';

require_admin();

$me = current_user();

/* ------------------------------ Actions ------------------------------ */

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name    = trim((string) ($_POST['name'] ?? ''));
        $contact = normalize_url((string) ($_POST['contact'] ?? ''));

        try {
            if ($name === '' || mb_strlen($name) > 120) {
                set_flash('Tên package không hợp lệ (1–120 ký tự).', 'danger');
            } elseif ($contact !== '' && !filter_var($contact, FILTER_VALIDATE_URL)) {
                set_flash('Link liên hệ phải là URL hợp lệ (VD: https://t.me/...).', 'danger');
            } else {
                db_query(
                    'INSERT INTO tbl_projects (name, project_token, contact_link, owner_id) VALUES (?, ?, ?, ?)',
                    [$name, generate_secure_token(16), $contact, (int) $me['id']]
                );
                set_flash('Đã tạo package "' . $name . '".', 'success');
                audit_log('package.created', 'admin', (int) current_user()['id'], 'package', $name, []);
            }
        } catch (Throwable $e) {
            set_flash('Không tạo được package — lỗi hệ thống. Hãy kiểm tra database đã cài đúng schema mới nhất.', 'danger');
        }
        redirect('packages.php');
    }

    if ($action === 'edit') {
        $id      = (int) ($_POST['id'] ?? 0);
        $name    = trim((string) ($_POST['name'] ?? ''));
        $contact = normalize_url((string) ($_POST['contact'] ?? ''));

        try {
            if ($name === '' || mb_strlen($name) > 120) {
                set_flash('Tên package không hợp lệ (1–120 ký tự).', 'danger');
            } elseif ($contact !== '' && !filter_var($contact, FILTER_VALIDATE_URL)) {
                set_flash('Link liên hệ phải là URL hợp lệ (VD: https://t.me/...).', 'danger');
            } else {
                db_query('UPDATE tbl_projects SET name = ?, contact_link = ? WHERE id = ?', [$name, $contact, $id]);
                set_flash('Đã cập nhật package.', 'success');
                audit_log('package.updated', 'admin', (int) current_user()['id'], 'package', $name, []);
            }
        } catch (Throwable $e) {
            set_flash('Không cập nhật được package — lỗi hệ thống.', 'danger');
        }
        redirect('packages.php');
    }

    if ($action === 'toggle_maintenance') {
        try {
            db_query('UPDATE tbl_projects SET is_maintenance = 1 - is_maintenance WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
            set_flash('Đã chuyển trạng thái maintenance.', 'success');
            $maint = db_query('SELECT is_maintenance FROM tbl_projects WHERE id = ?', [(int) ($_POST['id'] ?? 0)])->fetchColumn();
            audit_log(((int) $maint === 1) ? 'package.maintenance_on' : 'package.maintenance_off', 'admin', (int) current_user()['id'], 'package', '#' . (int) ($_POST['id'] ?? 0), []);
        } catch (Throwable $e) {
            set_flash('Không chuyển được trạng thái — lỗi hệ thống.', 'danger');
        }
        redirect('packages.php');
    }

    if ($action === 'delete') {
        try {
            db_query('DELETE FROM tbl_projects WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
            set_flash('Đã xóa package (kèm toàn bộ key và thiết bị liên quan).', 'success');
            audit_log('package.deleted', 'admin', (int) current_user()['id'], 'package', $name ?? '', []);
        } catch (Throwable $e) {
            set_flash('Không xóa được package — lỗi hệ thống.', 'danger');
        }
        redirect('packages.php');
    }

    http_response_code(400);
    exit('Unknown action');
}

/* ------------------------------- List -------------------------------- */

$packages = db_query(
    'SELECT p.id, p.name, p.project_token, p.contact_link, p.is_maintenance, p.created_at,
            u.username AS owner_name,
            (SELECT COUNT(*) FROM tbl_tokens t WHERE t.project_id = p.id) AS key_count
     FROM tbl_projects p
     LEFT JOIN tbl_users u ON u.id = p.owner_id
     ORDER BY p.id DESC'
)->fetchAll();

layout_header('Packages', 'packages');
?>
<div class="page-toolbar">
    <div></div>
    <button type="button" class="btn btn-primary" data-modal-open="createPackageModal">
        <?php echo icon('plus', 16); ?> Tạo Package
    </button>
</div>

<div class="card">
    <?php if (!$packages): ?>
    <div class="empty-state">
        <?php echo icon('package', 36); ?>
        <p>Chưa có package nào. Tạo package để bắt đầu quản lý key.</p>
        <button type="button" class="btn btn-primary btn-sm" data-modal-open="createPackageModal">Tạo Package đầu tiên</button>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Package Name</th><th>Owner</th><th>Package Token</th><th>Contact</th>
                    <th>Keys</th><th>Maintenance</th><th>Created At</th><th class="th-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($packages as $row): ?>
                <tr>
                    <td class="cell-strong"><?= e($row['name']) ?></td>
                    <td>
                        <?php if ($row['owner_name'] !== null): ?>
                        <span class="owner-cell"><?php echo icon('user', 13); ?> <?= e($row['owner_name']) ?></span>
                        <?php else: ?>
                        <span class="text-muted">Hệ thống</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="key-cell">
                            <code class="code-box token-box" data-masked="<?= e(substr($row['project_token'], 0, 6) . '••••••••••••••••' . substr($row['project_token'], -4)) ?>" data-full="<?= e($row['project_token']) ?>"><?= e(substr($row['project_token'], 0, 6) . '••••••••••••••••' . substr($row['project_token'], -4)) ?></code>
                            <button type="button" class="icon-btn icon-btn-xs" data-toggle-mask title="Hiện/ẩn token">
                                <?php echo icon('eye', 13); ?>
                            </button>
                            <button type="button" class="icon-btn icon-btn-xs" data-copy="<?= e($row['project_token']) ?>" title="Copy">
                                <?php echo icon('copy', 13); ?>
                            </button>
                        </div>
                    </td>
                    <td>
                        <?php if ($row['contact_link'] !== ''): ?>
                        <a class="table-link" href="<?= e($row['contact_link']) ?>" target="_blank" rel="noopener noreferrer">
                            <?php echo icon('external', 13); ?> Liên hệ
                        </a>
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="device-count"><?= (int) $row['key_count'] ?></span></td>
                    <td>
                        <?php if ((int) $row['is_maintenance'] === 1): ?>
                        <span class="badge badge-warning"><?php echo icon('maintenance', 12); ?> ON</span>
                        <?php else: ?>
                        <span class="badge badge-success">OFF</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    <td class="td-actions">
                        <form method="post" class="inline-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="toggle_maintenance">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="btn btn-ghost btn-sm" title="Bật/tắt bảo trì">
                                <?php echo icon('maintenance', 14); ?>
                            </button>
                        </form>
                        <button type="button" class="icon-btn" data-edit-package="<?= e(json_encode([
                            'id'      => (int) $row['id'],
                            'name'    => $row['name'],
                            'contact' => $row['contact_link'],
                        ])) ?>" title="Sửa">
                            <?php echo icon('edit', 15); ?>
                        </button>
                        <form method="post" class="inline-form" data-confirm="Xóa package &quot;<?= e($row['name']) ?>&quot;? Toàn bộ key và thiết bị của package này sẽ bị xóa theo.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn icon-btn-danger" title="Xóa">
                                <?php echo icon('trash', 15); ?>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<div class="modal-backdrop" id="createPackageModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="createPackageTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="createPackageTitle"><?php echo icon('package', 18); ?> Tạo Package mới</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label class="form-label">Package Name</label>
                <input type="text" name="name" class="form-control" maxlength="120" placeholder="VD: My iOS App" required>
            </div>
            <div class="form-group">
                <label class="form-label">Contact (URL hỗ trợ, không bắt buộc)</label>
                <input type="text" name="contact" class="form-control" placeholder="t.me/... hoặc https://..." inputmode="url">
                <p class="form-hint">Có thể nhập thiếu https:// — hệ thống tự thêm.</p>
            </div>
            <p class="form-hint">Package Token sẽ được sinh tự động bằng bộ sinh ngẫu nhiên an toàn.</p>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary"><?php echo icon('plus', 15); ?> Tạo Package</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-backdrop" id="editPackageModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="editPackageTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="editPackageTitle"><?php echo icon('edit', 18); ?> Sửa Package</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="epId">
            <div class="form-group">
                <label class="form-label">Package Name</label>
                <input type="text" name="name" id="epName" class="form-control" maxlength="120" required>
            </div>
            <div class="form-group">
                <label class="form-label">Contact</label>
                <input type="text" name="contact" id="epContact" class="form-control" placeholder="t.me/... hoặc https://..." inputmode="url">
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
            </div>
        </form>
    </div>
</div>
<?php layout_footer(['packages.js']); ?>
