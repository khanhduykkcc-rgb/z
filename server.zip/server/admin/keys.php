<?php
/**
 * Quản lý Key (admin): tạo, xóa, tìm kiếm, lọc, xem chi tiết.
 * Static key: hạn cố định. Dynamic key: hạn tính từ lần kích hoạt đầu.
 * Mọi key đều thuộc về người tạo (user_id) — admin thấy và thao tác TẤT CẢ
 * key của mọi người; user thường chỉ thấy của mình (user/keys.php).
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../lib/Audit.php';
require_once __DIR__ . '/../lib/KeyModel.php';
require_once __DIR__ . '/../lib/AuthPipeline.php';

require_admin();

$me = current_user();

/* ------------------------------ Actions ------------------------------ */

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_verify_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $projectId  = (int) ($_POST['project_id'] ?? 0);
        $type       = (($_POST['type'] ?? '') === 'static') ? 'static' : 'dynamic';
        $maxDevices = max(1, min(100, (int) ($_POST['max_devices'] ?? 1)));
        $expireDate = null;
        $duration   = 0;
        $error      = null;

        try {
            $projectExists = db_query('SELECT 1 FROM tbl_projects WHERE id = ?', [$projectId])->fetchColumn();
            if ($projectExists === false) {
                $error = 'Package không tồn tại — hãy tạo package trước khi tạo key.';
            } elseif ($type === 'static') {
                $expireDate = parse_datetime_local((string) ($_POST['expire_date'] ?? ''));
                if ($expireDate === null) {
                    $error = 'Ngày hết hạn không hợp lệ.';
                }
            } else {
                $duration = (int) ($_POST['duration'] ?? 0);
                if ($duration < 1 || $duration > 3650) {
                    $error = 'Số ngày sử dụng phải từ 1 đến 3650.';
                }
            }

            if ($error !== null) {
                set_flash($error, 'danger');
            } else {
                $code = generate_key_code();
                db_query(
                    'INSERT INTO tbl_tokens (project_id, token_code, type, duration, expire_date, max_devices, user_id)
                     VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [$projectId, $code, $type, $duration, $expireDate, $maxDevices, (int) $me['id']]
                );
                audit_log('key.created', 'admin', (int) $me['id'], 'key', mask_key($code), [
                    'type'        => $type,
                    'max_devices' => (string) $maxDevices,
                ]);
                set_flash('Đã tạo key: ' . $code, 'success');
            }
        } catch (Throwable $e) {
            set_flash('Không tạo được key — lỗi hệ thống. Hãy kiểm tra database đã cài đúng schema mới nhất.', 'danger');
        }
        redirect('keys.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        try {
            $row = db_query('SELECT token_code, project_id FROM tbl_tokens WHERE id = ?', [$id])->fetch();
            db_query('DELETE FROM tbl_tokens WHERE id = ?', [$id]);
            if ($row !== false) {
                audit_log('key.deleted', 'admin', (int) $me['id'], 'key', mask_key((string) $row['token_code']), []);
            }
            set_flash('Đã xóa key.', 'success');
        } catch (Throwable $e) {
            set_flash('Không xóa được key — lỗi hệ thống.', 'danger');
        }
        redirect('keys.php');
    }

    /* V2 — vòng đời key do admin kiểm soát */
    if (in_array($action, ['suspend', 'unsuspend', 'revoke'], true)) {
        $id = (int) ($_POST['id'] ?? 0);
        try {
            $row = db_query(
                'SELECT t.token_code, t.status, p.project_token FROM tbl_tokens t
                 JOIN tbl_projects p ON p.id = t.project_id WHERE t.id = ?',
                [$id]
            )->fetch();

            if ($row === false) {
                set_flash('Key không tồn tại.', 'danger');
                redirect('keys.php');
            }

            $newStatus = $action === 'suspend' ? 'suspended'
                : ($action === 'unsuspend' ? 'active' : 'revoked');
            db_query('UPDATE tbl_tokens SET status = ? WHERE id = ?', [$newStatus, $id]);

            /* Thu hồi mọi session đang chạy của key này (server-authoritative) */
            if ($newStatus !== 'active') {
                key_revoke_sessions($id);
            }

            $map = [
                'suspend'   => ['key.suspended', 'Đã tạm ngưng key — mọi phiên đang chạy bị thu hồi.'],
                'unsuspend' => ['key.unsuspended', 'Đã mở khóa key.'],
                'revoke'    => ['key.revoked', 'Đã thu hồi key vĩnh viễn.'],
            ];
            audit_log($map[$action][0], 'admin', (int) $me['id'], 'key', mask_key((string) $row['token_code']), []);
            set_flash($map[$action][1], 'success');
        } catch (Throwable $e) {
            set_flash('Không cập nhật được trạng thái key — lỗi hệ thống.', 'danger');
        }
        redirect('keys.php');
    }

    /* V2 — Key Debugging: chạy pipeline ở chế độ dry-run (không ghi DB) */
    if ($action === 'debug_validate') {
        $id  = (int) ($_POST['id'] ?? 0);
        $dev = trim((string) ($_POST['device_id'] ?? ''));

        try {
            $row = db_query(
                'SELECT t.token_code, p.project_token FROM tbl_tokens t
                 JOIN tbl_projects p ON p.id = t.project_id WHERE t.id = ?',
                [$id]
            )->fetch();

            if ($row === false) {
                json_out(['status' => false, 'message' => 'Key không tồn tại']);
            }

            $result = AuthPipeline::debugValidate(
                (string) $row['token_code'],
                (string) $row['project_token'],
                $dev
            );

            audit_log('key.debug_validated', 'admin', (int) $me['id'], 'key', mask_key((string) $row['token_code']), [
                'ok' => $result['ok'] ? '1' : '0',
            ]);

            json_out([
                'status'  => true,
                'ok'      => $result['ok'],
                'reason'  => $result['reason'],
                'stages'  => $result['stages'],
                'key'     => mask_key((string) $row['token_code']),
            ]);
        } catch (Throwable $e) {
            json_out(['status' => false, 'message' => 'Lỗi hệ thống khi kiểm tra key']);
        }
    }

    http_response_code(400);
    exit('Unknown action');
}

/* --------------------------- Filters + list --------------------------- */

$q        = trim((string) ($_GET['q'] ?? ''));
$type     = in_array($_GET['type'] ?? '', ['static', 'dynamic'], true) ? $_GET['type'] : '';
$status   = in_array($_GET['status'] ?? '', ['active', 'expired', 'pending', 'suspended', 'revoked'], true) ? $_GET['status'] : '';
$pkgFilter = (int) ($_GET['package'] ?? 0);

$where  = [];
$params = [];

if ($q !== '') {
    $where[]  = 't.token_code LIKE ?';
    $params[] = '%' . $q . '%';
}
if ($type !== '') {
    $where[]  = 't.type = ?';
    $params[] = $type;
}
if ($pkgFilter > 0) {
    $where[]  = 't.project_id = ?';
    $params[] = $pkgFilter;
}
if ($status === 'active') {
    $where[] = "t.status = 'active' AND (t.expire_date IS NULL OR t.expire_date >= CURRENT_TIMESTAMP)";
} elseif ($status === 'expired') {
    $where[] = "t.status = 'active' AND t.expire_date IS NOT NULL AND t.expire_date < CURRENT_TIMESTAMP";
} elseif ($status === 'pending') {
    $where[] = "t.status = 'active' AND t.expire_date IS NULL";
} elseif ($status === 'suspended' || $status === 'revoked') {
    $where[] = 't.status = ?';
    $params[] = $status;
}

$sql = 'SELECT t.id, t.token_code, t.type, t.duration, t.expire_date, t.max_devices, t.status, t.created_at,
               p.name AS package_name,
               u.username AS owner_name,
               COALESCE(d.device_count, 0) AS device_count,
               COALESCE(s.session_count, 0) AS session_count
        FROM tbl_tokens t
        JOIN tbl_projects p ON p.id = t.project_id
        LEFT JOIN tbl_users u ON u.id = t.user_id
        LEFT JOIN (SELECT token_id, COUNT(*) AS device_count FROM tbl_device_history GROUP BY token_id) d
            ON d.token_id = t.id
        LEFT JOIN (SELECT key_id, COUNT(*) AS session_count FROM tbl_sessions WHERE status = \'active\' GROUP BY key_id) s
            ON s.key_id = t.id'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY t.id DESC';

$keys = [];
try {
    $keys = db_query($sql, $params)->fetchAll();
} catch (Throwable $e) {
    /* DB cũ chưa có bảng tbl_users → bỏ JOIN owner, dùng query tương thích */
    $sqlCompat = str_replace('LEFT JOIN tbl_users u ON u.id = t.user_id', '', $sql);
    $sqlCompat = str_replace("\n               u.username AS owner_name,", '', $sqlCompat);
    try {
        $keys = db_query($sqlCompat, $params)->fetchAll();
    } catch (Throwable $e2) {
        $keys = [];
    }
}

$projects = db_query('SELECT id, name FROM tbl_projects ORDER BY name')->fetchAll();

function expiry_label(array $row): string
{
    if ($row['type'] === 'dynamic' && empty($row['expire_date'])) {
        return '<span class="text-muted">Chưa kích hoạt</span>';
    }
    return e(format_datetime($row['expire_date']));
}

function status_badge(array $row): string
{
    switch (key_status($row)) {
        case 'active':
            return '<span class="badge badge-success">Active</span>';
        case 'pending':
            return '<span class="badge badge-warning">Pending</span>';
        case 'suspended':
            return '<span class="badge badge-warning">Suspended</span>';
        case 'revoked':
            return '<span class="badge badge-danger">Revoked</span>';
        default:
            return '<span class="badge badge-danger">Expired</span>';
    }
}

layout_header('Keys', 'keys');
?>
<div class="page-toolbar">
    <form class="filter-bar" method="get">
        <div class="search-box">
            <?php echo icon('search', 16); ?>
            <input type="text" name="q" class="form-control" placeholder="Tìm key..." value="<?= e($q) ?>">
        </div>
        <select name="package" class="form-control form-control-sm">
            <option value="">Tất cả package</option>
            <?php foreach ($projects as $p): ?>
            <option value="<?= (int) $p['id'] ?>"<?= $pkgFilter === (int) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="type" class="form-control form-control-sm">
            <option value="">Loại key</option>
            <option value="static"<?= $type === 'static' ? ' selected' : '' ?>>Static</option>
            <option value="dynamic"<?= $type === 'dynamic' ? ' selected' : '' ?>>Dynamic</option>
        </select>
        <select name="status" class="form-control form-control-sm">
            <option value="">Trạng thái</option>
            <option value="active"<?= $status === 'active' ? ' selected' : '' ?>>Active</option>
            <option value="pending"<?= $status === 'pending' ? ' selected' : '' ?>>Pending</option>
            <option value="expired"<?= $status === 'expired' ? ' selected' : '' ?>>Expired</option>
            <option value="suspended"<?= $status === 'suspended' ? ' selected' : '' ?>>Suspended</option>
            <option value="revoked"<?= $status === 'revoked' ? ' selected' : '' ?>>Revoked</option>
        </select>
        <button type="submit" class="btn btn-secondary btn-sm">Lọc</button>
        <?php if ($q !== '' || $type !== '' || $status !== '' || $pkgFilter > 0): ?>
        <a href="keys.php" class="btn btn-ghost btn-sm">Xóa lọc</a>
        <?php endif; ?>
    </form>
    <button type="button" class="btn btn-primary" data-modal-open="createKeyModal">
        <?php echo icon('plus', 16); ?> Tạo Key
    </button>
</div>

<div class="card">
    <?php if (!$keys): ?>
    <div class="empty-state">
        <?php echo icon('key', 36); ?>
        <p>Không có key nào khớp. Tạo key mới hoặc đổi bộ lọc.</p>
        <button type="button" class="btn btn-primary btn-sm" data-modal-open="createKeyModal">Tạo Key đầu tiên</button>
    </div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Key</th><th>Package</th><th>Type</th><th>Expiry</th>
                    <th>Duration</th><th>Devices</th><th>Sessions</th><th>Status</th><th>Created At</th><th class="th-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($keys as $row): ?>
                <tr>
                    <td>
                        <div class="key-cell">
                            <code class="code-box"><?= e($row['token_code']) ?></code>
                            <button type="button" class="icon-btn icon-btn-xs" data-copy="<?= e($row['token_code']) ?>" title="Copy">
                                <?php echo icon('copy', 13); ?>
                            </button>
                        </div>
                    </td>
                    <td><?= e($row['package_name']) ?></td>
                    <td><span class="badge badge-neutral"><?= e($row['type']) ?></span></td>
                    <td><?= expiry_label($row) ?></td>
                    <td class="text-muted"><?= $row['type'] === 'dynamic' ? (int) $row['duration'] . ' ngày' : '—' ?></td>
                    <td><span class="device-count"><?= (int) $row['device_count'] ?> / <?= (int) $row['max_devices'] ?></span></td>
                    <td><span class="device-count"><?= (int) $row['session_count'] ?></span></td>
                    <td><?= status_badge($row) ?></td>
                    <td class="text-muted"><?= format_datetime($row['created_at']) ?></td>
                    <td class="td-actions">
                        <button type="button" class="icon-btn" data-debug-key="<?= (int) $row['id'] ?>" title="Kiểm tra key (debug pipeline)">
                            <?php echo icon('zap', 15); ?>
                        </button>
                        <button type="button" class="icon-btn" data-view-key="<?= e(json_encode([
                            'code'        => $row['token_code'],
                            'package'     => $row['package_name'],
                            'type'        => $row['type'],
                            'duration'    => (int) $row['duration'],
                            'expiry'      => format_datetime($row['expire_date']),
                            'devices'     => (int) $row['device_count'] . ' / ' . (int) $row['max_devices'],
                            'created'     => format_datetime($row['created_at']),
                            'owner'       => ($row['owner_name'] ?? null) !== null ? (string) $row['owner_name'] : 'Hệ thống',
                        ])) ?>" title="Xem chi tiết">
                            <?php echo icon('eye', 15); ?>
                        </button>
                        <form method="post" class="inline-form" data-confirm="Xóa key <?= e($row['token_code']) ?>? Thiết bị + session liên quan cũng sẽ bị xóa.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn icon-btn-danger" title="Xóa">
                                <?php echo icon('trash', 15); ?>
                            </button>
                        </form>
                        <?php if (($row['status'] ?? 'active') === 'active'): ?>
                        <form method="post" class="inline-form" data-confirm="Tạm ngưng key <?= e($row['token_code']) ?>? Mọi phiên đang chạy sẽ bị thu hồi ngay.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="suspend">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn icon-btn-warn" title="Tạm ngưng (suspend)">
                                <?php echo icon('lock', 15); ?>
                            </button>
                        </form>
                        <?php elseif (($row['status'] ?? '') === 'suspended'): ?>
                        <form method="post" class="inline-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="unsuspend">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn" title="Mở khóa key">
                                <?php echo icon('unlock', 15); ?>
                            </button>
                        </form>
                        <?php endif; ?>
                        <?php if (($row['status'] ?? 'active') !== 'revoked'): ?>
                        <form method="post" class="inline-form" data-confirm="Thu hồi vĩnh viễn key <?= e($row['token_code']) ?>? Không thể hoàn tác.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="revoke">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button type="submit" class="icon-btn icon-btn-danger" title="Thu hồi vĩnh viễn">
                                <?php echo icon('x', 15); ?>
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<div class="modal-backdrop" id="createKeyModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="createKeyTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="createKeyTitle"><?php echo icon('key', 18); ?> Tạo Key mới</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <form method="post" class="modal-body-form" data-loading>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label class="form-label">Package</label>
                <select name="project_id" class="form-control" required>
                    <?php foreach ($projects as $p): ?>
                    <option value="<?= (int) $p['id'] ?>"><?= e($p['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Loại key</label>
                <select name="type" id="keyType" class="form-control" required>
                    <option value="static">Static — hạn cố định</option>
                    <option value="dynamic">Dynamic — tính từ lần kích hoạt đầu</option>
                </select>
            </div>
            <div class="form-group" id="staticField">
                <label class="form-label">Ngày hết hạn</label>
                <input type="datetime-local" name="expire_date" class="form-control" required>
            </div>
            <div class="form-group" id="dynamicField" hidden>
                <label class="form-label">Số ngày sử dụng</label>
                <input type="number" name="duration" class="form-control" min="1" max="3650" placeholder="30">
                <div class="preset-row">
                    <button type="button" class="chip" data-preset="30">30 days</button>
                    <button type="button" class="chip" data-preset="60">60 days</button>
                    <button type="button" class="chip" data-preset="90">90 days</button>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Số thiết bị tối đa</label>
                <input type="number" name="max_devices" class="form-control" value="1" min="1" max="100" required>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" data-modal-close>Hủy</button>
                <button type="submit" class="btn btn-primary"><?php echo icon('plus', 15); ?> Tạo Key</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-backdrop" id="viewKeyModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="viewKeyTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="viewKeyTitle"><?php echo icon('eye', 18); ?> Chi tiết Key</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <div class="modal-body">
            <div class="key-detail-code">
                <code id="vkCode" class="code-box code-box-lg"></code>
                <button type="button" class="icon-btn" id="vkCopy"><?php echo icon('copy', 15); ?></button>
            </div>
            <dl class="detail-list">
                <dt>Package</dt><dd id="vkPackage"></dd>
                <dt>Type</dt><dd id="vkType"></dd>
                <dt>Duration</dt><dd id="vkDuration"></dd>
                <dt>Expiry</dt><dd id="vkExpiry"></dd>
                <dt>Devices</dt><dd id="vkDevices"></dd>
                <dt>Created At</dt><dd id="vkCreated"></dd>
                <dt>Owner</dt><dd id="vkOwner"></dd>
            </dl>
        </div>
    </div>
</div>
<div class="modal-backdrop" id="debugKeyModal" hidden>
    <div class="modal modal-lg" role="dialog" aria-modal="true" aria-labelledby="debugKeyTitle">
        <div class="modal-header">
            <h3 class="modal-title" id="debugKeyTitle"><?php echo icon('zap', 18); ?> Kiểm tra vòng đời Key</h3>
            <button type="button" class="icon-btn" data-modal-close><?php echo icon('x', 16); ?></button>
        </div>
        <div class="modal-body">
            <p class="modal-text">Chạy <strong>validation pipeline</strong> ở chế độ đọc-cho-biết (dry-run): không ghi database, không tiêu nonce, không tạo session, không kích hoạt key dynamic.</p>
            <form class="filter-bar" id="debugKeyForm">
                <?= csrf_field() ?>
                <div class="search-box">
                    <?php echo icon('device', 16); ?>
                    <input type="text" id="debugDeviceId" class="form-control" placeholder="Device ID (tùy chọn — bỏ trống = giả lập thiết bị mới)">
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Chạy kiểm tra</button>
            </form>
            <div id="debugKeyResult" class="stage-trace" hidden>
                <div class="stage-trace-verdict"></div>
                <div class="stage-trace-list"></div>
            </div>
        </div>
    </div>
</div>

<?php layout_footer(['keys.js']); ?>
