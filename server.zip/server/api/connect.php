<?php
/**
 * API endpoint cho client.
 *
 *   GET /api/connect.php?action=init&token={PROJECT_TOKEN}
 *   GET /api/connect.php?action=check&token={PROJECT_TOKEN}&key={KEY}&uuid={DEVICE_UUID}
 *
 * Luong xac thuc (giu nguyen logic goc):
 *   Package Token -> Key -> Maintenance -> Dynamic first-activation
 *   -> Expiry -> Device limit -> Device register -> Response
 *
 * Luon tra ve JSON hop le, khong bao gio tra HTML loi.
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/settings.php';
require_once __DIR__ . '/../lib/RateLimit.php';
require_once __DIR__ . '/../lib/Audit.php';

/* V2: rate limit cho API legacy theo IP (fail-open khi DB lỗi) */
$legacy_ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
if (!rl_allow('legacy:' . $legacy_ip, 120, 60)) {
    security_event('ratelimit.triggered', 'warning', ['details' => 'legacy bucket']);
    api_error('Too many requests', true);
}

try {
    handle_request();
} catch (Throwable $e) {
    api_error('Server error', true);
}

function handle_request(): void
{
    $action = $_GET['action'] ?? '';

    if (!isset($_GET['token'])) {
        api_error('Missing Package Token', true);
    }

    try {
        $project = db_query(
            'SELECT id, contact_link, is_maintenance FROM tbl_projects WHERE project_token = ? LIMIT 1',
            [$_GET['token']]
        )->fetch();
    } catch (RuntimeException $e) {
        api_error('Database unavailable', true);
    }

    if ($project === false) {
        api_error('Invalid Package Token', true);
    }

    $contact = (string) $project['contact_link'];

    if ($action === 'init') {
        json_out([
            'status'      => true,
            'contact'     => $contact,
            'maintenance' => (int) $project['is_maintenance'],
        ]);
    }

    if ($action === 'check') {
        do_check($project, $contact);
    }

    api_error('Unknown action');
}

function do_check(array $project, string $contact): void
{
    $key  = $_GET['key'] ?? '';
    $uuid = $_GET['uuid'] ?? '';

    if ($key === '' || $uuid === '') {
        api_error('Missing params');
    }

    $token = db_query(
        'SELECT id, type, duration, expire_date, max_devices, status FROM tbl_tokens
         WHERE token_code = ? AND project_id = ? LIMIT 1',
        [$key, $project['id']]
    )->fetch();

    if ($token === false) {
        security_event('legacy.denied', 'info', ['details' => 'key_not_found']);
        api_error('Key invalid for this package');
    }

    /* V2: tôn trọng vòng đời key do admin kiểm soát */
    $keyStatus = (string) ($token['status'] ?? 'active');
    if ($keyStatus === 'revoked') {
        security_event('legacy.denied', 'warning', ['key_id' => (int) $token['id'], 'details' => 'revoked']);
        api_error('Key revoked', false, $contact);
    }
    if ($keyStatus === 'suspended') {
        security_event('legacy.denied', 'warning', ['key_id' => (int) $token['id'], 'details' => 'suspended']);
        api_error('Key suspended', false, $contact);
    }

    if ((int) $project['is_maintenance'] === 1) {
        api_error('System Maintenance', true, $contact);
    }

    $now = date('Y-m-d H:i:s');

    /* Dynamic key: lan check dau tien ghi han su dung = now + duration */
    if ($token['type'] === 'dynamic' && $token['expire_date'] === null) {
        $expire = date('Y-m-d H:i:s', strtotime('+' . (int) $token['duration'] . ' days'));
        db_query('UPDATE tbl_tokens SET expire_date = ? WHERE id = ?', [$expire, $token['id']]);
        $token['expire_date'] = $expire;
    }

    if ($token['expire_date'] !== null && $token['expire_date'] < $now) {
        api_error('Key expired', false, $contact);
    }

    register_device((int) $token['id'], $uuid, (int) $token['max_devices'], $contact);

    $daysLeft = (int) floor((strtotime((string) $token['expire_date']) - strtotime($now)) / 86400);
    if ($daysLeft < 0) {
        $daysLeft = 0;
    }

    /* Ghi chú: KHÔNG log mỗi lần check thành công (client poll liên tục
     * sẽ làm ngập bảng sự kiện). Chỉ các lần TỪ CHỐI mới được ghi ở trên. */

    json_out([
        'status'    => true,
        'message'   => 'Active',
        'expiry'    => $token['expire_date'],
        'days_left' => $daysLeft,
        'contact'   => $contact,
    ]);
}

function register_device(int $tokenId, string $uuid, int $maxDevices, string $contact): void
{
    $exists = db_query(
        'SELECT 1 FROM tbl_device_history WHERE token_id = ? AND device_uuid = ? LIMIT 1',
        [$tokenId, $uuid]
    )->fetchColumn();

    if ($exists !== false) {
        return;
    }

    $used = (int) db_query(
        'SELECT COUNT(*) FROM tbl_device_history WHERE token_id = ?',
        [$tokenId]
    )->fetchColumn();

    if ($used >= $maxDevices) {
        api_error('Max devices reached', false, $contact);
    }

    try {
        db_query(
            'INSERT INTO tbl_device_history (token_id, device_uuid) VALUES (?, ?)',
            [$tokenId, $uuid]
        );
    } catch (PDOException $e) {
        /* Race: thiet bi vua duoc ghi boi request khac — coi nhu da dang ky */
        if ((int) $e->getCode() !== 23000) {
            throw $e;
        }
    }
}
