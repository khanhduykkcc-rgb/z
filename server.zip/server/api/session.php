<?php
/**
 * API v2 — SESSION endpoint (giao thức TAKEY-V2).
 *
 *   POST /api/session.php  action=check   → revalidate + gia hạn lease
 *   POST /api/session.php  action=renew   → alias của check
 *   POST /api/session.php  action=revoke  → client chủ động hủy session
 *
 * Mọi request phải có:
 *   session_id + nonce (single-use) + ts + req_id + mac
 *   mac = HMAC-SHA-512-256 (NaCl crypto_auth) trên canonical của
 *   {action, nonce, req_id, session_id, ts} với khóa = session_secret.
 *
 * Server TÁI XÁC THỰC toàn bộ (key/package/device/expiry) trước khi gia hạn —
 * lease chỉ dài thêm khi mọi điều kiện authority còn đúng.
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/settings.php';
require_once __DIR__ . '/../lib/Api.php';
require_once __DIR__ . '/../lib/RateLimit.php';
require_once __DIR__ . '/../lib/Audit.php';
require_once __DIR__ . '/../lib/Nonce.php';
require_once __DIR__ . '/../lib/KeyModel.php';
require_once __DIR__ . '/../lib/DeviceModel.php';
require_once __DIR__ . '/../lib/SessionModel.php';
require_once __DIR__ . '/../lib/AuthPipeline.php';

/* 405 cũng phải là JSON envelope — client không bao giờ nhận text bất ngờ */
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    api_v2_respond('denied', 'method_not_allowed', [], null, 405);
}

$request = api_v2_input();

/* Rate limit theo session_id (đã parse xong, chưa chạm DB) */
$sid = self_or($request, 'session_id', '');
if ($sid !== '' && !rl_allow('sess:' . substr($sid, 0, 40), 240, 60)) {
    security_event('ratelimit.triggered', 'warning', ['details' => 'session bucket']);
    api_v2_respond('denied', 'rate_limited', [], $request, 429);
}

try {
    $pipeline = new AuthPipeline(false);
    $data = $pipeline->sessionRequest($request);
    api_v2_respond('ok', 'ok', $data, $request, 200);
} catch (AuthDeniedException $e) {
    api_v2_respond('denied', $e->apiCode, $e->extra, $request, $e->http);
} catch (Throwable $e) {
    error_log('[api/session.php] ' . $e->getMessage());
    api_v2_respond('error', 'server_error', [], $request, 500);
}
