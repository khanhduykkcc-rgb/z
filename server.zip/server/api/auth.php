<?php
/**
 * API v2 — AUTH endpoint (giao thức TAKEY-V2).
 *
 *   POST /api/auth.php   action=init          → server hello + public key + challenge
 *   POST /api/auth.php   action=authenticate  → pipeline đầy đủ → session + lease
 *
 * API v1 (api/connect.php) vẫn hoạt động song song — không bị ảnh hưởng.
 *
 * Mọi response là envelope JSON có chữ ký ECDSA P-256 (xem lib/Api.php).
 * Rate limit theo IP áp trước khi chạm DB nặng.
 */

declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/settings.php';
require_once __DIR__ . '/../lib/Api.php';
require_once __DIR__ . '/../lib/RateLimit.php';
require_once __DIR__ . '/../lib/Audit.php';
require_once __DIR__ . '/../lib/Nonce.php';
require_once __DIR__ . '/../lib/KeyModel.php';
require_once __DIR__ . '/../lib/DeviceModel.php';
require_once __DIR__ . '/../lib/SessionModel.php';
require_once __DIR__ . '/../lib/AuthPipeline.php';

/* 405 cũng phải là JSON envelope — client không bao giờ nhận text bất ngờ */
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    api_v2_respond('denied', 'method_not_allowed', [], null, 405);
}

$ip = api_client_ip();

/* Rate limit theo IP cho toàn bộ v2 auth (fail-open khi DB lỗi) */
if (!rl_allow('api:' . $ip, 60, 60)) {
    security_event('ratelimit.triggered', 'warning', ['details' => 'api bucket ip']);
    api_v2_respond('denied', 'rate_limited', [], null, 429);
}

$request = api_v2_input();
$action  = self_or($request, 'action', '');

try {
    $pipeline = new AuthPipeline(false);

    if ($action === 'init') {
        $data = $pipeline->hello($request);
        api_v2_respond('ok', 'ok', $data, $request, 200);
    }

    if ($action === 'authenticate') {
        $data = $pipeline->authenticate($request);
        api_v2_respond('ok', 'ok', $data, $request, 200);
    }

    api_v2_respond('denied', 'bad_request', [], $request, 400);
} catch (AuthDeniedException $e) {
    api_v2_respond('denied', $e->apiCode, $e->extra, $request, $e->http);
} catch (Throwable $e) {
    /* Không bao giờ lộ chi tiết lỗi ra ngoài; envelope vẫn là JSON hợp lệ */
    error_log('[api/auth.php] ' . $e->getMessage());
    api_v2_respond('error', 'server_error', [], $request, 500);
}
