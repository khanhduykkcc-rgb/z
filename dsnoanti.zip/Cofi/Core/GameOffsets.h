#ifndef GameOffsets_h
#define GameOffsets_h

// ======================================================================
//  GameOffsets — RUNTIME REGISTRY (Task 17: offsets do server cấp).
//
//  KHÔNG còn một offset nào được hard-code trong app. Mọi giá trị khởi
//  tạo = 0 và CHỈ được đổ vào bởi Core/OffsetRegistry.mm sau khi client
//  fetch action=offsets từ server và verify chữ ký ECDSA thành công
//  (key hợp lệ + session lease còn hạn + device_binding khớp).
//
//  Hệ quả: app build ra mà không có key hợp lệ thì ESP/Aim đọc toàn
//  offset 0 → không đọc/ghi được dữ liệu game → không hoạt động. Key
//  bị revoke/expired giữa phiên → OffsetRegistry reset về 0 → chết ngay.
//
//  Tên + kiểu biến GIỮ NGUYÊN so với bản cũ (108 call-site không đổi).
//  Value gốc đã chuyển lên server: includes/offsets_data.php (seed) →
//  bảng license_offsets (admin → Offsets để cập nhật khi game update).
//
//  BytePlayerDictionaryEntry là layout struct compile-time (không phải
//  bí mật) — giữ nguyên; 2 kiểm tra compile-time cũ chuyển thành runtime
//  check trong OffsetRegistry (BytePlayerEntrySize/Value phải khớp struct,
//  sai thì từ chối payload — fail-closed).
// ======================================================================

#include <cstddef>
#include <cstdint>

namespace GameOffsets {

/* Bản bản game của bộ offset hiện có — filled bởi OffsetRegistry. */
inline char ExpectedGameVersion[32] = {0};

inline uint64_t GameFacadeTypeInfo = 0;
inline uint64_t GameVarDefTypeInfo = 0;
inline uint64_t Il2CppClassStaticFields = 0;
inline uint64_t GameFacadeCurrentGame = 0;
inline uint64_t GameFacadeCurrentMatchGame = 0;
inline uint64_t GameFacadeIsObserver = 0;
inline uint64_t GameFacadeIsMatchStarted = 0;
inline uint64_t BaseGameHasInited = 0;
inline uint64_t BaseGameHasLoadingFailed = 0;
inline uint64_t BaseGameHasFixedUpdated = 0;
inline uint64_t BaseGameSceneLoaded = 0;
inline uint64_t BaseGameIsPaused = 0;
inline uint64_t BaseGameIsMatchEnd = 0;
inline uint64_t MatchGameMatch = 0;
inline uint64_t MatchGameGRIDataPool = 0;
inline uint64_t MatchGameCameraControllerManager = 0;
inline uint64_t CameraControllerManagerGameCamera = 0;
inline uint64_t CameraControllerManagerAltCamera = 0;
inline uint64_t MatchLocalPlayer = 0;
inline uint64_t MatchShortIdToPlayers = 0;
inline uint64_t EntityIsRecycle = 0;
inline uint64_t EntityCachedTransform = 0;
inline uint64_t EntityPRIReceivedFirstTime = 0;
inline uint64_t PlayerPRIDataPool = 0;
inline uint64_t PlayerIsDead = 0;
inline uint64_t PlayerUGCStartFiring = 0;
inline uint64_t PlayerIsInZeppelin = 0;
inline uint64_t PlayerLastStartFireTime = 0;
inline uint64_t PlayerMainCameraTransform = 0;
inline uint64_t PlayerId = 0;
inline uint64_t PlayerNickName = 0;
inline uint64_t PlayerOriginalNickName = 0;
inline uint64_t PlayerIsClientBot = 0;
inline uint64_t PlayerAvatarInitialized = 0;
inline uint64_t PlayerIsInVehicle = 0;
inline uint64_t PlayerAimRotation = 0;
inline uint64_t PlayerAimRotationAux = 0;
inline uint64_t PlayerModelVisibilityState = 0;
inline uint64_t PlayerIsKnockedDownBleed = 0;
inline uint64_t PlayerIsKnockDownBleedingFromGS = 0;
inline uint64_t PlayerCurrentAimRotation = 0;
inline uint64_t PlayerBeingRescuredState = 0;
inline uint64_t PlayerPhysXData = 0;
inline uint64_t PhysXStateClassRef = 0;
inline uint64_t PhysXGhgState = 0;
inline uint64_t PlayerHeadNode = 0;
inline uint64_t PlayerHipNode = 0;
inline uint64_t PlayerLeftAnkleNode = 0;
inline uint64_t PlayerRightAnkleNode = 0;
inline uint64_t PlayerLeftToeNode = 0;
inline uint64_t PlayerRightToeNode = 0;
inline uint64_t PlayerLeftShoulderNode = 0;
inline uint64_t PlayerRightShoulderNode = 0;
inline uint64_t PlayerRightHandNode = 0;
inline uint64_t PlayerLeftHandNode = 0;
inline uint64_t PlayerRightForeArmNode = 0;
inline uint64_t PlayerLeftForeArmNode = 0;
inline uint64_t PlayerSpineBone = 0;
inline uint64_t PlayerHeadBone = 0;
inline uint64_t PlayerHipsBone = 0;
inline uint64_t GameVarDefSensitivityBlock = 0;
inline uint64_t GameVarDefRotationSensitivityMax = 0;
inline uint64_t GameVarDefAimRotationSensitivityMin = 0;
inline uint64_t GameVarDefAimRotationSensitivityMax = 0;
inline uint64_t PlayerAuxAimResetTime = 0;
inline uint64_t PlayerMinAngleX = 0;
inline uint64_t PlayerMaxAngleX = 0;
inline uint64_t PlayerPhysicalCCT = 0;
inline uint64_t PhysicalCCTVelocity = 0;
inline uint64_t PlayerInventoryManager = 0;
inline uint64_t InventoryItemOnHand = 0;
inline uint64_t WeaponRepItem = 0;
inline uint64_t WeaponRange = 0;
inline uint64_t WeaponFireInterval = 0;
inline uint64_t WeaponFullDamageDistance = 0;
inline uint64_t WeaponIsSingleShot = 0;
inline uint64_t DictionaryEntries = 0;
inline uint64_t DictionaryCount = 0;
inline uint64_t ArrayLength = 0;
inline uint64_t ArrayItems = 0;
inline uint64_t BytePlayerEntryValue = 0;
inline uint64_t BytePlayerEntrySize = 0;
inline uint64_t StringLength = 0;
inline uint64_t StringFirstChar = 0;
inline uint64_t ReplicationDataPoolData = 0;
inline uint64_t ReplicationDataGroup = 0;
inline uint64_t ReplicationDataValue = 0;
inline uint64_t TransformNodeTransform = 0;
inline int PriVarScope = 0;
inline int PriVarFire = 0;
inline uint32_t ReplicationGroupUInt8 = 0;
inline uint32_t ReplicationGroupUInt16 = 0;
inline uint32_t ReplicationGroupUInt32 = 0;
inline uint32_t PhysXPoseSkyDiving = 0;
inline uint32_t PhysXPoseKnockDown = 0;
inline uint32_t PhysXPoseParachuteFalling = 0;
inline uint64_t UnityObjectCachedPtr = 0;
inline uint64_t TransformAccess = 0;
inline uint64_t TransformIndex = 0;
inline uint64_t TransformData = 0;
inline uint64_t TransformParents = 0;
inline uint64_t BitArrayBooleanValue = 0;
inline uint64_t BitArrayBooleanInitialValue = 0;
inline uint64_t BitArrayBooleanMode = 0;
inline int32_t BitArrayBooleanAndTrue = 0;
inline int32_t BitArrayBooleanOrTrue = 0;

} // namespace GameOffsets

struct BytePlayerDictionaryEntry {
    int32_t hashCode;
    int32_t next;
    uint8_t key;
    uint8_t padding[7];
    uint64_t value;
};

#endif
