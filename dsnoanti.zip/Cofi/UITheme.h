#import <UIKit/UIKit.h>

static NSString * const UIThemePreferenceKey = @"renew.appearance";

static inline UIColor *UIAccent(void) {
    // 3105 v2 accent — cam ấm (light #D96B33 / dark #FFA36B), theo
    // DesignSystem.swift của ThreeOneOSFive (YangJiiii/3105).
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
        if (traits.userInterfaceStyle == UIUserInterfaceStyleDark)
            return [UIColor colorWithRed:1.00 green:0.64 blue:0.42 alpha:1.0]; // #FFA36B
        return [UIColor colorWithRed:0.85 green:0.42 blue:0.20 alpha:1.0]; // #D96B33
    }];
}

static inline UIColor *UISecondaryAccent(void) {
    // Cam đậm hơn — dùng cho text nhỏ trên nền trắng (đảm bảo tương phản).
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
        if (traits.userInterfaceStyle == UIUserInterfaceStyleDark)
            return [UIColor colorWithRed:1.00 green:0.71 blue:0.51 alpha:1.0]; // #FFB583
        return [UIColor colorWithRed:0.75 green:0.35 blue:0.15 alpha:1.0]; // #C05A26
    }];
}

static inline UIColor *UISectionColor(NSInteger section) {
    (void)section;
    // 3105: card trắng trên nền grouped xám nhạt (light) / card #1C1C1E (dark).
    return [UIColor secondarySystemGroupedBackgroundColor];
}

static inline void UIApplyTheme(void) {
    NSInteger value = [NSUserDefaults.standardUserDefaults integerForKey:UIThemePreferenceKey];
    UIUserInterfaceStyle style = value == 1 ? UIUserInterfaceStyleLight
        : value == 2 ? UIUserInterfaceStyleDark : UIUserInterfaceStyleUnspecified;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if ([window.rootViewController isKindOfClass:UITabBarController.class])
                window.overrideUserInterfaceStyle = style;
        }
    }
}

static inline void UIConfigureTable(UITableViewController *controller) {
    controller.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    // 3105: page = systemBackground/grouped; console = secondarySystemBackground.
    controller.tableView.backgroundColor = [UIColor systemGroupedBackgroundColor];
    controller.tableView.tintColor = UIAccent();
    controller.tableView.rowHeight = UITableViewAutomaticDimension;
    controller.tableView.estimatedRowHeight = 72;
    controller.tableView.separatorInset = UIEdgeInsetsMake(0, 20, 0, 0);
    controller.tableView.contentInset = UIEdgeInsetsMake(8, 0, 16, 0);
}
