#pragma once

#include <string>

#include "api_client.hpp"
#include "device.hpp"
#include "storage.hpp"

struct StartupResult {
    InitResult init;               /* trạng thái init từ server        */
    bool       has_saved_key = false;
    CheckResult saved_check;       /* hợp lệ khi has_saved_key == true */
};

/*
 * Điều phối luật key, giữ nguyên logic client gốc:
 *
 *   init -> maintenance? -> key đã lưu? -> auto check
 *   key thủ công -> check -> lưu khi thành công
 *   key sai / hết hạn -> xóa key đã lưu, host quyết định prompt lại
 */
class KeyManager {
public:
    KeyManager(ApiClient& client, IStorage& storage, IDeviceIdentity& device);

    /* Gọi khi app khởi động: init + tự kiểm tra key đã lưu (nếu có). */
    StartupResult startup();

    /* Kích hoạt key do người dùng nhập. Lưu key khi thành công. */
    CheckResult activate(const std::string& key);

    /* Kiểm tra lại key đã lưu — tự xóa khi không còn hợp lệ. */
    CheckResult validate_saved();

    std::string saved_key() const;

private:
    CheckResult process(const std::string& key, bool auto_mode);

    ApiClient&       client_;
    IStorage&        storage_;
    IDeviceIdentity& device_;
};
