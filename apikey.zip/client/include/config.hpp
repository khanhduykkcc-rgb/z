#pragma once

#include <string>

/*
 * Cấu hình client — thay đổi 2 hằng số này trước khi build.
 * Không rải URL/token qua nhiều file: mọi module đều đọc từ đây.
 */
namespace cfg {

constexpr const char* kApiUrl        = "http://YOUR_DOMAIN/api/connect.php";
constexpr const char* kPackageToken = "YOUR_PACKAGE_TOKEN";
constexpr const char* kStorageFile  = ".license_key";
constexpr int         kTimeoutSecs  = 15;

}  // namespace cfg

/* Config runtime — cho phép host app override sau khi dựng thư viện. */
struct Config {
    std::string api_url;
    std::string package_token;
    std::string storage_path;
    int         timeout_seconds;

    static Config defaults() {
        return Config{
            cfg::kApiUrl,
            cfg::kPackageToken,
            cfg::kStorageFile,
            cfg::kTimeoutSecs,
        };
    }
};
