#pragma once

#include <string>

#include "config.hpp"
#include "http.hpp"

struct InitResult {
    bool        ok          = false;  /* gói tin init hợp lệ */
    bool        maintenance = false;  /* package đang bảo trì */
    bool        force_exit  = false;  /* server yêu cầu chặn vĩnh viễn */
    std::string message;
    std::string contact;              /* link hỗ trợ do admin cấu hình */
    std::string error;                /* lỗi phía client (mạng/parse) */
};

struct CheckResult {
    bool        ok         = false;
    bool        force_exit = false;
    std::string message;
    std::string expiry;              /* "YYYY-MM-DD HH:MM:SS" */
    long        days_left  = -1;
    std::string contact;
    std::string error;
};

/*
 * Client cho API /api/connect.php — tương thích 100% response của
 * server: action=init và action=check.
 */
class ApiClient {
public:
    ApiClient(const Config& config, IHttpTransport& transport);

    InitResult init();
    CheckResult check(const std::string& key, const std::string& device_uuid);

private:
    std::string request(const std::string& query);

    Config          config_;
    IHttpTransport& transport_;
};
