/*
 * http_curl.cpp — HTTP(S) transport bằng libcurl (build: make CURL=1).
 */

#include "http.hpp"

#include <curl/curl.h>

#include <stdexcept>
#include <string>

namespace {

size_t append_to_string(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* body = static_cast<std::string*>(userdata);
    body->append(ptr, size * nmemb);
    return size * nmemb;
}

class CurlGlobal {
public:
    CurlGlobal()  { curl_global_init(CURL_GLOBAL_DEFAULT); }
    ~CurlGlobal() { curl_global_cleanup(); }
};

}  // namespace

class CurlTransport final : public IHttpTransport {
public:
    HttpResponse get(const std::string& url, int timeout_seconds) override {
        static CurlGlobal global_init;

        CURL* curl = curl_easy_init();
        if (curl == nullptr) {
            throw std::runtime_error("curl_easy_init failed");
        }

        HttpResponse res;
        CURLcode code = CURLE_OK;

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 3L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, static_cast<long>(timeout_seconds));
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, static_cast<long>(timeout_seconds));
        curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "apikey-client/1.0");
        curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, append_to_string);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &res.body);

        code = curl_easy_perform(curl);

        if (code == CURLE_OK) {
            long status = 0;
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
            res.status = status;
        }

        curl_easy_cleanup(curl);

        if (code != CURLE_OK) {
            throw std::runtime_error(std::string("curl: ") + curl_easy_strerror(code));
        }
        return res;
    }
};

std::unique_ptr<IHttpTransport> create_curl_transport() {
    return std::make_unique<CurlTransport>();
}

std::unique_ptr<IHttpTransport> create_default_transport() {
    return std::make_unique<CurlTransport>();
}
