/*
 * key_manager.cpp — điều phối luồng key, giữ nguyên logic client gốc.
 */

#include "key_manager.hpp"

#include <utility>

KeyManager::KeyManager(ApiClient& client, IStorage& storage, IDeviceIdentity& device)
    : client_(client), storage_(storage), device_(device) {}

StartupResult KeyManager::startup() {
    StartupResult result;
    result.init = client_.init();

    if (!result.init.ok || result.init.maintenance) {
        return result;
    }

    std::string saved;
    if (storage_.read(saved)) {
        result.has_saved_key = true;
        result.saved_check = process(saved, true);
    }
    return result;
}

CheckResult KeyManager::activate(const std::string& key) {
    CheckResult result = process(key, false);
    if (result.ok) {
        storage_.write(key);
    }
    return result;
}

CheckResult KeyManager::validate_saved() {
    std::string saved;
    if (!storage_.read(saved)) {
        CheckResult none;
        none.error = "no saved key";
        return none;
    }
    return process(saved, true);
}

std::string KeyManager::saved_key() const {
    std::string saved;
    storage_.read(saved);
    return saved;
}

CheckResult KeyManager::process(const std::string& key, bool auto_mode) {
    CheckResult result = client_.check(key, device_.uuid());

    /* Key không còn hợp lệ khi ở chế độ tự động -> xóa key đã lưu,
       host app sẽ prompt lại (giống hành vi client gốc). */
    if (auto_mode && !result.ok && result.error.empty()) {
        storage_.clear();
    }
    return result;
}
