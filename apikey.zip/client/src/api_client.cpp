/*
 * api_client.cpp — gọi API /api/connect.php, parse JSON an toàn bằng
 * nlohmann/json (vendored, include/nlohmann/json.hpp).
 */

#include "api_client.hpp"

#include <nlohmann/json.hpp>

#include <chrono>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <sstream>
#include <stdexcept>
#include <string>

namespace {

std::string url_encode(const std::string& value) {
    static const char* kHex = "0123456789ABCDEF";

    std::string out;
    out.reserve(value.size() * 2);

    for (const unsigned char c : value) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            out += static_cast<char>(c);
        } else {
            out += '%';
            out += kHex[(c >> 4) & 0xF];
            out += kHex[c & 0xF];
        }
    }
    return out;
}

/* "YYYY-MM-DD HH:MM:SS" -> time_t (giờ local, cùng ngữ nghĩa với NSDateFormatter gốc). */
bool parse_datetime(const std::string& value, std::time_t& out) {
    std::tm tm{};
    if (std::sscanf(value.c_str(), "%d-%d-%d %d:%d:%d",
                    &tm.tm_year, &tm.tm_mon, &tm.tm_mday,
                    &tm.tm_hour, &tm.tm_min, &tm.tm_sec) != 6) {
        return false;
    }
    if (tm.tm_year < 1900 || tm.tm_mon < 1 || tm.tm_mon > 12) {
        return false;
    }
    tm.tm_year -= 1900;
    tm.tm_mon -= 1;
    tm.tm_isdst = -1;

    const time_t parsed = std::mktime(&tm);
    if (parsed == static_cast<std::time_t>(-1)) {
        return false;
    }
    out = parsed;
    return true;
}

}  // namespace

ApiClient::ApiClient(const Config& config, IHttpTransport& transport)
    : config_(config), transport_(transport) {}

std::string ApiClient::request(const std::string& query) {
    std::string base = config_.api_url;
    if (base.find('?') == std::string::npos) {
        base += '?';
    } else {
        base += '&';
    }

    const HttpResponse res = transport_.get(base + query, config_.timeout_seconds);

    if (!res.ok()) {
        std::ostringstream err;
        err << "HTTP " << res.status;
        throw std::runtime_error(err.str());
    }
    return res.body;
}

InitResult ApiClient::init() {
    InitResult result;

    try {
        const std::string body = request(
            "action=init&token=" + url_encode(config_.package_token));

        const auto j = nlohmann::json::parse(body, nullptr, false);
        if (j.is_discarded() || !j.is_object()) {
            result.error = "invalid JSON from server";
            return result;
        }

        result.ok          = j.value("status", false);
        result.contact     = j.value("contact", "");
        result.maintenance = j.value("maintenance", 0) != 0;
        result.message     = j.value("message", "");
        result.force_exit  = j.value("force_exit", false);
    } catch (const std::exception& e) {
        result.error = e.what();
    }
    return result;
}

CheckResult ApiClient::check(const std::string& key, const std::string& device_uuid) {
    CheckResult result;

    try {
        const std::string body = request(
            "action=check"
            "&token=" + url_encode(config_.package_token) +
            "&key="   + url_encode(key) +
            "&uuid="  + url_encode(device_uuid));

        const auto j = nlohmann::json::parse(body, nullptr, false);
        if (j.is_discarded() || !j.is_object()) {
            result.error = "invalid JSON from server";
            return result;
        }

        result.ok         = j.value("status", false);
        result.message    = j.value("message", "");
        result.expiry     = j.value("expiry", "");
        result.days_left  = j.value("days_left", -1);
        result.contact    = j.value("contact", "");
        result.force_exit = j.value("force_exit", false);

        if (result.ok) {
            /* Kiểm tra kép phía client — giữ hành vi client gốc:
               days_left < 0 hoặc expiry đã qua đều coi là key lỗi thời gian. */
            std::time_t expiry_ts = 0;
            const bool parsed = parse_datetime(result.expiry, expiry_ts);

            if (result.days_left < 0) {
                result.ok = false;
                result.message = "Key loi thoi gian (Time Error)";
            } else if (!parsed || expiry_ts < std::time(nullptr)) {
                result.ok = false;
                result.message = "Key da het han su dung";
            }
        }
    } catch (const std::exception& e) {
        result.error = e.what();
    }
    return result;
}
