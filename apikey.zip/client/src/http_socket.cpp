/*
 * http_socket.cpp — HTTP transport bằng POSIX socket, không dependency.
 * Chỉ hỗ trợ http:// — dùng make CURL=1 để có HTTPS qua libcurl.
 */

#include "http.hpp"

#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <cctype>
#include <cstring>
#include <stdexcept>
#include <string>

namespace {

struct ParsedUrl {
    std::string host;
    std::string port;
    std::string path_query;
};

ParsedUrl parse_url(const std::string& url) {
    static const std::string kProto = "://";

    ParsedUrl out;
    std::string rest;

    if (url.rfind("http://", 0) == 0) {
        out.port = "80";
        rest = url.substr(7);
    } else if (url.rfind("https://", 0) == 0) {
        throw std::runtime_error("https:// requires CURL=1 build (libcurl transport)");
    } else {
        throw std::runtime_error("unsupported URL scheme: " + url);
    }

    const auto slash = rest.find('/');
    std::string authority = (slash == std::string::npos) ? rest : rest.substr(0, slash);
    out.path_query = (slash == std::string::npos) ? "/" : rest.substr(slash);

    const auto colon = authority.find(':');
    if (colon != std::string::npos) {
        out.host = authority.substr(0, colon);
        out.port = authority.substr(colon + 1);
    } else {
        out.host = authority;
    }

    if (out.host.empty()) {
        throw std::runtime_error("invalid URL: missing host");
    }
    return out;
}

int connect_with_timeout(const addrinfo* info, int timeout_seconds) {
    for (const addrinfo* ai = info; ai != nullptr; ai = ai->ai_next) {
        const int fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) {
            continue;
        }

        timeval tv{};
        tv.tv_sec = timeout_seconds;
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

        if (connect(fd, ai->ai_addr, ai->ai_addrlen) == 0) {
            return fd;
        }
        close(fd);
    }
    return -1;
}

}  // namespace

class SocketTransport final : public IHttpTransport {
public:
    HttpResponse get(const std::string& url, int timeout_seconds) override {
        const ParsedUrl target = parse_url(url);

        addrinfo hints{};
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;

        addrinfo* info = nullptr;
        if (getaddrinfo(target.host.c_str(), target.port.c_str(), &hints, &info) != 0 || info == nullptr) {
            throw std::runtime_error("cannot resolve host: " + target.host);
        }

        const int fd = connect_with_timeout(info, timeout_seconds);
        freeaddrinfo(info);

        if (fd < 0) {
            throw std::runtime_error("cannot connect to " + target.host + ":" + target.port);
        }

        const std::string request = "GET " + target.path_query + " HTTP/1.0\r\n"
                                    "Host: " + target.host + "\r\n"
                                    "User-Agent: apikey-client/1.0\r\n"
                                    "Accept: application/json\r\n"
                                    "Connection: close\r\n\r\n";

        std::string response = send_all_and_read_all(fd, request, timeout_seconds);
        close(fd);

        return parse_response(response);
    }

private:
    static std::string send_all_and_read_all(int fd, const std::string& request, int /*timeout_seconds*/) {
        size_t sent = 0;
        while (sent < request.size()) {
            const ssize_t n = send(fd, request.data() + sent, request.size() - sent, 0);
            if (n <= 0) {
                throw std::runtime_error("failed sending request");
            }
            sent += static_cast<size_t>(n);
        }

        std::string raw;
        char buffer[4096];
        for (;;) {
            const ssize_t n = recv(fd, buffer, sizeof(buffer), 0);
            if (n < 0) {
                throw std::runtime_error("recv failed or timed out");
            }
            if (n == 0) {
                break;
            }
            raw.append(buffer, static_cast<size_t>(n));
        }
        return raw;
    }

    static HttpResponse parse_response(const std::string& raw) {
        const auto header_end = raw.find("\r\n\r\n");
        if (header_end == std::string::npos) {
            throw std::runtime_error("malformed HTTP response");
        }

        HttpResponse res;
        res.body = raw.substr(header_end + 4);

        /* Dòng đầu: "HTTP/1.x 200 ..." */
        const auto line_end = raw.find("\r\n");
        const std::string status_line = raw.substr(0, line_end);
        const auto sp1 = status_line.find(' ');
        if (sp1 != std::string::npos) {
            const auto sp2 = status_line.find(' ', sp1 + 1);
            res.status = std::strtol(status_line.substr(sp1 + 1, sp2 - sp1 - 1).c_str(), nullptr, 10);
        }
        if (res.status == 0) {
            throw std::runtime_error("malformed HTTP status line");
        }
        return res;
    }
};

std::unique_ptr<IHttpTransport> create_socket_transport() {
    return std::make_unique<SocketTransport>();
}

std::unique_ptr<IHttpTransport> create_default_transport() {
    return std::make_unique<SocketTransport>();
}
