/*
 * storage_file.cpp — lưu key vào file quyền 0600 (POSIX).
 */

#include "storage.hpp"

#include <sys/stat.h>
#include <unistd.h>

#include <cstdio>
#include <fstream>
#include <string>

namespace {

void restrict_permissions(const std::string& path) {
    chmod(path.c_str(), S_IRUSR | S_IWUSR);
}

}  // namespace

FileStorage::FileStorage(std::string path) : path_(std::move(path)) {}

bool FileStorage::read(std::string& out) {
    std::ifstream file(path_);
    if (!file) {
        return false;
    }
    std::string line;
    if (!std::getline(file, line)) {
        return false;
    }
    out = line;
    return !out.empty();
}

bool FileStorage::write(const std::string& value) {
    {
        std::ofstream file(path_, std::ios::trunc);
        if (!file) {
            return false;
        }
        file << value << '\n';
        if (!file) {
            return false;
        }
    }
    restrict_permissions(path_);
    return true;
}

bool FileStorage::clear() {
    if (std::remove(path_.c_str()) == 0) {
        return true;
    }
    /* Remove thất bại — thành công nếu file vốn không tồn tại. */
    std::ifstream file(path_);
    return !file.good();
}
