/*
 * main.cpp — demo dòng lệnh cho thư viện client.
 * Cách tích hợp thật: link các file src/ (trừ main.cpp) vào app của bạn
 * và tự hiện thực UI — xem README.md mục "Tích hợp client".
 */

#include <iostream>
#include <string>

#include "api_client.hpp"
#include "config.hpp"
#include "device.hpp"
#include "http.hpp"
#include "key_manager.hpp"
#include "storage.hpp"

namespace {

void print_check_result(const CheckResult& result) {
    if (result.ok) {
        std::cout << "  [OK] " << result.message << "\n"
                  << "  Expiry    : " << result.expiry << "\n"
                  << "  Days left : " << result.days_left << "\n";
        if (!result.contact.empty()) {
            std::cout << "  Contact   : " << result.contact << "\n";
        }
    } else if (!result.error.empty()) {
        std::cout << "  [ERR] " << result.error << "\n";
    } else {
        std::cout << "  [FAIL] " << result.message << "\n";
        if (!result.contact.empty()) {
            std::cout << "  Contact   : " << result.contact << "\n";
        }
    }
}

int prompt_and_activate(KeyManager& manager) {
    for (;;) {
        std::cout << "\nLicense key> ";
        std::string key;

        if (!std::getline(std::cin, key)) {
            std::cout << "Het input — thoat.\n";
            return 1;
        }

        while (!key.empty() && (key.back() == ' ' || key.back() == '\r')) {
            key.pop_back();
        }
        if (key.empty()) {
            continue;
        }

        const CheckResult result = manager.activate(key);
        print_check_result(result);
        if (result.ok) {
            return 0;
        }
        if (result.force_exit) {
            return 2;
        }
    }
}

}  // namespace

int main() {
    const Config config = Config::defaults();
    auto transport = create_default_transport();

    ApiClient   client(config, *transport);
    FileStorage storage(config.storage_path);
    DefaultDeviceIdentity device;

    KeyManager manager(client, storage, device);

    std::cout << "API Panel — C++ Client Demo\n"
              << "Server: " << config.api_url << "\n\n";

    std::cout << "[init] " << std::flush;
    const StartupResult boot = manager.startup();

    if (!boot.init.ok) {
        std::cout << "[ERR] " << (boot.init.error.empty() ? boot.init.message : boot.init.error) << "\n";
        return 1;
    }

    if (boot.init.maintenance) {
        std::cout << "He thong dang bao tri.\n";
        if (!boot.init.contact.empty()) {
            std::cout << "Contact: " << boot.init.contact << "\n";
        }
        return 2;
    }

    std::cout << "[OK] Package hop le.\n";
    std::cout << "Device UUID: " << device.uuid() << "\n";

    if (boot.has_saved_key) {
        std::cout << "\n[saved key] kiem tra: ";
        print_check_result(boot.saved_check);
        if (boot.saved_check.ok) {
            return 0;
        }
        if (boot.saved_check.force_exit) {
            return 2;
        }
    }

    return prompt_and_activate(manager);
}
