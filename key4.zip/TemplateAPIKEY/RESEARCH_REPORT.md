# PASS 2 + PASS 3 — Research Sources Report

Ngày nghiên cứu: 2026-09-23. Phương pháp: web search engine + tải trực tiếp mã nguồn
thư viện từ canonical source (raw.githubusercontent.com / tweetnacl.cr.yp.to).

## A. Nguồn kiến trúc & pattern (chỉ tham khảo, không copy code)

| # | Source | URL | Purpose | License | Used? | Ghi chú |
|---|--------|-----|---------|---------|-------|---------|
| A1 | Keygen.sh — License API Reference | https://keygen.sh | Kiến trúc license server: licenses/machines(activation)/validation endpoints, machine fingerprint binding | AGPL-3.0 (product) | **Pattern only** | Tham khảo mô hình: activate gắn device, validate trả verdict server-side. KHÔNG copy code (license không tương thích) |
| A2 | OWASP SCS — SCWE-055 Missing Protection against Signature Replay | https://scs.owasp.org | Pattern chống replay: nonce single-use + timestamp window + signature | CC docs | Yes | Áp dụng: nonce table single-use + ±300s timestamp + HMAC request |
| A3 | OWASP MAS — MASTG-KNOW-0085 Anti-Debugging Detection | https://mas.owasp.org/MASTG/knowledge/ios/MASVS-RESILIENCE/MASTG-KNOW-0085/ | 4 kỹ thuật anti-debug iOS chuẩn: ptrace, sysctl, getppid, Mach Exception Ports | CC docs | Yes | Thiết kế AntiDebug engine theo đúng 4 signal chuẩn này |
| A4 | OWASP MAS — MASTG iOS Anti-Reversing Defenses (overview) | https://mas.owasp.org | Nguyên tắc: "preventing debugging is virtually impossible"; anti-debug là defense-in-depth, không phải security control | CC docs | Yes | Nguyên tắc thiết kế: fail-safe, không kill process, kết hợp với server authority |
| A5 | OWASP MAS — MASTG-KNOW-0090 Device Binding | https://mas.owasp.org | Pattern device binding + cân bằng privacy | CC docs | Yes | Device ID tối thiểu dữ liệu, không thu thập PII |
| A6 | Obfuscator-LLVM (Junio & Iadarola, IEEE paper + repos) | https://ieeexplore.ieee.org (paper), github.com/obfuscator-llvm | Control-flow flattening (-fla), bogus control flow (-bcf), instruction substitution (-sub), basic block splitting (-split) | NCSA/LLVM | **Research only** | Toolchain hiện tại (Apple clang / g++) không có pass này → báo NOT COMPATIBLE, chỉ thiết kế opt-in |
| A7 | VMProtect Software — markers & docs | https://vmpsoft.com/help/markers/ | SDK markers: VMProtectBeginVirtualization/BeginMutation/End | Commercial | **Research only** | VMProtect chỉ hỗ trợ Windows x86/x64 (+ Win-ARM cho Intel binary). KHÔNG hỗ trợ iOS/arm64 → integration = NOT SUPPORTED trên target |
| A8 | HashiCorp Vault — token lease & renewal pattern | https://discuss.hashicorp.com (Vault lease docs) | Mô hình lease ngắn hạn + renew trước khi hết hạn | BUSL docs | Yes | Session lease: cấp ngắn hạn, client renew theo chu kỳ |

## B. Thư viện crypto được vendor vào client (tải trực tiếp, đã kiểm chứng)

| # | Library | Source URL | License | Purpose | Reused | Rewritten |
|---|---------|-----------|---------|---------|--------|-----------|
| B1 | TweetNaCl | https://tweetnacl.cr.yp.to/20140427/tweetnacl.c (+ .h) | **Public Domain** | `crypto_auth` (HMAC-SHA-512-256) xác thực integrity request | Vendored nguyên văn 16.6KB | Không sửa lõi; chỉ thêm shim compile (extern "C", randombytes stub) |
| B2 | micro-ecc (uECC) | https://github.com/kmackay/micro-ecc (raw) | **BSD 2-clause** (Copyright 2014 Kenneth MacKay) | `uECC_verify` ECDSA P-256 — xác minh chữ ký server | Vendored nguyên văn (uECC.c/h, uECC_vli.h) | Không; chỉ define uECC_PLATFORM + disable RNG function |

Lý do chọn ECDSA P-256 thay vì Ed25519 (threat model + môi trường thực tế):
- Server PHP: `OPENSSL_ALGO_ED25519` KHÔNG tồn tại trong openssl_sign() của PHP
  (đã kiểm chứng thực tế trên PHP 8.4 + OpenSSL 3.6: keygen Ed25519 được nhưng
  không sign được; ext-sodium cũng không có trong phần lớn XAMPP shared host).
- ECDSA P-256 + SHA-256: 128-bit security, có sẵn 100% qua openssl_sign() PHP,
  verify client-side qua micro-ecc (được Google Pigweed third_party sử dụng).
- Envelope có trường `alg` → nâng cấp Ed25519 sau này không phá giao thức.

## C. Kiến thức nền tảng đã đối chiếu

| Chủ đề | Kết luận áp dụng vào thiết kế |
|--------|-------------------------------|
| Replay protection (OWASP) | Nonce single-use lưu DB + timestamp window + MAC request; replay → DENIED + security event |
| Canonical signing | Không ký JSON trực tiếp (field-order/whitespace ambiguity). Ký chuỗi canonical dạng length-prefixed "name:len:value" cố định thứ tự |
| Server-authoritative (game/license backend pattern) | Client chỉ render verdict có chữ ký; mọi quyết định expiry/device/limit tính trên server |
| Lease/session (Vault pattern) | Lease ngắn hạn (mặc định 600s), renew theo chu kỳ (lease/3), hết lease mà không renew được → AUTH_EXPIRED (không vô thời hạn) |
| Anti-debug (MASTG) | 4 signal chuẩn + aggregation NOT_DETECTED/DETECTED/CHECK_UNAVAILABLE/CHECK_ERROR; không abort(), không SIGKILL |
| VMProtect | Windows-only. Trên iOS: NOT SUPPORTED — wrapper biên dịch thành no-op có kiểm soát + report trung thực |
| OLLVM | Pass không có trong toolchain → NOT COMPATIBLE, chỉ thiết kế opt-in marker |

## D. Nguồn KHÔNG dùng (loại bỏ có chủ đích)

- Các repo crack/bypass VMProtect (vmpfix...): chỉ xuất hiện trong kết quả search,
  KHÔNG mở, KHÔNG dùng làm dependency — vi phạm yêu cầu đề bài.
- Keygen source code (AGPL): license không tương thích — chỉ đọc tài liệu API công khai.
- ADVobfuscator / string-encryption libs bên thứ ba: tự viết constexpr obfuscator
  tối giản (không phải crypto — chỉ chống grep chuỗi trong binary).
