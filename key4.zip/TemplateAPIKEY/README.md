# TemplateAPIKEY — License Key Server + C++ Client (V3)

Hệ thống quản lý license key: PHP + MySQL dashboard (admin/user), API xác thực
key **server-authoritative nhiều bước (V2 + V3)**, client C++17 thuần có
challenge-response, chữ ký ECDSA, session lease và **toàn bộ lớp bảo mật V3**:
anti-VPN/proxy, anti-dump, func-integrity (self-checksum), memory-integrity
(SecureVault canary), integrity report trong heartbeat MAC — tất cả TỰ KÍCH
HOẠT khi app khởi động, client chỉ báo cáo, **SERVER QUYẾT ĐỊNH TOÀN BỘ**.

---

## 1. Cấu trúc project

```
├── client/                        # Client C++17 (PASS 2 + 3)
│   ├── include/
│   │   ├── auth/                  # auth_state (state machine) + auth_pipeline + session
│   │   ├── crypto/                # canonical + mac (HMAC-SHA-512-256) + verifier (ECDSA P-256) + secure_random
│   │   ├── api/                   # api_client v2 (validate envelope đầy đủ)
│   │   ├── device/                # định danh thiết bị (privacy-conscious)
│   │   ├── protection/            # vmprotect + ollvm wrapper + anti_debug + anti_dump
│   │   │   │                       #   + anti_vpn + integrity (func/mem/vault)
│   │   │   │                       #   + security_state (monitor tổng hợp)
│   │   ├── nlohmann/json.hpp      # JSON parser (header-only)
│   │   ├── http.hpp / storage.hpp # abstraction transport + storage
│   │   └── config.hpp             # cấu hình tập trung (URL, token, pinned key)
│   ├── src/                       # mirror của include/ + http_socket/http_curl + storage_file
│   ├── vendor/                    # THƯ VIỆN CRYPTO AUDITED (nguyên vẹn, không sửa)
│   │   ├── tweetnacl/             # TweetNaCl — public domain (SHA-512 cho HMAC)
│   │   ├── micro-ecc/             # micro-ecc — BSD 2-clause (verify ECDSA P-256)
│   │   └── sha256/                # SHA-256 — public domain (băm trước verify)
│   ├── tests/                     # unit test 44 case + fixtures sinh bằng PHP
│   └── Makefile                   # 3 mode: debug / release / protected
├── server/
│   ├── lib/                       # LỎI PASS 2
│   │   ├── Crypto.php             # signing key ECDSA P-256 + canonical + sign
│   │   ├── AuthPipeline.php       # pipeline 14 stage (transaction + dry-run debug)
│   │   ├── SessionModel.php       # session/lease + HMAC request
│   │   ├── Nonce.php              # chống replay (single-use, TTL)
│   │   ├── RateLimit.php          # fixed-window, fail-open có kiểm soát
│   │   ├── Audit.php              # audit log + security events (che bí mật)
│   │   ├── KeyModel.php           # vòng đời key (active/suspended/revoked)
│   │   └── DeviceModel.php        # device binding (INSERT có điều kiện — chống race)
│   ├── api/
│   │   ├── auth.php               # V2: init + authenticate (envelope ký ECDSA)
│   │   ├── session.php            # V2: check / renew / revoke (MAC HMAC)
│   │   └── connect.php            # V1 legacy — vẫn chạy, giờ nhận biết revoked/suspended
│   ├── admin/                     # dashboard admin (+ security.php, audit.php mới)
│   ├── user/                      # dashboard user
│   ├── includes/                  # bootstrap, auth, settings, layout, helpers...
│   ├── storage/keys/              # signing key (0600 + .htaccess deny-all)
│   └── install.php / upgrade.php
└── database/database.sql          # 10 bảng + seed đầy đủ — import là chạy
```

## 2. Yêu cầu server

- PHP **7.4+** (`pdo_mysql`; `openssl` cho signing key; `mbstring` khuyến nghị — đã có polyfill)
- MySQL **5.7+** / MariaDB **10.3+**
- Apache (`.htaccess` tự chặn `/storage/`) hoặc Nginx (thêm `location /storage/ { deny all; }`)

## 3. Cài đặt

1. Upload nội dung thư mục `server/` lên web server.
2. Sửa `server/config.php`: `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`.
3. Mở `https://your-domain/install.php` — installer tạo 10 bảng, seed admin,
   sinh signing key ECDSA P-256 vào `server/storage/keys/` rồi tự khóa.
4. **Xóa `install.php` và `upgrade.php`** khỏi server sau khi cài.
5. Đăng nhập tại `https://your-domain/auth/login.php`.

> **Nâng cấp từ bản cũ**: upload code mới đè lên, mở `upgrade.php` MỘT lần —
> script tự ADD COLUMN `tbl_tokens.status`, `tbl_device_history.last_seen`,
> tạo 5 bảng V2 (sessions/nonces/security_events/audit_logs/rate_limits),
> seed cấu hình bảo mật, sinh signing key. Không đụng dữ liệu hiện có.

> Không dùng installer: import `database/database.sql` qua phpMyAdmin —
> file ĐẦY ĐỦ (schema + admin `khanhduy/khanhduy2010` + settings). Signing key
> tự sinh lần đầu API chạy (hoặc chạy upgrade.php một lần).

## 4. Tài khoản mặc định

| Trường   | Giá trị        |
|----------|----------------|
| Username | `khanhduy`     |
| Password | `khanhduy2010` |

Đổi mật khẩu ngay lần đăng nhập đầu tiên (Settings).

---

## 5. Key Validation V2 — cơ chế server-authoritative (PASS 2)

### 5.1 Nguyên tắc

Client **không bao giờ** tự quyết định key valid / expired / package active /
device authorized. Mọi verdict đến từ server dưới dạng **envelope JSON có chữ
ký ECDSA P-256**, client verify đầy đủ rồi mới tạo trạng thái authorized cục bộ.

### 5.2 Pipeline 14 stage (server — `lib/AuthPipeline.php`)

```
S01 Client initialization          (client)
S02 Configuration validation       schema + cửa sổ timestamp ±300s
S03 Package validation             tồn tại + không maintenance
S04 Key format validation          regex XXXX-XXXX-XXXX-XXXX
S05 Server-side key lookup         SELECT theo (code, project)
S06 Key status validation          active / suspended / revoked
S07 Expiry validation              SERVER là nguồn thời gian duy nhất
S08 Device binding validation      thiết bị đã biết / được phép mới
S09 Device limit validation        đếm < max_devices
S10 Session creation               TRANSACTION (FOR UPDATE + re-verify)
S11 Challenge/nonce validation     single-use nonce + MAC HMAC request
S12 Response authenticity          envelope ký ECDSA P-256
S13 Session/lease validation       tồn tại + active + chưa hết hạn
S14 Final authorization            re-validate toàn bộ rồi gia hạn lease
```

Stage thất bại bất kỳ → DENIED (fail-closed) + security event. KHÔNG có đường
tắt: "ok" chỉ được sinh sau khi mọi stage liên quan pass trong transaction.

### 5.3 Giao thức TAKEY-V2

**`POST /api/auth.php`** — `action=init`:
```json
{"proto":"TAKEY-V2","action":"init","req_id":"<hex>","nonce":"<hex>","ts":123,
 "package_token":"..."}
```
→ envelope: public key ECDSA, challenge single-use (TTL 600s), cấu hình lease.

**`POST /api/auth.php`** — `action=authenticate`:
thêm `key`, `device_id`, `challenge` (echo từ init) → envelope:
`session_id` + `session_secret` + `lease_expires` (600s mặc định) + hạn key.

**`POST /api/session.php`** — `action=check|renew|revoke`:
`session_id` + `mac` = HMAC-SHA-512-256 trên canonical của
`{action, nonce, req_id, session_id, ts}` với khóa `session_secret`
→ gia hạn lease (sau khi re-validate key/package/device đầy đủ).

**Mọi response** (kể cả lỗi) là envelope:
```json
{"proto":"TAKEY-V2","status":"ok|denied|error","code":"...",
 "data":{...},"meta":{"req_id":"<echo>","nonce":"<echo>","srv_nonce":"...","ts":"..."},
 "sig":"<hex ECDSA-P256 trên chuỗi canonical>","alg":"ecdsa-p256"}
```

**Chuỗi canonical** (PHP + C++ build giống hệt nhau — `TAKEY-SIG-1` +
length-prefixed fields sort theo tên) loại bỏ mọi ambiguity thứ tự/whitespace.

### 5.4 Chống replay

- Mỗi request phải mang `nonce` CSPRNG mới — server lưu SHA-256 với TTL,
  trùng → `replay_detected` (HTTP 409) + security event critical.
- Challenge từ `init` single-use: init → authenticate phải xong trong TTL.
- `meta.req_id`/`meta.nonce` echo — client đối chiếu, response cũ không
  gắn được vào request mới.

### 5.5 Chữ ký + lựa chọn thuật toán

ECDSA P-256 + SHA-256. Lý do (xem `research/RESEARCH_REPORT.md`): PHP
`openssl_sign()` không hỗ trợ Ed25519, ext-sodium thường không có trên shared
host; P-256 có sẵn 100% qua openssl và đủ 128-bit security. Envelope có trường
`alg` để nâng cấp sau không phá giao thức. **Private key chỉ nằm trên server**
(`storage/keys/signing_key.pem`, 0600, .htaccess deny) — client chỉ giữ public
key (compile-time pin hoặc TOFU có kiểm tra key-pinning).

### 5.6 Session lease + revalidation

Lease mặc định 600s. Client renew theo chu kỳ lease/3 (min 30s, backoff khi
lỗi mạng). Hết lease mà không renew được → `AUTH_EXPIRED` — **không** có
trạng thái authorized vô thời hạn. Lỗi mạng → `ERROR` (retry được), phân biệt
rõ với `DENIED` (server từ chối có chữ ký).

### 5.7 Device binding + giới hạn

- `device_id` do client sinh từ dữ liệu tối thiểu (privacy-conscious) hoặc
  host app tiêm (iOS: identifierForVendor).
- Server quyết định limit: `INSERT ... WHERE (SELECT COUNT(*)) < max` —
  nguyên tử, chống race ở slot cuối (test 6 request song song: đúng 1 thắng).
- 1 thiết bị giữ đúng 1 session active của 1 key.

### 5.8 Rate limiting + audit + security events

| Bucket | Ngưỡng mặc định |
|--------|-----------------|
| API v2 theo IP | 60/phút |
| authenticate theo key | 20/5 phút |
| session check theo session | 240/phút |
| đăng nhập (IP + username) | 8/5 phút |
| đăng ký theo IP | 5/giờ |
| legacy connect.php theo IP | 120/phút |

Đổi được trong Settings → Key Validation V2. Fail-open khi DB lỗi (đã ghi log).

- **Audit Logs** (admin): đăng nhập, CRUD key/package/user, suspend/revoke,
  debug key... Key bị che (`ABCD-…-MNOP`), không có hash/secret.
- **Security** (admin): xác thực thất bại, replay, MAC sai, vượt device limit,
  rate limit... filter Hôm nay / 7 ngày / 30 ngày / Tất cả + severity.
- **Key Debugging** (admin → Keys → ⚡): chạy pipeline ở chế độ dry-run —
  thấy từng stage ✓/✕ + lý do, KHÔNG ghi DB, KHÔNG tiêu nonce.

---

## 6. Client C++ — build & tích hợp

```bash
cd client
make                    # RELEASE (mặc định): mọi anti tự bật khi app dựng
                        #   AuthPipeline, obfuscation chuỗi bật
make MODE=debug         # DEBUG: anti-debug observe-only, symbol đầy đủ
make MODE=protected     # PROTECTED: mọi bảo vệ bật (VMProtect marker no-op
                        #   nếu không có SDK — báo trung thực, không giả vờ)
make CURL=1             # libcurl → HTTPS (khuyến nghị production)
make ollvm OLLVM_CXX=.. # OLLVM: obfuscate 12 TU nhạy cảm (probe toolchain)
make test               # 77 unit test (fixtures cross-language PHP + Python)
make clean
```

Cấu hình trong `client/include/config.hpp`:

```cpp
namespace cfg {
    constexpr const char* kAuthUrl      = "https://your-domain/api/auth.php";
    constexpr const char* kSessionUrl   = "https://your-domain/api/session.php";
    constexpr const char* kPackageToken = "<project_token>";
    constexpr const char* kServerPubKey = "";  // hex x||y 128 ký tự — pin khi build
}
```

Lấy public key: `openssl pkey -in storage/keys/signing_key.pem -pubout` hoặc
đọc `server_pub` từ response init. Bỏ trống = TOFU (ghi nhận lần đầu, khóa
các lần sau — đổi key server phải xóa storage client).

**Tích hợp vào app** (iOS/macOS/Linux): link mọi file trong `src/` trừ
`main.cpp`, tự hiện thực `IHttpTransport` (dùng URLSession của hệ thống nếu
muốn) và `IStorage` (Keychain...), rồi:

```cpp
AuthPipeline pipeline(config, *transport, *device, *storage);
auto snap = pipeline.authorize(key);          // init → authenticate → session
if (snap.authorized(time(nullptr))) { ... }   // state + lease + security OK
```

Client KHÔNG có hàm `bool isKeyValid()` — trạng thái authorized là kết quả
của pipeline (verdict có chữ ký + lease còn hạn + security state sạch),
không thể set tay từ bên ngoài (state machine chặn mọi transition bất hợp lệ,
kể cả START → AUTHORIZED).

## 7. Bảo mật client (PASS 3)

### Anti-debug (theo OWASP MASTG-KNOW-0085)

4 nhóm tín hiệu độc lập + aggregation:

| Tín hiệu | Nền tảng | Mức |
|----------|----------|-----|
| sysctl `KERN_PROC` P_TRACED | Darwin | MẠNH |
| Mach exception ports | Darwin | MẠNH |
| `/proc/self/status` TracerPid | Linux | MẠNH |
| `getppid() != 1` | iOS (không simulator) | YẾU |
| `DYLD_INSERT_LIBRARIES`... env | mọi nền | YẾU |

- Mỗi check trả `NOT_DETECTED / DETECTED / UNAVAILABLE / ERROR` — API lỗi
  KHÔNG bị coi là debugger (chống false positive).
- MẠNH DETECTED → `DEBUGGED`; chỉ YẾU → `SUSPICIOUS` (vẫn cho chạy, ghi nhận).
- Phát hiện → **authorization bị từ chối qua SecurityState tập trung** —
  KHÔNG có `exit()/abort()/kill()` ở bất kỳ đâu.
- Throttle 5s, chạy lúc startup + trước authenticate + theo chu kỳ revalidation.
- Không dùng `PT_DENY_ATTACH` (syscall không công khai — vi phạm nguyên tắc
  không private API và phá debug bản dev).

### VMProtect

VMProtect chỉ hỗ trợ Windows x86/x64 (không có iOS/arm64). Wrapper
`include/protection/vmprotect.hpp` biên dịch marker thành **no-op có kiểm soát**
và `vmprotect_status()` báo đúng "not-active". Trên Windows build thật:
`make MODE=protected TAKEY_VMPROTECT_SDK=1` (đặt VMProtectSDK.h vào include
path, link VMProtectSDK.lib) rồi xử lý binary qua VMProtect.

### LLVM obfuscation

Toolchain hiện tại không có pass (-fla/-bcf/-sub/-split) → **NOT COMPATIBLE**,
không cố ép. Các điểm mark `TAKEY_VMP_*` đã tổ chức theo function để khi đổi
sang toolchain OLLVM chỉ cần bật pass cho vùng nhạy cảm.

### Obfuscated strings

`TAKEY_OBF("...")` che chuỗi khỏi `strings` binary bằng keystream constexpr —
đây là **obfuscation, không phải mã hóa** (không dùng cho bí mật thật; private
key server không bao giờ nằm trong client).

## 7b. Bảo mật client V3 — TOÀN BỘ LỚP BẢO MẬT CÒN THIẾU (AUTO + SERVER-DECIDES)

> Nguyên tắc nền tảng (giữ nguyên triết lý V2): client **KHÔNG TỰ QUYẾT ĐỊNH**
> — client tổng hợp + báo cáo, **SERVER đọc report và phán quyết**. Mọi lớp
> dưới đây TỰ KÍCH HOẠT khi `AuthPipeline` được dựng (constructor gọi
> `SecurityMonitor::prime()`) — không cần nhấn bất kỳ nút nào.

### 7b.1 Anti-VPN/Proxy (ưu tiên cao nhất — quét ĐẦU TIÊN)

| Tín hiệu | Nền tảng | Mức |
|----------|----------|-----|
| Env `HTTP_PROXY/HTTPS_PROXY/ALL_PROXY` (cả lowercase) | Unix | DETECTED |
| Proxy loopback `127.0.0.1` (Charles/mitmproxy/Proxyman) | Unix | DETECTED |
| Interface tunnel `tun/tap/ppp/wg/vtun/utun/ipsec` | Linux + Apple | DETECTED |
| System proxy `scutil --proxy` | chỉ macOS | DETECTED |
| `no_proxy="*"` (người dùng tắt chủ động) | Unix | KHÔNG oan |

→ `sec_vpn=1` vào mọi request. Server: `security_block_vpn` (mặc định **1** = chặn).

### 7b.2 Anti-Dump (chống đóng băng + dump bộ nhớ)

| Tín hiệu | Cơ chế | Mức |
|----------|--------|-----|
| Watchdog staleness | Thread đập nhịp 500ms bằng CLOCK_MONOTONIC — bị SIGSTOP (gcore/procdump đóng băng tiến trình) thì mono vẫn chạy → nhịp "cũ" phình to. Laptop ngủ (system suspend) KHÔNG bị oan vì mono dừng theo hệ điều hành | >5s suspicious, >60s DETECTED |
| RLIMIT_CORE > 0 | core dump bật khi crash | YẾU |
| `LD_PRELOAD/LD_DEBUG/DYLD_*` | vector inject | YẾU |
| SecureVault | key/session_secret XOR keystream + canary tại chỗ → dump memory không grep ra secret | nền cho sec_mem |

→ `sec_dump=0/1/2`. Server: `security_block_tamper` (mặc định 1).

### 7b.3 FuncIntegrity (chống patch hàm runtime — NOP verify là vô dụng)

Baseline self-checksum **6 hàm lõi** bằng SHA-256 ngay khi tiến trình khởi động
(trước khi kẻ tấn công kịp patch runtime): `verify_server_signature`,
`mac_hex`, `canonical`, `validate_envelope`, `can_transition`,
`security_level_name`. Mỗi lần check: đọc lại bytes code (safe-read qua
`/proc/self/maps` hoặc `mach_vm_region` — không bao giờ crash) so baseline.

→ `sec_func=N` (số hàm bị patch). Patch runtime bất kỳ hàm nào → server cắt
session ngay ở heartbeat kế tiếp (chu kỳ lease/3).

### 7b.4 MemoryIntegrity (canary + quét vùng nhớ)

- **SecureVault**: `[canary|data^keystream|keystream|canary]` trong 1 cấp
  phát — canary vỡ = buffer overrun/tamper → sec_mem=2. Lưu ý trung thực:
  XOR keystream là OBFUSCATION (chống grep trong dump), không phải mã hóa.
- **Quét mapping**: region RWX mới xuất hiện sau baseline (Frida gadget,
  injected code) → sec_mem=1.
- **Quét thư viện nạp**: `frida/gum-js/substrate/cycript/r2frida` trong
  `/proc/self/maps` (Linux) hoặc `_dyld_image_count` (Apple — API công khai
  dùng được cả iOS) → sec_mem=2.

### 7b.5 Integrity report trong heartbeat MAC — XƯƠNG SỐNG V3

```
Client (mỗi session request):
  sec_dbg, sec_dump, sec_func, sec_mem, sec_vpn, sec_ctr
      ↓ đưa vào canonical MAC (11 trường)
  MAC = HMAC-SHA-512-256(canonical, session_secret)

Server (AuthPipeline.php — S13b, sau khi verify MAC):
  - report sai định dạng       → security_violation + REVOKE session
  - vpn + security_block_vpn   → security_violation + REVOKE
  - debug/dump/tamper + block  → security_violation + REVOKE
  - report sạch                → renew lease
```

Tại sao KHÔNG THỂ strip report: các trường sec_* nằm TRONG chuỗi canonical
của MAC → gỡ/sửa report làm MAC sai → server DENY `mac_invalid`. Tính lại
MAC đòi hỏi session_secret — nằm trong SecureVault (obfuscated + canary) và
dump memory cũng không grep ra được. 3 lớp phủ nhau.

Chu kỳ phán quyết: lease/3 (mặc định 200s với lease 600s) — client xấu bị
cắt tối đa sau ~200s + revoke tức thì.

### 7b.6 OLLVM pipeline (obfuscation thật khi có toolchain)

```bash
# Build obfuscator-llvm / Hikari trên máy CI, rồi:
make ollvm OLLVM_CXX=/path/to/obfuscator-clang++
# → probe toolchain TRƯỚC (không có pass → báo lỗi, không build lặng lẽ)
# → 12 TU nhạy cảm (crypto/verify/auth/protection) compile với:
#    -fla (flattening) -bcf (bogus flow) -sub (substitution) -split
# → binary chạy: dòng "OLLVM : ACTIVE" (ollvm_status trung thực)
```

Makefile dùng target-specific variables: chỉ các .o nhạy cảm qua OLLVM_CXX,
phần còn lại build bình thường (nhanh). Per-function (Hikari): marker
`TAKEY_OBF_FUNC` = `__attribute__((annotate("fla bcf")))`.

### 7b.7 Cấu hình policy phía server (tbl_settings)

| Setting | Mặc định | Ý nghĩa |
|---------|----------|---------|
| `security_block_vpn` | 1 | chặn client phát hiện VPN/proxy |
| `security_block_debug` | 1 | chặn client bị debugger |
| `security_block_tamper` | 1 | chặn dump-signature/hàm patch/canary vỡ |
| `security_require_report` | 0 | =1 thì từ chối client cũ không gửi report |

Tất cả đổi được trong DB (hoặc chạy upgrade.php một lần để seed). Mỗi lần
chặn: `security_event('auth.client_integrity', 'critical', ...)` hiện trên
trang Security của admin dashboard.

### 7b.8 Backward-compat

- Client cũ (không sec_*): MAC 5 trường y nguyên → cho qua (hoặc bật
  `security_require_report=1` để ép nâng cấp).
- Client mới ↔ server cũ: server cũ tính MAC 5 trường, client gửi 11 →
  MAC mismatch → CẢ HAI BÊN PHẢI NÂNG CẤP CÙNG LÚC (đã ghi rõ ở upgrade).

## 8. API legacy (v1)

`GET /api/connect.php?action=init|check` vẫn hoạt động y nguyên cho client cũ,
giờ bổ sung: tôn trọng `status` (revoked/suspended bị từ chối), rate limit
120/phút/IP. Khuyến nghị migrate sang V2.

## 9. Mô hình dữ liệu (V2)

| Bảng | Vai trò |
|------|---------|
| `tbl_users` | MỌI tài khoản: `role` (admin/user), hạn mức riêng |
| `tbl_settings` | Cấu hình: hạn mức, đăng ký, lease/drift/TTL, rate limit |
| `tbl_projects` | Package: token CSPRNG, `owner_id` |
| `tbl_tokens` | Key: static/dynamic, **`status` (active/suspended/revoked)** |
| `tbl_device_history` | UUID thiết bị + `first_used` + `last_seen` |
| `tbl_sessions` | Session/lease V2: secret HMAC, expires, status |
| `tbl_nonces` | Nonce đã dùng (SHA-256) + scope + TTL |
| `tbl_security_events` | Sự kiện bảo mật (trang Security) |
| `tbl_audit_logs` | Hành vi quản trị (trang Audit Logs) |
| `tbl_rate_limits` | Bộ đếm fixed-window |

## 10. Cơ chế tài khoản & hạn mức

- **Một nơi đăng nhập chung** — admin/user phân vai theo `role`.
- **Admin toàn quyền**: mọi package/key/thiết bị, quản lý user (role, hạn mức,
  reset mật khẩu, ban, xóa), cấu hình hệ thống. Không bị hạn mức.
- **User tự tạo package + key** trong hạn mức `max_packages`/`max_keys`
  (NULL = mặc định hệ thống 3/10; 0 = cấm).
- **Tách dữ liệu**: mọi query kèm `owner_id`/`user_id`; vào link admin bị đá.
- **Ban hiệu lực tức thì** (session bị hủy ở request kế tiếp).

## 11. Bảo mật nền (Pass 1 — giữ nguyên)

- SQL injection: 100% prepared statements (PDO)
- XSS: `e()` (htmlspecialchars) ở mọi output · CSRF: token session-bound
- Session: `session_regenerate_id(true)`, httponly + samesite
- Password: bcrypt qua `password_hash()`
- Token: CSPRNG `random_bytes()` — không bao giờ `str_shuffle()`
- Installer tự khóa + kiểm tra bảng trống

## 12. Kiểm thử

| Bộ test | Kết quả |
|---------|---------|
| Unit C++ (77 case: 44 gốc + 33 V3 — anti-VPN/dump/integrity/vault/MAC mở rộng) | 77/77 |
| MAC mở rộng cross-language (C++ ↔ Python bên thứ 3, 11 trường canonical) | 6/6 kịch bản |
| E2E V3 qua HTTP thật (client C++ ↔ mock server ECDSA-P256, scripts/run_v3_e2e.py) | 4/4 kịch bản |
| E2E API (ma trận spec 22 case + regression dashboard) | 50/50 |
| E2E client C++ ↔ PHP server thật (authorize/restore/revoke/mạng chết) | 12/12 |
| `php -l` toàn bộ 38 file PHP | PASS |
| Balance-check toàn bộ file PHP sau V3 (state machine) | 14/14 OK |

Lỗi đã tìm và sửa nhờ test: session giữ watermark (mac + echo), challenge
aliasing, `data:{}` thay `[]`, bin2hex public key, storage đọc nhiều dòng,
transition Error→Revalidating, race device slot cuối.

## 13. Known limitations (trung thực)

- Mọi lớp client (anti-debug/anti-dump/integrity) đều là **defense-in-depth**,
  không phải lớp bảo vệ tuyệt đối (MASTG: "preventing debugging is virtually
  impossible") — bị bypass bởi kẻ đủ quyết tâm. Điểm neo đúng: **server quyết
  định qua heartbeat MAC**, client xấu bị cắt tối đa sau 1 chu kỳ lease/3.
- FuncIntegrity phát hiện patch RUNTIME (sau baseline). Patch tĩnh binary
  trước khi chạy → server verdict vẫn là lớp cuối (không có gì client-side
  chống được patch tĩnh + re-sign).
- VMProtect/OLLVM KHÔNG khả dụng ngay trên toolchain mặc định — OLLVM cần
  build toolchain riêng (`make ollvm OLLVM_CXX=...`, probe trung thực).
- Anti-VPN client-side là tín hiệu môi trường (env/interface) — VPN mức
  router/transparent proxy không thấy được từ client. Cân nhắc check IP
  bên server (ASN/reputation) cho tầng đó.
- Device ID không phải hardware-attested — user xoá storage sẽ đếm là thiết bị
  mới (vẫn bị chặn bởi max_devices + giới hạn session đồng thời).
- TOFU pinning yếu hơn compile-time pinning — production nên set `kServerPubKey`.
- Session revoke có độ trễ tối đa bằng lease còn lại nếu client offline.
- Rate limit fail-open khi DB lỗi (đánh đổi availability, có log).
- SecureVault XOR keystream = obfuscation (chống grep), không phải mã hóa thật.
