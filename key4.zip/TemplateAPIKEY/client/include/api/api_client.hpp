#pragma once

#include <map>
#include <string>

#include "config.hpp"
#include "http.hpp"

/*
 * ApiClient V2 — client giao thức TAKEY-V2 (server-authoritative).
 *
 * Client KHÔNG BAO GIỜ tự quyết định: key valid / expired / package active /
 * device authorized / subscription active. Mọi verdict đến từ server qua
 * envelope có chữ ký ECDSA P-256, được verify đầy đủ trước khi chấp nhận
 * (spec mục 2 + 13).
 *
 * Phân loại lỗi rõ ràng (spec mục 12):
 *   OK               — envelope hợp lệ + server xác nhận
 *   DENIED           — server từ chối (verdict có chữ ký)
 *   AUTH_EXPIRED     — session hết lease (server xác nhận)
 *   NETWORK_ERROR    — không kết nối được (KHÔNG được coi là denied)
 *   SERVER_ERROR     — HTTP 5xx
 *   INVALID_RESPONSE — body rác / thiếu trường / sai echo / lệch timestamp
 *   CRYPTO_ERROR     — chữ ký không verify được
 */
namespace api {

enum class Status {
    OK,
    DENIED,
    AUTH_EXPIRED,
    NETWORK_ERROR,
    SERVER_ERROR,
    INVALID_RESPONSE,
    CRYPTO_ERROR,
};

const char* status_name(Status s);

struct Result {
    Status       status = Status::NETWORK_ERROR;
    std::string  code;                    /* mã máy của server (ok, key_expired...) */
    std::string  error;                   /* chi tiết lỗi phía client */
    std::map<std::string, std::string> data;

    bool ok() const { return status == Status::OK; }
};

}  // namespace api

class ApiClientV2 {
public:
    ApiClientV2(const Config& config, IHttpTransport& transport);

    /* action=init → server hello: public key + challenge + cấu hình. */
    api::Result init(std::string& out_challenge,
                     std::string& out_server_pub,
                     std::string& out_contact,
                     bool& out_maintenance);

    /* action=authenticate → pipeline đầy đủ → session + lease.
     * sec_fields (tùy chọn): security report từ SecurityMonitor::report()
     * — đưa vào body request để server áp policy từ lúc cấp session. */
    api::Result authenticate(const std::string& key,
                             const std::string& device_id,
                             const std::string& challenge,
                             std::map<std::string, std::string>& out_data,
                             const std::map<std::string, std::string>& sec_fields
                                 = std::map<std::string, std::string>());

    /* action=check/renew/revoke → session request có MAC.
     *
     * V3 — INTEGRITY REPORT TRONG HEARTBEAT MAC (xương sống server-authoritative):
     * sec_fields nằm TRONG chuỗi canonical của MAC → không thể strip/sửa nếu
     * không có session_secret. Server verify MAC rồi đọc report để quyết
     * định DENY/cho phép (policy security_block_* trong tbl_settings).
     * Client KHÔNG tự quyết định — chỉ báo cáo trung thực. */
    api::Result session_request(const std::string& action,
                                const std::string& session_id,
                                const std::string& session_secret,
                                std::map<std::string, std::string>& out_data,
                                const std::map<std::string, std::string>& sec_fields
                                    = std::map<std::string, std::string>());

    /* Public key server đang dùng (đã pin hoặc mới học từ init). */
    const std::string& server_public_key() const { return server_pub_; }
    void set_server_public_key(const std::string& hex) { server_pub_ = hex; }

private:
    api::Result post_json(const std::string& url, const std::string& body);

    Config          config_;
    IHttpTransport& transport_;
    std::string     server_pub_;
};

/* Helper nội bộ dùng chung (unit test tái dùng): validate envelope JSON. */
api::Result validate_envelope(const std::string& body,
                              const std::string& content_type,
                              long http_status,
                              const std::string& expected_req_id,
                              const std::string& expected_nonce,
                              int max_drift,
                              const std::string& server_pub_hex,
                              std::map<std::string, std::string>& out_data);
