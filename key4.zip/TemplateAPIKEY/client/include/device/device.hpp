#pragma once

#include <string>

/*
 * Abstraction cho định danh thiết bị.
 *
 * Lưu ý nền tảng (iOS): C++ thuần KHÔNG thể đọc identifierForVendor /
 * UDID vì đây là API UIKit. Host app phải lấy UUID ở tầng app rồi tiêm
 * vào bằng FixedDeviceIdentity — đây là ranh giới được khai báo rõ,
 * không cố "bọc" Objective-C bên trong thư viện C++.
 */
class IDeviceIdentity {
public:
    virtual ~IDeviceIdentity() = default;
    virtual std::string uuid() = 0;
};

/* UUID cố định do host app cung cấp. */
class FixedDeviceIdentity final : public IDeviceIdentity {
public:
    explicit FixedDeviceIdentity(std::string uuid) : uuid_(std::move(uuid)) {}
    std::string uuid() override { return uuid_; }

private:
    std::string uuid_;
};

/*
 * UUID ổn định suy ra từ máy đang chạy:
 *   Linux : /etc/machine-id
 *   macOS : IOPlatformUUID (qua ioreg, không dùng framework riêng)
 *   Fallback: địa chỉ MAC của interface đầu tiên khác loopback.
 */
class DefaultDeviceIdentity final : public IDeviceIdentity {
public:
    std::string uuid() override;
};
