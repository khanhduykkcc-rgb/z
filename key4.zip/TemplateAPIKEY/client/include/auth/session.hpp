#pragma once

#include <string>

/*
 * Session — lease ngắn hạn do server cấp sau khi key được xác thực
 * đầy đủ (spec mục 10-11).
 *
 * Client KHÔNG THỂ tự tạo session hợp lệ: session_id + session_secret
 * chỉ đến từ envelope có chữ ký của server.
 *
 * Lease hết hạn mà không renew được → authorize hết hiệu lực
 * (không có trạng thái authorized vô thời hạn).
 */
namespace auth {

struct Session {
    std::string id;            /* 64 hex — session_id */
    std::string secret;        /* 64 hex — khóa HMAC cho request */
    long        lease_expires  = 0;  /* unix time */
    long        key_expires    = 0;  /* unix time — 0 nếu không biết */
    std::string key_type;
    int         days_left      = 0;
    std::string contact;

    bool valid() const { return !id.empty() && !secret.empty(); }

    /* Còn lease không (kèm biên an toàn 5s để tránh đua đồng hồ)?
     * valid_secret: pipeline dùng vault — secret rỗng trong struct vẫn
     * hợp lệ khi vault còn giữ secret thật. */
    bool valid_with_secret(bool has_secret) const { return !id.empty() && has_secret; }
    bool lease_active(long now) const { return valid() && now < lease_expires - 5; }
    bool lease_active_with(long now, bool has_secret) const {
        return valid_with_secret(has_secret) && now < lease_expires - 5;
    }

    /* Serialize sang/dạng key=value để lưu storage (0600).
     * secret_override: khi pipeline giữ secret trong SecureVault, secret
     * trong struct bị wipe — serialize vẫn cần ghi secret ra storage. */
    std::string serialize() const;
    std::string serialize(const std::string& secret_override) const;
    static Session deserialize(const std::string& blob);
};

/* Parse "YYYY-MM-DD HH:MM:SS" của server → unix time (giả định cùng timezone
 * hệ thống — server ghi giờ local PHP date()). Trả về 0 nếu lỗi. */
long parse_server_datetime(const std::string& value);

}  // namespace auth
