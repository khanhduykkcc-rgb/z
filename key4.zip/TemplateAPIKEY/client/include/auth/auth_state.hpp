#pragma once

#include <string>
#include <vector>

/*
 * AuthState — state machine có kiểm soát (spec mục 4).
 *
 * KHÔNG có đường tắt START → AUTHORIZED. Transition chỉ diễn ra qua
 * bảng chuyển hợp lệ trong auth_state.cpp, và CHỈ AuthPipeline (friend)
 * mới chuyển được trạng thái — code bên ngoài không thể tự set
 * state = AUTHORIZED.
 *
 * Mapping stage server (S01-S14) → trạng thái client:
 *   START            — chưa làm gì
 *   INITIALIZING     — S01 client initialization
 *   HELLO_OK         — init verified (package + public key + challenge)
 *   REQUESTING       — authenticate/check đang bay trên mạng
 *   SESSION_CREATED  — S10 xong phía server (verdict có chữ ký)
 *   AUTHORIZED       — S12+S14 pass + security state OK + lease còn hạn
 *   REVALIDATING     — đang renew lease
 *   DENIED           — server từ chối (verdict có chữ ký)
 *   AUTH_EXPIRED     — hết lease, chưa renew lại được
 *   ERROR            — lỗi transient (mạng/server/response) — thử lại được
 */
namespace auth {

enum class State {
    Start,
    Initializing,
    HelloOk,
    Requesting,
    SessionCreated,
    Authorized,
    Revalidating,
    Denied,
    AuthExpired,
    Error,
};

const char* state_name(State s);

/* Một cột mốc trong trace — phục vụ debug và dashboard Key Debugging. */
struct StageMark {
    int         stage;   /* S01..S14 */
    std::string label;
    bool        ok      = false;
    std::string reason;
};

/* Snapshot bất biến của trạng thái — application ĐỌC, không sửa.
 * authorized() là kết quả tổng hợp: state + lease + security,
 * KHÔNG phải cờ tự do set được. */
struct Snapshot {
    State                state = State::Start;
    std::vector<StageMark> stages;
    std::string          last_code;    /* mã máy gần nhất của server */
    std::string          last_error;   /* lỗi client gần nhất */
    bool                 security_ok  = true;  /* anti-debug pass */
    long                 lease_expires = 0;
    long                 key_expires   = 0;
    int                  days_left     = 0;
    std::string          contact;

    /* Điều kiện authorized: state đúng + security ok + lease còn hạn.
     * Biên an toàn 5s nằm trong Session::lease_active(). */
    bool authorized(long now) const {
        return state == State::Authorized && security_ok
            && lease_expires != 0 && now < lease_expires - 5;
    }
};

}  // namespace auth
