#pragma once

#include <atomic>
#include <condition_variable>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "api/api_client.hpp"
#include "auth/auth_state.hpp"
#include "auth/session.hpp"
#include "device/device.hpp"
#include "http.hpp"
#include "protection/integrity.hpp"
#include "protection/security_state.hpp"
#include "storage.hpp"

/*
 * AuthPipeline — điều phối toàn bộ vòng đời xác thực phía client (PASS 2 + V3).
 *
 * KHÔNG tồn tại hàm bool isKeyValid() để mọi nơi gọi. Thay vào đó:
 *   - Trạng thái authorization là KẾT QUẢ của pipeline:
 *       server verdict (có chữ ký) + session lease + security state.
 *   - Application đọc snapshot() và kiểm tra authorized(now).
 *   - Không ai ngoài pipeline chuyển được trạng thái (AuthStateMachine
 *     chỉ cho phép các đường đi hợp lệ — không có START → AUTHORIZED).
 *
 * V3 — TỰ ĐỘNG HÓA & SERVER-AUTHORITATIVE TOÀN DIỆN:
 *   - Constructor gọi SecurityMonitor::prime() → TOÀN BỘ lớp bảo mật
 *     (anti-VPN, anti-debug, anti-dump, func-integrity, memory-integrity,
 *     watchdog) tự kích hoạt NGAY khi app dựng pipeline — không cần thao
 *     tác nhấn nào.
 *   - MỌI request gửi đi đều kèm security report (sec_*). Riêng session
 *     request: report nằm TRONG MAC → không thể strip. SERVER quyết định.
 *   - Session secret + license key giữ trong SecureVault (obfuscate +
 *     canary tại chỗ) — memory dump không grep ra được.
 *
 * Revalidation: thread nền renew lease theo chu kỳ lease/3 (tối thiểu 30s).
 * Hết lease mà không renew được → AUTH_EXPIRED. Lỗi mạng → ERROR/REVALIDATING
 * (không bao giờ coi network error là denied — spec mục 12).
 */
class AuthPipeline {
public:
    AuthPipeline(const Config& config,
                 IHttpTransport& transport,
                 IDeviceIdentity& device,
                 IStorage& storage);
    ~AuthPipeline();

    AuthPipeline(const AuthPipeline&) = delete;
    AuthPipeline& operator=(const AuthPipeline&) = delete;

    /* Kích hoạt: init → authenticate → session → AUTHORIZED.
     * Trả về trạng thái cuối sau khi chạy. Thread-safe. */
    auth::Snapshot authorize(const std::string& key);

    /* Khôi phục session từ storage (nếu lease còn) — không cần key lại. */
    auth::Snapshot restore();

    /* Snapshot hiện tại (thread-safe, không chặn lâu). */
    auth::Snapshot snapshot();

    /* Chủ động thu hồi session (logout app). */
    void logout();

    /* Bật/dỡ vòng revalidation nền (mặc định bật sau authorize thành công). */
    void start_revalidation();
    void stop_revalidation();

    /* Security report hiện tại (sec_*) — để app hiển thị/debug. */
    std::map<std::string, std::string> security_report();

private:
    void set_state(auth::State to, const std::string& code, const std::string& error);
    void mark(int stage, const std::string& label, bool ok, const std::string& reason);
    void save_session();
    void clear_session();
    void revalidation_loop();

    /* Lấy secret từ vault (wipe bản copy sau khi xài). */
    bool vault_secret(std::string& out) const;
    void vault_set_secret(const std::string& secret);

    Config                    config_;
    ApiClientV2               api_;
    IDeviceIdentity&          device_;
    IStorage&                 storage_;
    Protection::SecurityMonitor& security_;

    Protection::SecureVault   vault_;    /* key + session_secret at-rest-in-memory */

    std::mutex                mutex_;
    auth::Snapshot            snap_;
    auth::Session             session_;  /* secret trong struct LUÔN rỗng — vault giữ */
    std::string               key_;      /* wipe sau khi dùng — vault giữ bản obfuscated */

    std::thread               worker_;
    std::mutex                wake_mutex_;
    std::condition_variable   wake_;
    std::atomic<bool>         running_{false};
    std::atomic<bool>         stop_requested_{false};
};

/* Đóng gói state machine — public chỉ để auth_state.cpp định nghĩa bảng
 * transition; mọi thao tác qua AuthPipeline. */
namespace auth {
struct AuthStateMachine {
    static bool can_transition(State from, State to);
    static const char* illegal_message(State from, State to);
};
}  // namespace auth
