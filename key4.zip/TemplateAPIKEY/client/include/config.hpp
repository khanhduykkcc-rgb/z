#pragma once

#include <algorithm>
#include <cstdlib>
#include <string>

/*
 * Cấu hình client V2 — thay đổi các hằng số này trước khi build.
 * Không rải URL/token qua nhiều file: mọi module đều đọc từ đây.
 *
 * kServerPublicKey: hex x||y (128 ký tự) của signing key ECDSA P-256 server.
 *   - Đặt sẵn (pin khi build) = an toàn nhất — lấy từ init lần đầu hoặc
 *     hỏi admin (server/storage/keys/signing_key.pem → openssl pkey -in ... -pubout).
 *   - Để trống "" = chế độ TOFU (Trust On First Use): khóa nhận ở init
 *     đầu tiên được ghi vào file storage và khóa lại các lần sau.
 */
namespace cfg {

constexpr const char* kAuthUrl       = "http://YOUR_DOMAIN/api/auth.php";
constexpr const char* kSessionUrl    = "http://YOUR_DOMAIN/api/session.php";
constexpr const char* kPackageToken  = "YOUR_PACKAGE_TOKEN";
constexpr const char* kStorageFile   = ".license_session";
constexpr const char* kServerPubKey  = "";
constexpr int         kTimeoutSecs   = 15;
constexpr int         kMaxClockDrift = 300;   /* giây — khớp server default */

}  // namespace cfg

/* Config runtime — cho phép host app override sau khi dựng thư viện.
 *
 * Env override (TAKEY_AUTH_URL / TAKEY_SESSION_URL / TAKEY_PACKAGE_TOKEN /
 * TAKEY_SERVER_PUB): chỉ dùng cho DEMO + E2E test. Production nên hardcode
 * hằng số ở trên — đặt TAKEY_SERVER_PUB khi dùng env để tránh TOFU vào
 * server giả. */
struct Config {
    std::string auth_url;
    std::string session_url;
    std::string package_token;
    std::string storage_path;
    std::string pinned_server_pub;   /* hex x||y hoặc "" = TOFU */
    int         timeout_seconds;
    int         max_clock_drift;

    static Config defaults() {
        auto env = [](const char* name, const std::string& fallback) {
            const char* v = std::getenv(name);
            return (v != nullptr && *v != '\0') ? std::string(v) : fallback;
        };

        Config c{
            env("TAKEY_AUTH_URL", cfg::kAuthUrl),
            env("TAKEY_SESSION_URL", cfg::kSessionUrl),
            env("TAKEY_PACKAGE_TOKEN", cfg::kPackageToken),
            env("TAKEY_STORAGE", cfg::kStorageFile),
            env("TAKEY_SERVER_PUB", cfg::kServerPubKey),
            cfg::kTimeoutSecs,
            cfg::kMaxClockDrift,
        };
        if (const char* t = std::getenv("TAKEY_TIMEOUT")) {
            c.timeout_seconds = std::max(1, std::atoi(t));
        }
        return c;
    }
};
