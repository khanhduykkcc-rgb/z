#pragma once

#include <memory>
#include <string>

struct HttpResponse {
    long        status       = 0;
    std::string body;
    std::string content_type;  /* header Content-Type (đối chiếu spec 13) */

    bool ok() const { return status >= 200 && status < 300; }
};

/*
 * Abstraction cho tầng HTTP — client core không phụ thuộc thư viện mạng.
 *
 * Hai hiện thực đi kèm:
 *   - http_socket.cpp : POSIX socket, HTTP, không dependency (mặc định)
 *   - http_curl.cpp   : libcurl, hỗ trợ HTTPS (build với: make CURL=1)
 *
 * Host app (VD: app iOS/tweak) có thể tự hiện thực giao diện này để
 * dùng transport của hệ thống, sau đó tiêm vào ApiClient.
 */
class IHttpTransport {
public:
    virtual ~IHttpTransport() = default;

    /* GET một URL. Ném std::runtime_error khi lỗi mạng/timeout. */
    virtual HttpResponse get(const std::string& url, int timeout_seconds) = 0;

    /* POST body thô với content-type (VD: application/json).
     * Ném std::runtime_error khi lỗi mạng/timeout. */
    virtual HttpResponse post(const std::string& url,
                              const std::string& body,
                              const std::string& content_type,
                              int timeout_seconds) = 0;
};

std::unique_ptr<IHttpTransport> create_socket_transport();
std::unique_ptr<IHttpTransport> create_curl_transport();

/* Factory mặc định — file nguồn nào được link sẽ quyết định backend. */
std::unique_ptr<IHttpTransport> create_default_transport();
