#pragma once

#include <cstddef>
#include <string>
#include <vector>

/*
 * Hex helpers — chỉ là ENCODING, không phải mã hóa.
 * (base64/hex không bao giờ được coi là bảo mật — spec mục 19)
 */
namespace crypto {

std::string hex_encode(const unsigned char* data, std::size_t len);
std::string hex_encode(const std::string& raw);

/* Giải mã hex (case-insensitive). Trả về rỗng nếu input không hợp lệ. */
std::vector<unsigned char> hex_decode(const std::string& hex);

bool is_hex(const std::string& value);

}  // namespace crypto
