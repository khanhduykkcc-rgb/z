#pragma once

#include <string>

/*
 * Verifier — xác minh chữ ký ECDSA P-256 + SHA-256 của server (spec mục 6).
 *
 * Server ký bằng openssl_sign(..., OPENSSL_ALGO_SHA256) → chữ ký DER
 * (SEQUENCE{ INTEGER r, INTEGER s }). Client:
 *   1. SHA-256 canonical message (vendored, public domain — B-Con)
 *   2. Parse DER → r||s 64 byte
 *   3. uECC_verify (micro-ecc, BSD-2) với public key x||y
 *
 * KHÔNG tự implement thuật toán ECDSA — chỉ glue code + parse encoding.
 * Public key KHÔNG phải bí mật (client chỉ giữ material verify).
 */
namespace crypto {

enum class VerifyStatus {
    OK,
    INVALID_ARG,
    BAD_DER,
    BAD_SIGNATURE,
    INTERNAL_ERROR,
};

struct VerifyResult {
    VerifyStatus status = VerifyStatus::INTERNAL_ERROR;
    std::string   error;   /* mô tả cho logging — không đưa ra UI */

    bool ok() const { return status == VerifyStatus::OK; }
};

/*
 * Xác minh chữ ký DER (hex) trên canonical message với public key hex x||y
 * (128 ký tự — định dạng server trả ở init).
 */
VerifyResult verify_server_signature(const std::string& canonical_message,
                                     const std::string& signature_der_hex,
                                     const std::string& public_key_xy_hex);

}  // namespace crypto
