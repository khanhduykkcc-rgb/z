#pragma once

#include <map>
#include <string>
#include <utility>
#include <vector>

/*
 * Canonical — chuỗi chuẩn hóa để ký/xác thực (spec mục 7).
 *
 * Cả PHP (lib/Crypto.php) và C++ đều build CHÍNH XÁC chuỗi này:
 *
 *   "TAKEY-SIG-1\n"
 *   với mỗi trường sắp xếp theo tên (byte-order tăng dần):
 *       strlen(tên) ":" tên "=" strlen(giá_trị) ":" giá_trị "\n"
 *
 * Length-prefix loại bỏ hoàn toàn ambiguity:
 *   - thứ tự field (sort theo tên)
 *   - whitespace (không có padding)
 *   - encoding (mọi thứ là byte thô, đếm theo byte)
 */
namespace crypto {

using Fields = std::vector<std::pair<std::string, std::string>>;

/* Build chuỗi canonical từ danh sách trường (sẽ tự sort theo tên). */
std::string canonical(const Fields& fields);

/* Chuỗi dùng tính MAC cho request session — bộ trường CỐT ĐỊNH
 * (action, nonce, req_id, session_id, ts) giống hệt PHP
 * session_request_mac_message(). */
std::string request_mac_message(const std::string& action,
                                const std::string& nonce,
                                const std::string& req_id,
                                const std::string& session_id,
                                const std::string& ts);

/*
 * MAC mở rộng (V3) — integrity report trong heartbeat MAC:
 * bộ 5 trường cốt định + các trường sec_* (sec_dbg, sec_dump, sec_func,
 * sec_mem, sec_vpn, sec_ctr) từ Protection::SecurityMonitor::report().
 *
 * RẤT QUAN TRỌNG — chống strip report:
 *   các trường sec_* nằm TRONG chuỗi canonical của MAC → kẻ tấn công muốn
 *   gỡ report khỏi request phải tính lại MAC — không có session_secret thì
 *   không thể → strip = MAC sai = server DENY (replay_detected sẽ không xảy
 *   ra vì nonce mới, nhưng mac_invalid sẽ).
 *
 * Backward-compatible 2 chiều:
 *   - sec_fields rỗng → chuỗi giống hệt request_mac_message() (client cũ).
 *   - PHP session_request_mac_message() chỉ thêm sec_* khi có trong request.
 * Chỉ các trường CÓ GIÁ TRỊ KHÁC RỖNG mới vào canonical — hai phía dùng
 * cùng quy tắc này (xem lib/SessionModel.php).
 */
std::string request_mac_message_ext(const std::string& action,
                                    const std::string& nonce,
                                    const std::string& req_id,
                                    const std::string& session_id,
                                    const std::string& ts,
                                    const std::map<std::string, std::string>& sec_fields);

/* Chuỗi canonical của envelope response để verify chữ ký server —
 * giống hệt PHP api_v2_respond(): proto + status + code + data + meta. */
std::string response_sign_message(const std::string& proto,
                                  const std::string& status,
                                  const std::string& code,
                                  const Fields& data,
                                  const Fields& meta);

}  // namespace crypto
