#pragma once

#include <string>

/*
 * MAC — xác thực integrity request (spec mục 7).
 *
 * Dùng NaCl crypto_auth = HMAC-SHA-512-256 (audited, RFC 2104 HMAC
 * trên SHA-512, cắt 32 byte đầu). PHP side tương đương:
 *   substr(hash_hmac('sha512', msg, hex2bin(secret)), 0, 64)  (hex)
 *
 * KHÔNG tự viết HMAC — gọi thẳng TweetNaCl (public domain).
 */
namespace crypto {

/* Tính MAC 32-byte cho message với khóa hex (session_secret).
 * Trả về hex 64 ký tự. */
std::string mac_hex(const std::string& message, const std::string& key_hex);

/* So sánh MAC không lộ timing. */
bool mac_equal(const std::string& expected_hex, const std::string& given_hex);

}  // namespace crypto
