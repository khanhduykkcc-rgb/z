#pragma once

#include <cstddef>
#include <string>

/*
 * SecureRandom — bộ sinh ngẫu nhiên an toàn mật mã cho nonce.
 *
 * NGUYÊN TẮC (spec mục 5): KHÔNG BAO GIỜ dùng rand() cho mục đích bảo mật.
 *
 * Nguồn (theo thứ tự ưu tiên):
 *   1. /dev/urandom (POSIX — Linux, macOS, iOS: cách documented của Apple)
 *   2. std::random_device (fallback — tùy implementation, có thể không CSPRNG)
 *
 * random_source_strong() cho biết có dùng được nguồn (1) không —
 * AuthPipeline sẽ ghi nhận và báo cáo rõ ràng (không giả vờ an toàn).
 */
namespace crypto {

/* Sinh `bytes` byte ngẫu nhiên, trả về hex (2*bytes ký tự). */
std::string random_hex(std::size_t bytes);

/* Sinh `bytes` byte ngẫu nhiên vào buffer. */
void random_bytes(unsigned char* out, std::size_t bytes);

/* true nếu nguồn là /dev/urandom (CSPRNG chuẩn). */
bool random_source_strong();

}  // namespace crypto
