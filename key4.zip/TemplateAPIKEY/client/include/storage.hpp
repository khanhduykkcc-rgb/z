#pragma once

#include <string>

/*
 * Abstraction cho nơi lưu key. FileStorage là hiện thực mặc định
 * (file quyền 0600). Host app có thể hiện thực backend riêng
 * (VD: keychain, NSUserDefaults wrapper ở tầng app).
 */
class IStorage {
public:
    virtual ~IStorage() = default;

    virtual bool read(std::string& out)   = 0;
    virtual bool write(const std::string& value) = 0;
    virtual bool clear()                  = 0;
};

class FileStorage final : public IStorage {
public:
    explicit FileStorage(std::string path);

    bool read(std::string& out) override;
    bool write(const std::string& value) override;
    bool clear() override;

private:
    std::string path_;
};
