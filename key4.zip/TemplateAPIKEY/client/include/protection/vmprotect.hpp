#pragma once

/*
 * vmprotect.hpp — wrapper bảo vệ vùng code bằng VMProtect SDK (PASS 3).
 *
 * TÍNH TRUNG THỰC (spec mục 4 + 23):
 *   VMProtect là sản phẩm thương mại hỗ trợ Windows x86/x64 (có bản
 *   macOS cho binary Intel, KHÔNG hỗ trợ iOS/arm64). Trên target
 *   iOS-arm64: wrapper này biên dịch thành NO-OP CÓ KIỂM SOÁT và
 *   Protection::vmprotect_status() báo rõ "not-active" — hệ thống
 *   KHÔNG giả vờ đang được bảo vệ.
 *
 * Cách kích hoạt THẬT trên Windows build:
 *   1. Cài VMProtect + copy VMProtectSDK.h vào include path.
 *   2. Build: make PROTECTED=1 TAKEY_VMPROTECT_SDK=1
 *      (Makefile thêm -DTAKEY_HAS_VMPROTECT_SDK và link VMProtectSDK.lib)
 *   3. Chạy binary qua VMProtect UI với marker tương ứng.
 *
 * Chỉ MARK các hàm nhạy cảm (spec mục 5):
 *   AuthPipeline::authorize / verifier / session_request — không rải
 *   macro khắp project.
 */

#if defined(TAKEY_HAS_VMPROTECT_SDK) && !defined(TAKEY_TARGET_IOS)
    #include "VMProtectSDK.h"

    #define TAKEY_VMP_BEGIN_MUTATION(name)    VMProtectBeginMutation(name)
    #define TAKEY_VMP_BEGIN_VIRTUALIZATION(name) VMProtectBeginVirtualization(name)
    #define TAKEY_VMP_BEGIN_ULTRA(name)       VMProtectBeginUltra(name)
    #define TAKEY_VMP_END()                   VMProtectEnd()
#else
    /* No-op có chủ đích — không ảnh hưởng runtime, không đổi ngữ nghĩa */
    #define TAKEY_VMP_BEGIN_MUTATION(name)       ((void)0)
    #define TAKEY_VMP_BEGIN_VIRTUALIZATION(name) ((void)0)
    #define TAKEY_VMP_BEGIN_ULTRA(name)          ((void)0)
    #define TAKEY_VMP_END()                      ((void)0)
#endif

namespace Protection {

/* Trạng thái tích hợp VMProtect — hiển thị trong log/report, không bịa. */
struct VmprotectStatus {
    bool        active;      /* marker thật đang được biên dịch */
    const char* detail;      /* mô tả vì sao (không) active */
};

inline VmprotectStatus vmprotect_status() {
#if defined(TAKEY_HAS_VMPROTECT_SDK) && !defined(TAKEY_TARGET_IOS)
    return {true, "VMProtect SDK markers compiled — binary cần được xử lý qua VMProtect"};
#elif defined(__APPLE__) && (defined(__arm64__) || defined(__arm64e__) || defined(TAKEY_TARGET_IOS))
    return {false, "NOT SUPPORTED: VMProtect không hỗ trợ iOS/arm64 (Windows x86/x64 only)"};
#else
    return {false, "SDK not present — markers are inert no-ops"};
#endif
}

}  // namespace Protection
