#pragma once

/*
 * protection_types.hpp — các enum dùng chung cho mọi module protection.
 * Tách riêng để tránh include vòng (anti_vpn/anti_dump/integrity đều cần
 * CheckResult/SecurityLevel nhưng KHÔNG được include security_state.hpp
 * vì security_state.hpp lại include các module đó để tổng hợp).
 */

namespace Protection {

enum class SecurityLevel {
    Normal,      /* không có tín hiệu bất thường */
    Suspicious,  /* tín hiệu yếu (env var, ppid, vpn, core-limit) — ghi nhận */
    Debugged,    /* tín hiệu mạnh: debugger / dump-signature / hàm bị patch /
                    canary bị phá / thư viện inject */
};

enum class CheckResult {
    NotDetected,
    Detected,
    Unavailable,  /* API không tồn tại trên nền tảng này */
    Error,        /* API lỗi — KHÔNG coi là detected */
};

}  // namespace Protection
