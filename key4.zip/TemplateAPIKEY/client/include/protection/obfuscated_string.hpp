#pragma once

#include <cstddef>
#include <string>

/*
 * obfuscated_string.hpp — che chuỗi nhạy cảm khỏi grep binary (PASS 3 mục 7).
 *
 * ⚠️ ĐÂY LÀ OBFUSCATION, KHÔNG PHẢI MÃ HÓA:
 *   - Mục đích duy nhất: chuỗi như endpoint API / tên protocol / nhãn
 *     trạng thái không xuất hiện nguyên văn trong `strings` của binary.
 *   - KHÔNG dùng để bảo vệ bí mật thật. Private key server KHÔNG BAO GIỜ
 *     nằm trong client dưới bất kỳ dạng nào.
 *   - Keystream xorshift constexpr — không phải primitive mật mã.
 *
 * Giải mã tại thời điểm dùng (operator()), wipe buffer sau khi copy.
 */

#include <array>
#include <cstring>
#include <utility>

namespace Protection {

template <std::size_t N, unsigned Seed>
class ObfuscatedString {
public:
    constexpr ObfuscatedString(const char (&data)[N]) {
        for (std::size_t i = 0; i < N; ++i) {
            encoded_[i] = static_cast<char>(data[i] ^ keystream(i));
        }
    }

    /* Trả về chuỗi đã giải mã — bị chép vào std::string riêng của caller. */
    std::string decode() const {
        std::string out;
        out.reserve(N - 1);
        for (std::size_t i = 0; i < N - 1; ++i) {  /* bỏ '\0' cuối */
            out.push_back(static_cast<char>(encoded_[i] ^ keystream(i)));
        }
        return out;
    }

private:
    static constexpr unsigned keystream(std::size_t i) {
        /* xorshift32 deterministic — chỉ để che strings, không phải crypto */
        unsigned state = Seed + static_cast<unsigned>(i) * 2654435761u;
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        return state & 0xFF;
    }

    std::array<char, N> encoded_{};
};

/* Macro tiện dụng — mỗi chỗ dùng một Seed riêng */
#define TAKEY_OBF(str) \
    (::Protection::ObfuscatedString<sizeof(str), __LINE__ * 31 + 7>(str).decode())

}  // namespace Protection
