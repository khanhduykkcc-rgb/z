#pragma once

#include <atomic>
#include <map>
#include <mutex>
#include <string>

/*
 * SecurityState — trạng thái bảo mật môi trường TẬP TRUNG (PASS 3 + mở rộng).
 *
 * SecurityMonitor điều phối TOÀN BỘ lớp bảo mật client:
 *   1. Anti-debug   (MASTG-KNOW-0085: ptrace/sysctl/mach/TracerPid)
 *   2. Anti-VPN     (proxy env / tunnel iface / system proxy) — chạy ĐẦU TIÊN
 *   3. Anti-dump    (watchdog staleness / core-limit / env injection)
 *   4. FuncIntegrity (self-checksum các hàm crypto/verify — chống patch runtime)
 *   5. MemoryIntegrity (SecureVault canary + quét rwx + thư viện inject)
 *
 * TẤT CẢ TỰ ĐỘNG KÍCH HOẠT khi AuthPipeline được dựng (constructor gọi
 * SecurityMonitor::prime()) — KHÔNG cần bất kỳ thao tác nhấn nào.
 *
 * NGUYÊN TẮC "SERVER-AUTHORITATIVE" (spec mục 14):
 *   Client KHÔNG tự quyết định chặn. Client tổng hợp + TỐNG BÁO CÁO đầy đủ
 *   (sec_dbg/sec_dump/sec_func/sec_mem/sec_vpn/sec_ctr) trong MỌI request —
 *   các trường này nằm trong chuỗi canonical của MAC heartbeat → không thể
 *   strip/sửa nếu không có session_secret. SERVER đọc report và quyết định
 *   DENY/cho phép theo policy (security_block_* trong tbl_settings).
 *   Local fail-fast (security_ok=false) chỉ là lớp phòng thủ kép — không
 *   thay thế phán quyết server.
 *
 * KHÔNG có kill/abort/SIGKILL ở bất kỳ đâu.
 */

#include "protection/anti_dump.hpp"
#include "protection/anti_vpn.hpp"
#include "protection/protection_types.hpp"

namespace Protection {

struct AntiDebugSnapshot {
    CheckResult sysctl_traced   = CheckResult::Unavailable;
    CheckResult mach_ports      = CheckResult::Unavailable;
    CheckResult tracer_pid      = CheckResult::Unavailable;
    CheckResult parent_pid      = CheckResult::Unavailable;
    CheckResult env_indicators  = CheckResult::Unavailable;
    SecurityLevel level         = SecurityLevel::Normal;
    long         last_check_ts  = 0;
    int          checks_run     = 0;
    bool         strong_random  = false;
};

/* ---------------- Tổng hợp toàn bộ lớp bảo mật (V3) ---------------- */

struct SecuritySnapshot {
    /* Anti-debug (5 tín hiệu MASTG) */
    AntiDebugSnapshot anti_debug;

    /* Anti-VPN/Proxy — được chạy ĐẦU TIÊN theo yêu cầu ưu tiên */
    VpnSnapshot  vpn;

    /* Anti-dump (watchdog + core + env) */
    DumpSnapshot dump;

    /* FuncIntegrity: số hàm bị patch runtime */
    int          func_tampered = 0;

    /* MemoryIntegrity: 0 clean / 1 suspicious / 2 tampered */
    int          mem_level = 0;

    /* Tổng hợp sau cùng */
    SecurityLevel level      = SecurityLevel::Normal;
    long          last_check_ts = 0;
    int           checks_run    = 0;
    bool          strong_random = false;
};

/* Chạy riêng bộ tín hiệu anti-debug (được hiện thực trong anti_debug.cpp,
 * SecurityMonitor dùng kết quả này — tách bạch để unit test). */
AntiDebugSnapshot run_anti_debug_checks(int checks_run_before);

class SecurityMonitor {
public:
    static SecurityMonitor& instance();

    /*
     * KHỞI ĐỘNG TỰ ĐỘNG TOÀN BỘ LỚP BẢO MẬT — idempotent, không throw:
     *   1. DumpDetector::start()    — watchdog thread nền
     *   2. FuncIntegrity::prime()   — baseline self-checksum các hàm lõi
     *   3. MemoryIntegrity::prime() — baseline số vùng rwx
     *   4. VpnDetector::detect()    — quét VPN/proxy ngay lập tức
     *   5. Anti-debug lần đầu
     * Được gọi từ AuthPipeline constructor → khi app dựng pipeline là mọi
     * bảo vệ đã sống — không cần nhấn bất kỳ nút nào.
     */
    void prime();

    /*
     * Chạy bộ check (có throttle — không busy-loop). Thứ tự: VPN TRƯỚC,
     * rồi anti-debug, dump, func-integrity, memory-integrity. Aggregation:
     *   - MẠNH (→ Debugged): debugger DETECTED, dump-signature, hàm bị patch,
     *     canary vault bị phá, thư viện inject, vùng rwx mới (mức 2)
     *   - YẾU (→ Suspicious): VPN/proxy, env vars, core-limit, dump nhẹ
     *   - Unavailable/Error KHÔNG được tính là vi phạm
     */
    SecurityLevel check();

    /* Snapshot tổng hợp đầy đủ (gần nhất). */
    SecuritySnapshot full_snapshot() const;

    /* Backward-compat: khung nhìn anti-debug của snapshot gần nhất. */
    AntiDebugSnapshot snapshot() const;

    /*
     * BÁO CÁO gửi server — map các trường đưa vào canonical MAC:
     *   sec_dbg  : 0 normal / 1 suspicious / 2 debugged
     *   sec_dump : 0 clean / 1 suspicious / 2 detected
     *   sec_func : N — số hàm bị patch (0 = sạch)
     *   sec_mem  : 0 clean / 1 suspicious / 2 tampered
     *   sec_vpn  : 0 off / 1 detected
     *   sec_ctr  : số lần check đã chạy (freshness — client phải sống)
     * SERVER quyết định chặn hay không (tbl_settings: security_block_*).
     */
    std::map<std::string, std::string> report();

    /* Bật chế độ chỉ quan sát (DEBUG build: ghi nhận nhưng không chặn). */
    void set_observe_only(bool observe) { observe_only_.store(observe); }
    bool observe_only() const { return observe_only_.load(); }

    /* Throttle: tối thiểu bao nhiêu giây giữa 2 lần check (mặc định 5s). */
    void set_min_interval(int seconds) { min_interval_s_ = seconds; }

    /* Bỏ qua throttle cho lần check kế tiếp (test/integration). */
    void force_next_check() { last_run_.store(0); }

private:
    SecurityMonitor() = default;

    std::atomic<bool>  observe_only_{false};
    std::atomic<long>  last_run_{0};
    std::atomic<int>   min_interval_s_{5};
    mutable std::mutex snap_mutex_;
    SecuritySnapshot   last_{};

    /* Gọi khi throttle còn hiệu lực — dùng kết quả cũ. */
    SecuritySnapshot cached_snapshot() const;
};

const char* security_level_name(SecurityLevel level);

/* Chuyển SecurityLevel → giá trị số gửi server. */
const char* security_level_value(SecurityLevel level);

}  // namespace Protection
