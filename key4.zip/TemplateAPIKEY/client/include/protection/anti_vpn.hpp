#pragma once

#include <string>

/*
 * anti_vpn.hpp — phát hiện proxy / VPN phía client (PASS 3 mở rộng).
 *
 * NGUYÊN TẮC "SERVER-AUTHORITATIVE":
 *   Client KHÔNG tự chặn khi phát hiện VPN/proxy — client chỉ TỐNG BÁO CÁO
 *   (sec_vpn=1) trong mọi request (kèm heartbeat MAC). SERVER quyết định
 *   chặn hay cho phép theo setting `security_block_vpn` (mặc định: chặn).
 *
 * 4 nhóm tín hiệu (độc lập, fail-open có kiểm soát):
 *   1. Proxy env vars  — HTTP_PROXY / HTTPS_PROXY / ALL_PROXY (cả lowercase)
 *                       — mọi nền tảng (Unix)
 *   2. Tunnel iface    — tun, tap, ppp, wg, vtun (Linux qua
 *                       Apple qua getifaddrs: utun, tap, ppp, ipsec)
 *   3. System proxy    — macOS: scutil --proxy (HTTPEnable/HTTPProxy ≠ 0)
 *                       — chỉ macOS (iOS không có scutil; Linux desktop
 *                         không có chỗ thống nhất). Trung thực: UNAVAILABLE.
 *   4. Local intercept — proxy env trỏ về localhost/127.0.0.1 (Charles,
 *                       mitmproxy, Proxyman chạy local)
 *
 * Mỗi tín hiệu trả CheckResult chuẩn (NOT_DETECTED / DETECTED /
 * UNAVAILABLE / ERROR) — lỗi API KHÔNG bị coi là có VPN (chống false
 * positive, giống anti_debug).
 *
 * Tính đúng đắn (để tránh false positive oan cho user):
 *   - NO_PROXY bao phủ toàn bộ ("*") + proxy trỏ loopback đã bị skip qua
 *     nhóm 1 nếu nhóm 4 cũng không khớp → không đánh dấu môi trường dev
 *     phổ biến một cách oan.
 */

#include "protection/protection_types.hpp"

namespace Protection {

struct VpnSnapshot {
    CheckResult env_proxy_vars  = CheckResult::Unavailable;
    CheckResult tunnel_iface    = CheckResult::Unavailable;
    CheckResult system_proxy    = CheckResult::Unavailable;
    CheckResult local_intercept = CheckResult::Unavailable;
    bool        detected        = false;   /* bất kỳ tín hiệu DETECTED */
    long        last_check_ts   = 0;
};

class VpnDetector {
public:
    static VpnDetector& instance();

    /* Chạy toàn bộ tín hiệu — idempotent, không throw. */
    VpnSnapshot detect();

    /* Snapshot gần nhất (không chạy lại check). */
    VpnSnapshot snapshot() const { return last_; }

    /* Giá trị gửi server: "1" = detected, "0" = sạch. */
    const char* report_value() const {
        return last_.detected ? "1" : "0";
    }

private:
    VpnDetector() = default;
    VpnSnapshot last_{};
};

}  // namespace Protection
