#pragma once

/*
 * ollvm.hpp — trạng thái obfuscation toolchain Obfuscator-LLVM (PASS 3 mở rộng).
 *
 * TÍNH TRUNG THỰC (giống vmprotect.hpp — không giả vờ đang được bảo vệ):
 *   Obfuscator-LLVM (fork Hikari/ollvm-ng...) là TOOLCHAIN BUILD, không phải
 *   runtime: không thể phát hiện từ trong binary "mình đã được obfuscate".
 *   Vì vậy trạng thái được đánh dấu tại BUILD-TIME qua macro TAKEY_OLLVM
 *   (Makefile target `ollvm` truyền vào) và báo đúng những gì đã bật.
 *
 * Cách dùng thật:
 *   1. Build obfuscator-clang (vd github.com/obfuscator-llvm/obfuscator
 *      hoặc Hikari) trên máy CI riêng.
 *   2. make ollvm OLLVM_CXX=/path/to/obfuscator-clang
 *      (Makefile probe-compile trước khi build — toolchain không có pass
 *      sẽ báo lỗi rõ ràng, KHÔNG build lặng lẽ không bảo vệ).
 *   3. Các pass áp dụng vùng nhạy cảm: -mllvm -fla (control-flow flattening),
 *      -bcf (bogus control flow), -sub (instruction substitution), -split.
 *
 * Per-function (Hikari fork): dùng __attribute__((annotate("fla bcf")))
 * qua TAKEY_OBF_FUNC dưới đây — fork chính gốc LLVM chỉ nhận pass toàn TU.
 */

#if defined(TAKEY_OLLVM)
    /* Được build bằng toolchain Obfuscator-LLVM — xem TAKEY_OLLVM_PASSES
     * do Makefile truyền (dạng "fla bcf sub"). */
    #if !defined(TAKEY_OLLVM_PASSES)
        #define TAKEY_OLLVM_PASSES "fla bcf sub split"
    #endif
    #define TAKEY_OBF_FUNC __attribute__((annotate("fla bcf")))
#else
    /* No-op có chủ đích — toolchain thường không có pass OLLVM */
    #define TAKEY_OBF_FUNC
#endif

namespace Protection {

struct OllvmStatus {
    bool        active;   /* binary này được build bằng OLLVM thật */
    const char* detail;
};

inline OllvmStatus ollvm_status() {
#if defined(TAKEY_OLLVM)
    return {true, "Built with Obfuscator-LLVM passes: " TAKEY_OLLVM_PASSES};
#else
    return {false, "NOT ACTIVE: toolchain build thường — dùng `make ollvm OLLVM_CXX=...` "
                   "(xem README mục OLLVM) để bật control-flow flattening + bogus flow + substitution"};
#endif
}

}  // namespace Protection
