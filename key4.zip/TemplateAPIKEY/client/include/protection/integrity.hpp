#pragma once

#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

/*
 * integrity.hpp — FuncIntegrity + MemoryIntegrity + SecureVault (PASS 3 mở rộng).
 *
 * ================= FuncIntegrity (chống patch hàm runtime) =================
 *
 * Nguyên lý: baseline self-checksum các hàm nhạy cảm (crypto verify, MAC,
 * canonical, validate envelope) bằng SHA-256 (vendor/sha256 — public domain)
 * ngay khi tiến trình khởi động (trước khi kẻ tấn công có cơ hội patch runtime).
 * Mỗi lần verify: đọc lại bytes code và so với baseline — bytes khác nhau
 * (inline hook, byte patch, trampoline) → TAMPERED.
 *
 * Giới hạn trung thực (MASTG): bảo vệ chống patch RUNTIME (sau khi baseline);
 * patch tĩnh trên binary trước khi chạy thì server-side verdict vẫn là lớp
 * quyết định cuối — client REPORT (sec_func), SERVER quyết định.
 *
 * Địa chỉ hàm được đọc qua "safe read": xác nhận nằm trong vùng mapped
 * executable trước khi memcpy (Linux: /proc/self/maps; Apple: mach_vm_region)
 * → không bao giờ crash vì đọc lấn trang.
 *
 * =============== MemoryIntegrity (canary + quét vùng nhớ) ================
 *
 *   1. SecureVault — kho bí mật tại chỗ:
 *      [canary 8B | data XOR keystream | keystream | canary 8B] trong MỘT
 *      cấp phát duy nhất. Secret (license key, session_secret) không bao giờ
 *      nằm plain-text trong heap → file dump không grep ra được (anti-dump
 *      thật), canary hai đầu phát hiện buffer overrun/tamper lân cận.
 *      ⚠️ XOR keystream = OBFUSCATION (không phải mã hóa thật) — nâng rào,
 *      không phải tường tuyệt đối. Documented honestly.
 *   2. Quét vùng RWX: region read-write-execute mới xuất hiện sau baseline
 *      = code injected (Frida gadget, substrate) → DETECTED.
 *   3. Tên ảnh thư viện đáng ngờ trong mapping: frida / gum-js / substrate /
 *      cycript / r2frida → DETECTED.
 *
 * Client REPORT (sec_mem), SERVER quyết định.
 */

#include "protection/security_state.hpp"

namespace Protection {

/* ========================= FuncIntegrity ========================= */

struct FuncCheck {
    std::string name;
    CheckResult result;   /* NotDetected / Detected / Error */
    std::string baseline; /* SHA-256 hex lúc prime */
    std::string current;  /* SHA-256 hex lần verify gần nhất */
};

class FuncIntegrity {
public:
    static FuncIntegrity& instance();

    /* Baseline các hàm mặc định + khởi tạo. Idempotent. TỰ ĐỘNG chạy từ
     * SecurityMonitor::prime() — không cần thao tác nào của người dùng. */
    void prime();

    /* Đăng ký vùng code tùy chọn (dùng cho test + module ngoài). */
    bool register_region(const std::string& name, const void* addr, std::size_t bytes);

    /* Verify lại toàn bộ vùng đã đăng ký. Trả về số vùng bị TAMPERED.
     * An toàn với mọi nền tảng (safe read). */
    int verify();

    /* Số lần verify — đưa vào report để server thấy client đang tự check. */
    long verify_count() const;

    const std::vector<FuncCheck>& last_checks() const { return last_checks_; }

    /* Giá trị gửi server: "0" sạch, "N" số hàm bị patch. */
    std::string report_value() const;

    /* Cho test: reset để prime lại (mô phỏng tiến trình mới). */
    void reset_for_test();

private:
    FuncIntegrity() = default;

    struct Region {
        std::string   name;
        const void*   addr;
        std::size_t   bytes;
        std::string   baseline_hex;
    };

    bool hash_region(const Region& r, std::string& out_hex) const;

    mutable std::mutex  mutex_;
    std::vector<Region> regions_;
    std::vector<FuncCheck> last_checks_;
    bool                primed_ = false;
    long                verify_count_ = 0;
};

/* ========================= MemoryIntegrity ========================= */

enum class MemLevel {
    Clean = 0,
    Suspicious = 1,  /* vùng rwx mới xuất hiện (có thể JIT hợp lệ) */
    Tampered = 2,    /* canary vault bị phá / thư viện inject được nạp */
};

class SecureVault;  // forward

class MemoryIntegrity {
public:
    static MemoryIntegrity& instance();

    /* Baseline số vùng rwx lúc khởi động. Idempotent, TỰ ĐỘNG từ
     * SecurityMonitor::prime(). */
    void prime();

    /* Quét lại: rwx mới + tên thư viện đáng ngờ + (vault canary qua
     * check_vault()). Trả về level. */
    MemLevel verify();

    /* Liên kết vault (được sở hữu bởi AuthPipeline) vào monitor để canary
     * được kiểm trong mỗi lần verify(). */
    void attach_vault(SecureVault* vault) { vault_ = vault; }

    long verify_count() const { return verify_count_; }

    const char* report_value() const {
        switch (last_level_) {
            case MemLevel::Clean:      return "0";
            case MemLevel::Suspicious: return "1";
            case MemLevel::Tampered:   return "2";
        }
        return "0";
    }

    void reset_for_test();

private:
    MemoryIntegrity() = default;

    mutable std::mutex mutex_;
    long baseline_rwx_count_ = -1;  /* -1 = chưa prime */
    MemLevel last_level_ = MemLevel::Clean;
    long     verify_count_ = 0;
    SecureVault* vault_ = nullptr;
};

/* ========================= SecureVault ========================= */

class SecureVault {
public:
    SecureVault() = default;
    ~SecureVault();

    SecureVault(const SecureVault&) = delete;
    SecureVault& operator=(const SecureVault&) = delete;

    /* Cất chuỗi nhạy cảm: obfuscate tại chỗ + canary hai đầu.
     * Ghi đè entry cũ (nếu có) sau khi wipe. */
    void set(const std::string& name, const std::string& value);

    /* Lấy ra bản copy (caller wipe sau khi dùng — xem secure_wipe()).
     * Trả false nếu entry không tồn tại hoặc CANARY BỊ PHÁ. */
    bool get(const std::string& name, std::string& out) const;

    /* Kiểm tra canary mọi entry — không giải mã. */
    bool canaries_ok() const;

    /* Xóa hẳn một entry (wipe memory trước khi free). */
    void wipe(const std::string& name);
    void wipe_all();

    bool empty() const { return entries_.empty(); }
    std::size_t size() const { return entries_.size(); }

    /* Cho test: đục canary để mô phỏng tamper. */
    void debug_corrupt_canary(const std::string& name, bool front);

private:
    struct Entry {
        std::string  name;
        unsigned char* blob  = nullptr; /* [canary|data^key|key|canary] */
        std::size_t   alloc = 0;
        std::size_t   data_off = 0;
        std::size_t   key_off  = 0;
        std::size_t   data_len = 0;
        std::uint64_t canary_front = 0;
        std::uint64_t canary_back  = 0;
    };

    static constexpr std::size_t kCanaryBytes = 8;

    Entry* find(const std::string& name);
    const Entry* find(const std::string& name) const;

    std::vector<Entry> entries_;
    mutable std::mutex mutex_;
};

/* Wipe memory chống optimizer bỏ qua (volatile byte loop + barrier). */
void secure_wipe(std::string& s);
void secure_wipe(void* ptr, std::size_t len);

/* Sinh chuỗi hex ngẫu nhiên không đoán được (CSPRNG vendored) —
 * dùng cho keystream vault. Trả rỗng nếu CSPRNG lỗi. */
std::string vault_random_hex(std::size_t n_bytes);

}  // namespace Protection
