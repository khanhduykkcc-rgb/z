#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <mutex>
#include <string>
#include <thread>

/*
 * anti_dump.hpp — chống dump bộ nhớ tiến trình (PASS 3 mở rộng).
 *
 * NGUYÊN TẮC: detection + báo cáo (sec_dump) — SERVER quyết định chặn.
 *
 * 3 nhóm tín hiệu:
 *   1. Watchdog staleness (MẠNH, portable):
 *      Thread nền "đập nhịp" mỗi ~500ms bằng CLOCK_MONOTONIC.
 *      Khi tiến trình bị SIGSTOP (kỹ thuật đóng băng của dumper: gcore,
 *      procdump, process freezer), CLOCK_MONOTONIC (đồng hồ kernel toàn
 *      cục) VẪN TIẾP TỤC chạy — nên sau khi resumed, khoảng cách từ
 *      nhịp cuối đến hiện tại phình to bất thường → phát hiện bị đóng băng.
 *      Lưu ý quan trọng (chống false positive):
 *        - CLOCK_MONOTONIC trên Linux/Darwin KHÔNG chạy khi HỆ ĐIỆNG VÀNG
 *          (system suspend) → laptop ngủ không bị oan.
 *        - Trọng tải CPU nặng chỉ làm thread trễ vài trăm ms — ngưỡng
 *          suspicious là 5s, ngưỡng strong (dump signature) là 60s.
 *   2. Core dump enabled (YẾU): RLIMIT_CORE > 0 → core có thể được sinh ra
 *      khi crash → dấu hiệu cấu hình dễ dump (cũng là best practice tắt).
 *   3. Env injection (YẾU): LD_PRELOAD / LD_DEBUG / DYLD — vector inject
 *      thư viện dump/hook.
 *
 * Kết hợp với anti_debug (ptrace/task-port): dumper gắn debugger trước khi
 * đọc memory sẽ dính tín hiệu DEBUGGED của anti_debug — hai lớp phủ nhau.
 *
 * Bộ nhớ nhạy cảm (key, session_secret) KHÔNG nằm plain-text trong heap:
 * xem Protection::SecureVault (integrity.hpp) — obfuscation tại chỗ + canary,
 * khiến file dump không grep được secret.
 */

#include "protection/protection_types.hpp"

namespace Protection {

enum class DumpLevel {
    Clean = 0,        /* không tín hiệu */
    Suspicious = 1,   /* staleness 5-60s hoặc core-limit/env yếu */
    Detected = 2,     /* staleness > 60s — chữ ký dump (đóng băng tiến trình) */
};

struct DumpSnapshot {
    CheckResult watchdog_stale   = CheckResult::Unavailable; /* staleness mono */
    CheckResult core_limit       = CheckResult::Unavailable; /* RLIMIT_CORE */
    CheckResult env_injection    = CheckResult::Unavailable; /* LD_PRELOAD... */
    long        stale_ms         = 0;   /* chênh lệch phình to (ms) */
    long        last_check_ts    = 0;
    DumpLevel   level            = DumpLevel::Clean;
};

class DumpDetector {
public:
    static DumpDetector& instance();

    /* KHỞI ĐỘNG TỰ ĐỘNG — gọi từ SecurityMonitor::prime() (không cần
     * bất kỳ thao tác nhấn gì của người dùng): khởi động watchdog thread. */
    void start();

    /* Dừng watchdog (chỉ dùng cho test / shutdown). */
    void stop();

    /* Đếm nhịp — public để unit test có thể giả lập "đóng băng". */
    void beat();

    /* Snapshot gần nhất. */
    DumpSnapshot snapshot() const { return last_; }

    /* Chạy toàn bộ tín hiệu. */
    DumpSnapshot detect();

    /* Giá trị gửi server: "0" clean / "1" suspicious / "2" detected. */
    const char* report_value() const {
        switch (last_.level) {
            case DumpLevel::Clean:      return "0";
            case DumpLevel::Suspicious: return "1";
            case DumpLevel::Detected:   return "2";
        }
        return "0";
    }

    /* Ngưỡng cấu hình được (test dùng ngưỡng nhỏ). Đơn vị ms. */
    void set_thresholds(long suspicious_ms, long detected_ms) {
        suspicious_ms_ = suspicious_ms;
        detected_ms_ = detected_ms;
    }

    /* Cho test: giả lập nhịp cũ (mô phỏng bị đóng băng). */
    void debug_set_last_beat(std::chrono::steady_clock::time_point tp) {
        std::lock_guard<std::mutex> lock(beat_mutex_);
        last_beat_ = tp;
    }

    ~DumpDetector();

private:
    DumpDetector() = default;
    void watchdog_loop();

    std::mutex                                 beat_mutex_;
    std::chrono::steady_clock::time_point      last_beat_{};
    std::atomic<bool>                          running_{false};
    std::thread                                worker_{};
    DumpSnapshot                               last_{};

    long suspicious_ms_{5000};   /* 5s — trễ bất thường */
    long detected_ms_{60000};    /* 60s — chữ ký dump */
};

const char* dump_level_name(DumpLevel level);

}  // namespace Protection
