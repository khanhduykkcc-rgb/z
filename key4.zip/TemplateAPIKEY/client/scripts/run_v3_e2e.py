#!/usr/bin/env python3
"""
run_v3_e2e.py — E2E thật sự cho giao thức V3 (integrity report trong MAC).

Mô phỏng PHP server (auth.php + session.php) bằng Python + ECDSA P-256
(lib cryptography) rồi chạy CLIENT C++ THẬT qua HTTP localhost:

  Kịch bản A: authorize sạch  → init + authenticate (kèm sec_* sạch) → AUTHORIZED
  Kịch bản B: restore sạch    → session check: MAC trên 11 TRƯỜNG (5 base + 6
                sec_*) → server verify MAC + policy → OK → AUTHORIZED
  Kịch bản C: restore + http_proxy → sec_vpn=1 nằm TRONG MAC → server DENY
                security_violation → client không được khôi phục session

Pass criteria: 3/3 kịch bản đúng hành vi mong đợi.
"""
import hashlib
import hmac
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

# ---------------------------------------------------------------- crypto
V = "TAKEY-SIG-1"
PRIV = ec.generate_private_key(ec.SECP256R1())
PUB_HEX = (PRIV.public_key().public_bytes(Encoding.X962, PublicFormat.UncompressedPoint)[1:]).hex()

def canonical(fields: dict) -> str:
    out = V + "\n"
    for name in sorted(fields.keys()):
        val = str(fields[name])
        out += f"{len(name)}:{name}={len(val)}:{val}\n"
    return out

def sign(message: str) -> str:
    der = PRIV.sign(message.encode(), ec.ECDSA(hashes.SHA256()))
    return der.hex()

def mac_hex(message: str, secret_hex: str) -> str:
    return hmac.new(bytes.fromhex(secret_hex), message.encode(), hashlib.sha512).digest()[:32].hex()

# ---------------------------------------------------------------- server state
STATE = {
    "challenge": "aabbccddeeff00112233445566778899",
    "session_id": None,
    "session_secret": None,
    "session_expires": None,
    "revoked": False,
    "lease_seconds": 90,
}

def now_str(offset=0):
    return (datetime.now() + timedelta(seconds=offset)).strftime("%Y-%m-%d %H:%M:%S")

def envelope(status, code, data, request, http=200):
    meta = {
        "req_id": str(request.get("req_id", "")),
        "nonce": str(request.get("nonce", "")),
        "srv_nonce": hashlib.sha256(os.urandom(16)).hexdigest()[:32],
        "ts": str(int(time.time())),
    }
    sign_fields = {"proto": "TAKEY-V2", "status": status, "code": code}
    sign_fields.update(data)
    sign_fields.update(meta)
    body = {
        "proto": "TAKEY-V2",
        "status": status,
        "code": code,
        "data": data,
        "meta": meta,
        "sig": sign(canonical(sign_fields)),
        "alg": "ecdsa-p256",
    }
    return http, json.dumps(body)

def sec_report(request):
    """Đọc sec_* từ request — giống security_report_parse() PHP."""
    keys = ["sec_dbg", "sec_dump", "sec_func", "sec_mem", "sec_vpn", "sec_ctr"]
    vals, present, valid = {}, False, True
    for k in keys:
        raw = request.get(k)
        if raw is None or raw == "":
            continue
        present = True
        raw = str(raw)
        if not (raw.isdigit() and len(raw) <= 3):
            valid = False
            continue
        vals[k] = int(raw)
    return present, valid, vals

def policy_violations(vals):
    vi = []
    if vals.get("sec_dbg", 0) >= 2: vi.append("debug")
    if vals.get("sec_dump", 0) >= 2: vi.append("dump")
    if vals.get("sec_func", 0) > 0: vi.append("tamper_func")
    if vals.get("sec_mem", 0) >= 2: vi.append("tamper_mem")
    if vals.get("sec_vpn", 0) >= 1: vi.append("vpn")
    return vi

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # im lặng
        pass

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        request = json.loads(self.rfile.read(length) or b"{}")
        action = request.get("action", "")

        if self.path.endswith("auth.php"):
            if action == "init":
                data = {
                    "server_pub": PUB_HEX,
                    "alg": "ecdsa-p256",
                    "challenge": STATE["challenge"],
                    "contact": "admin@test.local",
                    "maintenance": "0",
                    "lease_seconds": str(STATE["lease_seconds"]),
                    "challenge_ttl": "600",
                }
                self._reply(*envelope("ok", "ok", data, request))
                return
            if action == "authenticate":
                # S06.5: policy integrity report NGAY TỪ KHÂU CẤP SESSION
                present, valid, vals = sec_report(request)
                if present and valid and policy_violations(vals):
                    http, body = envelope("denied", "security_violation",
                                          {"contact": "admin@test.local"}, request, 403)
                    self._reply(http, body)
                    print(f"    [server] authenticate DENIED: violations={policy_violations(vals)}")
                    return
                STATE["session_id"] = "e" * 64
                STATE["session_secret"] = hashlib.sha256(b"mock-secret").hexdigest()
                STATE["session_expires"] = now_str(STATE["lease_seconds"])
                STATE["revoked"] = False
                data = {
                    "session_id": STATE["session_id"],
                    "session_secret": STATE["session_secret"],
                    "lease_expires": STATE["session_expires"],
                    "key_expires": now_str(86400 * 30),
                    "key_type": "static",
                    "days_left": "30",
                    "contact": "admin@test.local",
                    "maintenance": "0",
                }
                self._reply(*envelope("ok", "ok", data, request))
                return
            self._reply(*envelope("denied", "bad_request", {}, request, 400))
            return

        if self.path.endswith("session.php"):
            sid = str(request.get("session_id", ""))
            if STATE["revoked"] or sid != STATE["session_id"]:
                self._reply(*envelope("denied", "session_invalid", {}, request, 401))
                return

            # ===== V3: MAC trên canonical BAO GỒM sec_* (nếu client gửi) =====
            fields = {
                "action": str(request.get("action", "")),
                "nonce": str(request.get("nonce", "")),
                "req_id": str(request.get("req_id", "")),
                "session_id": sid,
                "ts": str(request.get("ts", "")),
            }
            sec_present = False
            for k in ["sec_dbg", "sec_dump", "sec_func", "sec_mem", "sec_vpn", "sec_ctr"]:
                v = request.get(k, "")
                if v != "":
                    fields[k] = str(v)
                    sec_present = True
            expected = mac_hex(canonical(fields), STATE["session_secret"])
            given = str(request.get("mac", "")).lower()
            if expected != given:
                print(f"    [server] MAC MISMATCH: expected {expected[:16]}.. got {given[:16]}..")
                self._reply(*envelope("denied", "mac_invalid", {}, request, 401))
                return
            print(f"    [server] MAC OK trên {len(fields)} trường"
                  + (" (gồm sec_* integrity report)" if sec_present else " (legacy 5 trường)"))

            # ===== V3: policy — SERVER QUYẾT ĐỊNH =====
            present, valid, vals = sec_report(request)
            if present and (not valid or policy_violations(vals)):
                vi = policy_violations(vals) if valid else ["malformed"]
                print(f"    [server] DENIED: violations={vi} → REVOKE session")
                STATE["revoked"] = True
                self._reply(*envelope("denied", "security_violation", {}, request, 403))
                return

            STATE["session_expires"] = now_str(STATE["lease_seconds"])
            data = {
                "lease_expires": STATE["session_expires"],
                "key_expires": now_str(86400 * 30),
                "days_left": "30",
                "contact": "admin@test.local",
            }
            self._reply(*envelope("ok", "ok", data, request))
            return

        self._reply(*envelope("denied", "bad_request", {}, request, 404))

    def _reply(self, http, body):
        data = body.encode()
        self.send_response(http)
        self.send_header("Content-Type", "application/json; charset=UTF-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

# ---------------------------------------------------------------- runner
def run_client(tmpdir, env_extra, key="AAAA-BBBB-CCCC-DDDD"):  # key truyền qua stdin
    env = dict(os.environ)
    env.update({
        "TAKEY_AUTH_URL": "http://127.0.0.1:18745/api/auth.php",
        "TAKEY_SESSION_URL": "http://127.0.0.1:18745/api/session.php",
        "TAKEY_PACKAGE_TOKEN": "mock-package-token",
        "TAKEY_SERVER_PUB": PUB_HEX,
        "TAKEY_STORAGE": os.path.join(tmpdir, ".license_session"),
        "TAKEY_DEMO_ONCE": "1",
    })
    env.update(env_extra)
    p = subprocess.run(["./build/release/apikey-client"], env=env,
                       capture_output=True, text=True, timeout=30,
                       input=key + "\n",
                       cwd=os.path.dirname(os.path.abspath(__file__)) + "/..")
    return p.stdout + p.stderr

def main():
    server = ThreadingHTTPServer(("127.0.0.1", 18745), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    time.sleep(0.3)

    results = []

    # ---- Kịch bản A: authorize sạch ----
    print("\n=== A) authorize môi trường sạch (sec_* sạch kèm authenticate) ===")
    tmpA = tempfile.mkdtemp()
    outA = run_client(tmpA, {})
    okA = "[AUTHORIZED]" in outA
    results.append(("A: authorize sạch → AUTHORIZED", okA))
    print(f"    → {'PASS' if okA else 'FAIL'}")

    # ---- Kịch bản B: restore sạch — heartbeat MAC 11 trường ----
    print("\n=== B) restore sạch → session check MAC 11 trường (sec_* trong MAC) ===")
    outB = run_client(tmpA, {})
    okB = "[AUTHORIZED]" in outB and "lease còn" in outB
    results.append(("B: restore → MAC 11 trường verify OK → AUTHORIZED", okB))
    print(f"    → {'PASS' if okB else 'FAIL'}")

    # ---- Kịch bản C: VPN detected → server DENY + revoke ----
    print("\n=== C) restore với http_proxy → sec_vpn=1 TRONG MAC → server DENY ===")
    outC = run_client(tmpA, {"http_proxy": "http://proxy.attacker:8080"})
    # Server deny → client restore → DENIED session → không AUTHORIZED
    okC = "[AUTHORIZED]" not in outC
    results.append(("C: VPN trong MAC → server DENY security_violation", okC))
    print(f"    → {'PASS' if okC else 'FAIL'}")

    # ---- Kịch bản D: VPN + storage mới → bị chặn NGAY từ authenticate ----
    # (server quyết định từ lúc vào app — không phải chờ có session mới chặn)
    print("\n=== D) VPN + storage mới → DENY ngay tại authenticate (không có session) ===")
    tmpD = tempfile.mkdtemp()
    outD = run_client(tmpD, {"http_proxy": "http://proxy.attacker:8080"})
    okD = "[AUTHORIZED]" not in outD and "security_violation" in outD
    results.append(("D: VPN từ lúc vào app → DENY ngay tại authenticate", okD))
    print(f"    → {'PASS' if okD else 'FAIL'}")
    shutil.rmtree(tmpD, ignore_errors=True)

    shutil.rmtree(tmpA, ignore_errors=True)
    server.shutdown()

    print("\n" + "=" * 60)
    for name, ok in results:
        print(f"  {'✓' if ok else '✗'} {name}")
    n_ok = sum(1 for _, ok in results if ok)
    print(f"E2E V3: {n_ok}/{len(results)} kịch bản PASS")
    return 0 if n_ok == len(results) else 1

if __name__ == "__main__":
    sys.exit(main())
