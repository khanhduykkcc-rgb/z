#!/usr/bin/env python3
"""
gen_sec_fixture.py — sinh fixture cross-language cho MAC mở rộng (V3).

Canonical string phải giống HỆT PHP Crypto::canonical() và C++ crypto::canonical():
    "TAKEY-SIG-1\n" + với mỗi trường (sort theo tên, byte-order):
    str(len(name)) + ":" + name + "=" + str(len(value)) + ":" + value + "\n"

MAC = HMAC-SHA-512 trên (message, hex2bin(key)) — cắt 32 byte đầu → hex 64 ký tự
(= NaCl crypto_auth / PHP substr(hash_hmac('sha512', msg, key), 0, 64)).

Python là bên THỨ BA độc lập (PHP đã sinh fixtures gốc, C++ là bên được test)
→ cross-language validation thật sự.
"""
import hashlib
import hmac
import json
import random

V = "TAKEY-SIG-1"

def canonical(fields: dict) -> str:
    out = V + "\n"
    for name in sorted(fields.keys()):
        value = fields[name]
        out += f"{len(name)}:{name}={len(value)}:{value}\n"
    return out

def mac_hex(message: str, key_hex: str) -> str:
    key = bytes.fromhex(key_hex)
    d = hmac.new(key, message.encode(), hashlib.sha512).digest()
    return d[:32].hex()

random.seed(20260924)  # deterministic cho test
key_hex = ''.join(random.choice('0123456789abcdef') for _ in range(64))

base = {
    "action":     "check",
    "nonce":      "a1b2c3d4e5f60718293a4b5c6d7e8f90",
    "req_id":     "deadbeefcafe1234",
    "session_id": "e" * 64,
    "ts":         "1790000000",
}
sec = {
    "sec_dbg":  "0",
    "sec_dump": "1",
    "sec_func": "0",
    "sec_mem":  "2",
    "sec_vpn":  "1",
    "sec_ctr":  "7",
}

msg_ext = canonical({**base, **sec})
msg_legacy = canonical(base)

fixture = {
    "_comment": "Sinh bởi scripts/gen_sec_fixture.py (bên thứ 3 — Python). MAC mở rộng = HMAC-SHA-512-256 trên canonical 11 trường.",
    "session_secret_hex": key_hex,
    "base_fields": base,
    "sec_fields": sec,
    "canonical_expected": msg_ext,
    "mac_expected": mac_hex(msg_ext, key_hex),
    "canonical_legacy_expected": msg_legacy,
    "mac_legacy_expected": mac_hex(msg_legacy, key_hex),
}

with open("tests/fixtures/sec_mac_vectors.json", "w") as f:
    json.dump(fixture, f, indent=2)

print("Message (11 fields):")
print(msg_ext)
print("MAC ext :", fixture["mac_expected"])
print("MAC legacy:", fixture["mac_legacy_expected"])
