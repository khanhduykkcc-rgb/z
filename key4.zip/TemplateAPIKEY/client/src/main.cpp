/*
 * main.cpp — demo dòng lệnh cho thư viện client V2.
 *
 * Cách tích hợp thật: link các file src/ (trừ main.cpp) vào app của bạn
 * và tự hiện thực UI — xem README.md mục "Tích hợp client".
 *
 * Demo minh họa state machine: authorize → AUTHORIZED → revalidation
 * nền → in trạng thái. Ctrl+C để thoát (shutdown sạch, không crash).
 */

#include <chrono>
#include <csignal>
#include <ctime>
#include <iostream>
#include <string>
#include <thread>

#include "api/api_client.hpp"
#include "auth/auth_pipeline.hpp"
#include "config.hpp"
#include "device/device.hpp"
#include "http.hpp"
#include "protection/anti_dump.hpp"
#include "protection/anti_vpn.hpp"
#include "protection/integrity.hpp"
#include "protection/ollvm.hpp"
#include "protection/security_state.hpp"
#include "protection/vmprotect.hpp"
#include "storage.hpp"

namespace {

volatile std::sig_atomic_t g_stop = 0;

void handle_signal(int) {
    g_stop = 1;
}

void print_stage(const auth::StageMark& s) {
    std::cout << "  S" << (s.stage < 10 ? "0" : "") << s.stage
              << "  " << (s.ok ? "[OK]   " : "[FAIL] ") << s.label;
    if (!s.reason.empty()) {
        std::cout << " — " << s.reason;
    }
    std::cout << "\n";
}

long now() {
    return static_cast<long>(std::time(nullptr));
}

}  // namespace

int main() {
    std::signal(SIGINT, handle_signal);
    std::signal(SIGTERM, handle_signal);

    const Config config = Config::defaults();
    auto transport = create_default_transport();
    FileStorage storage(config.storage_path);
    DefaultDeviceIdentity device;

    /* DỰNG PIPELINE = TOÀN BỘ LỚP BẢO MẬT TỰ KÍCH HOẠT (constructor gọi
     * SecurityMonitor::prime()): anti-VPN chạy đầu, anti-debug, anti-dump
     * watchdog, func-integrity baseline, memory-integrity baseline.
     * KHÔNG cần nhấn bất kỳ nút nào. */
    AuthPipeline pipeline(config, *transport, device, storage);

    /* Báo cáo môi trường bảo mật — trung thực, không phóng đại */
    const auto vmp  = Protection::vmprotect_status();
    const auto obf  = Protection::ollvm_status();
    const Protection::SecuritySnapshot sec = Protection::SecurityMonitor::instance().full_snapshot();
    const auto func_monitored = Protection::FuncIntegrity::instance().last_checks().size();

    std::cout << "API Panel — C++ Client V2 (TAKEY-V2 + V3 Protection)\n"
              << "Server    : " << config.auth_url << "\n"
              << "Device ID : " << device.uuid() << "\n\n"
              << "[AUTO-PROTECTION] (tự kích hoạt khi app khởi động)\n"
              << "  Anti-VPN/Proxy : " << (sec.vpn.detected ? "DETECTED (server sẽ quyết định chặn)"
                                                      : "clean")
              << "\n"
              << "  Anti-Debug     : " << Protection::security_level_name(sec.anti_debug.level)
              << "\n"
              << "  Anti-Dump      : " << Protection::dump_level_name(sec.dump.level)
              << " (watchdog " << (sec.dump.watchdog_stale == Protection::CheckResult::Unavailable
                                     ? "n/a" : "running")
              << ", stale " << sec.dump.stale_ms << "ms)\n"
              << "  FuncIntegrity  : " << func_monitored << " hàm được giám sát, "
              << sec.func_tampered << " bị patch\n"
              << "  MemoryIntegrity: canary vault " << (sec.mem_level == 2 ? "BROKEN" : "ok")
              << ", level " << sec.mem_level << "\n"
              << "  VMProtect      : " << (vmp.active ? "ACTIVE" : "not-active")
              << " — " << vmp.detail << "\n"
              << "  OLLVM          : " << (obf.active ? "ACTIVE" : "not-active")
              << " — " << obf.detail << "\n"
              << "  Aggregate      : " << Protection::security_level_name(sec.level)
              << " (report sec_* sẽ đi kèm mọi request; server quyết định)\n\n";

    /* Thử khôi phục session cũ trước (khỏi gõ key lại nếu lease còn) */
    std::cout << "[restore] kiểm tra session cũ... ";
    std::cout.flush();
    auth::Snapshot snap = pipeline.restore();

    if (snap.state != auth::State::Authorized) {
        std::cout << "không có / hết hạn.\n\n";

        for (;;) {
            if (g_stop) {
                return 0;
            }
            std::cout << "License key> ";
            std::cout.flush();
            std::string key;
            if (!std::getline(std::cin, key)) {
                return 0;
            }
            while (!key.empty() && (key.back() == ' ' || key.back() == '\r')) {
                key.pop_back();
            }
            if (key.empty()) {
                continue;
            }

            snap = pipeline.authorize(key);

            std::cout << "\n";
            for (const auto& s : snap.stages) {
                print_stage(s);
            }
            std::cout << "\n";

            if (snap.authorized(now())) {
                break;
            }

            if (snap.state == auth::State::Denied) {
                std::cout << "DENIED (" << snap.last_code << ")";
                if (!snap.contact.empty()) {
                    std::cout << " — liên hệ: " << snap.contact;
                }
                std::cout << "\n\n";
            } else {
                std::cout << "Lỗi tạm thời (" << auth::state_name(snap.state) << ")"
                          << (snap.last_error.empty() ? "" : " — " + snap.last_error)
                          << " — thử lại hoặc kiểm tra kết nối.\n\n";
            }
        }
    } else {
        std::cout << "OK (lease còn hạn).\n\n";
    }

    std::cout << "[AUTHORIZED]\n"
              << "  State        : " << auth::state_name(snap.state) << "\n"
              << "  Lease còn    : " << (snap.lease_expires - now()) << " giây\n"
              << "  Key hết hạn  : " << (snap.key_expires != 0 ? std::to_string(snap.days_left) + " ngày nữa" : "—") << "\n\n"
              << "Revalidation chạy nền theo chu kỳ lease/3. Ctrl+C để thoát.\n\n";

    /* TAKEY_DEMO_ONCE=1: in 1 snapshot rồi thoát — dùng cho E2E test */
    if (std::getenv("TAKEY_DEMO_ONCE") != nullptr) {
        const auth::Snapshot s = pipeline.snapshot();
        std::cout << "[" << (s.authorized(now()) ? "AUTHORIZED" : auth::state_name(s.state)) << "]"
                  << " lease còn " << (s.lease_expires > now() ? s.lease_expires - now() : 0) << "s\n";
        std::cout << "DEMO-EXIT\n";
        return 0;
    }

    /* Vòng demo: in trạng thái mỗi 5 giây — cho thấy lease được gia hạn */
    while (!g_stop) {
        const auth::Snapshot s = pipeline.snapshot();
        std::cout << "[" << (s.authorized(now()) ? "AUTHORIZED" : auth::state_name(s.state)) << "]"
                  << " lease còn " << (s.lease_expires > now() ? s.lease_expires - now() : 0) << "s"
                  << " (code=" << (s.last_code.empty() ? "-" : s.last_code) << ")\n";
        std::cout.flush();
        for (int i = 0; i < 50 && !g_stop; ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }

    std::cout << "\nThoát — thu hồi session...\n";
    pipeline.logout();
    return 0;
}
