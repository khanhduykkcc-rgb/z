/*
 * http_curl.cpp — HTTP(S) transport bằng libcurl (build: make CURL=1).
 */

#include "http.hpp"

#include <curl/curl.h>

#include <stdexcept>
#include <string>

namespace {

size_t append_to_string(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* body = static_cast<std::string*>(userdata);
    body->append(ptr, size * nmemb);
    return size * nmemb;
}

size_t header_to_string(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* out = static_cast<std::string*>(userdata);
    out->append(ptr, size * nmemb);
    return size * nmemb;
}

class CurlGlobal {
public:
    CurlGlobal()  { curl_global_init(CURL_GLOBAL_DEFAULT); }
    ~CurlGlobal() { curl_global_cleanup(); }
};

std::string lower(std::string s) {
    for (char& c : s) {
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return s;
}

}  // namespace

class CurlTransport final : public IHttpTransport {
public:
    HttpResponse get(const std::string& url, int timeout_seconds) override {
        return perform(url, "GET", "", "", timeout_seconds);
    }

    HttpResponse post(const std::string& url,
                      const std::string& body,
                      const std::string& content_type,
                      int timeout_seconds) override {
        return perform(url, "POST", body, content_type, timeout_seconds);
    }

private:
    static HttpResponse perform(const std::string& url,
                                const char* method,
                                const std::string& body,
                                const std::string& content_type,
                                int timeout_seconds) {
        static CurlGlobal global_init;

        CURL* curl = curl_easy_init();
        if (curl == nullptr) {
            throw std::runtime_error("curl_easy_init failed");
        }

        HttpResponse res;
        std::string headers_raw;
        curl_slist* header_list = nullptr;
        CURLcode code = CURLE_OK;

        if (std::string(method) == "POST") {
            curl_easy_setopt(curl, CURLOPT_POST, 1L);
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
            curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
            if (!content_type.empty()) {
                header_list = curl_slist_append(header_list, ("Content-Type: " + content_type).c_str());
                curl_easy_setopt(curl, CURLOPT_HTTPHEADER, header_list);
            }
        } else {
            curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);
        }

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 3L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, static_cast<long>(timeout_seconds));
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, static_cast<long>(timeout_seconds));
        curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "apikey-client/2.0");
        curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, append_to_string);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &res.body);
        curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, header_to_string);
        curl_easy_setopt(curl, CURLOPT_HEADERDATA, &headers_raw);

        code = curl_easy_perform(curl);

        if (code == CURLE_OK) {
            long status = 0;
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
            res.status = status;
        }

        curl_easy_cleanup(curl);
        if (header_list != nullptr) {
            curl_slist_free_all(header_list);
        }

        if (code != CURLE_OK) {
            throw std::runtime_error(std::string("curl: ") + curl_easy_strerror(code));
        }
        fill_content_type(res, headers_raw);
        return res;
    }

    static void fill_content_type(HttpResponse& res, const std::string& headers_raw) {
        const std::string headers = lower(headers_raw);
        const auto ct = headers.find("content-type:");
        if (ct == std::string::npos) {
            return;
        }
        const auto eol = headers.find("\r\n", ct);
        std::string value = headers.substr(ct + 13, (eol == std::string::npos ? headers.size() : eol) - ct - 13);
        const auto first = value.find_first_not_of(" \t");
        const auto last  = value.find_last_not_of(" \t\r\n");
        res.content_type = (first == std::string::npos) ? "" : value.substr(first, last - first + 1);
    }
};

std::unique_ptr<IHttpTransport> create_curl_transport() {
    return std::make_unique<CurlTransport>();
}

std::unique_ptr<IHttpTransport> create_default_transport() {
    return std::make_unique<CurlTransport>();
}
