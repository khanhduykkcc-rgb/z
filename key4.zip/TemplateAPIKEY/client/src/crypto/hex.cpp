#include "crypto/hex.hpp"

namespace crypto {

namespace {
int nibble(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
}  // namespace

std::string hex_encode(const unsigned char* data, std::size_t len) {
    static const char* kHex = "0123456789abcdef";
    std::string out;
    out.reserve(len * 2);
    for (std::size_t i = 0; i < len; ++i) {
        out.push_back(kHex[data[i] >> 4]);
        out.push_back(kHex[data[i] & 0x0F]);
    }
    return out;
}

std::string hex_encode(const std::string& raw) {
    return hex_encode(reinterpret_cast<const unsigned char*>(raw.data()), raw.size());
}

std::vector<unsigned char> hex_decode(const std::string& hex) {
    std::vector<unsigned char> out;
    if (hex.size() % 2 != 0) {
        return out;
    }
    out.reserve(hex.size() / 2);
    for (std::size_t i = 0; i < hex.size(); i += 2) {
        const int hi = nibble(hex[i]);
        const int lo = nibble(hex[i + 1]);
        if (hi < 0 || lo < 0) {
            out.clear();
            return out;
        }
        out.push_back(static_cast<unsigned char>((hi << 4) | lo));
    }
    return out;
}

bool is_hex(const std::string& value) {
    if (value.empty()) {
        return false;
    }
    for (char c : value) {
        if (nibble(c) < 0) {
            return false;
        }
    }
    return true;
}

}  // namespace crypto
