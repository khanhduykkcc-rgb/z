#include "crypto/mac.hpp"

#include <array>
#include <cstring>
#include <vector>

extern "C" {
#include "tweetnacl.h"
}

#include "crypto/hex.hpp"

/*
 * HMAC-SHA-512-256 (NaCl crypto_auth) — dựng theo đúng RFC 2104
 * trên primitive SHA-512 ĐÃ AUDITED của TweetNaCl (crypto_hash):
 *
 *   K'        = K padded về block size 128 byte (key 32 byte → pad 0)
 *   inner     = SHA-512((K' ^ ipad) || message)
 *   mac(32B)  = SHA-512((K' ^ opad) || inner)[0..31]
 *
 * Đây là construction có chuẩn, không phải thuật toán tự chế.
 * Tính đúng được cross-verify với PHP hash_hmac('sha512') trong unit test
 * (tests/test_main.cpp) và E2E (server tính MAC y hệt).
 */

namespace crypto {
namespace {

constexpr std::size_t kBlock = 128;  /* SHA-512 block size */
constexpr unsigned char kIpad = 0x36;
constexpr unsigned char kOpad = 0x5c;

bool sha512(const unsigned char* msg, std::size_t len, unsigned char out[64]) {
    return crypto_hash(out, msg, static_cast<unsigned long long>(len)) == 0;
}

}  // namespace

std::string mac_hex(const std::string& message, const std::string& key_hex) {
    const std::vector<unsigned char> key = hex_decode(key_hex);
    if (key.size() != 32) {  /* session_secret = 32 byte */
        return "";
    }

    /* K' padded to 128 bytes */
    std::array<unsigned char, kBlock> kpad{};
    std::memcpy(kpad.data(), key.data(), key.size());

    std::array<unsigned char, kBlock> ipad{};
    std::array<unsigned char, kBlock> opad{};
    for (std::size_t i = 0; i < kBlock; ++i) {
        ipad[i] = static_cast<unsigned char>(kpad[i] ^ kIpad);
        opad[i] = static_cast<unsigned char>(kpad[i] ^ kOpad);
    }

    /* inner = SHA512(ipad || msg) */
    std::vector<unsigned char> inner_input(ipad.begin(), ipad.end());
    inner_input.insert(inner_input.end(), message.begin(), message.end());

    unsigned char inner[64];
    if (!sha512(inner_input.data(), inner_input.size(), inner)) {
        return "";
    }

    /* outer = SHA512(opad || inner) → cắt 32 byte đầu */
    std::vector<unsigned char> outer_input(opad.begin(), opad.end());
    outer_input.insert(outer_input.end(), inner, inner + 64);

    unsigned char outer[64];
    if (!sha512(outer_input.data(), outer_input.size(), outer)) {
        return "";
    }

    return hex_encode(outer, 32);  /* HMAC-SHA-512-256 */
}

bool mac_equal(const std::string& expected_hex, const std::string& given_hex) {
    if (expected_hex.size() != given_hex.size()) {
        return false;
    }
    /* constant-time */
    unsigned char diff = 0;
    for (std::size_t i = 0; i < expected_hex.size(); ++i) {
        diff |= static_cast<unsigned char>(expected_hex[i]) ^
                static_cast<unsigned char>(given_hex[i]);
    }
    return diff == 0;
}

}  // namespace crypto
