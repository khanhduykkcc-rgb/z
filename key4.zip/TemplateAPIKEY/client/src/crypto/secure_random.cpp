/*
 * secure_random.cpp — CSPRNG qua /dev/urandom, fallback std::random_device.
 *
 * File này đồng thời cung cấp randombytes() cho TweetNaCl
 * (tweetnacl.c khai báo extern randombytes nhưng không định nghĩa).
 */

#include "crypto/secure_random.hpp"

#include <fcntl.h>
#include <unistd.h>

#include <array>
#include <cstdio>
#include <mutex>
#include <random>
#include <stdexcept>

namespace crypto {

namespace {

std::mutex g_urandom_mutex;

bool read_urandom(unsigned char* out, std::size_t bytes) {
    if (bytes == 0) {
        return true;
    }

    std::lock_guard<std::mutex> lock(g_urandom_mutex);
    const int fd = ::open("/dev/urandom", O_RDONLY);
    if (fd < 0) {
        return false;
    }

    std::size_t got = 0;
    while (got < bytes) {
        const ssize_t n = ::read(fd, out + got, bytes - got);
        if (n <= 0) {
            ::close(fd);
            return false;
        }
        got += static_cast<std::size_t>(n);
    }
    ::close(fd);
    return true;
}

void fallback_random(unsigned char* out, std::size_t bytes) {
    /* std::random_device: trên clang/libc++ (iOS/macOS) là arc4random —
     * CSPRNG; trên một số nền tảng khác có thể chỉ là engine thường.
     * Trộn thêm entropy thời gian để không lặp pattern giữa các tiến trình. */
    static std::mutex fb_mutex;
    std::lock_guard<std::mutex> lock(fb_mutex);

    std::random_device rd;
    std::uniform_int_distribution<unsigned> dist(0, 255);
    for (std::size_t i = 0; i < bytes; ++i) {
        out[i] = static_cast<unsigned char>(dist(rd));
    }
}

std::string to_hex(const unsigned char* data, std::size_t len) {
    static const char* kHex = "0123456789abcdef";
    std::string out;
    out.reserve(len * 2);
    for (std::size_t i = 0; i < len; ++i) {
        out.push_back(kHex[data[i] >> 4]);
        out.push_back(kHex[data[i] & 0x0F]);
    }
    return out;
}

bool g_last_strong = false;

}  // namespace

void random_bytes(unsigned char* out, std::size_t bytes) {
    g_last_strong = read_urandom(out, bytes);
    if (!g_last_strong) {
        fallback_random(out, bytes);
    }
}

std::string random_hex(std::size_t bytes) {
    std::string raw(bytes, '\0');
    random_bytes(reinterpret_cast<unsigned char*>(&raw[0]), bytes);
    return to_hex(reinterpret_cast<const unsigned char*>(raw.data()), bytes);
}

bool random_source_strong() {
    return g_last_strong;
}

}  // namespace crypto

/* ---- randombytes cho TweetNaCl (link symbol C) ---- */
extern "C" void randombytes(unsigned char* buf, unsigned long long len) {
    crypto::random_bytes(buf, static_cast<std::size_t>(len));
}
