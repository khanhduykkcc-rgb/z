#include "crypto/canonical.hpp"

#include <algorithm>

namespace crypto {
namespace {

constexpr const char* kVersion = "TAKEY-SIG-1";

/* So sánh byte-order tăng dần — giống ksort(..., SORT_STRING) của PHP.
 * Dùng unsigned compare để không phụ thuộc signedness của char. */
bool name_less(const std::pair<std::string, std::string>& a,
               const std::pair<std::string, std::string>& b) {
    const std::size_t n = std::min(a.first.size(), b.first.size());
    for (std::size_t i = 0; i < n; ++i) {
        const unsigned char ca = static_cast<unsigned char>(a.first[i]);
        const unsigned char cb = static_cast<unsigned char>(b.first[i]);
        if (ca != cb) {
            return ca < cb;
        }
    }
    return a.first.size() < b.first.size();
}

}  // namespace

std::string canonical(const Fields& fields) {
    Fields sorted(fields);
    std::sort(sorted.begin(), sorted.end(), name_less);

    std::string out(kVersion);
    out.push_back('\n');
    for (const auto& kv : sorted) {
        out += std::to_string(kv.first.size());
        out.push_back(':');
        out += kv.first;
        out.push_back('=');
        out += std::to_string(kv.second.size());
        out.push_back(':');
        out += kv.second;
        out.push_back('\n');
    }
    return out;
}

std::string request_mac_message(const std::string& action,
                                const std::string& nonce,
                                const std::string& req_id,
                                const std::string& session_id,
                                const std::string& ts) {
    return canonical({
        {"action",     action},
        {"nonce",      nonce},
        {"req_id",     req_id},
        {"session_id", session_id},
        {"ts",         ts},
    });
}

std::string request_mac_message_ext(const std::string& action,
                                    const std::string& nonce,
                                    const std::string& req_id,
                                    const std::string& session_id,
                                    const std::string& ts,
                                    const std::map<std::string, std::string>& sec_fields) {
    Fields fields;
    fields.reserve(5 + sec_fields.size());
    fields.emplace_back("action",     action);
    fields.emplace_back("nonce",      nonce);
    fields.emplace_back("req_id",     req_id);
    fields.emplace_back("session_id", session_id);
    fields.emplace_back("ts",         ts);

    /* Chỉ thêm trường có GIÁ TRỊ KHÁC RỖNG — quy tắc giống hệt PHP
     * (self_or($request, $k, '') !== '' mới thêm). Client mới luôn gửi đủ
     * 6 trường sec_*; client cũ gửi rỗng → chuỗi về đúng dạng legacy. */
    for (const auto& kv : sec_fields) {
        if (!kv.first.empty() && !kv.second.empty()) {
            fields.emplace_back(kv.first, kv.second);
        }
    }

    return canonical(fields);
}

std::string response_sign_message(const std::string& proto,
                                  const std::string& status,
                                  const std::string& code,
                                  const Fields& data,
                                  const Fields& meta) {
    Fields all;
    all.reserve(3 + data.size() + meta.size());
    all.emplace_back("proto", proto);
    all.emplace_back("status", status);
    all.emplace_back("code", code);
    for (const auto& kv : data) {
        all.push_back(kv);
    }
    for (const auto& kv : meta) {
        all.push_back(kv);
    }
    return canonical(all);
}

}  // namespace crypto
