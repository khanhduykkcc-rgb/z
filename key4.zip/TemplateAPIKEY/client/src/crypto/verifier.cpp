#include "crypto/verifier.hpp"

#include <array>
#include <cstring>

extern "C" {
#include "sha256.h"
#include "uECC.h"
}

#include "crypto/hex.hpp"

namespace crypto {
namespace {

/* ---------------- DER parse: SEQUENCE{ INTEGER r, INTEGER s } ----------------
 * Cấu trúc cố định của chữ ký ECDSA DER:
 *   30 LL 02 LR <r: 1..33 byte> 02 LS <s: 1..33 byte>
 * Parser có kiểm tra biên đầy đủ — input rác bị từ chối, không crash. */
struct DerSig {
    unsigned char r[32];
    unsigned char s[32];
};

bool parse_der_signature(const unsigned char* der, std::size_t len, DerSig& out) {
    auto read_len = [&](std::size_t& pos, std::size_t& value) -> bool {
        if (pos >= len) return false;
        const unsigned char first = der[pos++];
        if (first < 0x80) {
            value = first;
            return true;
        }
        const std::size_t count = first & 0x7F;
        if (count == 0 || count > 4 || pos + count > len) return false;
        value = 0;
        for (std::size_t i = 0; i < count; ++i) {
            value = (value << 8) | der[pos++];
        }
        return true;
    };

    std::size_t pos = 0;

    /* SEQUENCE */
    if (pos >= len || der[pos] != 0x30) return false;
    ++pos;
    std::size_t seq_len = 0;
    if (!read_len(pos, seq_len)) return false;
    if (pos + seq_len != len) return false; /* không cho trailing garbage */

    /* INTEGER r */
    if (pos >= len || der[pos] != 0x02) return false;
    ++pos;
    std::size_t r_len = 0;
    if (!read_len(pos, r_len)) return false;
    if (r_len == 0 || r_len > 33 || pos + r_len > len) return false;

    /* Bỏ byte 0 padding đầu (quy tắc DER cho số dương) */
    std::size_t r_off = pos;
    std::size_t r_n   = r_len;
    if (der[r_off] == 0x00) {
        ++r_off;
        --r_n;
    }
    if (r_n > 32) return false;

    std::memset(out.r, 0, 32);
    std::memcpy(out.r + (32 - r_n), der + r_off, r_n); /* left-align vào 32 byte */
    pos += r_len;

    /* INTEGER s */
    if (pos >= len || der[pos] != 0x02) return false;
    ++pos;
    std::size_t s_len = 0;
    if (!read_len(pos, s_len)) return false;
    if (s_len == 0 || s_len > 33 || pos + s_len != len) return false;

    std::size_t s_off = pos;
    std::size_t s_n   = s_len;
    if (der[s_off] == 0x00) {
        ++s_off;
        --s_n;
    }
    if (s_n > 32) return false;

    std::memset(out.s, 0, 32);
    std::memcpy(out.s + (32 - s_n), der + s_off, s_n);

    return true;
}

}  // namespace

VerifyResult verify_server_signature(const std::string& canonical_message,
                                     const std::string& signature_der_hex,
                                     const std::string& public_key_xy_hex) {
    VerifyResult result;

    const std::vector<unsigned char> sig = hex_decode(signature_der_hex);
    const std::vector<unsigned char> pub = hex_decode(public_key_xy_hex);

    if (sig.empty() || pub.size() != 64) {  /* x||y = 32+32 byte */
        result.status = VerifyStatus::INVALID_ARG;
        result.error  = "bad hex input (sig hoặc public key)";
        return result;
    }

    /* 1. Băm SHA-256 canonical message */
    std::array<unsigned char, SHA256_BLOCK_SIZE> digest{};
    SHA256_CTX ctx;
    sha256_init(&ctx);
    sha256_update(&ctx,
                  reinterpret_cast<const BYTE*>(canonical_message.data()),
                  static_cast<unsigned int>(canonical_message.size()));
    sha256_final(&ctx, digest.data());

    /* 2. Parse DER → r||s */
    DerSig parsed{};
    if (!parse_der_signature(sig.data(), sig.size(), parsed)) {
        result.status = VerifyStatus::BAD_DER;
        result.error  = "signature is not valid DER ECDSA structure";
        return result;
    }

    unsigned char rs[64];
    std::memcpy(rs, parsed.r, 32);
    std::memcpy(rs + 32, parsed.s, 32);

    /* 3. Verify bằng micro-ecc (P-256 = secp256r1) */
    const uECC_Curve curve = uECC_secp256r1();
    if (curve == nullptr) {
        result.status = VerifyStatus::INTERNAL_ERROR;
        result.error  = "curve unavailable";
        return result;
    }

    if (uECC_verify(pub.data(), digest.data(), SHA256_BLOCK_SIZE, rs, curve) == 0) {
        result.status = VerifyStatus::BAD_SIGNATURE;
        result.error  = "signature does not match message/public key";
        return result;
    }

    result.status = VerifyStatus::OK;
    return result;
}

}  // namespace crypto
