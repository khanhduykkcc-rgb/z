#include "auth/auth_state.hpp"

namespace auth {

const char* state_name(State s) {
    switch (s) {
        case State::Start:          return "START";
        case State::Initializing:  return "INITIALIZING";
        case State::HelloOk:        return "HELLO_OK";
        case State::Requesting:     return "REQUESTING";
        case State::SessionCreated: return "SESSION_CREATED";
        case State::Authorized:     return "AUTHORIZED";
        case State::Revalidating:   return "REVALIDATING";
        case State::Denied:         return "DENIED";
        case State::AuthExpired:    return "AUTH_EXPIRED";
        case State::Error:          return "ERROR";
    }
    return "UNKNOWN";
}

}  // namespace auth

/* =====================================================================
 * Bảng transition — kiểm soát tập trung, chỉ AuthPipeline dùng được.
 * ===================================================================== */

#include "auth/auth_pipeline.hpp"

namespace auth {

bool AuthStateMachine::can_transition(State from, State to) {
    /* DENIED / AUTH_EXPIRED / ERROR là trạng thái "hạ cánh" an toàn —
     * được vào từ bất kỳ đâu (fail-closed), nhưng chỉ pipeline mới gọi. */
    if (to == State::Denied || to == State::AuthExpired || to == State::Error) {
        return from != State::Start;
    }

    switch (from) {
        case State::Start:
            return to == State::Initializing;
        case State::Initializing:
            return to == State::Requesting;
        case State::Requesting:
            return to == State::HelloOk || to == State::SessionCreated;
        case State::HelloOk:
            return to == State::Requesting;
        case State::SessionCreated:
            return to == State::Authorized || to == State::Requesting;
        case State::Authorized:
            return to == State::Revalidating;
        case State::Revalidating:
            return to == State::Authorized;
        case State::Error:
            /* Phục hồi sau lỗi transient (mạng/server) — được retry */
            return to == State::Revalidating || to == State::Authorized
                || to == State::Requesting || to == State::SessionCreated;
        default:
            return false;
    }
}

const char* AuthStateMachine::illegal_message(State from, State to) {
    (void)from;
    (void)to;
    return "illegal auth state transition";
}

}  // namespace auth
