#include "auth/session.hpp"

#include <cstdio>
#include <ctime>
#include <map>

namespace auth {

long parse_server_datetime(const std::string& value) {
    if (value.size() < 19) {
        return 0;
    }
    std::tm tm{};
    if (std::sscanf(value.c_str(), "%d-%d-%d %d:%d:%d",
                    &tm.tm_year, &tm.tm_mon, &tm.tm_mday,
                    &tm.tm_hour, &tm.tm_min, &tm.tm_sec) != 6) {
        return 0;
    }
    tm.tm_year -= 1900;
    tm.tm_mon  -= 1;
    return static_cast<long>(std::mktime(&tm));
}

std::string Session::serialize() const {
    return serialize(secret);
}

std::string Session::serialize(const std::string& secret_override) const {
    char lease[32];
    char keyexp[32];
    std::snprintf(lease, sizeof(lease), "%ld", lease_expires);
    std::snprintf(keyexp, sizeof(keyexp), "%ld", key_expires);
    char days[16];
    std::snprintf(days, sizeof(days), "%d", days_left);

    std::string out;
    out += "v=2\n";
    out += "sid=" + id + "\n";
    out += "secret=" + secret_override + "\n";
    out += std::string("lease=") + lease + "\n";
    out += std::string("keyexp=") + keyexp + "\n";
    out += "keytype=" + key_type + "\n";
    out += std::string("days=") + days + "\n";
    out += "contact=" + contact + "\n";
    return out;
}

Session Session::deserialize(const std::string& blob) {
    Session s;
    std::map<std::string, std::string> kv;
    std::size_t pos = 0;
    while (pos < blob.size()) {
        const auto eol = blob.find('\n', pos);
        const std::string line = blob.substr(pos, (eol == std::string::npos ? blob.size() : eol) - pos);
        pos = (eol == std::string::npos) ? blob.size() : eol + 1;
        const auto eq = line.find('=');
        if (eq == std::string::npos) {
            continue;
        }
        kv[line.substr(0, eq)] = line.substr(eq + 1);
    }

    if (kv.count("v") == 0 || kv["v"] != "2") {
        return s; /* định dạng không hỗ trợ → coi như rỗng */
    }
    s.id          = kv.count("sid") ? kv["sid"] : "";
    s.secret      = kv.count("secret") ? kv["secret"] : "";
    s.lease_expires = kv.count("lease") ? strtol(kv["lease"].c_str(), nullptr, 10) : 0;
    s.key_expires   = kv.count("keyexp") ? strtol(kv["keyexp"].c_str(), nullptr, 10) : 0;
    s.key_type      = kv.count("keytype") ? kv["keytype"] : "";
    s.days_left     = kv.count("days") ? atoi(kv["days"].c_str()) : 0;
    s.contact       = kv.count("contact") ? kv["contact"] : "";
    return s;
}

}  // namespace auth
