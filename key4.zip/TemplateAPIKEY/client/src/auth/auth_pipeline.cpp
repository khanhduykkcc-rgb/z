/*
 * auth_pipeline.cpp — điều phối xác thực client V2/V3.
 *
 * Luồng đầy đủ (spec mục 2):
 *   Client → create secure request → Server validate (14 stage)
 *   → signed response → Client verifies (sig + echo + timestamp)
 *   → local authenticated state (AUTHORIZED, có lease).
 *
 * Bảo vệ kép (spec mục 14 của PASS 3):
 *   Server Authorization  +  Anti-Debug Security State
 *   → Final Client Authorization State. Anti-debug KHÔNG thay thế server.
 *
 * V3 — SERVER-AUTHORITATIVE TOÀN DIỆN + AUTO-ACTIVATION:
 *   - Constructor: SecurityMonitor::prime() → mọi lớp bảo mật sống ngay.
 *   - Mọi request kèm sec_* report (heartbeat: nằm trong MAC — chống strip).
 *   - Server đọc report → quyết định DENY (xem AuthPipeline.php S13b).
 *     Client không tự phán quyết — local fail-fast chỉ là phòng thủ kép.
 *   - Secret/key trong SecureVault (canary + obfuscate) — chống memory dump.
 */

#include "auth/auth_pipeline.hpp"

#include <chrono>
#include <cstdlib>

#include "crypto/secure_random.hpp"
#include "protection/integrity.hpp"

namespace {

long now_unix() {
    return static_cast<long>(std::time(nullptr));
}

int clamp_min(int v, int lo) { return v < lo ? lo : v; }

}  // namespace

AuthPipeline::AuthPipeline(const Config& config,
                           IHttpTransport& transport,
                           IDeviceIdentity& device,
                           IStorage& storage)
    : config_(config),
      api_(config, transport),
      device_(device),
      storage_(storage),
      security_(Protection::SecurityMonitor::instance()) {
    /* AUTO-ACTIVATION: dựng pipeline = mọi bảo mật tự bật, không cần nhấn.
     * Thứ tự trong prime(): watchdog dump → baseline func-integrity →
     * baseline memory-integrity → quét VPN đầu tiên → anti-debug. */
    security_.prime();

    /* Vault chứa key/secret được monitor canary trong mỗi lần check. */
    Protection::MemoryIntegrity::instance().attach_vault(&vault_);
}

AuthPipeline::~AuthPipeline() {
    Protection::MemoryIntegrity::instance().attach_vault(nullptr);
    stop_revalidation();
    vault_.wipe_all();
}

/* ------------------------- vault helpers ------------------------- */

bool AuthPipeline::vault_secret(std::string& out) const {
    return vault_.get("session_secret", out);
}

void AuthPipeline::vault_set_secret(const std::string& secret) {
    if (secret.empty()) {
        vault_.wipe("session_secret");
    } else {
        vault_.set("session_secret", secret);
    }
}

std::map<std::string, std::string> AuthPipeline::security_report() {
    return security_.report();
}

/* ------------------------- state machine ------------------------- */

void AuthPipeline::set_state(auth::State to, const std::string& code, const std::string& error) {
    /* Bảng transition trong auth_state.cpp chặn mọi đường tắt */
    if (!auth::AuthStateMachine::can_transition(snap_.state, to)) {
        /* Chuyển bất hợp lệ → không thực hiện; ghi lỗi để debug.
         * Đặc biệt: không bao giờ cho phép nhảy tới AUTHORIZED trực tiếp. */
        snap_.last_error = std::string("blocked transition ")
            + auth::state_name(snap_.state) + " -> " + auth::state_name(to)
            + (error.empty() ? "" : (" (" + error + ")"));
        return;
    }
    snap_.state     = to;
    snap_.last_code = code;
    snap_.last_error = error;
}

void AuthPipeline::mark(int stage, const std::string& label, bool ok, const std::string& reason) {
    snap_.stages.push_back(auth::StageMark{stage, label, ok, reason});
    if (snap_.stages.size() > 64) {
        snap_.stages.erase(snap_.stages.begin()); /* giữ trace gọn */
    }
}

/* --------------------------- authorize --------------------------- */

auth::Snapshot AuthPipeline::authorize(const std::string& key) {
    std::lock_guard<std::mutex> lock(mutex_);
    snap_.stages.clear();

    /* Key vào vault (obfuscated + canary) — bản copy wipe ngay. */
    {
        std::string key_copy = key;
        vault_.set("license_key", key_copy);
        Protection::secure_wipe(key_copy);
    }

    /* S01 — client initialization */
    set_state(auth::State::Initializing, "", "");
    mark(1, "Client initialization", true, "");

    /* Dò nguồn ngẫu nhiên trực tiếp (1 byte) để báo cáo đúng trạng thái */
    crypto::random_hex(1);
    if (!crypto::random_source_strong()) {
        mark(1, "CSPRNG source", false, "không đọc được /dev/urandom — dùng fallback");
    }

    /* Kiểm tra môi trường bảo mật TRƯỚC khi gửi key đi.
     * VPN được quét ĐẦU TIÊN trong check() (theo ưu tiên anti proxy/vpn).
     * Lớp này chỉ là phòng thủ kép fail-fast — phán quyết cuối thuộc server
     * qua sec_* report kèm mọi request bên dưới. */
    const Protection::SecurityLevel level = security_.check();
    snap_.security_ok = (level != Protection::SecurityLevel::Debugged);
    if (level == Protection::SecurityLevel::Debugged) {
        mark(1, "Security environment", false, "debugger/tamper detected — từ chối kích hoạt");
        set_state(auth::State::Denied, "security_violation", "debugger detected");
        return snap_;
    }

    /* S02 — init (server hello + challenge + public key) */
    set_state(auth::State::Requesting, "", "");
    mark(2, "Init request", true, "");

    std::string challenge;
    std::string server_pub;
    std::string contact;
    bool maintenance = false;

    api::Result res = api_.init(challenge, server_pub, contact, maintenance);

    if (res.status == api::Status::NETWORK_ERROR
        || res.status == api::Status::SERVER_ERROR
        || res.status == api::Status::INVALID_RESPONSE
        || res.status == api::Status::CRYPTO_ERROR) {
        mark(2, "Init verified", false, res.error.empty() ? api::status_name(res.status) : res.error);
        set_state(auth::State::Error, res.code, res.error);
        return snap_;
    }
    if (res.status == api::Status::DENIED) {
        mark(2, "Init verified", false, "server denied: " + res.code);
        set_state(auth::State::Denied, res.code, "");
        return snap_;
    }
    if (maintenance) {
        mark(2, "Package maintenance", false, "package đang bảo trì");
        set_state(auth::State::Denied, "package_maintenance", contact);
        snap_.contact = contact;
        return snap_;
    }

    mark(2, "Init verified", true, "challenge + public key OK");
    set_state(auth::State::HelloOk, "ok", "");

    /* Pin public key đã verify vào storage (TOFU) */
    if (config_.pinned_server_pub.empty() && !server_pub.empty()) {
        std::string existing;
        if (storage_.read(existing) && existing.find("pub=" + server_pub) == std::string::npos
            && existing.find("sid=") != std::string::npos) {
            /* khóa khác với lần trước → từ chối (khóa đã đổi server?) */
            mark(2, "Server key pinning", false, "server key mismatch với lần lưu trước");
            set_state(auth::State::Error, "key_pinning_mismatch", "");
            return snap_;
        }
    }

    /* S03-S10 — authenticate: server chạy pipeline, ta verify verdict.
     * sec_* report đi kèm — server áp policy security_block_* ngay từ khâu
     * cấp session (client báo cáo, SERVER QUYẾT ĐỊNH). */
    set_state(auth::State::Requesting, "", "");
    mark(3, "Authenticate request", true, "security report đính kèm cho server");

    std::string key_for_auth;
    if (!vault_.get("license_key", key_for_auth)) {
        mark(3, "Vault read", false, "license key không đọc được từ vault (canary?)");
        set_state(auth::State::Error, "vault_error", "");
        return snap_;
    }

    std::map<std::string, std::string> data;
    res = api_.authenticate(key_for_auth, device_.uuid(), challenge, data, security_.report());
    Protection::secure_wipe(key_for_auth);

    if (res.status == api::Status::NETWORK_ERROR
        || res.status == api::Status::SERVER_ERROR
        || res.status == api::Status::INVALID_RESPONSE
        || res.status == api::Status::CRYPTO_ERROR) {
        mark(10, "Authenticated (verdict verified)", false,
             res.error.empty() ? api::status_name(res.status) : res.error);
        set_state(auth::State::Error, res.code, res.error);
        return snap_;
    }
    if (res.status != api::Status::OK) {
        mark(10, "Authenticated (verdict verified)", false, "server denied: " + res.code);
        set_state(auth::State::Denied, res.code, "");
        if (data.count("contact")) {
            snap_.contact = data.at("contact");
        }
        return snap_;
    }

    /* Session từ response ĐÃ VERIFY chữ ký — đây là dữ liệu tin được.
     * Secret đi thẳng vào vault; struct chỉ giữ metadata (secret rỗng). */
    session_ = auth::Session{};
    session_.id            = data.count("session_id") ? data.at("session_id") : "";
    {
        std::string secret = data.count("session_secret") ? data.at("session_secret") : "";
        vault_set_secret(secret);
        Protection::secure_wipe(secret);
        /* data map vẫn còn bản sao secret — wipe value trong map copy local */
        if (data.count("session_secret")) {
            std::string& sref = data.at("session_secret");
            Protection::secure_wipe(sref);
        }
    }
    session_.lease_expires = auth::parse_server_datetime(data.count("lease_expires") ? data.at("lease_expires") : "");
    session_.key_expires   = auth::parse_server_datetime(data.count("key_expires") ? data.at("key_expires") : "");
    session_.key_type      = data.count("key_type") ? data.at("key_type") : "";
    session_.days_left     = data.count("days_left") ? atoi(data.at("days_left").c_str()) : 0;
    session_.contact       = data.count("contact") ? data.at("contact") : "";

    bool have_secret = false;
    {
        std::string probe;
        have_secret = vault_secret(probe);
        Protection::secure_wipe(probe);
    }
    if (session_.id.empty() || !have_secret || session_.lease_expires == 0) {
        mark(10, "Session from signed response", false, "thiếu trường session");
        set_state(auth::State::Error, "invalid_session_data", "");
        return snap_;
    }

    mark(10, "Session created (server, signed)", true, "lease đến " + data.at("lease_expires"));
    set_state(auth::State::SessionCreated, "ok", "");

    save_session();

    /* S12+S14 — final gate: verdict + lease + security */
    snap_.lease_expires = session_.lease_expires;
    snap_.key_expires   = session_.key_expires;
    snap_.days_left     = session_.days_left;
    snap_.contact       = session_.contact;

    /* Re-check security trước khi vào AUTHORIZED — phòng thủ kép;
     * server vẫn là nơi quyết định qua heartbeat report. */
    const Protection::SecurityLevel final_level = security_.check();
    snap_.security_ok = (final_level != Protection::SecurityLevel::Debugged);
    if (!snap_.security_ok) {
        mark(14, "Final authorization", false, "debugger/tamper detected");
        set_state(auth::State::Denied, "security_violation", "");
        return snap_;
    }

    mark(12, "Response authenticity (ECDSA verified)", true, "");
    mark(14, "Final authorization", true, "AUTHORIZED");
    set_state(auth::State::Authorized, "ok", "");

    start_revalidation();
    return snap_;
}

/* ---------------------------- restore ---------------------------- */

auth::Snapshot AuthPipeline::restore() {
    std::lock_guard<std::mutex> lock(mutex_);

    std::string blob;
    if (!storage_.read(blob)) {
        return snap_; /* không có session cũ */
    }

    session_ = auth::Session::deserialize(blob);
    if (session_.id.empty()) {
        clear_session();
        Protection::secure_wipe(blob);
        return snap_;
    }

    /* Secret từ storage → vault; wipe blob (vừa chứa secret plain) */
    vault_set_secret(session_.secret);
    Protection::secure_wipe(session_.secret); /* struct giữ metadata thôi */
    Protection::secure_wipe(blob);

    bool have_secret = false;
    {
        std::string probe;
        have_secret = vault_secret(probe);
        Protection::secure_wipe(probe);
    }
    if (!have_secret) {
        mark(13, "Vault read", false, "secret không đọc được (canary?)");
        clear_session();
        set_state(auth::State::Error, "vault_error", "");
        return snap_;
    }

    if (!session_.lease_active_with(now_unix(), true)) {
        mark(13, "Stored session lease", false, "đã hết hạn");
        clear_session();
        set_state(auth::State::AuthExpired, "session_expired", "");
        return snap_;
    }

    /* Restore chỉ đưa tới SESSION_CREATED — AUTHORIZED đòi hỏi revalidate
     * ngay lần đầu để server xác nhận lại (không tin storage cục bộ). */
    if (snap_.state == auth::State::Start) {
        set_state(auth::State::Initializing, "", "");
        set_state(auth::State::Requesting, "", "");
        set_state(auth::State::SessionCreated, "restored", "");
    }

    snap_.lease_expires = session_.lease_expires;
    snap_.key_expires   = session_.key_expires;
    snap_.days_left     = session_.days_left;

    /* Revalidate đồng bộ một lần — kèm security report trong MAC */
    std::string secret;
    if (!vault_secret(secret)) {
        clear_session();
        set_state(auth::State::Error, "vault_error", "");
        return snap_;
    }
    std::map<std::string, std::string> data;
    const api::Result res = api_.session_request("check", session_.id, secret, data, security_.report());
    Protection::secure_wipe(secret);

    if (res.status == api::Status::OK) {
        session_.lease_expires = auth::parse_server_datetime(data.count("lease_expires") ? data.at("lease_expires") : "");
        snap_.lease_expires = session_.lease_expires;
        set_state(auth::State::Authorized, "ok", "");
        save_session();
        start_revalidation();
    } else if (res.status == api::Status::DENIED || res.status == api::Status::AUTH_EXPIRED) {
        clear_session();
        set_state(auth::State::AuthExpired, res.code, "");
    }
    /* NETWORK_ERROR/... → giữ SessionCreated, lần revalidation sau thử lại */
    return snap_;
}

/* ------------------------- snapshot/logout ------------------------- */

auth::Snapshot AuthPipeline::snapshot() {
    std::lock_guard<std::mutex> lock(mutex_);

    /* Auto-degrade: hết lease → không còn authorized (đọc thuần, không đổi state) */
    if (snap_.state == auth::State::Authorized && !session_.lease_active_with(now_unix(), true)) {
        snap_.state = auth::State::AuthExpired;
        snap_.last_code = "session_expired";
    }
    return snap_;
}

void AuthPipeline::logout() {
    stop_revalidation();
    std::lock_guard<std::mutex> lock(mutex_);

    if (!session_.id.empty()) {
        std::string secret;
        if (vault_secret(secret)) {
            std::map<std::string, std::string> data;
            api_.session_request("revoke", session_.id, secret, data, security_.report());
            Protection::secure_wipe(secret);
        }
    }
    clear_session();
    set_state(auth::State::Error, "logged_out", "");
}

/* ------------------------ revalidation loop ------------------------ */

void AuthPipeline::start_revalidation() {
    if (running_.load()) {
        return;
    }
    stop_requested_.store(false);
    running_.store(true);
    worker_ = std::thread([this] { revalidation_loop(); });
}

void AuthPipeline::stop_revalidation() {
    if (!running_.load()) {
        return;
    }
    stop_requested_.store(true);
    {
        std::lock_guard<std::mutex> lock(wake_mutex_);
        wake_.notify_all();
    }
    if (worker_.joinable()) {
        worker_.join();
    }
    running_.store(false);
}

void AuthPipeline::revalidation_loop() {
    int failures = 0;

    while (!stop_requested_.load()) {
        /* Chu kỳ = lease/3, tối thiểu 30s. Lease 600s → renew mỗi 200s. */
        int lease_seconds = 600;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            lease_seconds = static_cast<int>(session_.lease_expires - now_unix());
        }
        const int wait_s = clamp_min(lease_seconds / 3, 30);

        std::unique_lock<std::mutex> lock(wake_mutex_);
        wake_.wait_for(lock, std::chrono::seconds(wait_s),
                       [this] { return stop_requested_.load(); });
        lock.unlock();

        if (stop_requested_.load()) {
            break;
        }

        /* Copy dữ liệu session dưới lock — KHÔNG giữ lock trong lúc HTTP
         * (snapshot() của application không bị block chờ mạng). */
        std::string sid;
        std::string ssecret;
        {
            std::lock_guard<std::mutex> slock(mutex_);
            if (session_.id.empty() || !vault_secret(ssecret)) {
                break;
            }
            set_state(auth::State::Revalidating, "", "");
            sid = session_.id;
        }

        /* HEARTBEAT: security report nằm TRONG MAC → server verify MAC
         * rồi quyết định theo policy (security_block_*). Đây là xương sống
         * "server quyết định tất cả": client chỉ trung thực báo cáo. */
        std::map<std::string, std::string> data;
        const api::Result res = api_.session_request("check", sid, ssecret, data, security_.report());
        Protection::secure_wipe(ssecret);

        if (res.status == api::Status::OK) {
            failures = 0;
            std::lock_guard<std::mutex> slock(mutex_);
            session_.lease_expires =
                auth::parse_server_datetime(data.count("lease_expires") ? data.at("lease_expires") : "");
            snap_.lease_expires = session_.lease_expires;
            snap_.key_expires   = session_.key_expires;
            snap_.days_left     = session_.days_left;
            set_state(auth::State::Authorized, "ok", "");
            save_session();
        } else if (res.status == api::Status::DENIED || res.status == api::Status::AUTH_EXPIRED) {
            std::lock_guard<std::mutex> slock(mutex_);
            /* Server phán quyết: DENIED (kể cả security policy) → cắt ngay */
            clear_session();
            set_state(auth::State::AuthExpired, res.code, "");
            break; /* server đã nói hết hạn — dừng vòng */
        } else {
            /* NETWORK/SERVER/INVALID/CRYPTO — transient: thử lại với backoff */
            ++failures;
            std::lock_guard<std::mutex> slock(mutex_);
            set_state(auth::State::Error, res.code, res.error);
            /* Nhưng nếu lease thực sự đã trôi qua → hết quyền */
            if (!session_.lease_active_with(now_unix(), true)) {
                set_state(auth::State::AuthExpired, "session_expired", "lease trôi qua khi revalidate");
                clear_session();
                break;
            }
            /* backoff: 5s, 10s, 20s... tối đa 60s */
            std::unique_lock<std::mutex> wlock(wake_mutex_);
            wake_.wait_for(wlock, std::chrono::seconds(clamp_min(5 * failures, 60)),
                           [this] { return stop_requested_.load(); });
        }
    }
}

/* --------------------------- storage --------------------------- */

void AuthPipeline::save_session() {
    bool have_secret = false;
    std::string secret;
    have_secret = vault_secret(secret);
    if (session_.id.empty() || !have_secret) {
        return;
    }
    std::string blob = session_.serialize(secret);
    Protection::secure_wipe(secret);
    blob += "pub=" + api_.server_public_key() + "\n";
    storage_.write(blob);
    /* blob ra đĩa (0600) — wipe bản trong memory */
    Protection::secure_wipe(blob);
}

void AuthPipeline::clear_session() {
    storage_.clear();
    vault_.wipe("session_secret");
    session_ = auth::Session{};
    snap_.lease_expires = 0;
    snap_.key_expires   = 0;
}
