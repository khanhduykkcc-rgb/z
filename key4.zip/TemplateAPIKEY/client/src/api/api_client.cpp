/*
 * api_client.cpp — client giao thức TAKEY-V2.
 *
 * Mọi response đi qua validate_envelope() — checklist đầy đủ (spec 13):
 *   1. HTTP status
 *   2. Content-Type chứa json
 *   3. JSON parse
 *   4. Trường bắt buộc + đúng kiểu
 *   5. proto khớp
 *   6. req_id/nonce echo khớp request (chống replay response cũ)
 *   7. timestamp trong cửa sổ drift
 *   8. chữ ký ECDSA P-256 trên canonical (crypto/verifier)
 *
 * Không bao giờ crash trên response rác — mọi lỗi là Result có kiểm soát.
 */

#include "api/api_client.hpp"

#include <ctime>

#include <nlohmann/json.hpp>

#include "crypto/canonical.hpp"
#include "crypto/hex.hpp"
#include "crypto/mac.hpp"
#include "crypto/secure_random.hpp"
#include "crypto/verifier.hpp"

namespace api {

const char* status_name(Status s) {
    switch (s) {
        case Status::OK:               return "OK";
        case Status::DENIED:           return "DENIED";
        case Status::AUTH_EXPIRED:     return "AUTH_EXPIRED";
        case Status::NETWORK_ERROR:    return "NETWORK_ERROR";
        case Status::SERVER_ERROR:     return "SERVER_ERROR";
        case Status::INVALID_RESPONSE: return "INVALID_RESPONSE";
        case Status::CRYPTO_ERROR:     return "CRYPTO_ERROR";
    }
    return "UNKNOWN";
}

}  // namespace api

namespace {

long now_unix() {
    return static_cast<long>(std::time(nullptr));
}

}  // namespace

ApiClientV2::ApiClientV2(const Config& config, IHttpTransport& transport)
    : config_(config), transport_(transport), server_pub_(config.pinned_server_pub) {}

api::Result ApiClientV2::post_json(const std::string& url, const std::string& body) {
    api::Result res;
    try {
        const HttpResponse http = transport_.post(url, body, "application/json", config_.timeout_seconds);
        if (http.status >= 500) {
            res.status = api::Status::SERVER_ERROR;
            res.error  = "HTTP " + std::to_string(http.status);
            return res;
        }
        return res; /* sẽ được điền bởi caller qua validate_envelope */
    } catch (const std::exception& e) {
        res.status = api::Status::NETWORK_ERROR;
        res.error  = e.what();
        return res;
    }
}

api::Result ApiClientV2::init(std::string& out_challenge,
                              std::string& out_server_pub,
                              std::string& out_contact,
                              bool& out_maintenance) {
    const std::string req_id = crypto::random_hex(8);
    const std::string nonce  = crypto::random_hex(16);

    nlohmann::json body;
    body["proto"]         = "TAKEY-V2";
    body["action"]        = "init";
    body["req_id"]        = req_id;
    body["nonce"]         = nonce;
    body["ts"]            = now_unix();
    body["package_token"] = config_.package_token;
    body["client"]        = "apikey-cpp/2.0";

    api::Result res;
    HttpResponse http;
    try {
        http = transport_.post(config_.auth_url, body.dump(), "application/json", config_.timeout_seconds);
    } catch (const std::exception& e) {
        res.status = api::Status::NETWORK_ERROR;
        res.error  = e.what();
        return res;
    }

    if (http.status >= 500) {
        res.status = api::Status::SERVER_ERROR;
        res.error  = "HTTP " + std::to_string(http.status);
        return res;
    }

    /* Lần đầu chưa có key: học từ response (TOFU), sau đó verify */
    std::string pub_for_verify = server_pub_;
    if (pub_for_verify.empty()) {
        /* Bước 1: parse thô để lấy server_pub */
        auto parsed = nlohmann::json::parse(http.body, nullptr, false);
        if (!parsed.is_discarded() && parsed.is_object()) {
            const auto data = parsed.value("data", nlohmann::json::object());
            if (data.is_object()) {
                const std::string pub = data.value("server_pub", "");
                const std::string alg = data.value("alg", "");
                if (alg == "ecdsa-p256" && pub.size() == 128 && crypto::is_hex(pub)) {
                    pub_for_verify = pub;
                }
            }
        }
        if (pub_for_verify.empty()) {
            res.status = api::Status::INVALID_RESPONSE;
            res.error  = "no pinned key and init response has no usable server_pub";
            return res;
        }
    }

    std::map<std::string, std::string> data;
    res = validate_envelope(http.body, http.content_type, http.status,
                            req_id, nonce, config_.max_clock_drift, pub_for_verify,
                            data);
    res.data = data;
    if (!res.ok() && res.status != api::Status::DENIED && res.status != api::Status::AUTH_EXPIRED) {
        return res;
    }
    if (!res.ok()) {
        return res;
    }

    /* init thành công → ghi nhận public key (TOFU) */
    if (server_pub_.empty()) {
        const auto it = res.data.find("server_pub");
        if (it != res.data.end() && it->second.size() == 128 && crypto::is_hex(it->second)) {
            server_pub_ = it->second;
        }
    }

    out_challenge   = res.data.count("challenge") ? res.data.at("challenge") : "";
    out_server_pub  = server_pub_;
    out_contact     = res.data.count("contact") ? res.data.at("contact") : "";
    out_maintenance = res.data.count("maintenance") && res.data.at("maintenance") == "1";
    return res;
}

api::Result ApiClientV2::authenticate(const std::string& key,
                                      const std::string& device_id,
                                      const std::string& challenge,
                                      std::map<std::string, std::string>& out_data,
                                      const std::map<std::string, std::string>& sec_fields) {
    const std::string req_id = crypto::random_hex(8);
    const std::string nonce  = crypto::random_hex(16);

    nlohmann::json body;
    body["proto"]         = "TAKEY-V2";
    body["action"]        = "authenticate";
    body["req_id"]        = req_id;
    body["nonce"]         = nonce;
    body["ts"]            = now_unix();
    body["package_token"] = config_.package_token;
    body["key"]           = key;
    body["device_id"]     = device_id;
    body["challenge"]     = challenge;

    /* Security report đi kèm từ lúc cấp session — client báo cáo, server
     * quyết định (policy check ở stage authenticate của AuthPipeline.php).
     * Client cũ không có sec_* → server thấy là legacy client. */
    for (const auto& kv : sec_fields) {
        if (!kv.first.empty() && !kv.second.empty()) {
            body[kv.first] = kv.second;
        }
    }

    api::Result res;
    HttpResponse http;
    try {
        http = transport_.post(config_.auth_url, body.dump(), "application/json", config_.timeout_seconds);
    } catch (const std::exception& e) {
        res.status = api::Status::NETWORK_ERROR;
        res.error  = e.what();
        return res;
    }

    if (http.status >= 500) {
        res.status = api::Status::SERVER_ERROR;
        res.error  = "HTTP " + std::to_string(http.status);
        return res;
    }

    if (server_pub_.empty()) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "server public key unknown — call init() first";
        return res;
    }

    res = validate_envelope(http.body, http.content_type, http.status,
                            req_id, nonce, config_.max_clock_drift, server_pub_, out_data);
    return res;
}

api::Result ApiClientV2::session_request(const std::string& action,
                                         const std::string& session_id,
                                         const std::string& session_secret,
                                         std::map<std::string, std::string>& out_data,
                                         const std::map<std::string, std::string>& sec_fields) {
    const std::string req_id = crypto::random_hex(8);
    const std::string nonce  = crypto::random_hex(16);
    const std::string ts     = std::to_string(now_unix());

    /* MAC trên canonical 5 trường cốt định + sec_* report — giống hệt PHP
     * session_request_mac_message() (chỉ thêm trường có giá trị khác rỗng).
     * Đây là điểm neo: report bị strip/sửa → MAC sai → server DENY. */
    const std::string mac = crypto::mac_hex(
        crypto::request_mac_message_ext(action, nonce, req_id, session_id, ts, sec_fields),
        session_secret);

    if (mac.empty()) {
        api::Result res;
        res.status = api::Status::CRYPTO_ERROR;
        res.error  = "cannot compute request MAC (bad session secret)";
        return res;
    }

    nlohmann::json body;
    body["proto"]      = "TAKEY-V2";
    body["action"]     = action;
    body["req_id"]     = req_id;
    body["nonce"]      = nonce;
    body["ts"]         = std::stoll(ts);
    body["session_id"] = session_id;
    body["mac"]        = mac;

    /* sec_* phải nằm trong BODY y hệt như trong MAC — server đọc body để
     * check policy, MAC đảm bảo body không bị sửa trên đường. */
    for (const auto& kv : sec_fields) {
        if (!kv.first.empty() && !kv.second.empty()) {
            body[kv.first] = kv.second;
        }
    }

    api::Result res;
    HttpResponse http;
    try {
        http = transport_.post(config_.session_url, body.dump(), "application/json", config_.timeout_seconds);
    } catch (const std::exception& e) {
        res.status = api::Status::NETWORK_ERROR;
        res.error  = e.what();
        return res;
    }

    if (http.status >= 500) {
        res.status = api::Status::SERVER_ERROR;
        res.error  = "HTTP " + std::to_string(http.status);
        return res;
    }

    if (server_pub_.empty()) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "server public key unknown";
        return res;
    }

    res = validate_envelope(http.body, http.content_type, http.status,
                            req_id, nonce, config_.max_clock_drift, server_pub_, out_data);
    return res;
}

/* ===================== Envelope validation ===================== */

api::Result validate_envelope(const std::string& body,
                              const std::string& content_type,
                              long http_status,
                              const std::string& expected_req_id,
                              const std::string& expected_nonce,
                              int max_drift,
                              const std::string& server_pub_hex,
                              std::map<std::string, std::string>& out_data) {
    api::Result res;

    /* 1. HTTP status — caller đã loại 5xx; ghi nhận status vào error nếu từ chối */
    (void)http_status;

    /* 2. Content-Type phải là json — chặn HTML/text rác */
    if (content_type.find("json") == std::string::npos) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "content-type is not json: '" + content_type + "'";
        return res;
    }

    /* 3. JSON parse (không throw) */
    const auto env = nlohmann::json::parse(body, nullptr, false);
    if (env.is_discarded() || !env.is_object()) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "body is not a JSON object";
        return res;
    }

    /* 4. Trường bắt buộc + kiểu */
    static const char* kRequired[] = {"proto", "status", "code", "data", "meta", "sig"};
    for (const char* field : kRequired) {
        if (!env.contains(field)) {
            res.status = api::Status::INVALID_RESPONSE;
            res.error  = std::string("missing field: ") + field;
            return res;
        }
    }
    if (!env["proto"].is_string() || !env["status"].is_string() || !env["code"].is_string()
        || !env["sig"].is_string() || !env["data"].is_object() || !env["meta"].is_object()) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "field type mismatch";
        return res;
    }

    /* 5. proto */
    if (env["proto"].get<std::string>() != "TAKEY-V2") {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "proto mismatch";
        return res;
    }

    const std::string status = env["status"].get<std::string>();
    const std::string code   = env["code"].get<std::string>();

    /* 6. echo req_id + nonce — bind response với request đang chờ */
    const auto& meta = env["meta"];
    if (!meta.contains("req_id") || !meta.contains("nonce") || !meta.contains("ts")
        || !meta["req_id"].is_string() || !meta["nonce"].is_string() || !meta["ts"].is_string()) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "meta missing req_id/nonce/ts";
        return res;
    }
    if (meta["req_id"].get<std::string>() != expected_req_id
        || meta["nonce"].get<std::string>() != expected_nonce) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "req_id/nonce echo mismatch (replayed response?)";
        return res;
    }

    /* 7. timestamp window */
    const long ts = std::strtol(meta["ts"].get<std::string>().c_str(), nullptr, 10);
    const long drift = labs(now_unix() - ts);
    if (ts <= 0 || drift > static_cast<long>(max_drift)) {
        res.status = api::Status::INVALID_RESPONSE;
        res.error  = "server timestamp drift " + std::to_string(drift) + "s";
        return res;
    }

    /* 8. Build canonical + verify chữ ký */
    crypto::Fields data_fields;
    for (auto it = env["data"].begin(); it != env["data"].end(); ++it) {
        if (!it.value().is_string()) {
            res.status = api::Status::INVALID_RESPONSE;
            res.error  = "data field is not string: " + it.key();
            return res;
        }
        data_fields.emplace_back(it.key(), it.value().get<std::string>());
    }

    crypto::Fields meta_fields;
    for (auto it = meta.begin(); it != meta.end(); ++it) {
        if (!it.value().is_string()) {
            continue; /* server luôn trả string — bỏ qua kiểu lạ */
        }
        meta_fields.emplace_back(it.key(), it.value().get<std::string>());
    }

    const std::string message = crypto::response_sign_message(
        env["proto"].get<std::string>(), status, code, data_fields, meta_fields);

    const crypto::VerifyResult verify = crypto::verify_server_signature(
        message, env["sig"].get<std::string>(), server_pub_hex);
    if (!verify.ok()) {
        res.status = api::Status::CRYPTO_ERROR;
        res.error  = "signature: " + verify.error;
        return res;
    }

    /* Tất cả kiểm tra pass → verdict của server được CHẤP NHẬN */
    res.code = code;
    if (status == "ok") {
        res.status = api::Status::OK;
        out_data = std::map<std::string, std::string>(data_fields.begin(), data_fields.end());
    } else if (code == "session_expired") {
        res.status = api::Status::AUTH_EXPIRED;
    } else {
        res.status = api::Status::DENIED;
    }
    return res;
}
