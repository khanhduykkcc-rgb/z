/*
 * device.cpp — UUID ổn định của máy, thuần C++ (POSIX).
 */

#include "device/device.hpp"

#include <ifaddrs.h>
#include <net/if.h>
#include <sys/socket.h>
#include <sys/types.h>

#if defined(__APPLE__)
#include <net/if_dl.h>
#else
#include <netpacket/packet.h>
#endif

#include <cctype>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>

namespace {

std::string trim(const std::string& value) {
    const auto begin = value.find_first_not_of(" \t\r\n");
    if (begin == std::string::npos) {
        return "";
    }
    const auto end = value.find_last_not_of(" \t\r\n");
    return value.substr(begin, end - begin + 1);
}

bool is_hex_uuid(const std::string& value) {
    if (value.size() != 32) {
        return false;
    }
    for (const char c : value) {
        if (!std::isxdigit(static_cast<unsigned char>(c))) {
            return false;
        }
    }
    return true;
}

/* "abcdef012345..." -> "abcdef01-2345-..."; giữ nguyên nếu đã có dấu '-' */
std::string format_uuid(std::string hex) {
    if (hex.find('-') != std::string::npos) {
        return hex;
    }
    if (hex.size() != 32) {
        return hex;
    }
    for (const char c : hex) {
        if (!std::isxdigit(static_cast<unsigned char>(c))) {
            return hex;
        }
    }
    return hex.substr(0, 8) + "-" + hex.substr(8, 4) + "-" + hex.substr(12, 4) + "-"
         + hex.substr(16, 4) + "-" + hex.substr(20, 12);
}

std::string read_machine_id() {
    for (const char* path : {"/etc/machine-id", "/var/lib/dbus/machine-id"}) {
        std::ifstream file(path);
        if (!file) {
            continue;
        }
        std::string line;
        if (std::getline(file, line)) {
            line = trim(line);
            if (is_hex_uuid(line)) {
                return format_uuid(line);
            }
        }
    }
    return "";
}

std::string read_macos_platform_uuid() {
    FILE* pipe = popen("ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null", "r");
    if (pipe == nullptr) {
        return "";
    }

    std::string uuid;
    char buffer[512];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        const std::string line(buffer);
        const auto pos = line.find("IOPlatformUUID");
        if (pos == std::string::npos) {
            continue;
        }
        const auto quote = line.find('"', pos);
        if (quote == std::string::npos) {
            continue;
        }
        const auto start = line.find('"', quote + 1);
        if (start == std::string::npos) {
            continue;
        }
        const auto end = line.find('"', start + 1);
        if (end == std::string::npos) {
            continue;
        }
        uuid = line.substr(start + 1, end - start - 1);
        break;
    }
    pclose(pipe);
    return uuid;
}

std::string mac_to_uuid(const unsigned char* mac) {
    char buf[48];
    std::snprintf(buf, sizeof(buf),
                  "%02x%02x%02x%02x%02x%02x-0000-4000-8000-%02x%02x%02x%02x%02x%02x",
                  mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
                  mac[0] ^ 0xAB, mac[1] ^ 0xCD, mac[2] ^ 0xEF,
                  mac[3] ^ 0x12, mac[4] ^ 0x34, mac[5] ^ 0x56);
    return std::string(buf);
}

std::string first_mac_address() {
    ifaddrs* interfaces = nullptr;
    if (getifaddrs(&interfaces) != 0) {
        return "";
    }

    std::string uuid;
    for (ifaddrs* ifa = interfaces; ifa != nullptr; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr == nullptr || (ifa->ifa_flags & IFF_LOOPBACK) != 0) {
            continue;
        }

        const unsigned char* mac = nullptr;

#if defined(__APPLE__)
        if (ifa->ifa_addr->sa_family == AF_LINK) {
            const auto* sdl = reinterpret_cast<const sockaddr_dl*>(ifa->ifa_addr);
            if (sdl->sdl_alen == 6) {
                mac = reinterpret_cast<const unsigned char*>(LLADDR(sdl));
            }
        }
#else
        if (ifa->ifa_addr->sa_family == AF_PACKET) {
            const auto* sll = reinterpret_cast<const sockaddr_ll*>(ifa->ifa_addr);
            mac = sll->sll_addr;
        }
#endif

        if (mac == nullptr) {
            continue;
        }

        bool all_zero = true;
        for (int i = 0; i < 6 && all_zero; ++i) {
            if (mac[i] != 0) {
                all_zero = false;
            }
        }
        if (!all_zero) {
            uuid = mac_to_uuid(mac);
            break;
        }
    }

    freeifaddrs(interfaces);
    return uuid;
}

}  // namespace

std::string DefaultDeviceIdentity::uuid() {
    static const std::string cached = []() -> std::string {
        std::string id = read_machine_id();
        if (id.empty()) {
            id = read_macos_platform_uuid();
        }
        if (id.empty()) {
            id = first_mac_address();
        }
        return id.empty() ? "unknown-device" : id;
    }();
    return cached;
}
