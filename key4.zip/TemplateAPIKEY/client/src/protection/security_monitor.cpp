/*
 * security_monitor.cpp — SecurityMonitor: điều phối TOÀN BỘ lớp bảo mật client.
 *
 * (Đây là phần mở rộng V3 — anti-debug signals nằm ở anti_debug.cpp,
 *  VPN ở anti_vpn.cpp, dump ở anti_dump.cpp, integrity ở integrity.cpp.)
 *
 * Điểm neo kiến trúc "SERVER-AUTHORITATIVE":
 *   check() tổng hợp 5 module → report() xuất các trường sec_* →
 *   ApiClientV2 đưa vào canonical MAC của MỌI session request →
 *   server (AuthPipeline.php) verify MAC + đọc report + quyết định.
 *   Client không bao giờ tự chặn theo ý riêng — local fail-fast chỉ là
 *   lớp phòng thủ kép (xem auth_pipeline.cpp).
 */

#include "protection/security_state.hpp"

#include <chrono>
#include <map>
#include <string>

#include "crypto/secure_random.hpp"
#include "protection/integrity.hpp"

namespace Protection {

namespace {

long now_unix() {
    return static_cast<long>(std::time(nullptr));
}

}  // namespace

SecurityMonitor& SecurityMonitor::instance() {
    static SecurityMonitor monitor;
    return monitor;
}

void SecurityMonitor::prime() {
    /* Thứ tự: watchdog dump phải start TRƯỚC để baseline nhịp tim được ghi
     * trước mọi kiểm tra khác. Func/Memory baseline kế tiếp — càng sớm càng
     * "sạch" (chưa có kẻ tấn công nào kịp patch runtime). */
    DumpDetector::instance().start();
    FuncIntegrity::instance().prime();
    MemoryIntegrity::instance().prime();

    /* Chạy ngay một vòng check đầy đủ (VPN ưu tiên chạy đầu trong check()).
     * prime() thường được gọi lúc app vừa mở — mọi bảo vệ sống ngay lập tức. */
    force_next_check();
    check();
}

SecuritySnapshot SecurityMonitor::cached_snapshot() const {
    std::lock_guard<std::mutex> lock(snap_mutex_);
    return last_;
}

SecurityLevel SecurityMonitor::check() {
    const long now = now_unix();

    SecuritySnapshot prev;
    {
        std::lock_guard<std::mutex> lock(snap_mutex_);
        prev = last_;
    }

    /* Throttle — tránh tốn CPU khi app gọi check() nhiều lần */
    const long last = last_run_.load();
    if (last != 0 && now - last < min_interval_s_.load() && prev.checks_run > 0) {
        std::lock_guard<std::mutex> lock(snap_mutex_);
        return last_.level; /* dùng kết quả gần nhất */
    }
    last_run_.store(now);

    SecuritySnapshot snap;

    /* ---- 1. VPN/Proxy — ƯU TIÊN chạy đầu (theo yêu cầu anti proxy/vpn) ---- */
    snap.vpn = VpnDetector::instance().detect();

    /* ---- 2. Anti-debug (5 tín hiệu MASTG) ---- */
    snap.anti_debug = run_anti_debug_checks(prev.anti_debug.checks_run);

    /* ---- 3. Anti-dump ---- */
    snap.dump = DumpDetector::instance().detect();

    /* ---- 4. FuncIntegrity: self-checksum runtime ---- */
    snap.func_tampered = FuncIntegrity::instance().verify();

    /* ---- 5. MemoryIntegrity: canary + rwx + inject ---- */
    snap.mem_level = [&] {
        switch (MemoryIntegrity::instance().verify()) {
            case MemLevel::Clean:      return 0;
            case MemLevel::Suspicious: return 1;
            case MemLevel::Tampered:   return 2;
        }
        return 0;
    }();

    snap.last_check_ts = now;
    snap.checks_run    = prev.checks_run + 1;
    snap.strong_random = crypto::random_source_strong();

    /* ---- Aggregation tổng ----
     * MẠNH → Debugged:
     *   - anti-debug strong signal
     *   - dump chữ ký (mức 2)
     *   - hàm crypto/verify bị patch runtime (func_tampered > 0)
     *   - memory tamper (mức 2: canary vỡ / thư viện inject)
     * YẾU → Suspicious:
     *   - VPN/proxy phát hiện
     *   - anti-debug weak / dump mức 1 / mem mức 1 (rwx mới — có thể JIT)
     */
    const bool strong = snap.anti_debug.level == SecurityLevel::Debugged
                     || snap.dump.level == DumpLevel::Detected
                     || snap.func_tampered > 0
                     || snap.mem_level == 2;
    const bool weak = snap.anti_debug.level == SecurityLevel::Suspicious
                   || snap.vpn.detected
                   || snap.dump.level == DumpLevel::Suspicious
                   || snap.mem_level == 1;

    snap.level = strong ? SecurityLevel::Debugged
               : weak   ? SecurityLevel::Suspicious
                        : SecurityLevel::Normal;

    {
        std::lock_guard<std::mutex> lock(snap_mutex_);
        last_ = snap;
    }

    /* DEBUG build: chế độ chỉ quan sát — ghi nhận nhưng không kết luận chặn
     * (level vẫn được báo cáo trung thực lên server — server quyết định). */
    if (observe_only_.load() && snap.level == SecurityLevel::Debugged) {
        return SecurityLevel::Suspicious;
    }
    return snap.level;
}

SecuritySnapshot SecurityMonitor::full_snapshot() const {
    return cached_snapshot();
}

AntiDebugSnapshot SecurityMonitor::snapshot() const {
    std::lock_guard<std::mutex> lock(snap_mutex_);
    return last_.anti_debug;
}

std::map<std::string, std::string> SecurityMonitor::report() {
    /* Report đi kèm MAC — phải phản ánh hiện trạng: chạy check() (bên trong
     * có throttle, gọi liên tục không tốn CPU) rồi đọc snapshot mới nhất. */
    check();

    SecuritySnapshot snap = cached_snapshot();

    std::map<std::string, std::string> out;
    out["sec_dbg"]  = security_level_value(snap.anti_debug.level);
    out["sec_dump"] = DumpDetector::instance().report_value();
    out["sec_func"] = std::to_string(snap.func_tampered);
    out["sec_mem"]  = std::to_string(snap.mem_level);
    out["sec_vpn"]  = VpnDetector::instance().report_value();
    out["sec_ctr"]  = std::to_string(snap.checks_run);
    return out;
}

}  // namespace Protection
