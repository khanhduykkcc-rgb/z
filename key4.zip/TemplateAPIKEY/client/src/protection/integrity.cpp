/*
 * integrity.cpp — hiện thực FuncIntegrity + MemoryIntegrity + SecureVault.
 * Xem integrity.hpp cho thiết kế.
 */

#include "protection/integrity.hpp"

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>

#include <algorithm>

#include "api/api_client.hpp"
#include "auth/auth_pipeline.hpp"
#include "crypto/canonical.hpp"
#include "crypto/mac.hpp"
#include "crypto/secure_random.hpp"
#include "crypto/verifier.hpp"

extern "C" {
#include "sha256.h"
}

#if defined(__linux__)
    #include <fstream>
#endif

#if defined(__APPLE__)
    #include <mach/mach.h>
    #include <mach-o/dyld.h>
#endif

namespace Protection {

namespace {

/* SHA-256 (vendored, public domain) → hex lowercase 64 ký tự. */
std::string sha256_hex(const unsigned char* data, std::size_t len) {
    SHA256_CTX ctx;
    sha256_init(&ctx);
    sha256_update(&ctx, data, len);
    unsigned char digest[SHA256_BLOCK_SIZE];
    sha256_final(&ctx, digest);

    static const char* kHex = "0123456789abcdef";
    std::string out;
    out.reserve(SHA256_BLOCK_SIZE * 2);
    for (int i = 0; i < SHA256_BLOCK_SIZE; ++i) {
        out.push_back(kHex[(digest[i] >> 4) & 0xF]);
        out.push_back(kHex[digest[i] & 0xF]);
    }
    return out;
}

/* ------------------- Safe read: vùng mapped executable ------------------- */

struct MappedRange {
    bool        valid = false;
    const void* start = nullptr;
    std::size_t size  = 0;
};

#if defined(__linux__)
/* Đọc /proc/self/maps — tìm vùng chứa addr. Format dòng:
 * start-end rwxp offset dev inode pathname */
MappedRange find_mapped_range(const void* addr) {
    MappedRange range;
    std::ifstream maps("/proc/self/maps");
    if (!maps) {
        return range; /* valid = false → caller xử lý an toàn */
    }
    const uintptr_t target = reinterpret_cast<uintptr_t>(addr);
    std::string line;
    while (std::getline(maps, line)) {
        unsigned long long start = 0, end = 0;
        char perms[8] = {0};
        if (std::sscanf(line.c_str(), "%llx-%llx %7s", &start, &end, perms) != 3) {
            continue;
        }
        if (target >= start && target < end) {
            range.valid = true;
            range.start = reinterpret_cast<const void*>(static_cast<uintptr_t>(start));
            range.size  = static_cast<std::size_t>(end - start);
            return range;
        }
    }
    return range;
}
#elif defined(__APPLE__)
MappedRange find_mapped_range(const void* addr) {
    MappedRange range;
    mach_vm_address_t address = reinterpret_cast<mach_vm_address_t>(addr);
    mach_vm_size_t    size    = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t count = VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t object_name = MACH_PORT_NULL;

    const kern_return_t kr = ::mach_vm_region(
        ::mach_task_self(), &address, &size, VM_REGION_BASIC_INFO_64,
        reinterpret_cast<vm_region_info_t>(&info), &count, &object_name);
    if (kr != KERN_SUCCESS) {
        return range;
    }
    /* mach_vm_region có thể trả về vùng TRƯỚC addr — chỉ nhận nếu addr nằm trong */
    if (reinterpret_cast<uintptr_t>(addr) >= address
        && reinterpret_cast<uintptr_t>(addr) < address + size) {
        range.valid = true;
        range.start = reinterpret_cast<const void*>(static_cast<uintptr_t>(address));
        range.size  = static_cast<std::size_t>(size);
    }
    return range;
}
#else
MappedRange find_mapped_range(const void*) {
    MappedRange range; /* valid = false — nền khác: đọc trực tiếp 64 bytes */
    return range;
}
#endif

/* Đọc an toàn `want` bytes tại addr — tự clamp theo vùng mapped. */
bool safe_read_bytes(const void* addr, std::size_t want, std::vector<unsigned char>& out) {
    out.clear();
    if (addr == nullptr || want == 0) {
        return false;
    }
    const MappedRange range = find_mapped_range(addr);
    std::size_t len = want;
    if (range.valid) {
        const std::size_t offset =
            reinterpret_cast<uintptr_t>(addr) - reinterpret_cast<uintptr_t>(range.start);
        if (offset >= range.size) {
            return false;
        }
        const std::size_t avail = range.size - offset;
        if (len > avail) {
            len = avail; /* clamp — không đọc lấn vùng */
        }
    } else {
#if defined(__linux__) || defined(__APPLE__)
        /* maps đọc được nhưng không tìm thấy addr → vùng KHÔNG mapped: từ chối */
        return false;
#else
        len = want > 64 ? 64 : want; /* fallback platform khác: đọc ít thôi */
#endif
    }
    out.resize(len);
    std::memcpy(out.data(), addr, len);
    return true;
}

/* ------------------- Quét mapping: rwx + tên đáng ngờ ------------------- */

struct MapsScan {
    bool   ok = false;
    long   rwx_count = 0;
    bool   suspicious_lib = false;
};

#if defined(__linux__)
MapsScan scan_maps() {
    MapsScan scan;
    std::ifstream maps("/proc/self/maps");
    if (!maps) {
        return scan;
    }
    std::string line;
    while (std::getline(maps, line)) {
        unsigned long long start = 0, end = 0;
        char perms[8] = {0};
        if (std::sscanf(line.c_str(), "%llx-%llx %7s", &start, &end, perms) != 3) {
            continue;
        }
        if (perms[0] == 'r' && perms[1] == 'w' && perms[2] == 'x') {
            ++scan.rwx_count;
        }
        const std::string lower = [&line] {
            std::string s = line;
            std::transform(s.begin(), s.end(), s.begin(),
                           [](unsigned char c) { return static_cast<char>(c >= 'A' && c <= 'Z' ? c + 32 : c); });
            return s;
        }();
        static const char* kBad[] = {
            "frida", "gum-js", "gadget", "substrate", "cycript", "r2frida", "libinject",
        };
        for (const char* bad : kBad) {
            if (lower.find(bad) != std::string::npos) {
                scan.suspicious_lib = true;
                break;
            }
        }
    }
    scan.ok = true;
    return scan;
}
#elif defined(__APPLE__)
MapsScan scan_maps() {
    MapsScan scan;
    /* Duyệt vùng nhớ bằng mach_vm_region_recurse + đếm rwx... */
    mach_vm_address_t address = 0;
    mach_vm_size_t    size    = 0;
    natural_t         depth   = 0;

    for (;;) {
        struct vm_region_submap_info_64 info;
        mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
        const kern_return_t kr = ::mach_vm_region_recurse(
            ::mach_task_self(), &address, &size, &depth,
            reinterpret_cast<vm_region_recurse_info_t>(&info), &count);
        if (kr != KERN_SUCCESS) {
            break;
        }
        if (info.is_submap) {
            ++depth;
            continue;
        }
        if ((info.protection & VM_PROT_READ) != 0
            && (info.protection & VM_PROT_WRITE) != 0
            && (info.protection & VM_PROT_EXECUTE) != 0) {
            ++scan.rwx_count;
        }
        address += size;
        if (address == 0) {
            break; /* wrap — duyệt xong */
        }
    }

    /* Quét tên ảnh dylib đã nạp (API công khai mach-o/dyld.h — dùng được
     * cả iOS): frida/substrate/cycript inject dylib vào tiến trình. */
    static const char* kBad[] = {
        "frida", "gum-js", "gadget", "substrate", "cycript", "r2frida", "libinject",
    };
    const uint32_t image_count = ::_dyld_image_count();
    for (uint32_t i = 0; i < image_count; ++i) {
        const char* image_name = ::_dyld_get_image_name(i);
        if (image_name == nullptr) {
            continue;
        }
        std::string lower(image_name);
        std::transform(lower.begin(), lower.end(), lower.begin(),
                       [](unsigned char c) {
                           return static_cast<char>(c >= 'A' && c <= 'Z' ? c + 32 : c);
                       });
        for (const char* bad : kBad) {
            if (lower.find(bad) != std::string::npos) {
                scan.suspicious_lib = true;
                break;
            }
        }
        if (scan.suspicious_lib) {
            break;
        }
    }

    scan.ok = true;
    return scan;
}
#else
MapsScan scan_maps() {
    MapsScan scan; /* ok = false → UNAVAILABLE trung thực */
    return scan;
}
#endif

}  // namespace

/* ========================= FuncIntegrity ========================= */

FuncIntegrity& FuncIntegrity::instance() {
    static FuncIntegrity fi;
    return fi;
}

void FuncIntegrity::reset_for_test() {
    std::lock_guard<std::mutex> lock(mutex_);
    regions_.clear();
    last_checks_.clear();
    primed_ = false;
    verify_count_ = 0;
}

bool FuncIntegrity::register_region(const std::string& name, const void* addr, std::size_t bytes) {
    if (name.empty() || addr == nullptr || bytes == 0) {
        return false;
    }
    std::lock_guard<std::mutex> lock(mutex_);
    for (const Region& r : regions_) {
        if (r.name == name) {
            return false; /* trùng tên — từ chối (tránh đếm 2 lần) */
        }
    }
    Region r;
    r.name  = name;
    r.addr  = addr;
    r.bytes = bytes;

    /* Nếu ĐÃ prime: baseline tính NGAY lúc đăng ký (đăng ký sau prime
     * vẫn đúng — vùng này được chụp trước lần verify đầu tiên). */
    if (primed_) {
        if (!hash_region(r, r.baseline_hex)) {
            return false; /* vùng đọc không được — từ chối đăng ký */
        }
    }
    regions_.push_back(r);
    return true;
}

bool FuncIntegrity::hash_region(const Region& r, std::string& out_hex) const {
    std::vector<unsigned char> bytes;
    if (!safe_read_bytes(r.addr, r.bytes, bytes)) {
        return false;
    }
    out_hex = sha256_hex(bytes.data(), bytes.size());
    return true;
}

void FuncIntegrity::prime() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (primed_) {
        return;
    }

    /* 1) Baseline cho các vùng ĐÃ đăng ký trước prime (custom/test) —
     * vùng nào hash không được thì loại khỏi danh sách (trung thực). */
    std::vector<Region> keep;
    keep.reserve(regions_.size() + 8);
    for (Region& r : regions_) {
        if (!r.baseline_hex.empty() || hash_region(r, r.baseline_hex)) {
            keep.push_back(r);
        }
    }
    regions_.swap(keep);

    /* 2) Đăng ký các hàm lõi ra quyết định + crypto — nếu bị NOP/patch runtime
     * (đường tấn công kinh điển: NOP hàm verify) → verify() sẽ thấy khác. */
    struct Target {
        const char*  name;
        const void*  addr;
        std::size_t  bytes;
    };
    static const Target kDefaults[] = {
        {"verifier.verify_server_signature", reinterpret_cast<const void*>(&crypto::verify_server_signature), 192},
        {"crypto.mac_hex",                    reinterpret_cast<const void*>(&crypto::mac_hex), 96},
        {"crypto.canonical",                  reinterpret_cast<const void*>(&crypto::canonical), 96},
        {"api.validate_envelope",             reinterpret_cast<const void*>(&validate_envelope), 96},
        {"auth.state_machine.can_transition", reinterpret_cast<const void*>(&auth::AuthStateMachine::can_transition), 64},
        {"protection.security_level_name",    reinterpret_cast<const void*>(&security_level_name), 48},
    };

    for (const Target& t : kDefaults) {
        Region r;
        r.name  = t.name;
        r.addr  = t.addr;
        r.bytes = t.bytes;
        if (hash_region(r, r.baseline_hex)) {
            regions_.push_back(r);
        }
        /* hash fail (hiếm: vùng đọc không được) → bỏ qua hàm đó, trung thực
         * trong last_checks_ khi verify: không có = không bịa kết quả. */
    }
    primed_ = true;
}

int FuncIntegrity::verify() {
    std::lock_guard<std::mutex> lock(mutex_);
    ++verify_count_;
    last_checks_.clear();

    int tampered = 0;
    for (const Region& r : regions_) {
        FuncCheck c;
        c.name = r.name;
        c.baseline = r.baseline_hex;
        std::string current;
        if (!hash_region(r, current)) {
            c.result  = CheckResult::Error;
            c.current = "";
        } else {
            c.current = current;
            c.result  = (current == r.baseline_hex) ? CheckResult::NotDetected
                                                    : CheckResult::Detected;
            if (c.result == CheckResult::Detected) {
                ++tampered;
            }
        }
        last_checks_.push_back(c);
    }
    return tampered;
}

long FuncIntegrity::verify_count() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return verify_count_;
}

std::string FuncIntegrity::report_value() const {
    std::lock_guard<std::mutex> lock(mutex_);
    int tampered = 0;
    for (const FuncCheck& c : last_checks_) {
        if (c.result == CheckResult::Detected) {
            ++tampered;
        }
    }
    return std::to_string(tampered);
}

/* ========================= MemoryIntegrity ========================= */

MemoryIntegrity& MemoryIntegrity::instance() {
    static MemoryIntegrity mi;
    return mi;
}

void MemoryIntegrity::reset_for_test() {
    std::lock_guard<std::mutex> lock(mutex_);
    baseline_rwx_count_ = -1;
    last_level_ = MemLevel::Clean;
    verify_count_ = 0;
}

void MemoryIntegrity::prime() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (baseline_rwx_count_ >= 0) {
        return;
    }
    const MapsScan scan = scan_maps();
    if (scan.ok) {
        baseline_rwx_count_ = scan.rwx_count;
    } else {
        baseline_rwx_count_ = -2; /* không scan được — verify() sẽ bỏ tín hiệu này */
    }
}

MemLevel MemoryIntegrity::verify() {
    std::lock_guard<std::mutex> lock(mutex_);
    ++verify_count_;
    last_level_ = MemLevel::Clean;

    /* 1. Canary vault */
    if (vault_ != nullptr && !vault_->canaries_ok()) {
        last_level_ = MemLevel::Tampered;
        return last_level_;
    }

    const MapsScan scan = scan_maps();
    if (!scan.ok) {
        /* Không scan được — trung thực: không kết luận gì từ tín hiệu này */
        return last_level_;
    }

    /* 2. Thư viện inject đã nạp → TAMPERED (chắc chắn) */
    if (scan.suspicious_lib) {
        last_level_ = MemLevel::Tampered;
        return last_level_;
    }

    /* 3. Vùng rwx MỚI xuất hiện so baseline → Suspicious (JIT hợp lệ cũng
     *    tạo rwx — chỉ nâng mức nghi vấn, server quyết định). */
    if (baseline_rwx_count_ >= 0 && scan.rwx_count > baseline_rwx_count_) {
        last_level_ = MemLevel::Suspicious;
    }
    return last_level_;
}

/* ========================= SecureVault ========================= */

SecureVault::~SecureVault() {
    wipe_all();
}

SecureVault::Entry* SecureVault::find(const std::string& name) {
    for (Entry& e : entries_) {
        if (e.name == name) {
            return &e;
        }
    }
    return nullptr;
}

const SecureVault::Entry* SecureVault::find(const std::string& name) const {
    for (const Entry& e : entries_) {
        if (e.name == name) {
            return &e;
        }
    }
    return nullptr;
}

void SecureVault::set(const std::string& name, const std::string& value) {
    if (name.empty()) {
        return;
    }
    std::lock_guard<std::mutex> lock(mutex_);

    /* Wipe entry cũ cùng tên trước khi thay */
    Entry* old = find(name);
    if (old != nullptr) {
        secure_wipe(old->blob, old->alloc);
        delete[] old->blob;
        old->blob = nullptr;
        entries_.erase(std::remove_if(entries_.begin(), entries_.end(),
                                      [&name](const Entry& e) { return e.name == name; }),
                       entries_.end());
    }

    Entry e;
    e.name     = name;
    e.data_len = value.size();

    /* Keystream CSPRNG — mỗi entry một keystream riêng */
    std::string key_hex = crypto::random_hex(e.data_len > 0 ? e.data_len : 1);
    if (key_hex.empty()) {
        /* CSPRNG lỗi (cực hiếm) — keystream fallback tĩnh: vẫn che được
         * grep chuỗi trong dump (obfuscation), đã ghi nhận nguồn yếu. */
        key_hex.assign((e.data_len > 0 ? e.data_len : 1) * 2, '3');
    }

    /* Bố cục: [canary 8][data][key][canary 8] — 1 cấp phát liền khối */
    e.data_off = kCanaryBytes;
    e.key_off  = e.data_off + e.data_len;
    e.alloc    = e.key_off + (key_hex.size() / 2) + kCanaryBytes;

    e.blob = new (std::nothrow) unsigned char[e.alloc];
    if (e.blob == nullptr) {
        return;
    }
    std::memset(e.blob, 0, e.alloc);

    /* Canary: giá trị CSPRNG (không đoán được) */
    const std::string can_hex = crypto::random_hex(8);
    e.canary_front = can_hex.size() == 16 ? std::strtoull(can_hex.c_str(), nullptr, 16) : 0x9E3779B97F4A7C15ULL;
    e.canary_back  = e.canary_front ^ 0xA5A5A5A5DEADBEEFULL;

    std::memcpy(e.blob, &e.canary_front, kCanaryBytes);

    /* Data XOR keystream */
    for (std::size_t i = 0; i < e.data_len; ++i) {
        const unsigned char k = static_cast<unsigned char>(
            std::strtol(key_hex.substr(i * 2, 2).c_str(), nullptr, 16));
        e.blob[e.data_off + i] = static_cast<unsigned char>(value[i]) ^ k;
    }
    /* Keystream kế bên (lấy lại khi decrypt) */
    for (std::size_t i = 0; i < key_hex.size() / 2; ++i) {
        const unsigned char k = static_cast<unsigned char>(
            std::strtol(key_hex.substr(i * 2, 2).c_str(), nullptr, 16));
        e.blob[e.key_off + i] = k;
    }
    std::memcpy(e.blob + e.alloc - kCanaryBytes, &e.canary_back, kCanaryBytes);

    /* Wipe keystream hex tạm trong stack/heap */
    secure_wipe(key_hex);

    entries_.push_back(e);
}

bool SecureVault::get(const std::string& name, std::string& out) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const Entry* e = find(name);
    if (e == nullptr || e->blob == nullptr) {
        return false;
    }

    /* Kiểm canary TRƯỚC khi giải mã — canary hỏng = đã bị can thiệp */
    std::uint64_t front = 0;
    std::uint64_t back  = 0;
    std::memcpy(&front, e->blob, kCanaryBytes);
    std::memcpy(&back, e->blob + e->alloc - kCanaryBytes, kCanaryBytes);
    if (front != e->canary_front || back != e->canary_back) {
        return false;
    }

    out.clear();
    out.reserve(e->data_len);
    for (std::size_t i = 0; i < e->data_len; ++i) {
        const unsigned char k = e->blob[e->key_off + i];
        out.push_back(static_cast<char>(e->blob[e->data_off + i] ^ k));
    }
    return true;
}

bool SecureVault::canaries_ok() const {
    std::lock_guard<std::mutex> lock(mutex_);
    for (const Entry& e : entries_) {
        if (e.blob == nullptr) {
            return false;
        }
        std::uint64_t front = 0;
        std::uint64_t back  = 0;
        std::memcpy(&front, e.blob, kCanaryBytes);
        std::memcpy(&back, e.blob + e.alloc - kCanaryBytes, kCanaryBytes);
        if (front != e.canary_front || back != e.canary_back) {
            return false;
        }
    }
    return true;
}

void SecureVault::wipe(const std::string& name) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto it = entries_.begin(); it != entries_.end(); ++it) {
        if (it->name == name) {
            if (it->blob != nullptr) {
                secure_wipe(it->blob, it->alloc);
                delete[] it->blob;
            }
            entries_.erase(it);
            return;
        }
    }
}

void SecureVault::wipe_all() {
    std::lock_guard<std::mutex> lock(mutex_);
    for (Entry& e : entries_) {
        if (e.blob != nullptr) {
            secure_wipe(e.blob, e.alloc);
            delete[] e.blob;
            e.blob = nullptr;
        }
    }
    entries_.clear();
}

void SecureVault::debug_corrupt_canary(const std::string& name, bool front) {
    std::lock_guard<std::mutex> lock(mutex_);
    Entry* e = find(name);
    if (e == nullptr || e->blob == nullptr) {
        return;
    }
    const std::uint64_t bad = 0xDEADBEEFCAFEBABEULL;
    if (front) {
        std::memcpy(e->blob, &bad, kCanaryBytes);
    } else {
        std::memcpy(e->blob + e->alloc - kCanaryBytes, &bad, kCanaryBytes);
    }
}

/* ========================= helpers ========================= */

void secure_wipe(void* ptr, std::size_t len) {
    if (ptr == nullptr || len == 0) {
        return;
    }
    volatile unsigned char* p = static_cast<volatile unsigned char*>(ptr);
    for (std::size_t i = 0; i < len; ++i) {
        p[i] = 0;
    }
    /* Barrier chống compiler re-order/elision */
    std::atomic_signal_fence(std::memory_order_seq_cst);
}

void secure_wipe(std::string& s) {
    if (!s.empty()) {
        secure_wipe(&s[0], s.size());
    }
    s.clear();
}

std::string vault_random_hex(std::size_t n_bytes) {
    return crypto::random_hex(n_bytes);
}

}  // namespace Protection
