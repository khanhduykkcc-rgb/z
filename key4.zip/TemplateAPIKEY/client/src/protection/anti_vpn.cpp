/*
 * anti_vpn.cpp — hiện thực phát hiện proxy/VPN (PASS 3 mở rộng).
 *
 * Xem anti_vpn.hpp cho thiết kế. Tín hiệu 1 (env) chạy trên mọi nền Unix;
 * tín hiệu 2 dùng /sys/class/net (Linux) hoặc getifaddrs (Apple);
 * tín hiệu 3 dùng scutil (chỉ macOS); tín hiệu 4 suy ra từ tín hiệu 1.
 */

#include "protection/anti_vpn.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

#include <algorithm>

#if defined(__linux__)
    #include <dirent.h>
#endif

#if defined(__APPLE__)
    #include <ifaddrs.h>
    #include <sys/socket.h>
    #include <net/if.h>
#endif

namespace Protection {

namespace {

long now_unix() {
    return static_cast<long>(std::time(nullptr));
}

bool env_nonempty(const char* name) {
    const char* v = std::getenv(name);
    return v != nullptr && *v != '\0';
}

/* Không tính no_proxy="*" — người dùng chủ động tắt proxy toàn bộ. */
bool no_proxy_all() {
    const char* v = std::getenv("no_proxy");
    if (v == nullptr) {
        v = std::getenv("NO_PROXY");
    }
    if (v == nullptr) {
        return false;
    }
    /* strip whitespace + so sánh "*" */
    std::string s(v);
    while (!s.empty() && (s.back() == ' ' || s.back() == '\t')) {
        s.pop_back();
    }
    return s == "*";
}

bool value_is_loopback(const char* name) {
    const char* v = std::getenv(name);
    if (v == nullptr || *v == '\0') {
        return false;
    }
    const std::string s(v);
    return s.rfind("http://127.", 0) == 0
        || s.rfind("http://localhost", 0) == 0
        || s.rfind("socks5://127.", 0) == 0
        || s.rfind("socks5h://127.", 0) == 0
        || s.rfind("http://[::1]", 0) == 0
        || (s.find("localhost:") != std::string::npos && s.rfind("http://", 0) == 0);
}

/* ---------------- Tín hiệu 1: proxy env vars ---------------- */
CheckResult check_env_proxy_vars(bool* out_loopback_only) {
    static const char* kVars[] = {
        "http_proxy", "https_proxy", "all_proxy",
        "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
    };
    bool any = false;
    bool all_loopback = true;
    for (const char* var : kVars) {
        if (env_nonempty(var)) {
            any = true;
            if (!value_is_loopback(var)) {
                all_loopback = false;
            }
        }
    }
    if (out_loopback_only != nullptr) {
        *out_loopback_only = any && all_loopback;
    }
    if (!any) {
        return CheckResult::NotDetected;
    }
    if (no_proxy_all()) {
        /* no_proxy="*" = người dùng tắt proxy toàn bộ — không có proxy thật */
        return CheckResult::NotDetected;
    }
    return CheckResult::Detected;
}

/* ---------------- Tín hiệu 2: tunnel interface ---------------- */
bool name_is_tunnel(const std::string& name) {
    if (name.empty()) {
        return false;
    }
    static const char* kPrefixes[] = {
        "tun", "tap", "ppp", "wg", "vtun", "ipsec", "gpd", "nordlynx",
    };
    for (const char* p : kPrefixes) {
        if (name.rfind(p, 0) == 0) {
            /* utun phải có ít nhất 1 số sau prefix (utun0...) — nhưng
             * "tun" cũng match "utun"; Apple side đã lọc tên qua
             * getifaddrs nên chỉ nhận interface thật. */
            return true;
        }
    }
    return false;
}

#if defined(__linux__)
CheckResult check_tunnel_interfaces() {
    DIR* d = ::opendir("/sys/class/net");
    if (d == nullptr) {
        return CheckResult::Error;
    }
    CheckResult result = CheckResult::NotDetected;
    struct dirent* ent = nullptr;
    while ((ent = ::readdir(d)) != nullptr) {
        const std::string name(ent->d_name);
        if (name == "." || name == "..") {
            continue;
        }
        if (name_is_tunnel(name)) {
            result = CheckResult::Detected;
            break;
        }
    }
    ::closedir(d);
    return result;
}
#elif defined(__APPLE__)
CheckResult check_tunnel_interfaces() {
    struct ifaddrs* ifa = nullptr;
    if (::getifaddrs(&ifa) != 0) {
        return CheckResult::Error;
    }
    CheckResult result = CheckResult::NotDetected;
    for (struct ifaddrs* it = ifa; it != nullptr; it = it->ifa_next) {
        if (it->ifa_name == nullptr) {
            continue;
        }
        const std::string name(it->ifa_name);
        /* utun: tunnel IPsec/VPN trên macOS/iOS; tap/ppp: VPN cũ */
        if (name_is_tunnel(name) || name.rfind("utun", 0) == 0) {
            result = CheckResult::Detected;
            break;
        }
    }
    ::freeifaddrs(ifa);
    return result;
}
#else
CheckResult check_tunnel_interfaces() {
    return CheckResult::Unavailable; /* nền tảng khác — không bịa */
}
#endif

/* ---------------- Tín hiệu 3: system proxy (macOS) ---------------- */
#if defined(__APPLE__) && !defined(TAKEY_TARGET_IOS) && !defined(TAKEY_NO_SCUTIL)
CheckResult check_system_proxy() {
    /* scutil --proxy in ra key-value; HTTPEnable : 1 = có system proxy.
     * popen chỉ đọc, không ghi — an toàn về mặt phụ tác. */
    FILE* f = ::popen("/usr/sbin/scutil --proxy 2>/dev/null", "r");
    if (f == nullptr) {
        return CheckResult::Error;
    }
    char        line[512];
    CheckResult result = CheckResult::NotDetected;
    while (::fgets(line, sizeof(line), f) != nullptr) {
        if (std::strncmp(line, "HTTPEnable :", 12) == 0
            || std::strncmp(line, "HTTPSEnable :", 13) == 0
            || std::strncmp(line, "SOCKSEnable :", 13) == 0) {
            const char* colon = std::strchr(line, ':');
            const int   flag  = colon != nullptr ? std::atoi(colon + 1) : 0;
            if (flag != 0) {
                result = CheckResult::Detected;
                break;
            }
        }
    }
    const int rc = ::pclose(f);
    if (rc == -1) {
        return CheckResult::Error;
    }
    return result;
}
#else
CheckResult check_system_proxy() {
    return CheckResult::Unavailable; /* iOS không có scutil; Linux không có chỗ chung */
}
#endif

}  // namespace

VpnDetector& VpnDetector::instance() {
    static VpnDetector detector;
    return detector;
}

VpnSnapshot VpnDetector::detect() {
    VpnSnapshot snap;

    bool loopback_only = false;
    snap.env_proxy_vars  = check_env_proxy_vars(&loopback_only);

    /* Tín hiệu 4: proxy trỏ về localhost = công cụ intercept (Charles/
     * mitmproxy). Chỉ kết luận khi env proxy tồn tại và là loopback. */
    snap.local_intercept = loopback_only
        ? CheckResult::Detected
        : CheckResult::NotDetected;

    snap.tunnel_iface    = check_tunnel_interfaces();
    snap.system_proxy    = check_system_proxy();

    snap.detected = snap.env_proxy_vars == CheckResult::Detected
                 || snap.tunnel_iface   == CheckResult::Detected
                 || snap.system_proxy   == CheckResult::Detected
                 || snap.local_intercept == CheckResult::Detected;

    snap.last_check_ts = now_unix();
    last_ = snap;
    return snap;
}

}  // namespace Protection
