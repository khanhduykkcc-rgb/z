/*
 * anti_debug.cpp — engine chống debug theo chuẩn OWASP MASTG
 * (MASTG-KNOW-0085: ptrace / sysctl / getppid / Mach Exception Ports).
 *
 * NGUYÊN TẮC (spec mục 8-12 PASS 3):
 *   - Nhiều tín hiệu ĐỘC LẬP, không phụ thuộc một API duy nhất.
 *   - Phân biệt rõ: NOT_DETECTED / DETECTED / CHECK_UNAVAILABLE / CHECK_ERROR.
 *     Lỗi API KHÔNG bao giờ bị coi là "có debugger" (chống false positive).
 *   - KHÔNG dùng PT_DENY_ATTACH: đây là syscall không có trong SDK công
 *     khai, vừa phá debug bản dev vừa vi phạm nguyên tắc "không private API"
 *     (spec mục 3 + 10). Chỉ DETECTION, không can thiệp tiến trình.
 *   - Khi phát hiện: báo lên SecurityState → authorization bị từ chối.
 *     TUYỆT ĐỐI không exit()/abort()/kill() (spec mục 11).
 *
 * File này chỉ chứa 5 TÍN HIỆU + aggregation anti-debug nội bộ.
 * Việc điều phối toàn bộ lớp bảo mật nằm ở security_monitor.cpp.
 *
 * Compile guards (spec mục 10):
 *   - sysctl P_TRACED, getppid, Mach exception ports: __APPLE__
 *   - /proc/self/status TracerPid: __linux__ (không có trên iOS)
 *   - Mọi nền tảng khác: tín hiệu = CHECK_UNAVAILABLE (báo trung thực)
 */

#include "protection/security_state.hpp"

#include <chrono>
#include <cstdlib>
#include <cstring>

#if defined(__APPLE__)
    #include <mach/mach.h>
    #include <sys/sysctl.h>
    #include <sys/types.h>
    #include <unistd.h>
#endif

#if defined(__linux__)
    #include <cstdio>
    #include <unistd.h>
#endif

namespace Protection {

namespace {

long now_unix() {
    return static_cast<long>(std::time(nullptr));
}

/* ---------------- Tín hiệu 1: sysctl KERN_PROC P_TRACED ---------------- */
#if defined(__APPLE__)
CheckResult check_sysctl_traced() {
    int                 mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, ::getpid()};
    struct kinfo_proc   info;
    std::memset(&info, 0, sizeof(info));
    size_t              size = sizeof(info);

    if (::sysctl(mib, 4, &info, &size, nullptr, 0) != 0) {
        return CheckResult::Error;
    }
    if (size != sizeof(info)) {
        return CheckResult::Error;
    }
    return (info.kp_proc.p_flag & P_TRACED) != 0 ? CheckResult::Detected : CheckResult::NotDetected;
}
#else
CheckResult check_sysctl_traced() {
    return CheckResult::Unavailable; /* API Darwin-only */
}
#endif

/* ---------------- Tín hiệu 2: Mach exception ports ----------------
 * Debugger (lldb/gdb qua mach) đăng ký exception port vào task.
 * task_get_exception_ports trả về các port đang được đăng ký — nếu có
 * port nào khác MACH_PORT_NULL nghĩa là có thứ gì đang bắt exception. */
#if defined(__APPLE__) && !defined(TAKEY_NO_MACH_PORTS)
CheckResult check_mach_exception_ports() {
    mach_msg_type_number_t   count = 0;
    exception_mask_t         masks[EXC_TYPES_COUNT];
    mach_port_t              ports[EXC_TYPES_COUNT];
    exception_behavior_t     behaviors[EXC_TYPES_COUNT];
    thread_state_flavor_t    flavors[EXC_TYPES_COUNT];

    const kern_return_t kr = ::task_get_exception_ports(
        ::mach_task_self(),
        EXC_MASK_ALL,
        masks,
        &count,
        ports,
        behaviors,
        flavors);

    if (kr != KERN_SUCCESS) {
        return CheckResult::Error;
    }

    for (mach_msg_type_number_t i = 0; i < count; ++i) {
        if (MACH_PORT_VALID(ports[i])) {
            return CheckResult::Detected;
        }
    }
    return CheckResult::NotDetected;
}
#else
CheckResult check_mach_exception_ports() {
    return CheckResult::Unavailable;
}
#endif

/* ---------------- Tín hiệu 3: TracerPid (Linux) ---------------- */
#if defined(__linux__)
CheckResult check_tracer_pid() {
    FILE* f = std::fopen("/proc/self/status", "r");
    if (f == nullptr) {
        return CheckResult::Unavailable;
    }

    char line[256];
    CheckResult result = CheckResult::Unavailable;
    while (std::fgets(line, sizeof(line), f) != nullptr) {
        if (std::strncmp(line, "TracerPid:", 10) == 0) {
            const long pid = std::strtol(line + 10, nullptr, 10);
            result = (pid != 0) ? CheckResult::Detected : CheckResult::NotDetected;
            break;
        }
    }
    std::fclose(f);
    return result;
}
#else
CheckResult check_tracer_pid() {
    return CheckResult::Unavailable; /* /proc không tồn tại trên iOS */
}
#endif

/* ---------------- Tín hiệu 4 (yếu): getppid != 1 ----------------
 * Trên iOS, app được launchd (ppid=1) khởi động. Trên macOS/Linux
 * desktop ppid là shell — CHỈ TÍNH là tín hiệu YẾU (SUSPICIOUS),
 * không bao giờ enough để kết luận DEBUGGED. */
CheckResult check_parent_pid() {
#if defined(__APPLE__) && defined(TARGET_OS_IOS) && !defined(TARGET_OS_SIMULATOR)
    return (::getppid() != 1) ? CheckResult::Detected : CheckResult::NotDetected;
#else
    return CheckResult::Unavailable; /* desktop: ppid != 1 là chuyện bình thường */
#endif
}

/* ---------------- Tín hiệu 5 (yếu): env indicators ----------------
 * DYLD_INSERT_LIBRARIES và các biến debug của Apple. Spoofable hai chiều
 * → chỉ là tín hiệu YẾU, đánh SUSPICIOUS. */
CheckResult check_env_indicators() {
    static const char* kVars[] = {
        "DYLD_INSERT_LIBRARIES",
        "DYLD_PRINT_LIBRARIES",
        "NSZombieEnabled",
        "_MSSafeProcess",
        "XcodeCharacters",
    };
    for (const char* var : kVars) {
        if (std::getenv(var) != nullptr) {
            return CheckResult::Detected;
        }
    }
    return CheckResult::NotDetected;
}

}  // namespace

const char* security_level_name(SecurityLevel level) {
    switch (level) {
        case SecurityLevel::Normal:    return "NORMAL";
        case SecurityLevel::Suspicious: return "SUSPICIOUS";
        case SecurityLevel::Debugged:  return "DEBUGGED";
    }
    return "UNKNOWN";
}

const char* security_level_value(SecurityLevel level) {
    switch (level) {
        case SecurityLevel::Normal:    return "0";
        case SecurityLevel::Suspicious: return "1";
        case SecurityLevel::Debugged:  return "2";
    }
    return "0";
}

/* ---------------- Bộ tín hiệu anti-debug (gọi từ SecurityMonitor) ---------------- */

AntiDebugSnapshot run_anti_debug_checks(int checks_run_before) {
    AntiDebugSnapshot snap;
    snap.sysctl_traced  = check_sysctl_traced();
    snap.mach_ports     = check_mach_exception_ports();
    snap.tracer_pid     = check_tracer_pid();
    snap.parent_pid     = check_parent_pid();
    snap.env_indicators = check_env_indicators();
    snap.last_check_ts  = now_unix();
    snap.checks_run     = checks_run_before + 1;
    snap.strong_random  = true; /* SecurityMonitor điền nguồn thật khi tổng hợp */

    /* ---- Aggregation anti-debug ---- */
    const bool strong = snap.sysctl_traced == CheckResult::Detected
                     || snap.mach_ports    == CheckResult::Detected
                     || snap.tracer_pid    == CheckResult::Detected;
    const bool weak = snap.parent_pid    == CheckResult::Detected
                   || snap.env_indicators == CheckResult::Detected;

    snap.level = strong ? SecurityLevel::Debugged
               : weak   ? SecurityLevel::Suspicious
                        : SecurityLevel::Normal;
    return snap;
}

}  // namespace Protection
