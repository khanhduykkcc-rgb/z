/*
 * anti_dump.cpp — hiện thực chống dump (PASS 3 mở rộng). Xem anti_dump.hpp.
 */

#include "protection/anti_dump.hpp"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#if !defined(_WIN32)
    #include <sys/resource.h>
    #include <unistd.h>
#endif

namespace Protection {

namespace {

long now_unix() {
    return static_cast<long>(std::time(nullptr));
}

/* ---------------- Tín hiệu 2: RLIMIT_CORE ---------------- */
CheckResult check_core_limit() {
#if defined(_WIN32)
    return CheckResult::Unavailable; /* không có POSIX rlimit */
#else
    struct ::rlimit lim {};
    if (::getrlimit(RLIMIT_CORE, &lim) != 0) {
        return CheckResult::Error;
    }
    /* rlim_cur > 0 → core dump có thể được sinh ra khi crash */
    return (lim.rlim_cur > 0) ? CheckResult::Detected : CheckResult::NotDetected;
#endif
}

/* ---------------- Tín hiệu 3: env injection ---------------- */
CheckResult check_env_injection() {
    static const char* kVars[] = {
        "LD_PRELOAD",
        "LD_DEBUG",
        "DYLD_INSERT_LIBRARIES",
        "DYLD_PRINT_LIBRARIES",
        "MALLOC_PRETEND_SBRK_FAILS",
    };
    for (const char* var : kVars) {
        const char* v = std::getenv(var);
        if (v != nullptr && *v != '\0') {
            return CheckResult::Detected;
        }
    }
    return CheckResult::NotDetected;
}

}  // namespace

DumpDetector& DumpDetector::instance() {
    static DumpDetector detector;
    return detector;
}

DumpDetector::~DumpDetector() {
    stop();
}

void DumpDetector::beat() {
    std::lock_guard<std::mutex> lock(beat_mutex_);
    last_beat_ = std::chrono::steady_clock::now();
}

void DumpDetector::start() {
    if (running_.exchange(true)) {
        return; /* đã chạy */
    }
    beat();
    worker_ = std::thread([this] { watchdog_loop(); });
}

void DumpDetector::stop() {
    if (!running_.exchange(false)) {
        return;
    }
    if (worker_.joinable()) {
        worker_.join();
    }
}

void DumpDetector::watchdog_loop() {
    /* Đập nhịp ~500ms. Thread tách rời khỏi flow chính — không bao giờ
     * block, không chạm dữ liệu ngoài beat_mutex_/last_beat_. */
    while (running_.load()) {
        beat();
        for (int i = 0; i < 10 && running_.load(); ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    }
}

DumpSnapshot DumpDetector::detect() {
    DumpSnapshot snap;

    /* ---------------- Tín hiệu 1: watchdog staleness ---------------- */
    bool never_beat = false;
    {
        const auto now_tp = std::chrono::steady_clock::now();
        std::lock_guard<std::mutex> lock(beat_mutex_);
        if (last_beat_ == std::chrono::steady_clock::time_point{}) {
            never_beat = true;
        } else {
            snap.stale_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                                now_tp - last_beat_)
                                .count();
        }
    }
    if (never_beat) {
        /* chưa từng beat — watchdog chưa start: trung thực UNAVAILABLE */
        snap.watchdog_stale = CheckResult::Unavailable;
    } else if (snap.stale_ms > suspicious_ms_) {
        snap.watchdog_stale = CheckResult::Detected;
    } else {
        snap.watchdog_stale = CheckResult::NotDetected;
    }

    snap.core_limit    = check_core_limit();
    snap.env_injection = check_env_injection();
    snap.last_check_ts = now_unix();

    /* ---------------- Aggregation ---------------- */
    if (!never_beat && snap.stale_ms > detected_ms_) {
        snap.level = DumpLevel::Detected;           /* > 60s — dump signature */
    } else {
        const bool weak = (!never_beat && snap.stale_ms > suspicious_ms_)
                       || snap.core_limit == CheckResult::Detected
                       || snap.env_injection == CheckResult::Detected;
        snap.level = weak ? DumpLevel::Suspicious : DumpLevel::Clean;
    }

    last_ = snap;
    return snap;
}

const char* dump_level_name(DumpLevel level) {
    switch (level) {
        case DumpLevel::Clean:      return "CLEAN";
        case DumpLevel::Suspicious: return "SUSPICIOUS";
        case DumpLevel::Detected:   return "DETECTED";
    }
    return "UNKNOWN";
}

}  // namespace Protection
