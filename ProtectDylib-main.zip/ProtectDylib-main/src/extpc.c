#include "extpc.h"

static ExtPCRef *g_extpc = NULL;
static int g_nextpc = 0;
static int g_extpc_cap = 0;

void extpc_init(void){
    g_extpc_cap = 1048576;
    g_extpc = (ExtPCRef*)calloc((size_t)g_extpc_cap, sizeof(ExtPCRef));
    g_nextpc = 0;
}

void extpc_free(void){
    free(g_extpc);
    g_extpc = NULL;
    g_nextpc = 0;
    g_extpc_cap = 0;
}

void extpc_add(uint32_t boff, uint64_t abs_t, PCType t){
    if(g_nextpc >= g_extpc_cap){
        g_extpc_cap *= 2;
        g_extpc = (ExtPCRef*)realloc(g_extpc, (size_t)g_extpc_cap * sizeof(ExtPCRef));
    }
    g_extpc[g_nextpc].buf_byte_off = boff;
    g_extpc[g_nextpc].abs_target = abs_t;
    g_extpc[g_nextpc].type = t;
    g_nextpc++;
}

ExtPCRef *extpc_get_refs(void){ return g_extpc; }
int extpc_get_count(void){ return g_nextpc; }
