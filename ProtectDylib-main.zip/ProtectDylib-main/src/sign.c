#include "sign.h"
#include "sha256.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define MH_MAGIC_64        0xfeedfacfu
#define LC_SEGMENT_64      0x19u
#define LC_CODE_SIGNATURE  0x1du

#define CSMAGIC_EMBEDDED_SIGNATURE 0xfade0cc0u
#define CSMAGIC_CODEDIRECTORY      0xfade0c02u
#define CSMAGIC_REQUIREMENTS       0xfade0c01u
#define CSMAGIC_BLOBWRAPPER        0xfade0b01u
#define CSSLOT_CODEDIRECTORY 0x00000u
#define CSSLOT_REQUIREMENTS  0x00002u
#define CSSLOT_SIGNATURESLOT 0x10000u
#define CS_ADHOC             0x00002u
#define CS_HASHTYPE_SHA256   2

#define PAGE_GRANULE 0x4000ull
#define CODE_PAGE    4096u

static uint32_t rd32(const uint8_t *p){ return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static uint64_t rd64(const uint8_t *p){ uint64_t v=0; for(int i=0;i<8;i++) v|=((uint64_t)p[i])<<(8*i); return v; }
static void wr32le(uint8_t *p,uint32_t v){ p[0]=v&0xff;p[1]=(v>>8)&0xff;p[2]=(v>>16)&0xff;p[3]=(v>>24)&0xff; }
static void wr64le(uint8_t *p,uint64_t v){ for(int i=0;i<8;i++) p[i]=(v>>(8*i))&0xff; }
static void wr32be(uint8_t *p,uint32_t v){ p[0]=(v>>24)&0xff;p[1]=(v>>16)&0xff;p[2]=(v>>8)&0xff;p[3]=v&0xff; }
static void wr64be(uint8_t *p,uint64_t v){ for(int i=0;i<8;i++) p[i]=(v>>(8*(7-i)))&0xff; }
static uint64_t alignup(uint64_t v,uint64_t a){ return (v+a-1)&~(a-1); }

int sign_file_adhoc(const char *path)
{
    FILE *f = fopen(path,"rb");
    if(!f){ fprintf(stderr,"[sign] open failed: %s\n",path); return -1; }
    fseek(f,0,SEEK_END); long fl=ftell(f); fseek(f,0,SEEK_SET);
    if(fl < 0x20){ fclose(f); fprintf(stderr,"[sign] file too small\n"); return -1; }
    size_t n=(size_t)fl;
    uint8_t *d=(uint8_t*)malloc(n);
    if(!d){ fclose(f); return -1; }
    if(fread(d,1,n,f)!=n){ free(d); fclose(f); return -1; }
    fclose(f);

    if(rd32(d)!=MH_MAGIC_64){ free(d); fprintf(stderr,"[sign] not a 64-bit mach-o\n"); return -1; }
    uint32_t ncmds=rd32(d+16);

    size_t   sig_cmd=0;   uint32_t sig_dataoff=0;
    size_t   le_cmd=0;    uint64_t le_fileoff=0;
    uint64_t text_vmsize=0, text_fileoff=0; int have_text=0;

    size_t o=32;
    for(uint32_t i=0;i<ncmds;i++){
        if(o+8>n) break;
        uint32_t cmd=rd32(d+o), cs=rd32(d+o+4);
        if(cs<8 || o+cs>n) break;
        if(cmd==LC_SEGMENT_64 && o+72<=n){
            char nm[17]; memcpy(nm,d+o+8,16); nm[16]=0;
            uint64_t vmsize=rd64(d+o+32), fileoff=rd64(d+o+40);
            if(strcmp(nm,"__TEXT")==0){ text_vmsize=vmsize; text_fileoff=fileoff; have_text=1; }
            else if(strcmp(nm,"__LINKEDIT")==0){ le_cmd=o; le_fileoff=fileoff; }
        } else if(cmd==LC_CODE_SIGNATURE && o+16<=n){
            sig_cmd=o; sig_dataoff=rd32(d+o+8);
        }
        o+=cs;
    }
    if(!sig_cmd){ free(d); fprintf(stderr,"[sign] no LC_CODE_SIGNATURE\n"); return -1; }
    if(!le_cmd){ free(d); fprintf(stderr,"[sign] no __LINKEDIT\n"); return -1; }
    if(!have_text){ free(d); fprintf(stderr,"[sign] no __TEXT\n"); return -1; }

    uint32_t old_dataoff=sig_dataoff;
    if(old_dataoff==0 || old_dataoff>n){ free(d); fprintf(stderr,"[sign] bad dataoff\n"); return -1; }

    uint32_t dataoff  = (uint32_t)alignup(old_dataoff,16);
    uint32_t codeLimit= dataoff;

    const char *bn=path;
    for(const char *p=path;*p;p++) if(*p=='/'||*p=='\\') bn=p+1;
    char ident[256];
    size_t bl=strlen(bn); if(bl>=sizeof(ident)) bl=sizeof(ident)-1;
    memcpy(ident,bn,bl); ident[bl]=0;
    { size_t il=strlen(ident);
      if(il>6 && strcmp(ident+il-6,".dylib")==0) ident[il-6]=0; }
    uint32_t identSize=(uint32_t)strlen(ident)+1;

    uint32_t nSpecial=2, hashSize=32;
    uint32_t nCode=(codeLimit + CODE_PAGE - 1)/CODE_PAGE;
    uint32_t hashOffset=0x58 + identSize + nSpecial*hashSize;
    uint32_t cdLen=hashOffset + nCode*hashSize;

    uint32_t reqLen=0x0c, wrapLen=0x08;
    uint32_t sbHdr=12 + 3*8;
    uint32_t cdRel=sbHdr;
    uint32_t reqRel=cdRel+cdLen;
    uint32_t wrapRel=reqRel+reqLen;
    uint32_t sbLen=wrapRel+wrapLen;
    uint32_t datasize=(uint32_t)alignup(sbLen,16);

    size_t new_n=(size_t)dataoff+datasize;
    uint8_t *out=(uint8_t*)calloc(1,new_n);
    if(!out){ free(d); return -1; }
    memcpy(out,d,old_dataoff);

    wr32le(out+sig_cmd+8,dataoff);
    wr32le(out+sig_cmd+12,datasize);

    uint64_t le_filesize=(uint64_t)new_n - le_fileoff;
    uint64_t le_vmsize=alignup(le_filesize,PAGE_GRANULE);
    wr64le(out+le_cmd+32,le_vmsize);
    wr64le(out+le_cmd+48,le_filesize);

    uint8_t *sb=out+dataoff;
    uint8_t *cd=sb+cdRel;
    uint8_t *req=sb+reqRel;
    uint8_t *wrap=sb+wrapRel;

    wr32be(cd+0x00,CSMAGIC_CODEDIRECTORY);
    wr32be(cd+0x04,cdLen);
    wr32be(cd+0x08,0x20400);
    wr32be(cd+0x0c,CS_ADHOC);
    wr32be(cd+0x10,hashOffset);
    wr32be(cd+0x14,0x58);
    wr32be(cd+0x18,nSpecial);
    wr32be(cd+0x1c,nCode);
    wr32be(cd+0x20,codeLimit);
    cd[0x24]=(uint8_t)hashSize;
    cd[0x25]=CS_HASHTYPE_SHA256;
    cd[0x26]=0;
    cd[0x27]=12;
    wr32be(cd+0x28,0);
    wr32be(cd+0x2c,0);
    wr32be(cd+0x30,0);
    wr32be(cd+0x34,0);
    wr64be(cd+0x38,0);
    wr64be(cd+0x40,text_fileoff);
    wr64be(cd+0x48,text_vmsize);
    wr64be(cd+0x50,0);
    memcpy(cd+0x58,ident,identSize);

    wr32be(req+0,CSMAGIC_REQUIREMENTS);
    wr32be(req+4,reqLen);
    wr32be(req+8,0);

    wr32be(wrap+0,CSMAGIC_BLOBWRAPPER);
    wr32be(wrap+4,wrapLen);

    uint8_t *hashes=cd+hashOffset;
    sha256(req,reqLen,hashes-2*hashSize);
    memset(hashes-1*hashSize,0,hashSize);
    for(uint32_t i=0;i<nCode;i++){
        uint32_t start=i*CODE_PAGE;
        uint32_t len=(codeLimit-start<CODE_PAGE)?(codeLimit-start):CODE_PAGE;
        sha256(out+start,len,hashes+i*hashSize);
    }

    wr32be(sb+0,CSMAGIC_EMBEDDED_SIGNATURE);
    wr32be(sb+4,sbLen);
    wr32be(sb+8,3);
    wr32be(sb+12+0*8,CSSLOT_CODEDIRECTORY); wr32be(sb+12+0*8+4,cdRel);
    wr32be(sb+12+1*8,CSSLOT_REQUIREMENTS);  wr32be(sb+12+1*8+4,reqRel);
    wr32be(sb+12+2*8,CSSLOT_SIGNATURESLOT); wr32be(sb+12+2*8+4,wrapRel);

    FILE *w=fopen(path,"wb");
    if(!w){ free(out); free(d); return -1; }
    size_t wn=fwrite(out,1,new_n,w);
    fclose(w);
    free(out); free(d);
    if(wn!=new_n){ fprintf(stderr,"[sign] short write\n"); return -1; }
    return 0;
}
