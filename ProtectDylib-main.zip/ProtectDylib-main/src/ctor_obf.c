#include "ctor_obf.h"
#include "arm64_enc.h"
#include "util.h"

static uint64_t rand64(void){
    return ((uint64_t)rand()<<48) ^ ((uint64_t)rand()<<32) ^
           ((uint64_t)rand()<<16) ^ (uint64_t)rand();
}

static uint32_t rand32(void){
    return (uint32_t)rand() ^ ((uint32_t)rand()<<16);
}

static void gen_state_ids(uint32_t *ids, int count){
    for(int i=0;i<count;i++){
        uint32_t id;
        bool unique;
        do {
            id = rand32();
            if(id==0) id=1;
            unique=true;
            for(int j=0;j<i;j++){
                if(ids[j]==id){ unique=false; break; }
            }
        } while(!unique);
        ids[i]=id;
    }
}

#define CTOR_ENC_BR_SIZE 19

static int emit_ctor_enc_br(uint32_t *dst, int n, int max_n){
    if(n+CTOR_ENC_BR_SIZE > max_n) return -1;

    dst[n++]=enc_movz(16,0,0);
    dst[n++]=enc_movk(16,0,16);
    dst[n++]=enc_movk(16,0,32);
    dst[n++]=enc_movk(16,0,48);

    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);

    dst[n++]=enc_eor_x(16,16,17);

    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);

    dst[n++]=enc_add_r(16,16,17);

    dst[n++]=enc_adr(17,0);

    dst[n++]=enc_add_r(16,16,17);

    dst[n++]=enc_br(16);

    dst[n++]=NOP;
    dst[n++]=NOP;
    return n;
}

static void patch_ctor_enc_br(uint32_t *dst, int enc_start,
                              uint64_t target_va, uint64_t adr_va){
    uint64_t xor_key = rand64();
    uint64_t add_key = rand64();

    int64_t rel_off = (int64_t)target_va - (int64_t)adr_va;

    uint64_t val = ((uint64_t)rel_off - add_key) ^ xor_key;

    dst[enc_start+0]=enc_movz(16,(uint16_t)(val&0xFFFF),0);
    dst[enc_start+1]=enc_movk(16,(uint16_t)((val>>16)&0xFFFF),16);
    dst[enc_start+2]=enc_movk(16,(uint16_t)((val>>32)&0xFFFF),32);
    dst[enc_start+3]=enc_movk(16,(uint16_t)((val>>48)&0xFFFF),48);

    dst[enc_start+4]=enc_movz(17,(uint16_t)(xor_key&0xFFFF),0);
    dst[enc_start+5]=enc_movk(17,(uint16_t)((xor_key>>16)&0xFFFF),16);
    dst[enc_start+6]=enc_movk(17,(uint16_t)((xor_key>>32)&0xFFFF),32);
    dst[enc_start+7]=enc_movk(17,(uint16_t)((xor_key>>48)&0xFFFF),48);

    dst[enc_start+9]=enc_movz(17,(uint16_t)(add_key&0xFFFF),0);
    dst[enc_start+10]=enc_movk(17,(uint16_t)((add_key>>16)&0xFFFF),16);
    dst[enc_start+11]=enc_movk(17,(uint16_t)((add_key>>32)&0xFFFF),32);
    dst[enc_start+12]=enc_movk(17,(uint16_t)((add_key>>48)&0xFFFF),48);

    dst[enc_start+14]=enc_adr(17,0);

    dst[enc_start+17]=NOP;
    dst[enc_start+18]=NOP;
}

static int emit_bcf_block(uint32_t *dst, int n, int max_n){
    if(n+18 > max_n) return -1;
    uint64_t opaque_val = rand64() | 1ULL;
    int variant = rand() % 5;
    int dead_count = 2 + (rand() % 3);

    n=emit_mov64(dst,n,17,opaque_val);

    switch(variant){
    case 0:
        dst[n++]=enc_orn_x(16,17,17);
        dst[n++]=enc_cbnz_x(16, dead_count+1);
        break;
    case 1:
        dst[n++]=enc_movz(16,1,0);
        dst[n++]=0xAA100220u;
        dst[n++]=enc_cbnz_x(16, dead_count+1);
        break;
    case 2:
        dst[n++]=enc_eor_x(16,17,17);
        dst[n++]=enc_add_i(16,16,1);
        dst[n++]=enc_cbnz_x(16, dead_count+1);
        break;
    case 3:
        dst[n++]=enc_mvn_x(16,17);
        dst[n++]=0xAA110210u;
        dst[n++]=enc_cbnz_x(16, dead_count+1);
        break;
    case 4:
        dst[n++]=enc_orn_x(16,17,17);
        dst[n++]=enc_cbnz_x(16, dead_count+1);
        break;
    }

    for(int di=0; di<dead_count && n<max_n; di++)
        dst[n++]=0xD503201Fu;

    return n;
}

static int emit_junk(uint32_t *dst, int n, int max_n, int count){
    for(int i=0;i<count && n<max_n;i++){
        int kind = rand() % 12;
        switch(kind){
        case 0: dst[n++]=enc_eor_x(16,16,16); break;
        case 1: dst[n++]=enc_add_r(17,17,16); break;
        case 2: dst[n++]=enc_movz(16,(uint16_t)(rand()&0xFFFF),0); break;
        case 3: dst[n++]=enc_ror_x(17,17,rand()%63+1); break;
        case 4: dst[n++]=enc_mul_x(16,17,16); break;
        case 5: dst[n++]=enc_eor_x(17,17,16); break;
        case 6: dst[n++]=enc_sub_r(16,16,17); break;
        case 7: dst[n++]=enc_movk(16,(uint16_t)(rand()&0xFFFF),16); break;
        case 8: dst[n++]=enc_add_i(16,16,rand()%0xFFF+1); break;
        case 9: dst[n++]=enc_orn_x(16,17,16); break;
        case 10: dst[n++]=enc_mvn_x(16,16); break;
        case 11: dst[n++]=enc_movz(17,(uint16_t)(rand()&0xFFFF),0); break;
        }
    }
    return n;
}

static int emit_state_update(uint32_t *dst, int n, int max_n, uint32_t state_id){
    if(n+6>max_n) return -1;
    uint32_t key = rand32();
    uint32_t enc = state_id ^ key;
    dst[n++]=enc_movz(16,(uint16_t)(enc&0xFFFF),0);
    dst[n++]=enc_movk(16,(uint16_t)((enc>>16)&0xFFFF),16);
    dst[n++]=enc_movz(17,(uint16_t)(key&0xFFFF),0);
    dst[n++]=enc_movk(17,(uint16_t)((key>>16)&0xFFFF),16);
    dst[n++]=enc_eor_w(25,16,17);
    return n;
}

typedef struct {
    int enc_br_start;
    int block_idx;
} DispatchPatch;

static int emit_dispatch_case(uint32_t *dst, int n, int max_n,
                              uint32_t state_id,
                              DispatchPatch *patch, int *npatch, int block_idx){
    if(n+30>max_n) return -1;

    uint32_t cmp_mask = rand32();
    uint32_t masked_id = state_id ^ cmp_mask;

    dst[n++]=enc_movz(0,(uint16_t)(cmp_mask&0xFFFF),0);
    dst[n++]=enc_movk(0,(uint16_t)((cmp_mask>>16)&0xFFFF),16);
    dst[n++]=enc_eor_w(0,25,0);

    if(masked_id <= 0xFFF){
        dst[n++]=enc_subs_w_i(31,0,(int)(masked_id & 0xFFF));
    } else {

        dst[n++]=enc_movz(17,(uint16_t)(masked_id&0xFFFF),0);
        dst[n++]=enc_movk(17,(uint16_t)((masked_id>>16)&0xFFFF),16);

        dst[n++]=0x6B110000u | (0u << 5) | 31u;
    }

    int bne_pos = n;
    dst[n++]=enc_b_ne(0);

    n=emit_junk(dst,n,max_n,rand()%3+1);

    int enc_start = n;
    int new_n = emit_ctor_enc_br(dst,n,max_n);
    if(new_n<0) return -1;
    n = new_n;

    int bne_skip = n - bne_pos;
    dst[bne_pos] = enc_b_ne(bne_skip);

    patch[*npatch].enc_br_start = enc_start;
    patch[*npatch].block_idx = block_idx;
    (*npatch)++;

    return n;
}

typedef struct { int enc_start; } CtorBackPatch;

static int emit_crash_gadget(uint32_t *dst, int n, int max_n){
    if(n+12>max_n) return -1;
    uint64_t junk1 = rand64();
    uint64_t junk2 = rand64();
    uint32_t xor_key = rand32();

    n=emit_mov64(dst,n,21,junk1);
    dst[n++]=0xF9000BE0u | 21u;
    n=emit_mov64(dst,n,21,junk2);
    dst[n++]=0xF9000FE0u | 21u;

    dst[n++]=0x910003F5u;
    dst[n++]=enc_movz(22,(uint16_t)(xor_key&0xFFFF),0);
    dst[n++]=enc_movk(22,(uint16_t)((xor_key>>16)&0xFFFF),16);
    dst[n++]=enc_eor_x(21,21,22);
    dst[n++]=enc_br(21);
    return n;
}

#define AH_NUM_BLOCKS 6
#define AH_MAX_BOGUS  12
#define AH_TOTAL_BLOCKS (AH_NUM_BLOCKS + AH_MAX_BOGUS)

int build_antihex_ctor_obfuscated(
    uint32_t *buf, int max_insns,
    uint64_t exec_seg_va,
    uint64_t text_va,
    uint32_t text_sz,
    uint32_t text_xhash,
    uint64_t next_va)
{
    (void)text_xhash;
    int n=0;
    if(max_insns<512) return -1;

    uint32_t state_ids[AH_TOTAL_BLOCKS];
    gen_state_ids(state_ids, AH_TOTAL_BLOCKS);

    int order[AH_NUM_BLOCKS];
    for(int i=0;i<AH_NUM_BLOCKS;i++) order[i]=i;
    for(int i=AH_NUM_BLOCKS-1;i>0;i--){
        int j=rand()%(i+1);
        int tmp=order[i]; order[i]=order[j]; order[j]=tmp;
    }

    uint32_t seed_mask = rand32();
    uint32_t seed_blind = 0x55AA55AAu ^ seed_mask;
    uint32_t magic_mask = rand32();
    uint32_t magic_blind = 0xFEEDFACFu ^ magic_mask;

#define IC(x) do{ if(n>=max_insns) return -1; buf[n++]=(x); }while(0)

    IC(enc_sub_i(31,31,0x60));
    IC(enc_stp(19,20,31,0));
    IC(enc_stp(21,22,31,2));
    IC(enc_stp(23,24,31,4));
    IC(enc_stp(25,26,31,6));
    IC(enc_str_x_off(30,31,8));
    IC(enc_str_x_off(0,31,10));

    n=emit_state_update(buf,n,max_insns,state_ids[0]);

    n=emit_junk(buf,n,max_insns,rand()%6+4);

    int dispatcher_pos = n;

    n=emit_bcf_block(buf,n,max_insns);
    n=emit_junk(buf,n,max_insns,rand()%4+2);
    n=emit_bcf_block(buf,n,max_insns);
    n=emit_junk(buf,n,max_insns,rand()%5+3);

    DispatchPatch dpatches[AH_TOTAL_BLOCKS*2];
    int ndpatch=0;

    for(int si=0;si<AH_NUM_BLOCKS;si++){
        int bi = order[si];
        n=emit_dispatch_case(buf,n,max_insns,state_ids[bi],
                             dpatches,&ndpatch,bi);
        if(n<0) return -1;

        if(rand()%2==0 && si < AH_NUM_BLOCKS-1){
            int bogus_idx = AH_NUM_BLOCKS + (rand() % AH_MAX_BOGUS);
            n=emit_dispatch_case(buf,n,max_insns,state_ids[bogus_idx],
                                 dpatches,&ndpatch,bogus_idx);
            if(n<0) return -1;
        }
    }

    n=emit_crash_gadget(buf,n,max_insns);

    int block_pos[AH_TOTAL_BLOCKS];
    memset(block_pos, 0, sizeof(block_pos));

    CtorBackPatch back_patches[AH_TOTAL_BLOCKS];
    int nback=0;

    int emit_order[AH_TOTAL_BLOCKS];
    for(int i=0;i<AH_TOTAL_BLOCKS;i++) emit_order[i]=i;
    for(int i=AH_TOTAL_BLOCKS-1;i>0;i--){
        int j=rand()%(i+1);
        int tmp=emit_order[i]; emit_order[i]=emit_order[j]; emit_order[j]=tmp;
    }

    for(int si=0; si<AH_TOTAL_BLOCKS; si++){
        int bi = emit_order[si];
        block_pos[bi] = n;

        if(bi >= AH_NUM_BLOCKS){

            n=emit_bcf_block(buf,n,max_insns);
            n=emit_junk(buf,n,max_insns,rand()%8+5);

            n=emit_state_update(buf,n,max_insns, state_ids[rand()%AH_NUM_BLOCKS]);
            int bp_start = n;
            int nn = emit_ctor_enc_br(buf,n,max_insns);
            if(nn<0) return -1;
            n=nn;
            back_patches[nback].enc_start = bp_start;
            nback++;
            continue;
        }

        n=emit_junk(buf,n,max_insns,rand()%5+3);
        n=emit_bcf_block(buf,n,max_insns);

        switch(bi){
        case 0: {

            buf[n++]=0x10000013u;
            IC(0x92000000u|(1u<<22)|(50u<<16)|(49u<<10)|(19u<<5)|19u);

            n=emit_mov64(buf,n,21,(uint64_t)magic_blind);
            n=emit_mov64(buf,n,0,(uint64_t)magic_mask);
            IC(enc_eor_w(21,21,0));

            int walk_top = n;
            IC(enc_ldr_w_off(22,19,0));
            IC(enc_cmp_x(22,21));
            IC(enc_b_eq(3));
            IC(enc_sub_i_lsl12(19,19,4));
            { int _off=walk_top-n; IC(enc_b26(_off)); }

            n=emit_state_update(buf,n,max_insns,state_ids[1]);
            break;
        }
        case 1: {

            n=emit_mov64(buf,n,20,(uint64_t)text_va);
            IC(enc_add_r(20,19,20));
            n=emit_mov64(buf,n,21,(uint64_t)text_sz);
            n=emit_mov64(buf,n,25,(uint64_t)exec_seg_va);
            IC(enc_add_r(25,19,25));
            IC(enc_ldr_w_off(22,25,1));
            IC(enc_mov_x(23,20));
            IC(enc_lsr_w(24,21,2));

            n=emit_mov64(buf,n,26,(uint64_t)seed_blind);
            n=emit_mov64(buf,n,0,(uint64_t)seed_mask);
            IC(enc_eor_w(26,26,0));

            n=emit_state_update(buf,n,max_insns,state_ids[2]);
            break;
        }
        case 2: {

            int hl_start=n;
            IC(enc_ldr_w_post(0,23,4));
            IC(enc_eor_w(26,26,0));
            IC(enc_ror_w(26,26,7));
            IC(enc_subs_w_i(24,24,1));
            { int _off=hl_start-n; IC(enc_b_ne(_off)); }

            n=emit_state_update(buf,n,max_insns,state_ids[3]);
            break;
        }
        case 3: {

            IC(0x6B16035Fu);

            int beq_pos = n;
            IC(enc_b_eq(0));

            n=emit_state_update(buf,n,max_insns,state_ids[5]);
            int skip_pos = n;
            IC(enc_b26(0));

            int pass_target = n;
            n=emit_state_update(buf,n,max_insns,state_ids[4]);

            { int off1=pass_target-beq_pos; buf[beq_pos]=enc_b_eq(off1); }
            { int off2=n-skip_pos; buf[skip_pos]=enc_b26(off2); }
            break;
        }
        case 4: {

            IC(enc_ldr_x_off(0,31,10));
            IC(enc_ldr_x_off(30,31,8));
            IC(enc_ldp(25,26,31,6));
            IC(enc_ldp(23,24,31,4));
            IC(enc_ldp(21,22,31,2));
            IC(enc_ldp(19,20,31,0));
            IC(enc_add_i(31,31,0x60));
            if(next_va){

                int enc_start = n;
                int nn = emit_ctor_enc_br(buf,n,max_insns);
                if(nn<0) return -1;
                n=nn;

                buf[enc_start + 17] = (uint32_t)(next_va & 0xFFFFFFFF);
                buf[enc_start + 18] = (uint32_t)(next_va >> 32);
            } else {
                IC(enc_ret());
            }

            goto skip_back_jump_0;
        }
        case 5: {

            n=emit_crash_gadget(buf,n,max_insns);

            goto skip_back_jump_0;
        }
        }

        {
            int bp_start = n;
            int nn = emit_ctor_enc_br(buf,n,max_insns);
            if(nn<0) return -1;
            n=nn;
            back_patches[nback].enc_start = bp_start;
            nback++;
        }
        skip_back_jump_0:

        n=emit_junk(buf,n,max_insns,rand()%5+3);
    }

    for(int i=0;i<ndpatch;i++){
        int enc_start = dpatches[i].enc_br_start;
        int bi = dpatches[i].block_idx;
        int target_idx = block_pos[bi];
        buf[enc_start + 17] = (uint32_t)target_idx;
        buf[enc_start + 18] = 0xDEAD0001u;
    }

    for(int i=0;i<nback;i++){
        int enc_start = back_patches[i].enc_start;
        buf[enc_start + 17] = (uint32_t)dispatcher_pos;
        buf[enc_start + 18] = 0xDEAD0001u;
    }

    if(n>max_insns) return -1;
    return n;
#undef IC
}

#define TP_NUM_BLOCKS 4
#define TP_MAX_BOGUS  8
#define TP_TOTAL_BLOCKS (TP_NUM_BLOCKS + TP_MAX_BOGUS)

int build_timeprotect_obfuscated(
    uint32_t *buf, int max_insns,
    uint64_t deadline_epoch,
    uint64_t next_va)
{
    int n=0;
    if(max_insns<400) return -1;

    uint32_t state_ids[TP_TOTAL_BLOCKS];
    gen_state_ids(state_ids, TP_TOTAL_BLOCKS);

    int order[TP_NUM_BLOCKS];
    for(int i=0;i<TP_NUM_BLOCKS;i++) order[i]=i;
    for(int i=TP_NUM_BLOCKS-1;i>0;i--){
        int j=rand()%(i+1);
        int tmp=order[i]; order[i]=order[j]; order[j]=tmp;
    }

#define TP(x) do{ if(n>=max_insns) return -1; buf[n++]=(x); }while(0)

    TP(enc_sub_i(31,31,0x70));
    TP(enc_stp(29,30,31,0));
    TP(enc_stp(19,20,31,2));
    TP(enc_stp(21,22,31,4));
    TP(enc_stp(25,26,31,6));
    TP(enc_str_x_off(0,31,8));

    n=emit_state_update(buf,n,max_insns,state_ids[0]);
    n=emit_junk(buf,n,max_insns,rand()%6+4);

    int dispatcher_pos = n;
    n=emit_bcf_block(buf,n,max_insns);
    n=emit_junk(buf,n,max_insns,rand()%4+2);
    n=emit_bcf_block(buf,n,max_insns);
    n=emit_junk(buf,n,max_insns,rand()%4+2);

    DispatchPatch dpatches[TP_TOTAL_BLOCKS*2];
    int ndpatch=0;

    for(int si=0;si<TP_NUM_BLOCKS;si++){
        int bi=order[si];
        n=emit_dispatch_case(buf,n,max_insns,state_ids[bi],
                             dpatches,&ndpatch,bi);
        if(n<0) return -1;
        if(rand()%2==0 && si<TP_NUM_BLOCKS-1){
            int bogus_idx=TP_NUM_BLOCKS+(rand()%TP_MAX_BOGUS);
            n=emit_dispatch_case(buf,n,max_insns,state_ids[bogus_idx],
                                 dpatches,&ndpatch,bogus_idx);
            if(n<0) return -1;
        }
    }
    n=emit_crash_gadget(buf,n,max_insns);

    int block_pos[TP_TOTAL_BLOCKS];
    memset(block_pos,0,sizeof(block_pos));
    CtorBackPatch back_patches[TP_TOTAL_BLOCKS];
    int nback=0;

    int emit_order[TP_TOTAL_BLOCKS];
    for(int i=0;i<TP_TOTAL_BLOCKS;i++) emit_order[i]=i;
    for(int i=TP_TOTAL_BLOCKS-1;i>0;i--){
        int j=rand()%(i+1);
        int tmp=emit_order[i]; emit_order[i]=emit_order[j]; emit_order[j]=tmp;
    }

    for(int si=0;si<TP_TOTAL_BLOCKS;si++){
        int bi=emit_order[si];
        block_pos[bi]=n;

        if(bi>=TP_NUM_BLOCKS){
            n=emit_bcf_block(buf,n,max_insns);
            n=emit_junk(buf,n,max_insns,rand()%8+5);
            n=emit_state_update(buf,n,max_insns,state_ids[rand()%TP_NUM_BLOCKS]);
            int bp_start=n;
            int nn=emit_ctor_enc_br(buf,n,max_insns);
            if(nn<0) return -1;
            n=nn;
            back_patches[nback].enc_start=bp_start;
            nback++;
            continue;
        }

        n=emit_junk(buf,n,max_insns,rand()%5+3);
        n=emit_bcf_block(buf,n,max_insns);

        switch(bi){
        case 0: {

            TP(enc_movz(19,0,0));
            TP(enc_str_x_off(19,31,10));
            TP(enc_str_x_off(19,31,11));
            TP(enc_add_i(0,31,0x50));
            TP(enc_movz(1,0,0));
            TP(enc_movz(16,0x74,0));
            TP(0xD4001001u);
            TP(enc_ldr_x_off(19,31,10));
            n=emit_state_update(buf,n,max_insns,state_ids[1]);
            break;
        }
        case 1: {

            n=emit_mov64(buf,n,20,deadline_epoch);
            TP(enc_cmp_x(19,20));

            int bcc_pos=n;
            TP(0x54000003u);

            n=emit_state_update(buf,n,max_insns,state_ids[3]);
            int skip_pos=n;
            TP(enc_b26(0));

            int not_expired=n;
            n=emit_state_update(buf,n,max_insns,state_ids[2]);

            { int off1=not_expired-bcc_pos; buf[bcc_pos]=0x54000003u|((uint32_t)(off1&0x7FFFF)<<5); }
            { int off2=n-skip_pos; buf[skip_pos]=enc_b26(off2); }
            break;
        }
        case 2: {

            TP(enc_ldr_x_off(0,31,8));
            TP(enc_ldp(25,26,31,6));
            TP(enc_ldp(21,22,31,4));
            TP(enc_ldp(19,20,31,2));
            TP(enc_ldp(29,30,31,0));
            TP(enc_add_i(31,31,0x70));
            if(next_va){
                int enc_start=n;
                int nn=emit_ctor_enc_br(buf,n,max_insns);
                if(nn<0) return -1;
                n=nn;
                buf[enc_start+17]=(uint32_t)(next_va&0xFFFFFFFF);
                buf[enc_start+18]=(uint32_t)(next_va>>32);
            } else {
                TP(enc_ret());
            }
            goto skip_back_jump_1;
        }
        case 3: {

            n=emit_crash_gadget(buf,n,max_insns);
            goto skip_back_jump_1;
        }
        }

        {
            int bp_start=n;
            int nn=emit_ctor_enc_br(buf,n,max_insns);
            if(nn<0) return -1;
            n=nn;
            back_patches[nback].enc_start=bp_start;
            nback++;
        }
        skip_back_jump_1:

        n=emit_junk(buf,n,max_insns,rand()%5+3);
    }

    for(int i=0;i<ndpatch;i++){
        int enc_start=dpatches[i].enc_br_start;
        int bi=dpatches[i].block_idx;
        buf[enc_start+17]=(uint32_t)block_pos[bi];
        buf[enc_start+18]=0xDEAD0001u;
    }
    for(int i=0;i<nback;i++){
        buf[back_patches[i].enc_start+17]=(uint32_t)dispatcher_pos;
        buf[back_patches[i].enc_start+18]=0xDEAD0001u;
    }

    if(n>max_insns) return -1;
    return n;
#undef TP
}

int build_init_wrapper_obfuscated(
    uint32_t *buf, int max_insns,
    uint64_t wrapper_va,
    uint64_t antihex_va,
    uint64_t timeprotect_va,
    uint64_t orig_init_va)
{
    (void)wrapper_va;
    int n=0;
    if(max_insns<64) return -1;

#define WR(x) do{ if(n>=max_insns) return -1; buf[n++]=(x); }while(0)

    WR(enc_stp_pre(29,30,31,(int)(-2u&0x7F)));
    WR(enc_mov_x(29,31));

    n=emit_junk(buf,n,max_insns,rand()%4+2);

    n=emit_bcf_block(buf,n,max_insns);
    n=emit_junk(buf,n,max_insns,rand()%3+1);
    n=emit_bcf_block(buf,n,max_insns);

    WR(enc_ldp_post(29,30,31,2));

    uint64_t first_target = 0;
    if(antihex_va) first_target = antihex_va;
    else if(timeprotect_va) first_target = timeprotect_va;
    else if(orig_init_va) first_target = orig_init_va;

    if(first_target){
        n=emit_junk(buf,n,max_insns,rand()%2+1);

        int enc_start = n;
        int nn = emit_ctor_enc_br(buf,n,max_insns);
        if(nn<0) return -1;
        n=nn;

        buf[enc_start+17]=(uint32_t)(first_target & 0xFFFFFFFF);
        buf[enc_start+18]=(uint32_t)(first_target >> 32);
    } else {
        WR(enc_ret());
    }

    n=emit_junk(buf,n,max_insns,rand()%2+1);

    if(n>max_insns) return -1;
    return n;
#undef WR
}

void fixup_ctor_obf_branches(uint32_t *buf, int insn_count, uint64_t base_va){
    for(int i=0; i+CTOR_ENC_BR_SIZE <= insn_count; i++){

        if(buf[i+16] != enc_br(16)) continue;

        uint32_t lo = buf[i+17];
        uint32_t hi = buf[i+18];

        if(hi == 0xDEAD0001u){

            int target_idx = (int)lo;
            uint64_t target_va = base_va + (uint64_t)target_idx * 4;
            uint64_t adr_va = base_va + (uint64_t)(i+14) * 4;
            patch_ctor_enc_br(buf, i, target_va, adr_va);
        } else {

            uint64_t target_va = (uint64_t)lo | ((uint64_t)hi << 32);
            if(target_va != 0){
                uint64_t adr_va = base_va + (uint64_t)(i+14) * 4;
                patch_ctor_enc_br(buf, i, target_va, adr_va);
            }
        }
    }
}
