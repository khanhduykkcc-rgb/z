
#include "types.h"
#include "util.h"
#include "container.h"

#define SHIFT   0xD0000u

#define O_HDR_END     0x012f0u
#define O_ENGINE_LO   0x08220u
#define O_ENGINE_HI   0x0d0001u
#define O_TEXT_LO     0x0d4f44u
#define O_TEXT_HI     0x0d6e68u
#define O_STUBS_LO    0x0d6e68u
#define O_SH0_LO      0x0d700cu
#define O_SH0_HI      0x0d7024u
#define O_SHTAIL_HI   0x0d7bbcu
#define O_UNWIND_LO   0x0d7bbcu
#define O_UNWIND_HI   0x0d7ce0u
#define O_EHFRAME_HI  0x0d8000u
#define O_DATA_LO     0x0d8000u
#define O_DATA_HI     0x0e0000u
#define O_MODINIT     0x0d8060u
#define O_VDATA_LO    0x0e0000u
#define O_VDATA_HI    0x0e4000u

#define I_STUBS_LO    0x6e68u
#define I_SHTAIL_LO   0x7024u
#define I_UNWIND_LO   0x7bbcu
#define I_UNWIND_HI   0x7ce0u
#define I_EHFRAME_LO  0x7ce0u
#define I_DATA_LO     0x8000u
#define I_DATA_HI     0x10000u

#define PTR_LO        0x4f44u
#define PTR_HI        0x10000u

typedef struct {
    uint32_t symoff, nsyms, stroff, strsize;
    uint32_t indirectsymoff, nindirectsyms;
    uint32_t csig_off, csig_size;
    int has_symtab, has_dysym, has_csig;
} LcInfo;

static int parse_lcs(const uint8_t *b, uint32_t sz, LcInfo *o) {
    memset(o, 0, sizeof(*o));
    if (sz < 0x20) return 0;
    if (rd32(b) != MH_MAGIC_64) return 0;
    uint32_t ncmds = rd32(b + 0x10);
    uint32_t off = 0x20;
    for (uint32_t i = 0; i < ncmds; i++) {
        if (off + 8 > sz) return 0;
        uint32_t cmd = rd32(b + off), cs = rd32(b + off + 4);
        if (cs < 8 || (uint64_t)off + cs > sz) return 0;
        if (cmd == LC_SYMTAB) {
            o->symoff  = rd32(b + off + 8);  o->nsyms   = rd32(b + off + 12);
            o->stroff  = rd32(b + off + 16); o->strsize = rd32(b + off + 20);
            o->has_symtab = 1;
        } else if (cmd == LC_DYSYMTAB) {
            o->indirectsymoff = rd32(b + off + 8 + 12 * 4);
            o->nindirectsyms  = rd32(b + off + 8 + 13 * 4);
            o->has_dysym = 1;
        } else if (cmd == LC_CODE_SIGNATURE) {
            o->csig_off  = rd32(b + off + 8);
            o->csig_size = rd32(b + off + 12);
            o->has_csig = 1;
        }
        off += cs;
    }
    return 1;
}

static uint8_t *load_asset(const char *dir, const char *name, uint32_t *out_sz) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", dir, name);
    return load_file(path, out_sz);
}

static int place_shift(uint8_t *reb, uint32_t glo, uint32_t ghi,
                       const uint8_t *inp, uint32_t insize, uint32_t src) {
    uint32_t n = ghi - glo;
    if ((uint64_t)src + n > insize) {
        fprintf(stderr, "[container] LOI: input qua ngan de sao chep vung 0x%x..0x%x (can input 0x%x)\n",
                glo, ghi, src + n);
        return 0;
    }
    memcpy(reb + glo, inp + src, n);
    return 1;
}

int container_run(const char *in_path, const char *out_path, const char *assetdir) {
    int rc = 1;
    uint8_t *inp = NULL, *reb = NULL;
    uint8_t *A[8] = {0};
    uint32_t Asz[8] = {0};
    static const char *ANAME[8] = {
        "hdr_lc.bin", "engine.bin", "text_lifted.bin", "stubhelper_blk0.bin",
        "vdata.bin", "dyldinfo_funcstarts.bin", "data_special_modinit.bin", "codesig.bin"
    };

    uint32_t insize = 0;
    inp = load_file(in_path, &insize);
    if (!inp) { fprintf(stderr, "[container] LOI: khong doc duoc input '%s'\n", in_path); goto done; }
    LcInfo I;
    if (!parse_lcs(inp, insize, &I) || !I.has_symtab || !I.has_dysym) {
        fprintf(stderr, "[container] LOI: '%s' khong phai Mach-O dylib hop le (thieu symtab/dysym)\n", in_path);
        goto done;
    }

    for (int k = 0; k < 8; k++) {
        A[k] = load_asset(assetdir, ANAME[k], &Asz[k]);
        if (!A[k]) {
            fprintf(stderr, "[container] LOI: thieu asset '%s/%s'\n", assetdir, ANAME[k]);
            goto done;
        }
    }
    uint8_t *a_hdr = A[0], *a_eng = A[1], *a_text = A[2], *a_sh0 = A[3];
    uint8_t *a_vdata = A[4], *a_dyld = A[5], *a_modi = A[6], *a_csig = A[7];

    LcInfo Gp;
    if (!parse_lcs(a_hdr, Asz[0], &Gp) || !Gp.has_symtab || !Gp.has_dysym || !Gp.has_csig) {
        fprintf(stderr, "[container] LOI: hdr_lc.bin khong parse duoc (thieu symtab/dysym/codesig)\n");
        goto done;
    }
    uint32_t i_sym = I.symoff, i_ind = I.indirectsymoff, i_str = I.stroff;
    uint32_t nsyms = I.nsyms;
    uint32_t g_sym = Gp.symoff, g_ind = Gp.indirectsymoff, g_str = Gp.stroff;
    uint32_t g_csig = Gp.csig_off, csig_sz = Gp.csig_size;
    uint32_t G = g_csig + csig_sz;

    if (!(g_sym >= O_VDATA_HI && g_ind > g_sym && g_str > g_ind && g_csig > g_str && G > g_csig)) {
        fprintf(stderr, "[container] LOI: thu tu linkedit gold bat thuong "
                "(sym=0x%x ind=0x%x str=0x%x csig=0x%x G=0x%x)\n", g_sym, g_ind, g_str, g_csig, G);
        goto done;
    }

    struct { int idx; uint32_t want; const char *what; } chk[] = {
        {0, O_HDR_END,               "hdr_lc.bin"},
        {1, O_ENGINE_HI - O_ENGINE_LO, "engine.bin"},
        {2, O_TEXT_HI - O_TEXT_LO,   "text_lifted.bin"},
        {3, O_SH0_HI - O_SH0_LO,     "stubhelper_blk0.bin"},
        {4, O_VDATA_HI - O_VDATA_LO, "vdata.bin"},
        {5, g_sym - O_VDATA_HI,      "dyldinfo_funcstarts.bin"},
        {6, 8u,                      "data_special_modinit.bin"},
        {7, csig_sz,                 "codesig.bin"},
    };
    for (unsigned c = 0; c < sizeof(chk) / sizeof(chk[0]); c++) {
        if (Asz[chk[c].idx] != chk[c].want) {
            fprintf(stderr, "[container] LOI: asset '%s' sai kich thuoc: co %u B, can %u B\n",
                    chk[c].what, Asz[chk[c].idx], chk[c].want);
            goto done;
        }
    }

    reb = (uint8_t *)calloc(1, G);
    if (!reb) { fprintf(stderr, "[container] LOI: het bo nho (%u B)\n", G); goto done; }

    memcpy(reb + 0x00000,    a_hdr,  O_HDR_END);

    memcpy(reb + O_ENGINE_LO, a_eng,  O_ENGINE_HI - O_ENGINE_LO);

    memcpy(reb + O_TEXT_LO,  a_text, O_TEXT_HI - O_TEXT_LO);
    memcpy(reb + O_SH0_LO,   a_sh0,  O_SH0_HI - O_SH0_LO);
    memcpy(reb + O_VDATA_LO, a_vdata, O_VDATA_HI - O_VDATA_LO);
    memcpy(reb + O_VDATA_HI, a_dyld, g_sym - O_VDATA_HI);
    memcpy(reb + g_csig,     a_csig, csig_sz);

    if (!place_shift(reb, O_STUBS_LO, O_SH0_LO, inp, insize, I_STUBS_LO)) goto done;

    if (!place_shift(reb, O_SH0_HI, O_SHTAIL_HI, inp, insize, I_SHTAIL_LO)) goto done;

    if (!place_shift(reb, O_UNWIND_LO, O_UNWIND_HI, inp, insize, I_UNWIND_LO)) goto done;

    if (!place_shift(reb, O_UNWIND_HI, O_EHFRAME_HI, inp, insize, I_EHFRAME_LO)) goto done;

    if (!place_shift(reb, O_DATA_LO, O_DATA_HI, inp, insize, I_DATA_LO)) goto done;

    if (!place_shift(reb, g_sym, g_ind, inp, insize, i_sym)) goto done;

    if (!place_shift(reb, g_ind, g_str, inp, insize, i_ind)) goto done;

    if (!place_shift(reb, g_str, g_csig, inp, insize, i_str)) goto done;

    uint32_t u_fixed = 0;
    for (uint32_t ioff = I_UNWIND_LO; ioff + 4 <= I_UNWIND_HI; ioff += 4) {
        uint32_t v = rd32(inp + ioff);
        if (v >= PTR_LO && v < PTR_HI) {
            wr32(reb + ioff + SHIFT, v + SHIFT);
            u_fixed++;
        }
    }

    uint32_t d_fixed = 0, d_special = 0, d_unknown = 0;
    for (uint32_t goff = O_DATA_LO; goff < O_DATA_HI; goff += 8) {
        if (goff == O_MODINIT) {
            wr64(reb + goff, rd64(a_modi));
            d_special++;
            continue;
        }
        uint32_t ioff = goff - SHIFT;
        uint64_t iv = rd64(inp + ioff);
        if (iv >= PTR_LO && iv < PTR_HI) {
            wr64(reb + goff, iv + SHIFT);
            d_fixed++;
        }

    }
    (void)d_unknown;

    uint32_t s_fixed = 0;
    for (uint32_t k = 0; k < nsyms; k++) {
        uint32_t e = i_sym + 16 * k;
        uint8_t  ntype = inp[e + 4];
        uint8_t  nsect = inp[e + 5];
        uint64_t nvalue = rd64(inp + e + 8);
        if ((ntype & 0xe0) == 0 && (ntype & 0x0e) == 0x0e && nsect != 0) {
            wr64(reb + g_sym + 16 * k + 8, nvalue + SHIFT);
            s_fixed++;
        }
    }

    if (!save_file(out_path, reb, G)) {
        fprintf(stderr, "[container] LOI: khong ghi duoc output '%s'\n", out_path);
        goto done;
    }

    {
        uint32_t asset_tot = O_HDR_END
                           + (O_ENGINE_HI - O_ENGINE_LO)
                           + (O_TEXT_HI - O_TEXT_LO)
                           + (O_SH0_HI - O_SH0_LO)
                           + (O_VDATA_HI - O_VDATA_LO)
                           + (g_sym - O_VDATA_HI)
                           + csig_sz;
        printf("[container] TAI TAO PIPELINE inputOther->outputOther\n");
        printf("  input  : %s (%u B, %u nlist)\n", in_path, insize, nsyms);
        printf("  asset  : %s (8 file)\n", assetdir);
        printf("  output : %s (%u B = 0x%x)\n", out_path, G, G);
        printf("  dich   : +0x%x (toan bo noi dung goc)\n", SHIFT);
        printf("  reloc  : unwind(u32)=%u  data(u64)=%u(special=%u)  symtab=%u\n",
               u_fixed, d_fixed, d_special, s_fixed);
        printf("  ASSET  : %u B (%.1f%% output) = engine/text'/vdata/dyld-info/codesig (obfuscator sinh)\n",
               asset_tot, 100.0 * (double)asset_tot / (double)G);
        printf("  ==> Da ghi output. Kiem byte-exact bang: cmp %s outputOther.dylib\n", out_path);
    }
    rc = 0;

done:
    if (reb) free(reb);
    for (int k = 0; k < 8; k++) if (A[k]) free(A[k]);
    if (inp) free(inp);
    return rc;
}
