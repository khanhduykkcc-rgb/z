#include "arm64_enc.h"

uint32_t enc_b26(int32_t im){ return 0x14000000u|((uint32_t)im&0x3FFFFFFu); }
uint32_t enc_bl26(int32_t im){ return 0x94000000u|((uint32_t)im&0x3FFFFFFu); }
uint32_t enc_movz(int d,uint16_t im,int sh){ return 0xD2800000u|((uint32_t)(sh/16)<<21)|((uint32_t)im<<5)|(uint32_t)d; }
uint32_t enc_movk(int d,uint16_t im,int sh){ return 0xF2800000u|((uint32_t)(sh/16)<<21)|((uint32_t)im<<5)|(uint32_t)d; }
uint32_t enc_add_i(int d,int n,int im){ return 0x91000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sub_i(int d,int n,int im){ return 0xD1000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_add_r(int d,int n,int m){ return 0x8B000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_mov_x(int d,int m){ return 0xAA0003E0u|((uint32_t)m<<16)|(uint32_t)d; }
uint32_t enc_str_x_off(int t,int n,int sc){ return 0xF9000000u|((uint32_t)(sc&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_ldr_x_off(int t,int n,int sc){ return 0xF9400000u|((uint32_t)(sc&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_ldr_w_off(int t,int n,int sc){ return 0xB9400000u|((uint32_t)(sc&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_ldr_w_post(int t,int n,int im9){ return 0xB8400400u|(((uint32_t)im9&0x1FF)<<12)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_stp_pre(int a,int b,int n,int im7){ return 0xA9800000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }
uint32_t enc_ldp_post(int a,int b,int n,int im7){ return 0xA8C00000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }
uint32_t enc_stp(int a,int b,int n,int im7){ return 0xA9000000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }
uint32_t enc_ldp(int a,int b,int n,int im7){ return 0xA9400000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }
uint32_t enc_br(int n){ return 0xD61F0000u|((uint32_t)n<<5); }
uint32_t enc_ret(void){ return 0xD65F03C0u; }
uint32_t enc_b_ne(int32_t im19){ return 0x54000001u|((uint32_t)(im19&0x7FFFF)<<5); }
uint32_t enc_b_eq(int32_t im19){ return 0x54000000u|((uint32_t)(im19&0x7FFFF)<<5); }
uint32_t enc_subs_w_i(int d,int n,int im){ return 0x71000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_cmp_x(int n,int m){ return 0xEB000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|31u; }
uint32_t enc_eor_w(int d,int n,int m){ return 0x4A000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_eor_x(int d,int n,int m){ return 0xCA000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_ror_w(int d,int n,int sh){ return 0x13800000u|((uint32_t)n<<16)|((uint32_t)(sh&31)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_lsr_w(int d,int n,int sh){ return 0x53000000u|((uint32_t)(sh&31)<<16)|(31u<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sub_i_lsl12(int d,int n,int im){ return 0xD1400000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_orr_w(int d,int n,int m){ return 0x2A000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_and_x(int d,int n,int m){ return 0x8A000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sub_r(int d,int n,int m){ return 0xCB000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_orn_x(int d,int n,int m){ return 0xAA200000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_adr(int d, int32_t off){
    uint32_t lo = (uint32_t)off & 3u;
    uint32_t hi = ((uint32_t)off >> 2) & 0x7FFFFu;
    return 0x10000000u | (lo << 29) | (hi << 5) | (uint32_t)d;
}

uint32_t enc_adrp(int d, int32_t page_delta){
    uint32_t lo = (uint32_t)page_delta & 3u;
    uint32_t hi = ((uint32_t)page_delta >> 2) & 0x7FFFFu;
    return 0x90000000u | (lo << 29) | (hi << 5) | (uint32_t)d;
}
uint32_t enc_mul_x(int d,int n,int m){ return 0x9B007C00u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_madd_x(int d,int n,int m,int a){ return 0x9B000000u|((uint32_t)m<<16)|((uint32_t)a<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_csel_x(int d,int n,int m,int cond){ return 0x9A800000u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_lsl_x_imm(int d,int n,int sh){ int immr=(64-sh)&63; int imms=63-sh; return 0xD3400000u|(uint32_t)((immr&63)<<16)|(uint32_t)((imms&63)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_lsr_x_imm(int d,int n,int sh){ return 0xD340FC00u|((uint32_t)(sh&63)<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_ror_x(int d,int n,int sh){ return 0x93C00000u|((uint32_t)n<<16)|((uint32_t)(sh&63)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_mvn_x(int d,int m){ return 0xAA200000u|((uint32_t)m<<16)|(0x1Fu<<5)|(uint32_t)d; }
uint32_t enc_neg_x(int d,int m){ return 0xCB000000u|((uint32_t)m<<16)|(0x1Fu<<5)|(uint32_t)d; }
uint32_t enc_cbz_x(int rt,int32_t off19){ return 0xB4000000u|((uint32_t)(off19&0x7FFFF)<<5)|(uint32_t)rt; }
uint32_t enc_cbnz_x(int rt,int32_t off19){ return 0xB5000000u|((uint32_t)(off19&0x7FFFF)<<5)|(uint32_t)rt; }

uint32_t enc_cbz_w(int rt,int32_t off19){ return 0x34000000u|((uint32_t)(off19&0x7FFFF)<<5)|(uint32_t)rt; }
uint32_t enc_cbnz_w(int rt,int32_t off19){ return 0x35000000u|((uint32_t)(off19&0x7FFFF)<<5)|(uint32_t)rt; }
uint32_t enc_subs_x_r(int d,int n,int m){ return 0xEB000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_adds_x_r(int d,int n,int m){ return 0xAB000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_subs_w_r(int d,int n,int m){ return 0x6B000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_adds_w_r(int d,int n,int m){ return 0x2B000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sub_w_r(int d,int n,int m){ return 0x4B000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_add_w_r(int d,int n,int m){ return 0x0B000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sub_w_i(int d,int n,int im){ return 0x51000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_add_w_i(int d,int n,int im){ return 0x11000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_eor_x_imm(int d,int n,uint32_t immr,uint32_t imms){
    return 0xD2000000u|(1u<<22)|((immr&0x3F)<<16)|((imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d;
}
uint32_t enc_orr_x(int d,int n,int m){ return 0xAA000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_bic_x(int d,int n,int m){ return 0x8A200000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_eon_x(int d,int n,int m){ return 0xCA200000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sdiv_x(int d,int n,int m){ return 0x9AC00C00u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_udiv_x(int d,int n,int m){ return 0x9AC00800u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_msub_x(int d,int n,int m,int a){ return 0x9B008000u|((uint32_t)m<<16)|((uint32_t)a<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_clz_x(int d,int n){ return 0xDAC01000u|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_rev_x(int d,int n){ return 0xDAC00C00u|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_rbit_x(int d,int n){ return 0xDAC00000u|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_b_cc(int cond,int32_t im19){ return 0x54000000u|((uint32_t)(im19&0x7FFFF)<<5)|(uint32_t)(cond&0xF); }
uint32_t enc_tbz(int rt,int bit,int32_t off14){
    uint32_t b5=((uint32_t)bit>>5)&1;
    uint32_t b40=(uint32_t)bit&0x1F;
    return 0x36000000u|(b5<<31)|(b40<<19)|((uint32_t)(off14&0x3FFF)<<5)|(uint32_t)rt;
}
uint32_t enc_tbnz(int rt,int bit,int32_t off14){
    uint32_t b5=((uint32_t)bit>>5)&1;
    uint32_t b40=(uint32_t)bit&0x1F;
    return 0x37000000u|(b5<<31)|(b40<<19)|((uint32_t)(off14&0x3FFF)<<5)|(uint32_t)rt;
}
uint32_t enc_blr(int n){ return 0xD63F0000u|((uint32_t)n<<5); }
uint32_t enc_nop(void){ return NOP; }
uint32_t enc_movn_x(int d,uint16_t im,int sh){ return 0x92800000u|((uint32_t)(sh/16)<<21)|((uint32_t)im<<5)|(uint32_t)d; }

uint32_t enc_movz_w(int d,uint16_t im,int sh){ return 0x52800000u|((uint32_t)(sh/16)<<21)|((uint32_t)im<<5)|(uint32_t)d; }
uint32_t enc_movk_w(int d,uint16_t im,int sh){ return 0x72800000u|((uint32_t)(sh/16)<<21)|((uint32_t)im<<5)|(uint32_t)d; }
uint32_t enc_movn_w(int d,uint16_t im,int sh){ return 0x12800000u|((uint32_t)(sh/16)<<21)|((uint32_t)im<<5)|(uint32_t)d; }

uint32_t enc_mov_w(int d,int m){ return 0x2A0003E0u|((uint32_t)m<<16)|(uint32_t)d; }

uint32_t enc_subs_x_i(int d,int n,int im){ return 0xF1000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_adds_x_i(int d,int n,int im){ return 0xB1000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_adds_w_i(int d,int n,int im){ return 0x31000000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_add_i_lsl12(int d,int n,int im){ return 0x91400000u|((uint32_t)(im&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)d; }

uint32_t enc_and_w(int d,int n,int m){ return 0x0A000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_bic_w(int d,int n,int m){ return 0x0A200000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_orn_w(int d,int n,int m){ return 0x2A200000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_eon_w(int d,int n,int m){ return 0x4A200000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_orr_w_r(int d,int n,int m){ return 0x2A000000u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }

uint32_t enc_and_x_imm(int d,int n,uint32_t immr,uint32_t imms){
    return 0x92000000u|(1u<<22)|((immr&0x3F)<<16)|((imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d;
}
uint32_t enc_orr_x_imm(int d,int n,uint32_t immr,uint32_t imms){
    return 0xB2000000u|(1u<<22)|((immr&0x3F)<<16)|((imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d;
}
uint32_t enc_ands_x_imm(int d,int n,uint32_t immr,uint32_t imms){
    return 0xF2000000u|(1u<<22)|((immr&0x3F)<<16)|((imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d;
}

uint32_t enc_csel_w(int d,int n,int m,int cond){ return 0x1A800000u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_csinc_x(int d,int n,int m,int cond){ return 0x9A800400u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_csinc_w(int d,int n,int m,int cond){ return 0x1A800400u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_csinv_x(int d,int n,int m,int cond){ return 0xDA800000u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_csinv_w(int d,int n,int m,int cond){ return 0x5A800000u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_csneg_x(int d,int n,int m,int cond){ return 0xDA800400u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_csneg_w(int d,int n,int m,int cond){ return 0x5A800400u|((uint32_t)m<<16)|((uint32_t)cond<<12)|((uint32_t)n<<5)|(uint32_t)d; }

uint32_t enc_mul_w(int d,int n,int m){ return 0x1B007C00u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_madd_w(int d,int n,int m,int a){ return 0x1B000000u|((uint32_t)m<<16)|((uint32_t)a<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_msub_w(int d,int n,int m,int a){ return 0x1B008000u|((uint32_t)m<<16)|((uint32_t)a<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sdiv_w(int d,int n,int m){ return 0x1AC00C00u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_udiv_w(int d,int n,int m){ return 0x1AC00800u|((uint32_t)m<<16)|((uint32_t)n<<5)|(uint32_t)d; }

uint32_t enc_clz_w(int d,int n){ return 0x5AC01000u|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_rev_w(int d,int n){ return 0x5AC00800u|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_rbit_w(int d,int n){ return 0x5AC00000u|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_cls_x(int d,int n){ return 0xDAC01400u|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_neg_w(int d,int m){ return 0x4B000000u|((uint32_t)m<<16)|(0x1Fu<<5)|(uint32_t)d; }
uint32_t enc_mvn_w(int d,int m){ return 0x2A200000u|((uint32_t)m<<16)|(0x1Fu<<5)|(uint32_t)d; }

uint32_t enc_str_w_off(int t,int n,int sc){ return 0xB9000000u|((uint32_t)(sc&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_ldrb_off(int t,int n,int imm){ return 0x39400000u|((uint32_t)(imm&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_strb_off(int t,int n,int imm){ return 0x39000000u|((uint32_t)(imm&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_ldrh_off(int t,int n,int imm){ return 0x79400000u|((uint32_t)(imm&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_strh_off(int t,int n,int imm){ return 0x79000000u|((uint32_t)(imm&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_ldrsw_off(int t,int n,int sc){ return 0xB9800000u|((uint32_t)(sc&0xFFF)<<10)|((uint32_t)n<<5)|(uint32_t)t; }
uint32_t enc_stp_w(int a,int b,int n,int im7){ return 0x29000000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }
uint32_t enc_ldp_w(int a,int b,int n,int im7){ return 0x29400000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }
uint32_t enc_stp_w_pre(int a,int b,int n,int im7){ return 0x29800000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }
uint32_t enc_ldp_w_post(int a,int b,int n,int im7){ return 0x28C00000u|((uint32_t)(im7&0x7F)<<15)|((uint32_t)b<<10)|((uint32_t)n<<5)|(uint32_t)a; }

uint32_t enc_lsl_w_imm(int d,int n,int sh){ int immr=(32-sh)&31; int imms=31-sh; return 0x53000000u|(uint32_t)((immr&31)<<16)|(uint32_t)((imms&31)<<10)|((uint32_t)n<<5)|(uint32_t)d; }

uint32_t enc_sbfm_x(int d,int n,int immr,int imms){ return 0x93400000u|((uint32_t)(immr&0x3F)<<16)|((uint32_t)(imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_ubfm_x(int d,int n,int immr,int imms){ return 0xD3400000u|((uint32_t)(immr&0x3F)<<16)|((uint32_t)(imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_sbfm_w(int d,int n,int immr,int imms){ return 0x13000000u|((uint32_t)(immr&0x3F)<<16)|((uint32_t)(imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_ubfm_w(int d,int n,int immr,int imms){ return 0x53000000u|((uint32_t)(immr&0x3F)<<16)|((uint32_t)(imms&0x3F)<<10)|((uint32_t)n<<5)|(uint32_t)d; }
uint32_t enc_asr_x(int d,int n,int sh){ return enc_sbfm_x(d,n,sh,63); }
uint32_t enc_sxtw(int d,int n){ return enc_sbfm_x(d,n,0,31); }

uint32_t enc_ccmp_x_i(int n,int imm5,int nzcv,int cond){ return 0xFA400800u|((uint32_t)(imm5&0x1F)<<16)|((uint32_t)(cond&0xF)<<12)|((uint32_t)n<<5)|(uint32_t)(nzcv&0xF); }
uint32_t enc_ccmp_x_r(int n,int m,int nzcv,int cond){ return 0xFA400000u|((uint32_t)m<<16)|((uint32_t)(cond&0xF)<<12)|((uint32_t)n<<5)|(uint32_t)(nzcv&0xF); }
uint32_t enc_ccmn_x_i(int n,int imm5,int nzcv,int cond){ return 0xBA400800u|((uint32_t)(imm5&0x1F)<<16)|((uint32_t)(cond&0xF)<<12)|((uint32_t)n<<5)|(uint32_t)(nzcv&0xF); }

int emit_mov64(uint32_t *buf, int n, int reg, uint64_t val){
    buf[n++]=enc_movz(reg,(uint16_t)(val&0xFFFF),0);
    if(val>>16) buf[n++]=enc_movk(reg,(uint16_t)((val>>16)&0xFFFF),16);
    if(val>>32) buf[n++]=enc_movk(reg,(uint16_t)((val>>32)&0xFFFF),32);
    if(val>>48) buf[n++]=enc_movk(reg,(uint16_t)((val>>48)&0xFFFF),48);
    return n;
}

uint64_t decode_bitmask_imm(uint32_t N, uint32_t immr, uint32_t imms, int is64){
    uint32_t len = 0;
    uint32_t combined = (N << 6) | (~imms & 0x3F);

    for(int i = 6; i >= 0; i--){
        if(combined & (1u << i)){ len = (uint32_t)i; break; }
    }
    uint32_t esize = 1u << len;
    uint32_t levels = esize - 1;
    uint32_t s = imms & levels;
    uint32_t r = immr & levels;
    uint64_t welem = 0;
    for(uint32_t i = 0; i <= s; i++) welem |= (1ULL << i);

    uint64_t mask = (esize == 64) ? ~0ULL : ((1ULL << esize) - 1);
    welem = ((welem >> r) | (welem << (esize - r))) & mask;

    uint64_t result = 0;
    for(uint32_t i = 0; i < (is64 ? 64u : 32u); i += esize)
        result |= (welem << i);
    if(!is64) result &= 0xFFFFFFFFULL;
    return result;
}

bool encode_bitmask_imm(uint64_t val, int is64, uint32_t *N, uint32_t *immr, uint32_t *imms){
    if(val == 0 || (is64 && val == ~0ULL) || (!is64 && val == 0xFFFFFFFF)) return false;
    if(!is64) val = (val & 0xFFFFFFFF) | ((val & 0xFFFFFFFF) << 32);

    for(int esz_log2 = 1; esz_log2 <= 6; esz_log2++){
        uint32_t esize = 1u << esz_log2;
        if(esize < 2) continue;
        uint64_t emask = (esize == 64) ? ~0ULL : ((1ULL << esize) - 1);
        uint64_t elem = val & emask;

        bool ok = true;
        for(uint32_t i = esize; i < 64; i += esize){
            if(((val >> i) & emask) != elem){ ok = false; break; }
        }
        if(!ok) continue;

        for(uint32_t r = 0; r < esize; r++){
            uint64_t rot = ((elem >> r) | (elem << (esize - r))) & emask;

            if(rot == 0) continue;
            uint64_t tmp = rot;
            uint32_t ones = 0;
            while(tmp & 1){ ones++; tmp >>= 1; }
            if(tmp == 0 && ones > 0){
                uint32_t levels = esize - 1;
                *immr = r & levels;
                *imms = (ones - 1) & levels;
                if(esz_log2 < 6) *imms |= (~levels & 0x3F) & ~(esize);
                *N = (esize == 64) ? 1 : 0;

                if(esize != 64){
                    uint32_t mask_bits = 0;
                    for(int k = esz_log2; k < 6; k++) mask_bits |= (1u << k);
                    *imms = (*imms & (esize - 1)) | ((~(esize - 1)) & 0x3F & ~mask_bits);
                    *imms = (ones - 1) | ((~levels) & 0x3F);
                    *imms &= 0x3F;
                }
                return true;
            }
        }
    }
    return false;
}
