
#include "types.h"
#include "util.h"
#include "buf.h"
#include "arm64_analyze.h"
#include "arm64_enc.h"
#include "pcrel.h"
#include "extpc.h"
#include "obfuscate.h"
#include "ctor_obf.h"
#include "macho.h"
#include "vm.h"
#include "tui.h"
#include "sign.h"
#include "container.h"

static bool is_ret_like_word(uint32_t w){
    if(w==0xD65F03C0u||w==0xD65F0BFFu||w==0xD65F0FFFu) return true;
    if((w&0xFFFFFC1Fu)==0xD61F0000u){
        int rn = (int)((w>>5)&0x1F);
        return rn == 30;
    }
    return false;
}

static bool is_brk_like_word(uint32_t w){
    return (w&0xFFE0001Fu)==0xD4200000u;
}

static int find_func_index_exact(const uint64_t *func_vas, int nfuncs, uint64_t target_va){
    int lo = 0, hi = nfuncs - 1;
    while(lo <= hi){
        int mid = lo + (hi - lo) / 2;
        if(func_vas[mid] == target_va) return mid;
        if(func_vas[mid] < target_va) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

static bool va_in_set(const uint64_t *set, int n, uint64_t va){
    for(int i=0;i<n;i++) if(set[i]==va) return true;
    return false;
}

static bool func_has_reachable_brk(const uint8_t *text_data, uint64_t text_va,
                                   uint64_t fva, uint32_t fsz)
{
    uint32_t insns = fsz / 4;
    uint64_t off = fva - text_va;
    for(uint32_t i=0; i<insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if(is_brk_like_word(w)) return true;
    }
    return false;
}

static bool func_has_reachable_ret(const uint8_t *text_data, uint64_t text_va,
                                   uint64_t fva, uint32_t fsz)
{
    uint32_t insns = fsz / 4;
    uint64_t off = fva - text_va;
    for(uint32_t i=0; i<insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if(is_ret_like_word(w)) return true;
    }
    return false;
}

static bool func_has_cond_branch(const uint8_t *text_data, uint64_t text_va,
                                 uint64_t fva, uint32_t fsz)
{
    uint32_t insns = fsz / 4;
    uint64_t off = fva - text_va;
    for(uint32_t i=0; i<insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if(is_cond_branch(w)) return true;
    }
    return false;
}

static bool func_has_external_conditional(const uint8_t *text_data, uint64_t text_va,
                                          uint64_t fva, uint32_t fsz)
{
    uint32_t insns = fsz / 4;
    uint64_t off = fva - text_va;
    for(uint32_t i=0; i<insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if(!is_cond_branch(w)) continue;
        int64_t rel = 0;
        PCType t = classify_pcrel(w, &rel);
        uint64_t tgt = (uint64_t)((int64_t)(fva + (uint64_t)i*4) + rel);
        if(t==PC_BCOND||t==PC_CBZ_W||t==PC_CBNZ_W||t==PC_CBZ_X||t==PC_CBNZ_X||
           t==PC_TBZ||t==PC_TBNZ){
            if(tgt < fva || tgt >= fva + fsz) return true;
        }
    }
    return false;
}

static bool func_has_flag_gap(const uint8_t *text_data, uint64_t text_va,
                              uint64_t fva, uint32_t fsz)
{
    uint32_t insns = fsz / 4;
    uint64_t off = fva - text_va;
    for(uint32_t i=0; i<insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if(!sets_flags(w)) continue;
        for(uint32_t j=i+1; j<insns; j++){
            uint32_t w2 = rd32(text_data + off + j*4);
            if(uses_flags(w2)) return (j > i + 1);
            if(sets_flags(w2) || is_terminator(w2)) break;
        }
    }
    return false;
}

static bool func_calls_trap_helper(const uint8_t *text_data, uint64_t text_va,
                                   uint64_t fva, uint32_t fsz,
                                   const uint64_t *func_vas, const FuncEntry *fentries,
                                   int nfuncs)
{
    uint32_t insns = fsz / 4;
    uint64_t off = fva - text_va;
    for(uint32_t i=0; i<insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        int64_t rel = 0;
        if(classify_pcrel(w, &rel) != PC_BL26) continue;
        uint64_t tgt = (uint64_t)((int64_t)(fva + (uint64_t)i*4) + rel);
        int callee = find_func_index_exact(func_vas, nfuncs, tgt);
        if(callee >= 0 && fentries[callee].is_trap_helper) return true;
    }
    return false;
}

static void write_slidesafe_branch(uint8_t *new_data, uint32_t fo,
                                   uint64_t first_va, uint64_t target_va){
    uint64_t anchor_va = first_va + 4ull*4;
    uint64_t d = (uint64_t)((int64_t)target_va - (int64_t)anchor_va);
    wr32(new_data+fo+0,  enc_movz(16,(uint16_t)(d&0xFFFF),0));
    wr32(new_data+fo+4,  enc_movk(16,(uint16_t)((d>>16)&0xFFFF),16));
    wr32(new_data+fo+8,  enc_movk(16,(uint16_t)((d>>32)&0xFFFF),32));
    wr32(new_data+fo+12, enc_movk(16,(uint16_t)((d>>48)&0xFFFF),48));
    wr32(new_data+fo+16, enc_adr(17,0));
    wr32(new_data+fo+20, enc_add_r(16,16,17));
    wr32(new_data+fo+24, enc_br(16));
}

static int va_in_reachable_code(uint64_t va, const FuncEntry *fe, int nf){
    int lo=0, hi=nf-1;
    while(lo<=hi){
        int mid=(int)(((unsigned)lo+(unsigned)hi)>>1);
        uint64_t s=fe[mid].va;
        uint64_t e=s+(uint64_t)fe[mid].size;
        if(va<s) hi=mid-1;
        else if(va>=e) lo=mid+1;
        else return 1;
    }
    return 0;
}

int main(int argc, char **argv){
    bool auto_mode = false;
    bool do_antihex_flag = true;
    bool do_timeprotect_flag = false;
    bool do_vmenc_flag = true;
    bool force_flag = false;
    int auto_expire_days = 0;
    bool container_mode = false;
    const char *assetdir = NULL;
    int argi = 1;

    while(argi < argc && argv[argi][0] == '-'){
        if(strcmp(argv[argi], "-a") == 0) auto_mode = true;
        else if(strcmp(argv[argi], "-no-antihex") == 0) do_antihex_flag = false;
        else if(strcmp(argv[argi], "-no-vmenc") == 0) do_vmenc_flag = false;
        else if(strcmp(argv[argi], "-force") == 0) force_flag = true;
        else if(strncmp(argv[argi], "-container=", 11) == 0){
            container_mode = true;
            assetdir = argv[argi]+11;
        }
        else if(strncmp(argv[argi], "-expire=", 8) == 0){
            do_timeprotect_flag = true;
            auto_expire_days = atoi(argv[argi]+8);
            if(auto_expire_days < 1) auto_expire_days = 1;
        }
        argi++;
    }

    if(argc - argi != 2){
        fprintf(stderr,"usage: %s [-a] [-no-antihex] [-no-vmenc] [-force] [-expire=DAYS] input.dylib output.dylib\n",argv[0]);
        fprintf(stderr,"  -a              auto mode (select all eligible, no TUI)\n");
        fprintf(stderr,"  -no-antihex     disable anti-hex integrity check\n");
        fprintf(stderr,"  -no-vmenc       disable VM bytecode encryption (decrypt-on-fetch)\n");
        fprintf(stderr,"  -force          re-process a dylib already protected by this tool (unsafe)\n");
        fprintf(stderr,"  -container=DIR  tai tao pipeline inputOther->outputOther tu asset trong DIR\n");
        fprintf(stderr,"  -expire=DAYS    enable time-based expiration (DAYS from now)\n");
        return 1;
    }

    const char *input_path = argv[argi];
    const char *output_path = argv[argi+1];

    if(container_mode){
        return container_run(input_path, output_path, assetdir);
    }

    srand((unsigned)time(NULL)^(unsigned)getpid());
    uint32_t fsize=0;
    uint8_t *fdata=load_file(input_path,&fsize);
    if(!fdata) return 1;
    DylibInfo di;
    if(!parse_dylib(fdata,fsize,&di)){ fprintf(stderr,"[!] parse fail\n"); return 1; }
    printf("[*] Input: %u bytes\n",fsize);
    printf("[*] __text: va=0x%llx fo=0x%llx sz=0x%llx\n",
           (unsigned long long)di.text_va,(unsigned long long)di.text_fo,(unsigned long long)di.text_sz);

    {
        const uint32_t M_AHEX = 0x41484558u;
        const uint32_t M_VMBC = 0x564D4243u;
        int found_ahex = 0, found_vmbc = 0;
        uint32_t ahex_off = 0, vmbc_off = 0;
        for(uint32_t off = 0; off + 4 <= fsize; off += 4){
            uint32_t w = rd32(fdata + off);
            if(w == M_AHEX && !found_ahex){ found_ahex = 1; ahex_off = off; }
            else if(w == M_VMBC && !found_vmbc){ found_vmbc = 1; vmbc_off = off; }
            if(found_ahex && found_vmbc) break;
        }
        if(found_ahex || found_vmbc){
            fprintf(stderr,
                "[!] Double-processing guard: input already carries this tool's markers"
                " (AHEX=%s@0x%x VM_MAGIC=%s@0x%x).\n",
                found_ahex?"yes":"no", ahex_off, found_vmbc?"yes":"no", vmbc_off);
            if(!force_flag){
                fprintf(stderr,
                    "[!] Refusing to re-protect an already-protected dylib."
                    " Pass -force to override (output may be corrupt).\n");
                free(fdata);
                return 1;
            }
            fprintf(stderr,"[!] -force given: proceeding despite existing markers.\n");
        }
    }

    uint64_t *func_vas=(uint64_t*)malloc((size_t)MAX_FUNCS*sizeof(uint64_t));
    if(!func_vas){ free(fdata); return 1; }
    int nfuncs=get_func_starts(fdata,&di,func_vas,MAX_FUNCS);
    printf("[*] Functions from LC_FUNCTION_STARTS: %d\n",nfuncs);

    FuncEntry *fentries = (FuncEntry*)calloc((size_t)nfuncs, sizeof(FuncEntry));
    if(!fentries){ free(fdata); free(func_vas); return 1; }
    for(int i=0;i<nfuncs;i++){
        uint64_t fs = func_vas[i];
        uint64_t nx = (i+1<nfuncs) ? func_vas[i+1] : di.text_va+di.text_sz;
        uint64_t fe = func_end_va_reachable(fdata+di.text_fo,di.text_va,di.text_sz,fs,nx);
        fentries[i].va = fs;
        fentries[i].size = (uint32_t)(fe-fs);
        fentries[i].insn_cnt = fentries[i].size/4;
        fentries[i].sym_name = find_symbol_name(fdata,fsize,fs);
        fentries[i].selected = false;
        detect_prologue(fdata+di.text_fo,di.text_va,fs,fentries[i].prologue);
        fentries[i].complexity = compute_func_complexity(fdata+di.text_fo,di.text_va,fs,fentries[i].size);
        fentries[i].is_safe = (fentries[i].size >= MIN_FUNC_SIZE
            && !has_computed_branch(fdata+di.text_fo,di.text_va,fs,fentries[i].size)
            && func_is_ultra_safe(fdata+di.text_fo,di.text_va,fs,fentries[i].size));
    }

    uint64_t init_func_vas[64];
    int n_init_func_vas = 0;
    {
        const uint8_t *lcp2 = fdata + 32;
        const mh64 *h2 = (const mh64*)fdata;
        for(uint32_t ci = 0; ci < h2->ncmds; ci++){
            const lc_t *lc = (const lc_t*)lcp2;
            if(lc->cmd == LC_SEGMENT_64){
                const seg64 *seg = (const seg64*)lcp2;
                const uint8_t *sp2 = lcp2 + sizeof(seg64);
                for(uint32_t sj = 0; sj < seg->nsects; sj++){
                    const sec64 *sect = (const sec64*)sp2;
                    if((sect->flags & 0xFF) == 0x16 && sect->offset && sect->size > 0){
                        uint32_t n_off = (uint32_t)(sect->size / 4);
                        for(uint32_t k = 0; k < n_off && n_init_func_vas < 64; k++){
                            uint32_t fo2 = sect->offset + k * 4;
                            if(fo2 + 4 <= fsize){
                                uint32_t init_off = rd32(fdata + fo2);
                                init_func_vas[n_init_func_vas++] = di.tseg_va + init_off;
                            }
                        }
                    }
                    if((sect->flags & 0xFF) == S_MOD_INIT_FUNC_PTRS && sect->offset && sect->size > 0){
                        uint32_t n_ptrs = (uint32_t)(sect->size / 8);
                        for(uint32_t k = 0; k < n_ptrs && n_init_func_vas < 64; k++){
                            uint32_t fo2 = sect->offset + k * 8;
                            if(fo2 + 8 <= fsize)
                                init_func_vas[n_init_func_vas++] = rd64(fdata + fo2);
                        }
                    }
                    sp2 += sizeof(sec64);
                }
            }
            lcp2 += lc->cmdsize;
        }
    }
    for(int i = 0; i < nfuncs; i++){
        uint64_t fstart = fentries[i].va;
        uint64_t fend = fstart + fentries[i].size;
        for(int j = 0; j < n_init_func_vas; j++){
            if(init_func_vas[j] >= fstart && init_func_vas[j] < fend){
                fentries[i].is_safe = false;
                break;
            }
        }
    }
    if(n_init_func_vas > 0)
        printf("[*] Found %d init function entry points (excluded from obfuscation)\n", n_init_func_vas);

    {
        int trap_helpers = 0;
        int safe_mode_funcs = 0;
        int cond_trap_funcs = 0;
        int flag_gap_funcs = 0;
        int ext_cond_funcs = 0;
        int reg_clobber_funcs = 0;
        int special_op_funcs = 0;
        int exclusive_funcs = 0;
        int system_funcs = 0;
        int barrier_funcs = 0;
        int ptrauth_funcs = 0;
        static const int alt_state_candidates[] = {9, 10, 11, 12, 13, 14};
        const uint8_t *text_data = fdata + di.text_fo;

        for(int i=0; i<nfuncs; i++){
            uint64_t fs = fentries[i].va;
            uint32_t fsz = fentries[i].size;
            if(fsz < 4) continue;
            bool has_brk = func_has_reachable_brk(text_data, di.text_va, fs, fsz);
            bool has_ret = func_has_reachable_ret(text_data, di.text_va, fs, fsz);
            fentries[i].is_trap_helper = has_brk && !has_ret;
            if(fentries[i].is_trap_helper) trap_helpers++;
        }

        for(int i=0; i<nfuncs; i++){
            uint64_t fs = fentries[i].va;
            uint32_t fsz = fentries[i].size;
            uint32_t risk_flags = FUNC_RISK_NONE;
            Arm64FuncAnalysis analysis;
            bool analysis_ok = false;
            bool has_cond = false;
            bool has_brk = false;
            bool calls_trap = false;

            memset(&analysis, 0, sizeof(analysis));
            fentries[i].used_gpr_mask = 0;
            fentries[i].analysis_flags = 0;

            if(fsz >= 4){
                has_cond = func_has_cond_branch(text_data, di.text_va, fs, fsz);
                has_brk = func_has_reachable_brk(text_data, di.text_va, fs, fsz);
                calls_trap = func_calls_trap_helper(text_data, di.text_va, fs, fsz,
                                                    func_vas, fentries, nfuncs);
                analysis_ok = arm64_analyze_words(
                    (const uint32_t *)(text_data + (fs - di.text_va)),
                    (int)(fsz / 4), fs, &analysis);
                fentries[i].used_gpr_mask = analysis.gpr_used_mask;
                fentries[i].analysis_flags = analysis.feature_flags;
                if(has_cond && (has_brk || calls_trap)) risk_flags |= FUNC_RISK_COND_TRAP;
                if(func_has_flag_gap(text_data, di.text_va, fs, fsz)) risk_flags |= FUNC_RISK_FLAG_GAP;
                if(func_has_external_conditional(text_data, di.text_va, fs, fsz)) risk_flags |= FUNC_RISK_EXT_COND;
                if(!analysis_ok || (analysis.feature_flags & ARM64_ANALYSIS_FORCE_SAFE_MASK))
                    risk_flags |= FUNC_RISK_SPECIAL_OP;
                if(analysis.uses_x15)
                    risk_flags |= FUNC_RISK_REG_CLOBBER;
                if(analysis.uses_x16 || analysis.uses_x17){
                    int s0 = -1, s1 = -1;
                    if(arm64_pick_unused_pair(analysis.gpr_used_mask, alt_state_candidates, 6, &s0, &s1) < 2)
                        risk_flags |= FUNC_RISK_REG_CLOBBER;
                }
            }

            fentries[i].risk_flags = risk_flags;
            fentries[i].force_safe_mode = (risk_flags != FUNC_RISK_NONE);

            if(risk_flags & FUNC_RISK_COND_TRAP) cond_trap_funcs++;
            if(risk_flags & FUNC_RISK_FLAG_GAP) flag_gap_funcs++;
            if(risk_flags & FUNC_RISK_EXT_COND) ext_cond_funcs++;
            if(risk_flags & FUNC_RISK_REG_CLOBBER) reg_clobber_funcs++;
            if(risk_flags & FUNC_RISK_SPECIAL_OP) special_op_funcs++;
            if(analysis.feature_flags & ARM64_ANALYSIS_EXCLUSIVE) exclusive_funcs++;
            if(analysis.feature_flags & ARM64_ANALYSIS_SYSTEM) system_funcs++;
            if(analysis.feature_flags & ARM64_ANALYSIS_BARRIER) barrier_funcs++;
            if(analysis.feature_flags & ARM64_ANALYSIS_PAUTH) ptrauth_funcs++;
            if(fentries[i].force_safe_mode) safe_mode_funcs++;
        }

        printf("[*] Risk analysis: trap helpers=%d, safe-mode=%d (cond-trap=%d, flag-gap=%d, ext-cond=%d, reg-clobber=%d, special-op=%d)\n",
               trap_helpers, safe_mode_funcs, cond_trap_funcs, flag_gap_funcs,
               ext_cond_funcs, reg_clobber_funcs, special_op_funcs);
        printf("[*] Special opcode scan: exclusive=%d, system=%d, barrier=%d, ptrauth=%d\n",
               exclusive_funcs, system_funcs, barrier_funcs, ptrauth_funcs);
    }

    bool do_obf = false, do_antihex = false, do_vm = false;
    bool do_timeprotect = false;
    int expire_days = 1;

    if(auto_mode){
        do_obf = true;
        do_antihex = do_antihex_flag;
        do_vm = true;
        do_timeprotect = do_timeprotect_flag;
        expire_days = auto_expire_days > 0 ? auto_expire_days : 1;
        int nskip_tiny=0, nskip_br=0, nskip_init=0, nsel=0;
        int nsel_full=0, nsel_safe=0;
        for(int i=0;i<nfuncs;i++){
            if(fentries[i].size < MIN_FUNC_SIZE){ nskip_tiny++; continue; }
            if(has_computed_branch(fdata+di.text_fo,di.text_va,fentries[i].va,fentries[i].size)){ nskip_br++; continue; }
            bool is_init = false;
            uint64_t fstart = fentries[i].va, fend = fstart + fentries[i].size;
            for(int j=0;j<n_init_func_vas;j++){
                if(init_func_vas[j]>=fstart && init_func_vas[j]<fend){ is_init=true; break; }
            }
            if(is_init){ nskip_init++; continue; }
            fentries[i].selected = true;
            nsel++;
            if(fentries[i].force_safe_mode) nsel_safe++;
            else nsel_full++;
        }
        printf("[*] Auto mode: %d selected, %d skipped (tiny), %d skipped (BR), %d skipped (init)\n",
               nsel, nskip_tiny, nskip_br, nskip_init);
        printf("[*] Strategy split: %d full-CFF, %d safe-CFG\n", nsel_full, nsel_safe);
    } else {
        run_tui(fentries, nfuncs, &do_obf, &do_antihex, &do_vm, &do_timeprotect, &expire_days,
                fdata+di.text_fo, di.text_va);
    }

    printf("\n[*] Obfuscation: %s\n", do_obf ? "ENABLED" : "DISABLED");
    printf("[*] Anti-hex: %s\n", do_antihex ? "ENABLED" : "DISABLED");
    printf("[*] Time-protect: %s", do_timeprotect ? "ENABLED" : "DISABLED");
    if(do_timeprotect) printf(" (%d days)", expire_days);
    printf("\n");
    printf("[*] VM mode: %s\n", do_vm ? "ENABLED (heaviest func -> VM)" : "DISABLED (encrypt all normally)");

    if(!do_obf && !do_antihex && !do_timeprotect && !do_vm){
        printf("[!] Nothing to do\n");
        free(fdata); free(func_vas); free(fentries); return 0;
    }

    int nselected = 0;
    int nselected_safe = 0;
    int nselected_full = 0;
    if(do_obf){
        for(int i=0;i<nfuncs;i++){
            if(!fentries[i].selected) continue;
            nselected++;
            if(fentries[i].force_safe_mode) nselected_safe++;
            else nselected_full++;
        }
        printf("[*] Functions selected for obfuscation: %d\n", nselected);
        printf("[*] Planned strategies: %d full-CFF, %d safe-CFG\n", nselected_full, nselected_safe);
    }

    Buf code_buf; buf_init(&code_buf);
    uint64_t insert_point = di.insert_point;
    uint64_t insert_va = di.tseg_va + insert_point;

    typedef struct { int func_idx; uint64_t orig_va; uint64_t new_va; uint32_t buf_off; uint32_t orig_sz; bool ok; } FuncMap;
    FuncMap *fmap = (FuncMap*)calloc((size_t)nfuncs, sizeof(FuncMap));
    if(!fmap){ free(fdata); free(func_vas); free(fentries); return 1; }

    int nvirt=0;
    int nvirt_safe=0;
    int nvirt_full=0;
    uint32_t *obf_buf = NULL;
    if(do_obf) obf_buf = (uint32_t*)malloc((size_t)MAX_OBF*4);

    extpc_init();

    int vm_func_idx = -1;
    uint32_t vm_func_complexity = 0;
    VmBytecode vm_bc; vm_bc_init(&vm_bc);
    uint32_t vm_stub_insn_count = 0;
    uint32_t *vm_stub_code = NULL;
    uint8_t *vm_bc_raw = NULL;
    uint32_t vm_bc_raw_size = 0;
    uint32_t *vm_native_words = NULL;
    int vm_n_native_words = 0;
    int      vm_encrypt   = do_vmenc_flag ? 1 : 0;
    uint32_t vm_enc_key0  = 0, vm_enc_key1 = 0;

    if(do_obf && do_vm){

        int *cand = (int*)malloc(sizeof(int)*(size_t)(nfuncs>0?nfuncs:1));
        int ncand = 0;
        if(cand){
            for(int i=0;i<nfuncs;i++){
                if(!fentries[i].selected) continue;
                if(fentries[i].size < MIN_FUNC_SIZE) continue;
                if(has_computed_branch(fdata+di.text_fo,di.text_va,fentries[i].va,fentries[i].size)) continue;
                cand[ncand++]=i;
            }
            for(int a=1;a<ncand;a++){
                int key=cand[a]; uint32_t kc=fentries[key].complexity; int b=a-1;
                while(b>=0 && fentries[cand[b]].complexity < kc){ cand[b+1]=cand[b]; b--; }
                cand[b+1]=key;
            }
        }

        vm_native_words = (uint32_t*)calloc(2048, sizeof(uint32_t));

        for(int ci=0; ci<ncand && cand && vm_native_words; ci++){
            int idx = cand[ci];
            uint64_t fs = func_vas[idx];
            uint64_t nx = (idx+1<nfuncs) ? func_vas[idx+1] : di.text_va+di.text_sz;
            uint64_t fe = func_end_va_reachable(fdata+di.text_fo,di.text_va,di.text_sz,fs,nx);
            uint32_t fsz = (uint32_t)(fe-fs);
            uint32_t icnt = fsz/4;
            const uint32_t *src = (const uint32_t*)(fdata+di.text_fo+(fs-di.text_va));

            uint64_t ext_calls[256];
            int n_ext_calls = 0;

            vm_bc.count = 0;
            vm_n_native_words = 0;

            printf("[*] VM: Translating func[%d] @ 0x%llx (%u insns, complexity=%u) to VM bytecode\n",
                   idx, (unsigned long long)fs, icnt, fentries[idx].complexity);

            if(ldvq2306_translate_arm64_to_vm(src, icnt, fs, di.text_va, di.text_sz, &vm_bc,
                                     ext_calls, &n_ext_calls, 256,
                                     vm_native_words, &vm_n_native_words, 2048)){
                vm_func_idx = idx;
                vm_func_complexity = fentries[idx].complexity;
                printf("[+] VM: Translated %u ARM64 insns -> %u VM instructions (%d ext calls, %d native trampolines)\n",
                       icnt, vm_bc.count, n_ext_calls, vm_n_native_words);

                vm_bc_raw_size = vm_bc.count * 8 + 16;
                vm_bc_raw = (uint8_t*)calloc(1, vm_bc_raw_size + 256);
                if(vm_bc_raw){
                    uint32_t actual_bc_sz = vm_bc_serialize(&vm_bc, vm_bc_raw, vm_bc_raw_size + 256);
                    if(actual_bc_sz > 0) vm_bc_raw_size = actual_bc_sz;
                    printf("[+] VM: Bytecode serialized: %u bytes\n", vm_bc_raw_size);
                }

                vm_enc_key0 = (0x9E3779B9u ^ 0x4C445651u) ^ (vm_bc.count * 2654435761u);
                vm_enc_key1 = (0x85EBCA77u + 0x32333036u) + (vm_bc.count * 0x27D4EB2Fu);

                vm_stub_code = (uint32_t*)calloc(8192, sizeof(uint32_t));
                if(vm_stub_code){
                    int stub_cnt = ldvq2306_emit_vm_interpreter_stub(vm_stub_code, 8192, 0, vm_bc.count, 0, 0, (uint32_t)vm_n_native_words,
                                                            vm_encrypt, vm_enc_key0, vm_enc_key1);
                    if(stub_cnt > 0){
                        vm_stub_insn_count = (uint32_t)stub_cnt;
                        printf("[+] VM: Interpreter stub generated: %u instructions (%u bytes)\n",
                               vm_stub_insn_count, vm_stub_insn_count*4);
                    } else {
                        printf("[!] VM: Failed to generate interpreter stub\n");
                        vm_func_idx = -1;
                    }
                }

                if(vm_func_idx >= 0){
                    fentries[vm_func_idx].selected = false;
                    break;
                }

                if(vm_bc_raw){ free(vm_bc_raw); vm_bc_raw=NULL; vm_bc_raw_size=0; }
                if(vm_stub_code){ free(vm_stub_code); vm_stub_code=NULL; }
                vm_stub_insn_count=0;
            } else {
                printf("[!] VM: func[%d] rejected (unvirtualizable insn) -> trying next candidate\n", idx);
            }
        }

        if(vm_func_idx < 0)
            printf("[!] VM: no eligible function could be virtualized, obfuscation only\n");

        free(cand);
    }

    uint32_t vm_stub_buf_off = 0, vm_bc_buf_off = 0, vm_tramp_buf_off = 0;
    if(vm_func_idx >= 0 && vm_stub_code && vm_bc_raw){
        buf_pad16(&code_buf);
        vm_stub_buf_off = code_buf.size;
        buf_push(&code_buf, vm_stub_code, vm_stub_insn_count * 4);

        buf_pad16(&code_buf);
        vm_bc_buf_off = code_buf.size;
        buf_push(&code_buf, vm_bc_raw, vm_bc_raw_size);

        buf_pad16(&code_buf);
        vm_tramp_buf_off = code_buf.size;
        for(int ti=0; ti<vm_n_native_words; ti++){
            buf_u32(&code_buf, vm_native_words[ti]);
            buf_u32(&code_buf, 0xD65F03C0u);
        }

        printf("[+] VM: Stub @ buf+0x%x, Bytecode @ buf+0x%x, Trampolines @ buf+0x%x (%d entries)\n",
               vm_stub_buf_off, vm_bc_buf_off, vm_tramp_buf_off, vm_n_native_words);
    }

    if(do_obf){

        uint32_t min_complexity = UINT32_MAX, max_complexity = 0;
        for(int i = 0; i < nfuncs; i++){
            if(!fentries[i].selected) continue;
            if(fentries[i].size < MIN_FUNC_SIZE) continue;
            if(fentries[i].complexity < min_complexity) min_complexity = fentries[i].complexity;
            if(fentries[i].complexity > max_complexity) max_complexity = fentries[i].complexity;
        }
        uint32_t complexity_range = (max_complexity > min_complexity) ? (max_complexity - min_complexity) : 1;
        printf("[*] Complexity range: min=%u max=%u range=%u\n", min_complexity, max_complexity, complexity_range);

        for(int i=0;i<nfuncs;i++){
            fmap[i].ok = false;
            if(!fentries[i].selected) continue;
            uint64_t fs = func_vas[i];
            uint64_t nx = (i+1<nfuncs) ? func_vas[i+1] : di.text_va+di.text_sz;
            uint64_t fe = func_end_va_reachable(fdata+di.text_fo,di.text_va,di.text_sz,fs,nx);
            uint32_t fsz = (uint32_t)(fe-fs);
            if(fsz < MIN_FUNC_SIZE) continue;
            if(has_computed_branch(fdata+di.text_fo,di.text_va,fs,fsz)) continue;
            uint32_t icnt = fsz/4;
            buf_pad16(&code_buf);
            uint32_t buf_off = code_buf.size;
            uint64_t new_va = insert_va + buf_off;
            const uint32_t *src = (const uint32_t*)(fdata+di.text_fo+(fs-di.text_va));

            float obf_weight = 1.0f - (float)(fentries[i].complexity - min_complexity) / (float)complexity_range;
            if(obf_weight < 0.05f) obf_weight = 0.05f;
            if(obf_weight > 1.0f) obf_weight = 1.0f;
            int obf_cnt = ldvq2306_obfuscate_func(src,(int)icnt,fs,new_va,obf_buf,MAX_OBF,
                                         buf_off,obf_weight,fentries[i].force_safe_mode,
                                         fentries[i].used_gpr_mask,
                                         fentries[i].analysis_flags);
            if(obf_cnt < 0){
                if(obf_cnt == -2)
                    printf("[!] func[%d] 0x%04llx: buffer truncated, skipping\n", i, (unsigned long long)fs);
                continue;
            }
            buf_push(&code_buf,obf_buf,(uint32_t)obf_cnt*4);
            fmap[i].func_idx=i;
            fmap[i].orig_va=fs;
            fmap[i].new_va=new_va;
            fmap[i].buf_off=buf_off;
            fmap[i].orig_sz=fsz;
            fmap[i].ok=true;
            nvirt++;
            if(fentries[i].force_safe_mode) nvirt_safe++;
            else nvirt_full++;
            printf("[+] func[%d] 0x%04llx -> obf@0x%04llx (%u -> %d insns, %.1fx, w=%.2f, %s)\n",
                   i,(unsigned long long)fs,(unsigned long long)new_va,icnt,obf_cnt,
                   (float)obf_cnt/(float)icnt,obf_weight,
                   fentries[i].force_safe_mode ? "safe-cfg" : "full-cff");
        }
    }
    if(obf_buf) free(obf_buf);
    printf("[*] Obfuscated %d functions, code buffer: %u bytes\n",nvirt,code_buf.size);
    if(do_obf)
        printf("[*] Completed strategies: %d full-CFF, %d safe-CFG\n", nvirt_full, nvirt_safe);

    uint32_t ctor_stub_buf_off=0, ctor_body_buf_off=0;
    uint32_t wrapper_stub_buf_off=0, wrapper_body_buf_off=0;
    uint32_t tp_stub_buf_off=0, tp_body_buf_off=0;
    uint64_t orig_init_va_0=0;
    int n_init_funcs=0;
    uint32_t ctor_body_reserved_bytes=0, wrapper_body_reserved_bytes=0;
    uint32_t tp_body_reserved_bytes=0;

    bool need_init_hook = (do_antihex || do_timeprotect);

    if(do_antihex){

        uint32_t ctor_est_insns = 2400;
        ctor_body_reserved_bytes = (uint32_t)align_up(ctor_est_insns * 4 + 512, 64);

        buf_pad16(&code_buf);
        ctor_stub_buf_off=code_buf.size;
        buf_u32(&code_buf, NOP);
        buf_pad16(&code_buf);
        ctor_body_buf_off=code_buf.size;
        for(uint32_t pp=0;pp<ctor_body_reserved_bytes;pp+=4) buf_u32(&code_buf,NOP);
    }

    if(do_timeprotect){

        uint32_t tp_est_insns = 1800;
        tp_body_reserved_bytes = (uint32_t)align_up(tp_est_insns * 4 + 512, 64);

        buf_pad16(&code_buf);
        tp_stub_buf_off=code_buf.size;
        buf_u32(&code_buf, NOP);
        buf_pad16(&code_buf);
        tp_body_buf_off=code_buf.size;
        for(uint32_t pp=0;pp<tp_body_reserved_bytes;pp+=4) buf_u32(&code_buf,NOP);
    }

    if(need_init_hook){

        wrapper_body_reserved_bytes = (uint32_t)align_up(256 * 4 + 256, 16);

        buf_pad16(&code_buf);
        wrapper_stub_buf_off=code_buf.size;
        buf_u32(&code_buf, NOP);
        buf_pad16(&code_buf);
        wrapper_body_buf_off=code_buf.size;
        for(uint32_t pp=0;pp<wrapper_body_reserved_bytes;pp+=4) buf_u32(&code_buf,NOP);

        if(di.mod_init_fo && di.mod_init_sz>=8){
            orig_init_va_0=rd64(fdata+(uint32_t)di.mod_init_fo);
            n_init_funcs=(int)(di.mod_init_sz/8);
        }
    }

    buf_pad16(&code_buf);
    printf("[*] Total code buffer: %u bytes\n",code_buf.size);

    uint64_t shift_threshold=di.tseg_va+insert_point;
    uint64_t shift_end=di.tseg_va+di.tseg_vsz+0x10000000;
    uint64_t actual_shift=0;
    uint32_t new_fsize=0;
    uint64_t exec_fo_out=0, exec_va_out=0;
    uint8_t *new_data=build_output(fdata,fsize,code_buf.data,code_buf.size,
        insert_point,&actual_shift,&new_fsize,need_init_hook,&exec_fo_out,&exec_va_out);
    if(!new_data){
        fprintf(stderr,"[!] build_output failed\n");
        free(fdata); buf_free(&code_buf); free(fmap); free(func_vas); free(fentries); extpc_free(); return 1;
    }
    printf("[*] Actual shift: 0x%llx\n",(unsigned long long)actual_shift);
    printf("[*] Fixing %d external PC-relative references\n",extpc_get_count());

    int fix_overflow_cnt=0, fix_converted_cnt=0;
    for(int i=0;i<extpc_get_count();i++){
        uint32_t file_off=(uint32_t)insert_point+extpc_get_refs()[i].buf_byte_off;
        if(file_off+4>new_fsize) continue;
        uint64_t abs_tgt=extpc_get_refs()[i].abs_target;
        uint64_t adj_tgt=abs_tgt;
        if(abs_tgt>=shift_threshold&&abs_tgt<shift_end)
            adj_tgt=abs_tgt+actual_shift;
        uint64_t insn_va=di.tseg_va+file_off;
        uint32_t w=rd32(new_data+file_off);
        int64_t new_off;
        PCType t=extpc_get_refs()[i].type;
        { int64_t _chk_off=0; PCType _chk_t=classify_pcrel(w,&_chk_off);
          if(_chk_t!=t){
            printf("[!] EXTPC MISMATCH fo=0x%x: recorded type=%d actual type=%d insn=0x%08X (off corruption?)\n",
                file_off,(int)t,(int)_chk_t,(unsigned)w);
          }
        }
        if(t==PC_ADRP){
            int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
            int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
            new_off=tgt_page-cur_page;
        } else {
            new_off=(int64_t)adj_tgt-(int64_t)insn_va;
        }
        if(!pcrel_in_range(t,new_off)){
            if(t==PC_ADR && file_off+8<=new_fsize){
                int rd = (int)(w & 0x1F);
                int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                int64_t page_off=tgt_page-cur_page;
                if(pcrel_in_range(PC_ADRP,page_off)){
                    uint32_t adrp_w = 0x90000000u | (uint32_t)rd;
                    adrp_w = rewrite_pcrel(adrp_w, PC_ADRP, page_off);
                    uint32_t pageoff = (uint32_t)((uint64_t)adj_tgt & 0xFFF);
                    uint32_t add_w = 0x91000000u | (pageoff<<10) | ((uint32_t)rd<<5) | (uint32_t)rd;
                    wr32(new_data+file_off, adrp_w);
                    wr32(new_data+file_off+4, add_w);
                    fix_converted_cnt++; continue;
                }
            }
            if(t==PC_LDR_X_LIT && file_off+8<=new_fsize){
                int rt = (int)(w & 0x1F);
                int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                int64_t page_off=tgt_page-cur_page;
                if(pcrel_in_range(PC_ADRP,page_off)){
                    uint32_t adrp_w = rewrite_pcrel(0x90000000u|(uint32_t)rt, PC_ADRP, page_off);
                    uint32_t pageoff = (uint32_t)((uint64_t)adj_tgt & 0xFFF);
                    uint32_t ldr_w = 0xF9400000u | ((pageoff/8)<<10) | ((uint32_t)rt<<5) | (uint32_t)rt;
                    wr32(new_data+file_off, adrp_w);
                    wr32(new_data+file_off+4, ldr_w);
                    fix_converted_cnt++; continue;
                }
            }
            if(t==PC_LDR_W_LIT && file_off+8<=new_fsize){
                int rt = (int)(w & 0x1F);
                int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                int64_t page_off=tgt_page-cur_page;
                if(pcrel_in_range(PC_ADRP,page_off)){
                    uint32_t adrp_w = rewrite_pcrel(0x90000000u|(uint32_t)rt, PC_ADRP, page_off);
                    uint32_t pageoff = (uint32_t)((uint64_t)adj_tgt & 0xFFF);
                    uint32_t ldr_w = 0xB9400000u | ((pageoff/4)<<10) | ((uint32_t)rt<<5) | (uint32_t)rt;
                    wr32(new_data+file_off, adrp_w);
                    wr32(new_data+file_off+4, ldr_w);
                    fix_converted_cnt++; continue;
                }
            }
            if(t==PC_LDRSW_LIT && file_off+8<=new_fsize){
                int rt = (int)(w & 0x1F);
                int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                int64_t page_off=tgt_page-cur_page;
                if(pcrel_in_range(PC_ADRP,page_off)){
                    uint32_t adrp_w = rewrite_pcrel(0x90000000u|(uint32_t)rt, PC_ADRP, page_off);
                    uint32_t pageoff = (uint32_t)((uint64_t)adj_tgt & 0xFFF);
                    uint32_t ldrsw_w = 0xB9800000u | ((pageoff/4)<<10) | ((uint32_t)rt<<5) | (uint32_t)rt;
                    wr32(new_data+file_off, adrp_w);
                    wr32(new_data+file_off+4, ldrsw_w);
                    fix_converted_cnt++; continue;
                }
            }
            if((t==PC_LDR_S_LIT||t==PC_LDR_D_LIT||t==PC_LDR_Q_LIT) && file_off+8<=new_fsize){
                int rt = (int)(w & 0x1F);
                int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                int64_t page_off=tgt_page-cur_page;
                if(pcrel_in_range(PC_ADRP,page_off)){
                    uint32_t adrp_w = rewrite_pcrel(0x90000000u|16u, PC_ADRP, page_off);
                    uint32_t pageoff = (uint32_t)((uint64_t)adj_tgt & 0xFFF);
                    uint32_t ldr_w;
                    if(t==PC_LDR_S_LIT) ldr_w = 0xBD400000u | ((pageoff/4)<<10) | (16u<<5) | (uint32_t)rt;
                    else if(t==PC_LDR_D_LIT) ldr_w = 0xFD400000u | ((pageoff/8)<<10) | (16u<<5) | (uint32_t)rt;
                    else ldr_w = 0x3DC00000u | ((pageoff/16)<<10) | (16u<<5) | (uint32_t)rt;
                    wr32(new_data+file_off, adrp_w);
                    wr32(new_data+file_off+4, ldr_w);
                    fix_converted_cnt++; continue;
                }
            }
            if(t==PC_PRFM_LIT){
                wr32(new_data+file_off, NOP);
                wr32(new_data+file_off+4, NOP);
                fix_converted_cnt++; continue;
            }
            if((t==PC_BCOND||t==PC_CBZ_W||t==PC_CBNZ_W||t==PC_CBZ_X||t==PC_CBNZ_X||
                t==PC_TBZ||t==PC_TBNZ) && file_off+8<=new_fsize &&
               rd32(new_data+file_off+4)==NOP){

                uint32_t inv_w;
                PCType inv_t;
                switch(t){
                case PC_BCOND:  inv_w=w^1u;                             inv_t=PC_BCOND;  break;
                case PC_CBZ_W:  inv_w=(w&~0xFF000000u)|0x35000000u;     inv_t=PC_CBNZ_W; break;
                case PC_CBNZ_W: inv_w=(w&~0xFF000000u)|0x34000000u;     inv_t=PC_CBZ_W;  break;
                case PC_CBZ_X:  inv_w=(w&~0xFF000000u)|0xB5000000u;     inv_t=PC_CBNZ_X; break;
                case PC_CBNZ_X: inv_w=(w&~0xFF000000u)|0xB4000000u;     inv_t=PC_CBZ_X;  break;
                case PC_TBZ:    inv_w=(w&~0x7F000000u)|0x37000000u;     inv_t=PC_TBNZ;   break;
                case PC_TBNZ:   inv_w=(w&~0x7F000000u)|0x36000000u;     inv_t=PC_TBZ;    break;
                default:        inv_w=w;                                 inv_t=t;          break;
                }
                int64_t b_off = (int64_t)adj_tgt - (int64_t)(insn_va + 4);
                if(pcrel_in_range(PC_B26, b_off)){

                    uint32_t skip_insn = rewrite_pcrel(inv_w, inv_t, 2*4);
                    wr32(new_data+file_off,   skip_insn);
                    wr32(new_data+file_off+4, enc_b26((int32_t)(b_off/4)));
                    fix_converted_cnt++; continue;
                }

                {
                    int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                    int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                    int64_t page_off=tgt_page-cur_page;
                    if(file_off+16<=new_fsize &&
                       rd32(new_data+file_off+8)==NOP && rd32(new_data+file_off+12)==NOP &&
                       pcrel_in_range(PC_ADRP,page_off)){
                        uint32_t skip4   = rewrite_pcrel(inv_w, inv_t, 4*4);
                        uint32_t adrp_w  = rewrite_pcrel(0x90000000u|16u, PC_ADRP, page_off);
                        uint32_t pageoff = (uint32_t)((uint64_t)adj_tgt & 0xFFF);
                        uint32_t add_w   = 0x91000000u|(pageoff<<10)|(16u<<5)|16u;
                        wr32(new_data+file_off,    skip4);
                        wr32(new_data+file_off+4,  adrp_w);
                        wr32(new_data+file_off+8,  add_w);
                        wr32(new_data+file_off+12, 0xD61F0200u);
                        fix_converted_cnt++; continue;
                    }
                }
                fix_overflow_cnt++;
                printf("[!] Cond branch overflow fo=0x%x tgt=0x%llx B26 also OOR\n",
                    file_off,(unsigned long long)adj_tgt);
                wr32(new_data+file_off,   NOP);
                wr32(new_data+file_off+4, NOP);
                continue;
            }

            if(t==PC_BL26 && file_off+8<=new_fsize){
                int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                int64_t page_off=tgt_page-cur_page;
                uint32_t pageoff=(uint32_t)((uint64_t)adj_tgt&0xFFF);
                if(pcrel_in_range(PC_ADRP,page_off) && pageoff==0){
                    uint32_t adrp_w=rewrite_pcrel(0x90000000u|16u,PC_ADRP,page_off);
                    wr32(new_data+file_off,   adrp_w);
                    wr32(new_data+file_off+4, 0xD63F0200u);
                    fix_converted_cnt++; continue;
                }
                if(pcrel_in_range(PC_ADRP,page_off) && file_off+12<=new_fsize){
                    uint32_t adrp_w=rewrite_pcrel(0x90000000u|16u,PC_ADRP,page_off);
                    uint32_t add_w=0x91000000u|(pageoff<<10)|(16u<<5)|16u;
                    wr32(new_data+file_off,    adrp_w);
                    wr32(new_data+file_off+4,  add_w);
                    wr32(new_data+file_off+8,  0xD63F0200u);
                    fix_converted_cnt++; continue;
                }
                fix_overflow_cnt++;
                printf("[!] BL26 overflow fo=0x%x tgt=0x%llx off=%lld (no fix)\n",
                    file_off,(unsigned long long)adj_tgt,(long long)new_off);
                wr32(new_data+file_off, NOP);
                wr32(new_data+file_off+4, NOP);
                continue;
            }

            if(t==PC_ADRP && file_off+8<=new_fsize){
                int rd2=(int)(w&0x1F);
                uint64_t page_base=(uint64_t)adj_tgt&~0xFFFULL;
                uint32_t i0=enc_movz(rd2,(uint16_t)(page_base&0xFFFF),0);
                uint32_t i1=enc_movk(rd2,(uint16_t)((page_base>>16)&0xFFFF),16);
                uint32_t i2=enc_movk(rd2,(uint16_t)((page_base>>32)&0xFFFF),32);
                uint32_t i3=enc_movk(rd2,(uint16_t)((page_base>>48)&0xFFFF),48);
                if((page_base>>32)==0){
                    wr32(new_data+file_off,   i0);
                    wr32(new_data+file_off+4, i1);
                    fix_converted_cnt++; continue;
                }
                if((page_base>>48)==0 && file_off+12<=new_fsize){
                    wr32(new_data+file_off,   i0);
                    wr32(new_data+file_off+4, i1);
                    wr32(new_data+file_off+8, i2);
                    fix_converted_cnt++; continue;
                }
                if(file_off+16<=new_fsize){
                    wr32(new_data+file_off,    i0);
                    wr32(new_data+file_off+4,  i1);
                    wr32(new_data+file_off+8,  i2);
                    wr32(new_data+file_off+12, i3);
                    fix_converted_cnt++; continue;
                }
                fix_overflow_cnt++;
                printf("[!] ADRP extreme overflow fo=0x%x tgt=0x%llx page_base=0x%llx\n",
                    file_off,(unsigned long long)adj_tgt,(unsigned long long)((uint64_t)adj_tgt&~0xFFFULL));
                continue;
            }

            if(t==PC_B26 && file_off+12<=new_fsize &&
               rd32(new_data+file_off+4)==NOP && rd32(new_data+file_off+8)==NOP){

                int64_t tgt_page=(int64_t)adj_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)insn_va&~0xFFFLL;
                int64_t page_off=tgt_page-cur_page;
                if(pcrel_in_range(PC_ADRP,page_off)){
                    uint32_t adrp_w  = rewrite_pcrel(0x90000000u|16u, PC_ADRP, page_off);
                    uint32_t pageoff = (uint32_t)((uint64_t)adj_tgt & 0xFFF);
                    uint32_t add_w   = 0x91000000u|(pageoff<<10)|(16u<<5)|16u;
                    wr32(new_data+file_off,    adrp_w);
                    wr32(new_data+file_off+4,  add_w);
                    wr32(new_data+file_off+8,  0xD61F0200u);
                    fix_converted_cnt++; continue;
                }
                fix_overflow_cnt++;
                printf("[!] B26 overflow fo=0x%x tgt=0x%llx off=%lld (ADRP page OOR >+-4GB)\n",
                    file_off,(unsigned long long)adj_tgt,(long long)new_off);
                wr32(new_data+file_off, NOP);
                continue;
            }

            fix_overflow_cnt++;
            printf("[!] OVERFLOW type=%d fo=0x%x insn_va=0x%llx tgt=0x%llx off=%lld insn=0x%08X\n",
                (int)t, file_off, (unsigned long long)insn_va, (unsigned long long)adj_tgt, (long long)new_off, (unsigned)w);
            wr32(new_data+file_off, NOP);
        } else {
            w=rewrite_pcrel(w,t,new_off);
            wr32(new_data+file_off,w);
        }
    }
    if(fix_converted_cnt>0)
        printf("[*] Converted %d ADR/LDR-lit to ADRP+ADD/LDR pairs\n",fix_converted_cnt);
    if(fix_overflow_cnt>0)
        printf("[!] WARNING: %d PC-relative references still overflow!\n",fix_overflow_cnt);
    {
        uint32_t shifted_text_fo2=(uint32_t)(di.text_fo+actual_shift);
        uint32_t shifted_text_sz2=(uint32_t)di.text_sz;
        uint64_t shifted_text_va2=di.text_va+actual_shift;
        int nofix_pcrel=0, skip_insns=0, data_skipped=0;

        for(uint32_t k=0;k+4<=shifted_text_sz2;k+=4){
            uint32_t fo2=shifted_text_fo2+k;
            if(fo2+4>new_fsize) break;
            uint32_t w2=rd32(new_data+fo2);
            int64_t off2=0;
            PCType t2=classify_pcrel(w2,&off2);
            if(t2==PC_NONE) continue;

            uint64_t orig_word_va=di.text_va+k;
            if(!va_in_reachable_code(orig_word_va,fentries,nfuncs)){ data_skipped++; continue; }
            uint64_t insn_va2=shifted_text_va2+k;
            uint64_t abs_tgt2=(uint64_t)((int64_t)insn_va2+off2);
            if(t2==PC_ADRP){
                int64_t ap __attribute__((unused))=(int64_t)abs_tgt2&~0xFFFLL;
                uint32_t immlo=(w2>>29)&3u;
                uint32_t immhi=(w2>>5)&0x7FFFFu;
                int32_t imm21=(int32_t)((immhi<<2)|immlo);
                if(imm21&(1<<20)) imm21|=(int32_t)0xFFE00000;
                int64_t page_delta=(int64_t)imm21;

                uint64_t orig_insn_va2=insn_va2-actual_shift;
                int64_t orig_abs_page=(int64_t)(orig_insn_va2&~0xFFFULL)+(page_delta<<12);

                if((uint64_t)orig_abs_page<di.tseg_va||(uint64_t)orig_abs_page>=shift_end){ data_skipped++; continue; }
                int64_t adj_abs_page=orig_abs_page;
                if((uint64_t)orig_abs_page>=shift_threshold&&(uint64_t)orig_abs_page<shift_end)
                    adj_abs_page=orig_abs_page+(int64_t)actual_shift;
                int64_t new_page_delta=((adj_abs_page-(int64_t)(insn_va2&~0xFFFULL))>>12);
                if(new_page_delta>=-0x100000LL&&new_page_delta<=0xFFFFFLL){
                    uint32_t e=(uint32_t)(int32_t)new_page_delta;
                    uint32_t nw=(w2&0x9F00001Fu)|((e&3u)<<29)|(((e>>2)&0x7FFFFu)<<5);
                    wr32(new_data+fo2,nw);
                    nofix_pcrel++;
                } else {
                    int rd2=(int)(w2&0x1F);
                    uint64_t page_base=(uint64_t)adj_abs_page;
                    if(fo2+8<=new_fsize){
                        wr32(new_data+fo2, enc_movz(rd2,(uint16_t)(page_base&0xFFFF),0));
                        wr32(new_data+fo2+4, enc_movk(rd2,(uint16_t)((page_base>>16)&0xFFFF),16));
                        nofix_pcrel++;
                    } else {
                        skip_insns++;
                        printf("[!] ADRP shifted overflow, no space for MOV64 fallback fo=0x%x\n", fo2);
                    }
                }
                continue;
            }

            uint64_t orig_abs=(uint64_t)((int64_t)(insn_va2-actual_shift)+off2);

            if(orig_abs<di.tseg_va||orig_abs>=shift_end){ data_skipped++; continue; }
            uint64_t adj_abs=orig_abs;
            if(orig_abs>=shift_threshold&&orig_abs<shift_end)
                adj_abs=orig_abs+actual_shift;
            int64_t new_off2=(int64_t)adj_abs-(int64_t)insn_va2;
            if(pcrel_in_range(t2,new_off2)){
                wr32(new_data+fo2, rewrite_pcrel(w2,t2,new_off2));
                nofix_pcrel++;
            } else {
                bool fixed2=false;
                if(t2==PC_ADR && fo2+8<=new_fsize){
                    uint32_t next_w=rd32(new_data+fo2+4);
                    if(next_w==NOP || next_w==BRK_0){
                        int rd2=(int)(w2&0x1F);
                        int64_t tgt_page2=(int64_t)adj_abs&~0xFFFLL;
                        int64_t cur_page2=(int64_t)insn_va2&~0xFFFLL;
                        int64_t page_off2=tgt_page2-cur_page2;
                        if(pcrel_in_range(PC_ADRP,page_off2)){
                            uint32_t adrp2=rewrite_pcrel(0x90000000u|(uint32_t)rd2,PC_ADRP,page_off2);
                            uint32_t pageoff2=(uint32_t)((uint64_t)adj_abs&0xFFF);
                            uint32_t add2=0x91000000u|(pageoff2<<10)|((uint32_t)rd2<<5)|(uint32_t)rd2;
                            wr32(new_data+fo2,   adrp2);
                            wr32(new_data+fo2+4, add2);
                            nofix_pcrel++; fixed2=true;
                        }
                    }
                }
                if(!fixed2){
                    skip_insns++;
                    printf("[!] orig-text overflow type=%d fo=0x%x va=0x%llx tgt=0x%llx off=%lld insn=0x%08X\n",
                        (int)t2,fo2,(unsigned long long)insn_va2,(unsigned long long)adj_abs,
                        (long long)new_off2,(unsigned)w2);
                }
            }
        }
        printf("[*] Fixed %d PC-relative refs in shifted original __text (%d overflow skipped, %d data preserved)\n",
            nofix_pcrel,skip_insns,data_skipped);
    }

    if(do_obf){
        int tramp_ok=0, tramp_far=0;
        for(int i=0;i<nfuncs;i++){
            if(!fmap[i].ok) continue;
            uint64_t new_func_va=fmap[i].orig_va+actual_shift;
            uint64_t new_func_fo=di.text_fo+actual_shift+(fmap[i].orig_va-di.text_va);
            uint32_t fsz=fmap[i].orig_sz;
            uint64_t obf_va=di.tseg_va+(uint32_t)insert_point+fmap[i].buf_off;
            int64_t b_off_func=(int64_t)obf_va-(int64_t)new_func_va;
            int32_t b_imm26=(int32_t)(b_off_func/4);

            int entry_ok=0; uint32_t start_fill=4;
            if(b_imm26 >= -0x2000000 && b_imm26 <= 0x1FFFFFF){
                if(new_func_fo+4<=new_fsize){
                    wr32(new_data+(uint32_t)new_func_fo,enc_b26(b_imm26));
                    entry_ok=1; start_fill=4;
                }
                tramp_ok++;
            } else {

                if(new_func_fo+16<=new_fsize && fsz>=16){

                    int64_t tgt_page=(int64_t)obf_va&~0xFFFLL;
                    int64_t cur_page=(int64_t)new_func_va&~0xFFFLL;
                    int64_t page_off=tgt_page-cur_page;
                    if(page_off >= -(1LL<<32) && page_off < (1LL<<32)){
                        uint32_t adrp_w = rewrite_pcrel(0x90000000u|16u, PC_ADRP, page_off);
                        uint32_t pageoff = (uint32_t)((uint64_t)obf_va & 0xFFF);
                        uint32_t add_w = 0x91000000u|(pageoff<<10)|(16u<<5)|16u;
                        wr32(new_data+(uint32_t)new_func_fo,   adrp_w);
                        wr32(new_data+(uint32_t)new_func_fo+4, add_w);
                        wr32(new_data+(uint32_t)new_func_fo+8, enc_br(16));
                        wr32(new_data+(uint32_t)new_func_fo+12, NOP);
                        entry_ok=1; start_fill=16;
                        tramp_far++;
                    } else {

                        if(new_func_fo+24<=new_fsize && fsz>=24){
                            wr32(new_data+(uint32_t)new_func_fo,    enc_movz(16,(uint16_t)(obf_va&0xFFFF),0));
                            wr32(new_data+(uint32_t)new_func_fo+4,  enc_movk(16,(uint16_t)((obf_va>>16)&0xFFFF),16));
                            wr32(new_data+(uint32_t)new_func_fo+8,  enc_movk(16,(uint16_t)((obf_va>>32)&0xFFFF),32));
                            wr32(new_data+(uint32_t)new_func_fo+12, enc_movk(16,(uint16_t)((obf_va>>48)&0xFFFF),48));
                            wr32(new_data+(uint32_t)new_func_fo+16, enc_br(16));
                            wr32(new_data+(uint32_t)new_func_fo+20, NOP);
                            entry_ok=1; start_fill=24;
                            tramp_far++;
                        } else {
                            printf("[!] Far trampoline: func too small for MOV64+BR at 0x%llx\n",
                                   (unsigned long long)new_func_va);

                        }
                    }
                } else {
                    printf("[!] Far trampoline: no space for ADRP+BR at 0x%llx (fsz=%u)\n",
                           (unsigned long long)new_func_va, fsz);

                }
            }

            if(!entry_ok) continue;

            {
                uint64_t eng_lo_va = insert_va;
                uint64_t eng_span  = (uint64_t)code_buf.size;
                uint32_t rng = (uint32_t)(new_func_va ^ (0x9E3779B9u ^ 0x4C445651u)); rng |= 1u;
                for(uint32_t k=start_fill;k<fsz;k+=4){
                    if(new_func_fo+k+4>new_fsize) break;
                    rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                    uint32_t sel = rng % 100u;
                    if(sel < 5u){

                        continue;
                    } else if(sel < 34u && eng_span >= 4){

                        rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                        uint64_t tgt = eng_lo_va + (((uint64_t)rng % eng_span) & ~3ull);
                        uint64_t slot_va = new_func_va + k;
                        int64_t disp = ((int64_t)tgt - (int64_t)slot_va) / 4;
                        if(disp >= -0x2000000 && disp <= 0x1FFFFFF){
                            wr32(new_data+(uint32_t)new_func_fo+k, enc_b26((int32_t)disp));
                        } else {
                            rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                            wr32(new_data+(uint32_t)new_func_fo+k, rng);
                        }
                    } else {

                        rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                        wr32(new_data+(uint32_t)new_func_fo+k, rng);
                    }
                }
            }
        }
        if(tramp_far > 0)
            printf("[*] Far trampolines (ADRP+BR or MOV64+BR): %d out of %d\n", tramp_far, tramp_ok+tramp_far);
    }

    if(vm_func_idx >= 0 && vm_stub_code && vm_bc_raw){
        uint64_t vm_func_va = func_vas[vm_func_idx];
        uint64_t new_vm_func_va = vm_func_va + actual_shift;
        uint64_t new_vm_func_fo = di.text_fo + actual_shift + (vm_func_va - di.text_va);
        uint64_t fe2 = func_end_va_reachable(fdata+di.text_fo,di.text_va,di.text_sz,
                        vm_func_va, (vm_func_idx+1<nfuncs)?func_vas[vm_func_idx+1]:di.text_va+di.text_sz);
        uint32_t vm_fsz = (uint32_t)(fe2 - vm_func_va);

        uint64_t vm_stub_va = di.tseg_va + (uint32_t)insert_point + vm_stub_buf_off;
        uint64_t vm_bc_va = di.tseg_va + (uint32_t)insert_point + vm_bc_buf_off;
        uint64_t vm_tramp_va = di.tseg_va + (uint32_t)insert_point + vm_tramp_buf_off;
        uint32_t vm_stub_fo = (uint32_t)insert_point + vm_stub_buf_off;
        uint32_t vm_bc_fo = (uint32_t)insert_point + vm_bc_buf_off;
        uint32_t vm_tramp_fo = (uint32_t)insert_point + vm_tramp_buf_off;

        printf("[*] VM: Stub VA=0x%llx, Bytecode VA=0x%llx, Trampoline VA=0x%llx\n",
               (unsigned long long)vm_stub_va, (unsigned long long)vm_bc_va,
               (unsigned long long)vm_tramp_va);

        int stub_cnt2 = ldvq2306_emit_vm_interpreter_stub(vm_stub_code, 8192,
                                                  vm_bc_va, vm_bc.count, vm_stub_va,
                                                  vm_tramp_va, (uint32_t)vm_n_native_words,
                                                  vm_encrypt, vm_enc_key0, vm_enc_key1);
        if(stub_cnt2 > 0){
            memcpy(new_data + vm_stub_fo, vm_stub_code, (size_t)stub_cnt2 * 4);
            printf("[+] VM: Interpreter stub patched with bytecode @ 0x%llx\n",
                   (unsigned long long)vm_bc_va);
        }

        memcpy(new_data + vm_bc_fo, vm_bc_raw, vm_bc_raw_size);

        {
            int bc_fixed = 0;
            for(uint32_t bi = 0; bi < vm_bc.count; bi++){
                uint32_t boff = vm_bc_fo + 16 + bi * 8;
                if(boff + 8 > new_fsize) break;
                uint8_t op = new_data[boff];

                if(op == VM_OP_LOAD_ABS || op == VM_OP_BL_NATIVE || op == VM_OP_B_ABS){
                    uint8_t hi8 = new_data[boff + 3];
                    uint32_t lo32 = rd32(new_data + boff + 4);
                    uint64_t abs_va = (uint64_t)lo32 | ((uint64_t)hi8 << 32);
                    if(abs_va >= shift_threshold && abs_va < shift_end){
                        abs_va += actual_shift;
                        new_data[boff + 3] = (uint8_t)((abs_va >> 32) & 0xFF);
                        wr32(new_data + boff + 4, (uint32_t)(abs_va & 0xFFFFFFFF));
                        bc_fixed++;
                    }
                }
            }
            printf("[+] VM: Fixed %d absolute addresses in bytecode (shift=0x%llx)\n",
                   bc_fixed, (unsigned long long)actual_shift);
        }

        if(vm_encrypt){
            int bc_enc = 0;
            for(uint32_t bi = 0; bi < vm_bc.count; bi++){
                uint32_t boff = vm_bc_fo + 16 + bi * 8;
                if(boff + 8 > new_fsize) break;
                wr32(new_data + boff,     rd32(new_data + boff)     ^ vm_enc_key0);
                wr32(new_data + boff + 4, rd32(new_data + boff + 4) ^ vm_enc_key1);
                bc_enc++;
            }
            printf("[+] VM: Encrypted %d bytecode instructions (key0=0x%08x key1=0x%08x)\n",
                   bc_enc, vm_enc_key0, vm_enc_key1);
        }

        if(vm_n_native_words > 0 && vm_tramp_fo + vm_n_native_words*8 <= new_fsize){
            for(int ti=0; ti<vm_n_native_words; ti++){
                wr32(new_data + vm_tramp_fo + ti*8, vm_native_words[ti]);
                wr32(new_data + vm_tramp_fo + ti*8 + 4, 0xD65F03C0u);
            }
        }

        if(exec_fo_out && exec_fo_out + 0x100 <= new_fsize){
            wr32(new_data + (uint32_t)exec_fo_out + 0x10, VM_MAGIC);
            wr32(new_data + (uint32_t)exec_fo_out + 0x14, vm_bc.count);
            wr32(new_data + (uint32_t)exec_fo_out + 0x18, (uint32_t)(vm_bc_va & 0xFFFFFFFF));
            wr32(new_data + (uint32_t)exec_fo_out + 0x1C, (uint32_t)(vm_bc_va >> 32));
            wr32(new_data + (uint32_t)exec_fo_out + 0x20, (uint32_t)(vm_stub_va & 0xFFFFFFFF));
            wr32(new_data + (uint32_t)exec_fo_out + 0x24, (uint32_t)(vm_stub_va >> 32));
            printf("[+] VM: Bytecode reference embedded in EXEC header\n");
        }

        int64_t vm_b_off = (int64_t)vm_stub_va - (int64_t)new_vm_func_va;

        int vm_far = !(vm_b_off >= -(1LL<<27) && vm_b_off < (1LL<<27) && (vm_b_off & 3) == 0);
        uint32_t vm_tramp_bytes = 4;
        int vm_entry_branch = 0;
        if(new_vm_func_fo + 4 <= new_fsize){
            if(!vm_far){
                wr32(new_data + (uint32_t)new_vm_func_fo, enc_b26((int32_t)(vm_b_off / 4)));
                vm_entry_branch = 1;
            } else if(vm_fsz >= 12 && new_vm_func_fo + 12 <= new_fsize &&
                      ((((int64_t)(vm_stub_va & ~0xFFFull) - (int64_t)(new_vm_func_va & ~0xFFFull)) / 4096)
                          >= -(1LL<<20) &&
                       (((int64_t)(vm_stub_va & ~0xFFFull) - (int64_t)(new_vm_func_va & ~0xFFFull)) / 4096)
                          <  (1LL<<20))){

                int64_t pd = (int64_t)(vm_stub_va & ~0xFFFull) - (int64_t)(new_vm_func_va & ~0xFFFull);
                int32_t page_delta = (int32_t)(pd / 4096);
                wr32(new_data + (uint32_t)new_vm_func_fo + 0, enc_adrp(16, page_delta));
                wr32(new_data + (uint32_t)new_vm_func_fo + 4, enc_add_i(16, 16, (int)(vm_stub_va & 0xFFF)));
                wr32(new_data + (uint32_t)new_vm_func_fo + 8, enc_br(16));
                vm_tramp_bytes = 12;
                vm_entry_branch = 1;
                printf("[+] VM: slide-safe ADRP far veneer trampoline (disp 0x%llx > +-128MB, B26 cannot reach)\n",
                       (unsigned long long)(uint64_t)(vm_b_off<0?-vm_b_off:vm_b_off));
            } else {

                fprintf(stderr,"[!] VM: trampoline disp 0x%llx out of B26 range and fsz=%u too small for veneer; leaving function native\n",
                        (unsigned long long)(uint64_t)(vm_b_off<0?-vm_b_off:vm_b_off), vm_fsz);
                vm_tramp_bytes = vm_fsz;
            }
            printf("[+] VM: Trampoline installed @ 0x%llx -> VM stub @ 0x%llx\n",
                   (unsigned long long)new_vm_func_va, (unsigned long long)vm_stub_va);
        }

        if(vm_entry_branch){
            uint64_t eng_lo_va = insert_va;
            uint64_t eng_span  = (uint64_t)code_buf.size;
            uint32_t rng = (uint32_t)(new_vm_func_va ^ 0x9E3779B9u); rng |= 1u;
            for(uint32_t k=vm_tramp_bytes; k<vm_fsz; k+=4){
                if(new_vm_func_fo+k+4>new_fsize) break;
                rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                uint32_t sel = rng % 100u;
                if(sel < 5u){
                    continue;
                } else if(sel < 34u && eng_span >= 4){
                    rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                    uint64_t tgt = eng_lo_va + (((uint64_t)rng % eng_span) & ~3ull);
                    uint64_t slot_va = new_vm_func_va + k;
                    int64_t disp = ((int64_t)tgt - (int64_t)slot_va) / 4;
                    if(disp >= -0x2000000 && disp <= 0x1FFFFFF){
                        wr32(new_data+(uint32_t)new_vm_func_fo+k, enc_b26((int32_t)disp));
                    } else {
                        rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                        wr32(new_data+(uint32_t)new_vm_func_fo+k, rng);
                    }
                } else {
                    rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;
                    wr32(new_data+(uint32_t)new_vm_func_fo+k, rng);
                }
            }
        } else {
            for(uint32_t k=vm_tramp_bytes; k<vm_fsz; k+=4){
                if(new_vm_func_fo + k + 4 <= new_fsize)
                    wr32(new_data + (uint32_t)new_vm_func_fo + k, NOP);
            }
        }

        printf("[+] VM: Function protected successfully (bytecode=%u insns, stub=%u insns)\n",
               vm_bc.count, vm_stub_insn_count);

        {
            uint64_t vm_orig_va = func_vas[vm_func_idx];
            uint64_t vm_orig_fo = di.text_fo + (vm_orig_va - di.text_va);
            uint64_t vm_orig_end = func_end_va_reachable(fdata+di.text_fo,di.text_va,di.text_sz,
                        vm_orig_va, (vm_func_idx+1<nfuncs)?func_vas[vm_func_idx+1]:di.text_va+di.text_sz);
            uint32_t vm_orig_sz = (uint32_t)(vm_orig_end - vm_orig_va);
            const char *vm_sym = fentries[vm_func_idx].sym_name;
            printf("[+] VM: Original function offset mapping:\n");
            printf("    %-12s %s\n", "Symbol:", vm_sym ? vm_sym : "(unknown)");
            printf("    %-12s 0x%llx (file offset: 0x%llx)\n", "Orig VA:",
                   (unsigned long long)vm_orig_va, (unsigned long long)vm_orig_fo);
            printf("    %-12s 0x%llx (file offset: 0x%llx)\n", "Orig End:",
                   (unsigned long long)vm_orig_end,
                   (unsigned long long)(vm_orig_fo + vm_orig_sz));
            printf("    %-12s %u bytes (%u instructions)\n", "Orig Size:",
                   vm_orig_sz, vm_orig_sz / 4);
            printf("    %-12s 0x%llx (offset from __TEXT base: 0x%llx)\n", "New VM Stub:",
                   (unsigned long long)vm_stub_va,
                   (unsigned long long)(vm_stub_va - di.tseg_va));
            printf("    %-12s 0x%llx (offset from __TEXT base: 0x%llx)\n", "New Bytecode:",
                   (unsigned long long)vm_bc_va,
                   (unsigned long long)(vm_bc_va - di.tseg_va));
            printf("    %-12s 0x%llx (offset from __TEXT base: 0x%llx)\n", "New Trampoline:",
                   (unsigned long long)vm_tramp_va,
                   (unsigned long long)(vm_tramp_va - di.tseg_va));
            printf("    %-12s 0x%llx -> 0x%llx (shift: 0x%llx)\n", "Entry Remap:",
                   (unsigned long long)vm_orig_va,
                   (unsigned long long)new_vm_func_va,
                   (unsigned long long)actual_shift);
        }
    }

    vm_bc_free(&vm_bc);
    if(vm_stub_code) free(vm_stub_code);
    if(vm_bc_raw) free(vm_bc_raw);
    if(vm_native_words) free(vm_native_words);

    SegLayout layout; memset(&layout,0,sizeof(layout));
    { uint8_t *lcp2=new_data+32; mh64 *nh2=(mh64*)new_data;
      for(uint32_t i=0;i<nh2->ncmds;i++){
          lc_t *lc=(lc_t*)lcp2;
          if(lc->cmd==LC_SEGMENT_64){
              seg64 *seg=(seg64*)lcp2;
              if(layout.nseg<16){ layout.seg_vmaddr[layout.nseg]=seg->vmaddr; layout.seg_fileoff[layout.nseg]=seg->fileoff; layout.seg_filesize[layout.nseg]=seg->filesize; layout.nseg++; }
          }
          lcp2+=lc->cmdsize;
      }
    }
    { uint8_t *lcp2=new_data+32; mh64 *nh2=(mh64*)new_data;
      uint32_t rebase_off2=0,rebase_size2=0,symoff2=0,nsyms2=0;
      for(uint32_t i=0;i<nh2->ncmds;i++){
          lc_t *lc=(lc_t*)lcp2;
          if(lc->cmd==LC_DYLD_INFO_ONLY||lc->cmd==0x22){
              dyldinfo_lc *di2=(dyldinfo_lc*)lcp2; rebase_off2=di2->rebase_off; rebase_size2=di2->rebase_size;
          }
          if(lc->cmd==LC_SYMTAB){ symtab_lc *sc=(symtab_lc*)lcp2; symoff2=sc->symoff; nsyms2=sc->nsyms; }
          lcp2+=lc->cmdsize;
      }
      if(rebase_off2&&rebase_size2&&rebase_off2+rebase_size2<=new_fsize)
          fix_rebase_pointer_values(new_data,new_fsize,new_data+rebase_off2,rebase_size2,&layout,shift_threshold,shift_end,actual_shift);
      if(symoff2&&nsyms2&&symoff2+nsyms2*16<=new_fsize)
          fix_symbol_values(new_data,new_fsize,symoff2,nsyms2,shift_threshold,shift_end,actual_shift);
    }

    fix_lc_function_starts(new_data,&new_fsize,new_fsize+0x100000,actual_shift,di.tseg_va);
    fix_export_trie(new_data,&new_fsize,new_fsize+0x100000,actual_shift);
    fix_chained_fixups(new_data,new_fsize,actual_shift,shift_threshold,shift_end,actual_shift);

    {
        uint8_t *lcp2=new_data+32; mh64 *nh2=(mh64*)new_data;
        for(uint32_t i=0;i<nh2->ncmds;i++){
            lc_t *lc=(lc_t*)lcp2;
            if(lc->cmd==LC_SEGMENT_64){
                seg64 *seg=(seg64*)lcp2;
                uint8_t *sp=lcp2+sizeof(seg64);
                for(uint32_t j=0;j<seg->nsects;j++){
                    sec64 *sect=(sec64*)sp;
                    if((sect->flags & 0xFF) == 0x16 && sect->offset && sect->size > 0){
                        uint32_t n_offsets = (uint32_t)(sect->size / 4);
                        int fixed = 0;
                        for(uint32_t k=0; k<n_offsets; k++){
                            uint32_t fo = sect->offset + k*4;
                            if(fo+4 > new_fsize) break;
                            uint32_t val = rd32(new_data+fo);
                            if(val >= (uint32_t)insert_point && val < (uint32_t)(di.tseg_va + di.tseg_vsz)){
                                wr32(new_data+fo, val + (uint32_t)actual_shift);
                                fixed++;
                            }
                        }
                        if(fixed) printf("[+] Fixed %d offsets in __init_offsets (shift +0x%llx)\n",
                                         fixed, (unsigned long long)actual_shift);
                    }
                    sp+=sizeof(sec64);
                }
            }
            lcp2+=lc->cmdsize;
        }
    }

    if(need_init_hook){
        uint32_t wrapper_stub_fo=(uint32_t)insert_point+wrapper_stub_buf_off;
        uint64_t wrapper_stub_va=di.tseg_va+wrapper_stub_fo;
        uint32_t wrapper_body_fo=(uint32_t)insert_point+wrapper_body_buf_off;
        uint64_t wrapper_body_va=di.tseg_va+wrapper_body_fo;

        uint64_t ctor_body_va = 0;
        uint64_t tp_body_va = 0;

        uint64_t shifted_init = 0;
        if(orig_init_va_0){
            shifted_init = orig_init_va_0;
            if(orig_init_va_0>=shift_threshold&&orig_init_va_0<shift_end)
                shifted_init=orig_init_va_0+actual_shift;
        }

        uint64_t tp_next_va = shifted_init;
        uint64_t ah_next_va = 0;

        if(do_timeprotect){
            uint32_t tp_body_fo=(uint32_t)insert_point+tp_body_buf_off;
            tp_body_va=di.tseg_va+tp_body_fo;
            ah_next_va = tp_body_va;
        } else {
            ah_next_va = shifted_init;
        }

        if(do_antihex){
            uint64_t shifted_text_va=di.text_va+actual_shift;
            uint64_t shifted_text_fo=di.text_fo+actual_shift;
            uint32_t ctor_stub_fo=(uint32_t)insert_point+ctor_stub_buf_off;
            uint32_t ctor_body_fo=(uint32_t)insert_point+ctor_body_buf_off;
            ctor_body_va=di.tseg_va+ctor_body_fo;

            uint32_t text_hash=xhash(new_data+(uint32_t)shifted_text_fo,(uint32_t)di.text_sz);
            printf("[*] text xhash = 0x%08X\n",text_hash);

            wr32(new_data+(uint32_t)exec_fo_out+0,0x41484558u);
            wr32(new_data+(uint32_t)exec_fo_out+4,text_hash);
            wr32(new_data+(uint32_t)exec_fo_out+8,(uint32_t)di.text_sz);
            wr32(new_data+(uint32_t)exec_fo_out+12,(uint32_t)shifted_text_fo);

            uint32_t ctor_obf[8192];
            int ctor_obf_cnt = build_antihex_ctor_obfuscated(
                ctor_obf, 8192,
                exec_va_out, shifted_text_va, (uint32_t)di.text_sz, text_hash,
                ah_next_va);

            if(ctor_obf_cnt >= 0){
                if((uint32_t)ctor_obf_cnt*4 > ctor_body_reserved_bytes)
                    ctor_obf_cnt = (int)(ctor_body_reserved_bytes/4);

                fixup_ctor_obf_branches(ctor_obf, ctor_obf_cnt, ctor_body_va);

                for(uint32_t pp=0; pp<ctor_body_reserved_bytes; pp+=4)
                    wr32(new_data+ctor_body_fo+pp, NOP);
                memcpy(new_data+ctor_body_fo, ctor_obf, (size_t)ctor_obf_cnt*4);

                uint64_t ctor_stub_va=di.tseg_va+ctor_stub_fo;
                int32_t ctor_stub_b=(int32_t)(((int64_t)ctor_body_va-(int64_t)ctor_stub_va)/4);
                wr32(new_data+ctor_stub_fo, enc_b26(ctor_stub_b));

                printf("[+] Anti-hex: CFF+BCF+indirect obfuscated (%d insns, %d bytes)\n",
                       ctor_obf_cnt, ctor_obf_cnt*4);
            } else {
                printf("[!] Anti-hex obfuscated build failed, falling back to raw\n");

                uint32_t ctor_raw[2048];
                int ctor_raw_cnt=ldvq2306_build_antihex_ctor_raw(ctor_raw,2048,exec_va_out,shifted_text_va,(uint32_t)di.text_sz,text_hash);
                if(ctor_raw_cnt>=0){
                    if((uint32_t)ctor_raw_cnt*4>ctor_body_reserved_bytes) ctor_raw_cnt=(int)(ctor_body_reserved_bytes/4);
                    memset(new_data+ctor_body_fo,0,ctor_body_reserved_bytes);
                    memcpy(new_data+ctor_body_fo,ctor_raw,(size_t)ctor_raw_cnt*4);
                    uint64_t ctor_stub_va=di.tseg_va+ctor_stub_fo;
                    int32_t ctor_stub_b=(int32_t)(((int64_t)ctor_body_va-(int64_t)ctor_stub_va)/4);
                    wr32(new_data+ctor_stub_fo, enc_b26(ctor_stub_b));

                    if(ah_next_va){
                        for(int scan=(int)ctor_body_reserved_bytes/4-1;scan>=0;scan--){
                            uint32_t w=rd32(new_data+ctor_body_fo+(uint32_t)scan*4);
                            if(w==enc_ret()){
                                int64_t b_off=(int64_t)ah_next_va-(int64_t)(ctor_body_va+(uint64_t)scan*4);
                                int32_t b_imm=(int32_t)(b_off/4);
                                if(b_imm>=-0x2000000&&b_imm<=0x1FFFFFF)
                                    wr32(new_data+ctor_body_fo+(uint32_t)scan*4,enc_b26(b_imm));
                                else if((uint32_t)(scan+7)*4<=ctor_body_reserved_bytes)

                                    write_slidesafe_branch(new_data,ctor_body_fo+(uint32_t)scan*4,
                                                           ctor_body_va+(uint64_t)scan*4,ah_next_va);
                                break;
                            }
                        }
                    }
                    printf("[+] Anti-hex: raw fallback injected (%d insns)\n", ctor_raw_cnt);
                }
            }
        }

        if(do_timeprotect){
            uint64_t deadline_epoch = (uint64_t)time(NULL) + (uint64_t)expire_days * 86400;
            uint32_t tp_stub_fo=(uint32_t)insert_point+tp_stub_buf_off;
            uint32_t tp_body_fo=(uint32_t)insert_point+tp_body_buf_off;
            tp_body_va=di.tseg_va+tp_body_fo;

            uint32_t tp_obf[8192];
            int tp_obf_cnt = build_timeprotect_obfuscated(
                tp_obf, 8192,
                deadline_epoch,
                tp_next_va);

            if(tp_obf_cnt >= 0){
                if((uint32_t)tp_obf_cnt*4 > tp_body_reserved_bytes)
                    tp_obf_cnt = (int)(tp_body_reserved_bytes/4);

                fixup_ctor_obf_branches(tp_obf, tp_obf_cnt, tp_body_va);

                for(uint32_t pp=0; pp<tp_body_reserved_bytes; pp+=4)
                    wr32(new_data+tp_body_fo+pp, NOP);
                memcpy(new_data+tp_body_fo, tp_obf, (size_t)tp_obf_cnt*4);

                uint64_t tp_stub_va=di.tseg_va+tp_stub_fo;
                int32_t tp_stub_b=(int32_t)(((int64_t)tp_body_va-(int64_t)tp_stub_va)/4);
                wr32(new_data+tp_stub_fo, enc_b26(tp_stub_b));

                printf("[+] Time-protect: CFF+BCF+indirect obfuscated (%d insns), deadline=%llu, expires in %d days\n",
                       tp_obf_cnt, (unsigned long long)deadline_epoch, expire_days);
            } else {
                printf("[!] Time-protect obfuscated build failed, falling back to raw\n");
                uint32_t tp_raw[2048];
                int tp_raw_cnt = ldvq2306_build_timeprotect_raw(tp_raw, 2048, deadline_epoch);
                if(tp_raw_cnt>=0){
                    if((uint32_t)tp_raw_cnt*4>tp_body_reserved_bytes) tp_raw_cnt=(int)(tp_body_reserved_bytes/4);
                    memset(new_data+tp_body_fo,0,tp_body_reserved_bytes);
                    memcpy(new_data+tp_body_fo,tp_raw,(size_t)tp_raw_cnt*4);
                    uint64_t tp_stub_va=di.tseg_va+tp_stub_fo;
                    int32_t tp_stub_b=(int32_t)(((int64_t)tp_body_va-(int64_t)tp_stub_va)/4);
                    wr32(new_data+tp_stub_fo, enc_b26(tp_stub_b));
                    if(tp_next_va){
                        for(int scan=(int)tp_body_reserved_bytes/4-1;scan>=0;scan--){
                            uint32_t w=rd32(new_data+tp_body_fo+(uint32_t)scan*4);
                            if(w==enc_ret()){
                                int64_t b_off=(int64_t)tp_next_va-(int64_t)(tp_body_va+(uint64_t)scan*4);
                                int32_t b_imm=(int32_t)(b_off/4);
                                if(b_imm>=-0x2000000&&b_imm<=0x1FFFFFF)
                                    wr32(new_data+tp_body_fo+(uint32_t)scan*4,enc_b26(b_imm));
                                else if((uint32_t)(scan+7)*4<=tp_body_reserved_bytes)

                                    write_slidesafe_branch(new_data,tp_body_fo+(uint32_t)scan*4,
                                                           tp_body_va+(uint64_t)scan*4,tp_next_va);
                                break;
                            }
                        }
                    }
                    printf("[+] Time-protect: raw fallback (%d insns), deadline=%llu\n",
                           tp_raw_cnt, (unsigned long long)deadline_epoch);
                }
            }
        }

        uint64_t first_target = 0;
        if(do_antihex && ctor_body_va)
            first_target = ctor_body_va;
        else if(do_timeprotect && tp_body_va)
            first_target = tp_body_va;
        else if(shifted_init)
            first_target = shifted_init;

        {
            uint32_t wrapper_obf[512];
            int wrapper_cnt = build_init_wrapper_obfuscated(
                wrapper_obf, 512,
                wrapper_body_va,
                do_antihex ? ctor_body_va : 0,
                do_timeprotect ? tp_body_va : 0,
                shifted_init);

            if(wrapper_cnt >= 0){
                if((uint32_t)wrapper_cnt*4 > wrapper_body_reserved_bytes)
                    wrapper_cnt = (int)(wrapper_body_reserved_bytes/4);

                fixup_ctor_obf_branches(wrapper_obf, wrapper_cnt, wrapper_body_va);

                for(uint32_t pp=0; pp<wrapper_body_reserved_bytes; pp+=4)
                    wr32(new_data+wrapper_body_fo+pp, NOP);
                memcpy(new_data+wrapper_body_fo, wrapper_obf, (size_t)wrapper_cnt*4);
            } else {

                uint32_t wrapper_raw[128]; int wn=0;
                wrapper_raw[wn++]=enc_stp_pre(29,30,31,(int)(-2u&0x7F));
                wrapper_raw[wn++]=enc_mov_x(29,31);
                wrapper_raw[wn++]=enc_ldp_post(29,30,31,2);
                if(first_target){

                    uint64_t anchor_va = wrapper_body_va + (uint64_t)(wn+4)*4;
                    uint64_t d = (uint64_t)((int64_t)first_target - (int64_t)anchor_va);
                    wrapper_raw[wn++]=enc_movz(16,(uint16_t)(d&0xFFFF),0);
                    wrapper_raw[wn++]=enc_movk(16,(uint16_t)((d>>16)&0xFFFF),16);
                    wrapper_raw[wn++]=enc_movk(16,(uint16_t)((d>>32)&0xFFFF),32);
                    wrapper_raw[wn++]=enc_movk(16,(uint16_t)((d>>48)&0xFFFF),48);
                    wrapper_raw[wn++]=enc_adr(17,0);
                    wrapper_raw[wn++]=enc_add_r(16,16,17);
                    wrapper_raw[wn++]=enc_br(16);
                } else {
                    wrapper_raw[wn++]=enc_ret();
                }
                wrapper_cnt = wn;
                memset(new_data+wrapper_body_fo, 0, wrapper_body_reserved_bytes);
                memcpy(new_data+wrapper_body_fo, wrapper_raw, (size_t)wn*4);
            }

            int32_t wrapper_stub_b=(int32_t)(((int64_t)wrapper_body_va-(int64_t)wrapper_stub_va)/4);
            wr32(new_data+wrapper_stub_fo, enc_b26(wrapper_stub_b));

            printf("[+] Wrapper: %d insns (CFF+BCF+indirect), chain: wrapper -> %s%s%s\n",
                   wrapper_cnt,
                   do_antihex ? "antihex -> " : "",
                   do_timeprotect ? "timeprotect -> " : "",
                   shifted_init ? "orig_init" : "RET");
        }

        if(di.mod_init_fo&&di.mod_init_sz>=8){
            uint32_t new_mod_init_fo=(uint32_t)(di.mod_init_fo+actual_shift);
            if(new_mod_init_fo+8<=new_fsize){
                wr64(new_data+new_mod_init_fo,wrapper_stub_va);
                printf("[+] mod_init_func[0] -> wrapper @ 0x%llx\n",(unsigned long long)wrapper_stub_va);
                for(int ii=1;ii<n_init_funcs;ii++){
                    uint64_t ival=rd64(fdata+(uint32_t)di.mod_init_fo+ii*8);
                    if(ival>=shift_threshold&&ival<shift_end) ival+=actual_shift;
                    if(new_mod_init_fo+(uint32_t)(ii+1)*8<=new_fsize)
                        wr64(new_data+new_mod_init_fo+ii*8,ival);
                }
                printf("[*] Fixed %d mod_init_func entries total\n",n_init_funcs);
            }
        } else {
            printf("[!] No mod_init_func found\n");
        }
    }

    { uint8_t *pp2=new_data+32; mh64 *nh=(mh64*)new_data;
      for(uint32_t i=0;i<nh->ncmds;i++){
          lc_t *cmd=(lc_t*)pp2;
          if(cmd->cmd==LC_CODE_SIGNATURE){
              linkedit_lc *ll=(linkedit_lc*)pp2;
              if(ll->dataoff&&ll->datasize&&ll->dataoff+ll->datasize<=new_fsize)
                  memset(new_data+ll->dataoff,0,ll->datasize);
              break;
          }
          pp2+=cmd->cmdsize;
      }
    }

    if(!save_file(output_path,new_data,new_fsize)){
        fprintf(stderr,"[!] save failed\n");
        free(fdata); free(new_data); buf_free(&code_buf); free(fmap); free(func_vas); free(fentries); extpc_free(); return 1;
    }
    printf("[*] Saved %u bytes -> %s\n",new_fsize,output_path);

#ifdef _WIN32
    if(getenv("DYLIB_PROTECT_NOSIGN")){
        printf("[*] DYLIB_PROTECT_NOSIGN set - skipping signature\n");
    } else if(sign_file_adhoc(output_path)==0){
        printf("[+] ad-hoc signed (native)\n");
    } else {
        printf("[!] native sign failed\n");
    }
#else
    char cmd[1024];
    snprintf(cmd,sizeof(cmd),"ldid -S \"%s\" 2>/dev/null",output_path);
    if(system(cmd)!=0){
        snprintf(cmd,sizeof(cmd),"codesign -f -s - \"%s\" 2>/dev/null",output_path);
        if(system(cmd)!=0) printf("[!] codesign failed - sign manually\n");
        else printf("[+] codesign ok\n");
    } else printf("[+] ldid ok\n");
#endif

    free(fdata); free(new_data); buf_free(&code_buf); free(fmap); free(func_vas); free(fentries); extpc_free();
    return 0;
}
