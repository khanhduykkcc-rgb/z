#include "buf.h"

void buf_init(Buf *b){ b->data=NULL; b->size=0; b->cap=0; }

void buf_reserve(Buf *b, uint32_t extra){

    uint64_t need = (uint64_t)b->size + (uint64_t)extra;
    if(need > 0xFFFFFFFFull){
        fprintf(stderr,"[FATAL] buf_reserve: required size %llu bytes exceeds the "
                "4GB single-buffer limit (file too large for 32-bit offsets)\n",
                (unsigned long long)need);
        exit(1);
    }
    if(need <= (uint64_t)b->cap) return;
    uint64_t newcap = b->cap ? (uint64_t)b->cap : 131072ull;
    while(newcap < need) newcap *= 2;
    if(newcap > 0xFFFFFFFFull) newcap = 0xFFFFFFFFull;
    uint8_t *nd = (uint8_t*)realloc(b->data,(size_t)newcap);
    if(!nd){
        fprintf(stderr,"[FATAL] buf_reserve: realloc of %llu bytes failed\n",
                (unsigned long long)newcap);
        exit(1);
    }
    b->data=nd; b->cap=(uint32_t)newcap;
}

void buf_push(Buf *b, const void *src, uint32_t n){
    buf_reserve(b,n); memcpy(b->data+b->size,src,n); b->size+=n;
}

void buf_u8(Buf *b, uint8_t v){ buf_push(b,&v,1); }
void buf_u32(Buf *b, uint32_t v){ buf_push(b,&v,4); }

void buf_free(Buf *b){ free(b->data); b->data=NULL; b->size=b->cap=0; }

void buf_pad16(Buf *b){ while(b->size&15) buf_u8(b,0); }
