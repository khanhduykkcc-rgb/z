#include "util.h"

uint8_t *load_file(const char *path, uint32_t *out_sz){
    FILE *f=fopen(path,"rb"); if(!f){perror(path);return NULL;}
    fseek(f,0,SEEK_END); long l=ftell(f); fseek(f,0,SEEK_SET);
    if(l <= 0 || l > 0xFFFFFFFFLL){
        fprintf(stderr,"[!] File too large or empty: %s (%ld bytes)\n",path,l);
        fclose(f); return NULL;
    }
    size_t alloc=(size_t)l*6+0x1000000;
    uint8_t *d=(uint8_t*)malloc(alloc);
    if(!d){fclose(f);return NULL;}
    memset(d,0,alloc);
    if(fread(d,1,(size_t)l,f)!=(size_t)l){fclose(f);free(d);return NULL;}
    fclose(f); *out_sz=(uint32_t)l; return d;
}

bool save_file(const char *path,const uint8_t *d,uint32_t sz){
    FILE *f=fopen(path,"wb"); if(!f){perror(path);return false;}
    fwrite(d,1,sz,f); fclose(f); return true;
}

uint32_t xhash(const uint8_t *d, uint32_t sz){
    uint32_t h=0x55AA55AA;
    for(uint32_t i=0;i+4<=sz;i+=4){ h^=rd32(d+i); h=(h>>7)|(h<<25); }
    return h;
}

uint64_t read_uleb128(const uint8_t **pp, const uint8_t *end){
    uint64_t result=0; int shift=0;
    while(*pp<end){ uint8_t byte=*(*pp)++; result|=((uint64_t)(byte&0x7F))<<shift; if(!(byte&0x80))break; shift+=7; }
    return result;
}

void encode_uleb128(uint8_t *buf, uint32_t *pos, uint64_t val){
    do{ uint8_t byte=(uint8_t)(val&0x7F); val>>=7; if(val)byte|=0x80; buf[(*pos)++]=byte; }while(val);
}

uint64_t decode_uleb128(const uint8_t *buf, uint32_t *pos, uint32_t end){
    uint64_t result=0; int shift=0;
    while(*pos<end){ uint8_t byte=buf[(*pos)++]; result|=((uint64_t)(byte&0x7F))<<shift; if(!(byte&0x80))break; shift+=7; }
    return result;
}
