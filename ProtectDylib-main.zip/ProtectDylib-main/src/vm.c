
#include "vm.h"
#include "pcrel.h"
#include "arm64_enc.h"
#include "util.h"
#include <capstone/capstone.h>

static int reg_is_unsafe_for_native(unsigned id){
    switch(id){
        case ARM64_REG_X9:  case ARM64_REG_W9:
        case ARM64_REG_X18: case ARM64_REG_W18:
        case ARM64_REG_X19: case ARM64_REG_W19:
        case ARM64_REG_X20: case ARM64_REG_W20:
        case ARM64_REG_X21: case ARM64_REG_W21:
        case ARM64_REG_X22: case ARM64_REG_W22:
        case ARM64_REG_X23: case ARM64_REG_W23:
        case ARM64_REG_X24: case ARM64_REG_W24:
        case ARM64_REG_X25: case ARM64_REG_W25:
        case ARM64_REG_X26: case ARM64_REG_W26:
        case ARM64_REG_X27: case ARM64_REG_W27:
        case ARM64_REG_X28: case ARM64_REG_W28:
        case ARM64_REG_X29: case ARM64_REG_W29:
        case ARM64_REG_X30: case ARM64_REG_W30:
            return 1;
        default:
            return 0;
    }
}

static int native_touches_unsafe_reg(uint32_t w){
    static csh s_cs = 0;
    static int  s_cs_ok = -1;
    if(s_cs_ok < 0){
        s_cs_ok = (cs_open(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN, &s_cs)==CS_ERR_OK) ? 1 : 0;
        if(s_cs_ok) cs_option(s_cs, CS_OPT_DETAIL, CS_OPT_ON);
    }
    if(!s_cs_ok) return 0;
    cs_insn *insn=NULL;
    size_t cnt=cs_disasm(s_cs,(const uint8_t*)&w,4,0x1000,1,&insn);
    if(cnt==0) return 1;
    int unsafe=0;
    cs_detail *d=insn[0].detail;
    if(d){
        for(uint8_t r=0;r<d->regs_read_count && !unsafe;r++)
            if(reg_is_unsafe_for_native(d->regs_read[r])) unsafe=1;
        for(uint8_t r=0;r<d->regs_write_count && !unsafe;r++)
            if(reg_is_unsafe_for_native(d->regs_write[r])) unsafe=1;
        cs_arm64 *a=&d->arm64;
        for(int oi=0; oi<a->op_count && !unsafe; oi++){
            cs_arm64_op *op=&a->operands[oi];
            if(op->type==ARM64_OP_REG){
                if(reg_is_unsafe_for_native(op->reg)) unsafe=1;
            } else if(op->type==ARM64_OP_MEM){
                if(op->mem.base!=ARM64_REG_INVALID && reg_is_unsafe_for_native(op->mem.base)) unsafe=1;
                if(op->mem.index!=ARM64_REG_INVALID && reg_is_unsafe_for_native(op->mem.index)) unsafe=1;
            }
        }
    } else {
        unsafe=1;
    }
    cs_free(insn,cnt);
    return unsafe;
}

void vm_bc_init(VmBytecode *bc){
    bc->cap=4096; bc->count=0;
    bc->insns=(vm_insn_t*)calloc(bc->cap,sizeof(vm_insn_t));
}

void vm_bc_free(VmBytecode *bc){ free(bc->insns); bc->insns=NULL; bc->count=bc->cap=0; }

void vm_bc_emit(VmBytecode *bc, uint8_t op, uint8_t rd, uint8_t rn, uint8_t rm, uint32_t imm){
    if(bc->count>=bc->cap){ bc->cap*=2; bc->insns=(vm_insn_t*)realloc(bc->insns,bc->cap*sizeof(vm_insn_t)); }
    vm_insn_t *vi=&bc->insns[bc->count++];
    vi->opcode=op; vi->rd=rd; vi->rn=rn; vi->rm=rm; vi->imm=imm;
}

uint32_t vm_bc_serialize(const VmBytecode *bc, uint8_t *out, uint32_t max_sz){
    uint32_t needed=bc->count*8+16;
    if(needed>max_sz) return 0;
    wr32(out+0, VM_MAGIC);
    wr32(out+4, bc->count);
    wr32(out+8, 0);
    wr32(out+12, 0);
    for(uint32_t i=0;i<bc->count;i++){
        uint32_t off=16+i*8;
        const vm_insn_t *vi=&bc->insns[i];
        out[off+0]=vi->opcode;
        out[off+1]=vi->rd;
        out[off+2]=vi->rn;
        out[off+3]=vi->rm;
        wr32(out+off+4, vi->imm);
    }
    return needed;
}

bool ldvq2306_translate_arm64_to_vm_ex(const uint32_t *insns, uint32_t insn_count,
                                   uint64_t func_va, uint64_t text_va, uint64_t text_sz,
                                   VmBytecode *bc,
                                   uint64_t *ext_call_targets, int *n_ext_calls, int max_ext,
                                   uint32_t *native_words, int *n_native_words, int max_native,
                                   int *out_insn_to_vm)
{
    (void)text_va; (void)text_sz;
    int *insn_to_vm = (int*)calloc(insn_count+1, sizeof(int));
    if(!insn_to_vm) return false;

    #define EMIT_NATIVE(w_val) do { \
        uint32_t _wv = (uint32_t)(w_val); \
        if(native_touches_unsafe_reg(_wv)) { VM_REJECT(); } \
        if(*n_native_words < max_native) { \
            uint32_t _tidx = (uint32_t)*n_native_words; \
            native_words[(*n_native_words)++] = _wv; \
            vm_bc_emit(bc, VM_OP_NATIVE, 0, 0, 0, _tidx); \
        } else { \
            VM_REJECT(); \
        } \
    } while(0)

    #define VM_REJECT() do { free(insn_to_vm); return false; } while(0)

    for(uint32_t i=0;i<insn_count;i++){
        insn_to_vm[i]=(int)bc->count;
        uint32_t w=insns[i];

        if(w==NOP){ vm_bc_emit(bc,VM_OP_NOP,0,0,0,0); continue; }

        if(w==0xD65F03C0u){ vm_bc_emit(bc,VM_OP_RET,0,0,0,0); continue; }

        if((w&0xFFE0001Fu)==0xD4200000u){ vm_bc_emit(bc,VM_OP_HALT,0,0,0,w); continue; }

        if((w&0xFFE0FFE0u)==0xAA0003E0u){
            int rd=(int)(w&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_MOV_REG,(uint8_t)rd,(uint8_t)rm,0,0); continue;
        }

        if((w&0xFF800000u)==0xD2800000u){
            int rd=(int)(w&0x1F);
            uint32_t imm16=(w>>5)&0xFFFF;
            int hw=(int)((w>>21)&3);
            uint64_t val=(uint64_t)imm16<<(hw*16);
            vm_bc_emit(bc,VM_OP_MOV_IMM32,(uint8_t)rd,0,0,(uint32_t)(val&0xFFFFFFFF));
            if(val>>32) vm_bc_emit(bc,VM_OP_MOVK_HI,(uint8_t)rd,0,0,(uint32_t)(val>>32));
            continue;
        }
        if((w&0xFF800000u)==0x52800000u){
            int rd=(int)(w&0x1F);
            uint32_t imm16=(w>>5)&0xFFFF;
            int hw=(int)((w>>21)&3);
            uint32_t val=imm16<<(hw*16);
            vm_bc_emit(bc,VM_OP_MOV_IMM32,(uint8_t)rd,0,0,val);
            continue;
        }

        if((w&0xFF800000u)==0xF2800000u){
            int rd=(int)(w&0x1F);
            int hw=(int)((w>>21)&3);
            uint32_t imm16=(w>>5)&0xFFFFu;
            vm_bc_emit(bc,VM_OP_MOVK_X16,(uint8_t)rd,0,(uint8_t)hw,(uint32_t)imm16);
            continue;
        }
        if((w&0xFF800000u)==0x72800000u){
            int rd=(int)(w&0x1F);
            int hw=(int)((w>>21)&3);
            uint32_t imm16=(w>>5)&0xFFFFu;
            vm_bc_emit(bc,VM_OP_MOVK_W16,(uint8_t)rd,0,(uint8_t)hw,(uint32_t)imm16);
            continue;
        }

        if((w&0xFFE00000u)==0x8B000000u && ((w>>22)&3)==0){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_ADD_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }

        if((w&0xFF800000u)==0x91000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            int sh=(int)((w>>22)&1);
            if(sh) imm12<<=12;
            vm_bc_emit(bc,VM_OP_ADD_IMM,(uint8_t)rd,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFE00000u)==0xCB000000u && ((w>>22)&3)==0){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_SUB_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }

        if((w&0xFF800000u)==0xD1000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            int sh=(int)((w>>22)&1);
            if(sh) imm12<<=12;
            vm_bc_emit(bc,VM_OP_SUB_IMM,(uint8_t)rd,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFE00000u)==0x8A000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_AND_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }
        if((w&0xFFE00000u)==0xAA000000u && ((w>>5)&0x1F)!=31){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_ORR_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }
        if((w&0xFFE00000u)==0xCA000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_EOR_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }

        if((w&0xFFE08000u)==0x9B000000u && ((w>>10)&0x1F)==31){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_MUL_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }

        if((w&0xFFE00000u)==0xEB000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            if(rd==31) vm_bc_emit(bc,VM_OP_CMP_REG,31,(uint8_t)rn,(uint8_t)rm,0);
            else vm_bc_emit(bc,VM_OP_SUBS_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0);
            continue;
        }

        if((w&0xFFE00000u)==0x6B000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            if(rd==31) vm_bc_emit(bc,VM_OP_CMP_REG,31,(uint8_t)rn,(uint8_t)rm,1);
            else vm_bc_emit(bc,VM_OP_SUBS_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1);
            continue;
        }

        if((w&0xFFC00000u)==0xF1000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            if(rd==31) vm_bc_emit(bc,VM_OP_CMP_IMM,31,(uint8_t)rn,0,imm12);
            else vm_bc_emit(bc,VM_OP_SUBS_IMM,(uint8_t)rd,(uint8_t)rn,0,imm12);
            continue;
        }
        if((w&0xFFC00000u)==0x71000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            if(rd==31) vm_bc_emit(bc,VM_OP_CMP_IMM,31,(uint8_t)rn,1,imm12);
            else vm_bc_emit(bc,VM_OP_SUBS_IMM,(uint8_t)rd,(uint8_t)rn,1,imm12);
            continue;
        }

        if((w&0xFFC00000u)==0xF9400000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*8;
            vm_bc_emit(bc,VM_OP_LDR64,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }
        if((w&0xFFC00000u)==0xB9400000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*4;
            vm_bc_emit(bc,VM_OP_LDR32,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }
        if((w&0xFFC00000u)==0xF9000000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*8;
            vm_bc_emit(bc,VM_OP_STR64,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }
        if((w&0xFFC00C00u)==0xF8400000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm9=(int32_t)((w>>12)&0x1FF);
            if(imm9&0x100) imm9|=(int32_t)0xFFFFFF00;
            vm_bc_emit(bc,VM_OP_LDR64,(uint8_t)rt,(uint8_t)rn,0,(uint32_t)imm9); continue;
        }
        if((w&0xFFC00C00u)==0xF8000000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm9=(int32_t)((w>>12)&0x1FF);
            if(imm9&0x100) imm9|=(int32_t)0xFFFFFF00;
            vm_bc_emit(bc,VM_OP_STR64,(uint8_t)rt,(uint8_t)rn,0,(uint32_t)imm9); continue;
        }
        if((w&0xFFE00C00u)==0xF8600800u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint32_t S_bit=(w>>12)&1;
            vm_bc_emit(bc,VM_OP_LDR_REG,(uint8_t)rt,(uint8_t)rn,(uint8_t)rm, S_bit ? 3 : 0); continue;
        }
        if((w&0xFFE00C00u)==0xF8200800u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint32_t S_bit=(w>>12)&1;
            vm_bc_emit(bc,VM_OP_STR_REG,(uint8_t)rt,(uint8_t)rn,(uint8_t)rm, S_bit ? 3 : 0); continue;
        }
        if((w&0xFFC00000u)==0xB9000000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*4;
            vm_bc_emit(bc,VM_OP_STR32,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFC00000u)==0x39400000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            vm_bc_emit(bc,VM_OP_LDRB,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFC00000u)==0x39000000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            vm_bc_emit(bc,VM_OP_STRB,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFC00000u)==0x79400000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*2;
            vm_bc_emit(bc,VM_OP_LDRH,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFC00000u)==0x79000000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*2;
            vm_bc_emit(bc,VM_OP_STRH,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFC00000u)==0xB9800000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*4;
            vm_bc_emit(bc,VM_OP_LDRSW,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        {
            uint32_t top = w & 0xFFE00000u;
            int is_wb  = (int)((w>>10)&1);
            int is_pre = (int)((w>>11)&1);
            uint8_t mop=0; int matched=1;
            switch(top){
                case 0xF8400000u: mop=VM_OP_LDR64; break;
                case 0xF8000000u: mop=VM_OP_STR64; break;
                case 0xB8400000u: mop=VM_OP_LDR32; break;
                case 0xB8000000u: mop=VM_OP_STR32; break;
                case 0x78400000u: mop=VM_OP_LDRH;  break;
                case 0x78000000u: mop=VM_OP_STRH;  break;
                case 0x38400000u: mop=VM_OP_LDRB;  break;
                case 0x38000000u: mop=VM_OP_STRB;  break;
                default: matched=0; break;
            }
            if(matched && is_wb){
                int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
                int32_t imm9=(int32_t)((w>>12)&0x1FF);
                if(imm9&0x100) imm9|=(int32_t)0xFFFFFF00;
                if(rt!=31){
                    uint8_t  aop = (imm9<0)?VM_OP_SUB_IMM:VM_OP_ADD_IMM;
                    uint32_t mag = (uint32_t)(imm9<0 ? -imm9 : imm9);
                    if(is_pre){
                        vm_bc_emit(bc,aop,(uint8_t)rn,(uint8_t)rn,0,mag);
                        vm_bc_emit(bc,mop,(uint8_t)rt,(uint8_t)rn,0,0);
                    } else {
                        vm_bc_emit(bc,mop,(uint8_t)rt,(uint8_t)rn,0,0);
                        vm_bc_emit(bc,aop,(uint8_t)rn,(uint8_t)rn,0,mag);
                    }
                    continue;
                }
            }
        }

        if((w&0xFFC00000u)==0xA9800000u){
            int rt=(int)(w&0x1F), rt2=(int)((w>>10)&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm7=(int32_t)((w>>15)&0x7F);
            if(imm7&0x40) imm7|=(int32_t)0xFFFFFF80;
            vm_bc_emit(bc,VM_OP_STP_PRE,(uint8_t)rt,(uint8_t)rn,(uint8_t)rt2,(uint32_t)(imm7*8)); continue;
        }
        if((w&0xFFC00000u)==0xA8C00000u){
            int rt=(int)(w&0x1F), rt2=(int)((w>>10)&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm7=(int32_t)((w>>15)&0x7F);
            if(imm7&0x40) imm7|=(int32_t)0xFFFFFF80;
            vm_bc_emit(bc,VM_OP_LDP_POST,(uint8_t)rt,(uint8_t)rn,(uint8_t)rt2,(uint32_t)(imm7*8)); continue;
        }
        if((w&0xFFC00000u)==0xA9000000u){
            int rt=(int)(w&0x1F), rt2=(int)((w>>10)&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm7=(int32_t)((w>>15)&0x7F);
            if(imm7&0x40) imm7|=(int32_t)0xFFFFFF80;
            vm_bc_emit(bc,VM_OP_STP,(uint8_t)rt,(uint8_t)rn,(uint8_t)rt2,(uint32_t)(imm7*8)); continue;
        }
        if((w&0xFFC00000u)==0xA9400000u){
            int rt=(int)(w&0x1F), rt2=(int)((w>>10)&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm7=(int32_t)((w>>15)&0x7F);
            if(imm7&0x40) imm7|=(int32_t)0xFFFFFF80;
            vm_bc_emit(bc,VM_OP_LDP,(uint8_t)rt,(uint8_t)rn,(uint8_t)rt2,(uint32_t)(imm7*8)); continue;
        }

        if((w&0xFC000000u)==0x14000000u){
            int32_t off26=(int32_t)(w&0x3FFFFFFu);
            if(off26&0x2000000) off26|=(int32_t)0xFC000000;
            int64_t tgt_va=(int64_t)(func_va+(uint64_t)i*4)+(int64_t)off26*4;
            int64_t tgt_idx=((int64_t)tgt_va-(int64_t)func_va)/4;
            if(tgt_idx>=0 && (uint64_t)tgt_idx<insn_count){
                vm_bc_emit(bc,VM_OP_B,0,0,0,(uint32_t)tgt_idx);
            } else {

                uint64_t tv=(uint64_t)tgt_va;
                if(tv>>40){ VM_REJECT(); }
                vm_bc_emit(bc,VM_OP_B_ABS,0,0,(uint8_t)((tv>>32)&0xFF),(uint32_t)(tv&0xFFFFFFFFu));
            }
            continue;
        }

        if((w&0xFC000000u)==0x94000000u){
            int32_t off26=(int32_t)(w&0x3FFFFFFu);
            if(off26&0x2000000) off26|=(int32_t)0xFC000000;
            uint64_t tgt_va=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+(int64_t)off26*4);
            if(*n_ext_calls<max_ext){
                ext_call_targets[*n_ext_calls]=tgt_va;
                (*n_ext_calls)++;
            }
            vm_bc_emit(bc,VM_OP_BL_NATIVE,0,0,(uint8_t)((tgt_va>>32)&0xFF),(uint32_t)(tgt_va&0xFFFFFFFFu));
            continue;
        }

        if((w&0xFF000010u)==0x54000000u){
            uint8_t cond=(uint8_t)(w&0xF);
            int32_t off19=(int32_t)((w>>5)&0x7FFFFu);
            if(off19&0x40000) off19|=(int32_t)0xFFF80000;
            int64_t tgt_va=(int64_t)(func_va+(uint64_t)i*4)+(int64_t)off19*4;
            int64_t tgt_idx=((int64_t)tgt_va-(int64_t)func_va)/4;
            if(tgt_idx>=0 && (uint64_t)tgt_idx<insn_count){
                vm_bc_emit(bc,VM_OP_B_COND,cond,0,0,(uint32_t)tgt_idx);
            } else {

                VM_REJECT();
            }
            continue;
        }

        if((w&0xFF000000u)==0xB4000000u || (w&0xFF000000u)==0xB5000000u){
            int rt=(int)(w&0x1F);
            bool is_nz=((w&0xFF000000u)==0xB5000000u);
            int32_t off19=(int32_t)((w>>5)&0x7FFFFu);
            if(off19&0x40000) off19|=(int32_t)0xFFF80000;
            int64_t tgt_va=(int64_t)(func_va+(uint64_t)i*4)+(int64_t)off19*4;
            int64_t tgt_idx=((int64_t)tgt_va-(int64_t)func_va)/4;
            if(tgt_idx>=0 && (uint64_t)tgt_idx<insn_count){
                vm_bc_emit(bc,is_nz?VM_OP_CBNZ:VM_OP_CBZ,0,(uint8_t)rt,0,(uint32_t)tgt_idx);
            } else {

                VM_REJECT();
            }
            continue;
        }
        if((w&0xFF000000u)==0x34000000u || (w&0xFF000000u)==0x35000000u){
            int rt=(int)(w&0x1F);
            bool is_nz=((w&0xFF000000u)==0x35000000u);
            int32_t off19=(int32_t)((w>>5)&0x7FFFFu);
            if(off19&0x40000) off19|=(int32_t)0xFFF80000;
            int64_t tgt_va=(int64_t)(func_va+(uint64_t)i*4)+(int64_t)off19*4;
            int64_t tgt_idx=((int64_t)tgt_va-(int64_t)func_va)/4;
            if(tgt_idx>=0 && (uint64_t)tgt_idx<insn_count){
                vm_bc_emit(bc,is_nz?VM_OP_CBNZ:VM_OP_CBZ,0,(uint8_t)rt,0,(uint32_t)tgt_idx);
            } else {

                VM_REJECT();
            }
            continue;
        }

        if((w&0x7F000000u)==0x36000000u || (w&0x7F000000u)==0x37000000u){
            int rt=(int)(w&0x1F);
            bool is_nz=((w&0x7F000000u)==0x37000000u);
            uint8_t bit_pos=(uint8_t)(((w>>31)<<5)|((w>>19)&0x1F));
            int32_t off14=(int32_t)((w>>5)&0x3FFFu);
            if(off14&0x2000) off14|=(int32_t)0xFFFFC000;
            int64_t tgt_va=(int64_t)(func_va+(uint64_t)i*4)+(int64_t)off14*4;
            int64_t tgt_idx=((int64_t)tgt_va-(int64_t)func_va)/4;
            if(tgt_idx>=0 && (uint64_t)tgt_idx<insn_count){
                vm_bc_emit(bc,is_nz?VM_OP_TBNZ:VM_OP_TBZ,0,(uint8_t)rt,bit_pos,(uint32_t)tgt_idx);
            } else {

                VM_REJECT();
            }
            continue;
        }

        if((w&0xFF000000u)==0x58000000u){
            int rt=(int)(w&0x1F);
            int32_t imm19=(int32_t)((w>>5)&0x7FFFFu);
            if(imm19&0x40000) imm19|=(int32_t)0xFFF80000;
            uint64_t abs_addr=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+(int64_t)imm19*4);
            vm_bc_emit(bc,VM_OP_LOAD_ABS,(uint8_t)rt,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
            vm_bc_emit(bc,VM_OP_LDR64,(uint8_t)rt,(uint8_t)rt,0,0);
            continue;
        }

        if((w&0xFF000000u)==0x18000000u){
            int rt=(int)(w&0x1F);
            int32_t imm19=(int32_t)((w>>5)&0x7FFFFu);
            if(imm19&0x40000) imm19|=(int32_t)0xFFF80000;
            uint64_t abs_addr=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+(int64_t)imm19*4);
            vm_bc_emit(bc,VM_OP_LOAD_ABS,(uint8_t)rt,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
            vm_bc_emit(bc,VM_OP_LDR32,(uint8_t)rt,(uint8_t)rt,0,0);
            continue;
        }

        if((w&0xFF000000u)==0x98000000u){
            int rt=(int)(w&0x1F);
            int32_t imm19=(int32_t)((w>>5)&0x7FFFFu);
            if(imm19&0x40000) imm19|=(int32_t)0xFFF80000;
            uint64_t abs_addr=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+(int64_t)imm19*4);
            vm_bc_emit(bc,VM_OP_LOAD_ABS,(uint8_t)rt,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
            vm_bc_emit(bc,VM_OP_LDRSW,(uint8_t)rt,(uint8_t)rt,0,0);
            continue;
        }

        if((w&0xFF000000u)==0xD8000000u){
            vm_bc_emit(bc,VM_OP_NOP,0,0,0,0);
            continue;
        }

        if((w&0xFF000000u)==0x1C000000u){
            int rt=(int)(w&0x1F);
            int32_t imm19=(int32_t)((w>>5)&0x7FFFFu);
            if(imm19&0x40000) imm19|=(int32_t)0xFFF80000;
            uint64_t abs_addr=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+(int64_t)imm19*4);
            vm_bc_emit(bc,VM_OP_LOAD_ABS,16,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
            EMIT_NATIVE(0xBD400200u|(uint32_t)rt);
            continue;
        }

        if((w&0xFF000000u)==0x5C000000u){
            int rt=(int)(w&0x1F);
            int32_t imm19=(int32_t)((w>>5)&0x7FFFFu);
            if(imm19&0x40000) imm19|=(int32_t)0xFFF80000;
            uint64_t abs_addr=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+(int64_t)imm19*4);
            vm_bc_emit(bc,VM_OP_LOAD_ABS,16,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
            EMIT_NATIVE(0xFD400200u|(uint32_t)rt);
            continue;
        }

        if((w&0xFF000000u)==0x9C000000u){
            int rt=(int)(w&0x1F);
            int32_t imm19=(int32_t)((w>>5)&0x7FFFFu);
            if(imm19&0x40000) imm19|=(int32_t)0xFFF80000;
            uint64_t abs_addr=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+(int64_t)imm19*4);
            vm_bc_emit(bc,VM_OP_LOAD_ABS,16,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
            EMIT_NATIVE(0x3DC00200u|(uint32_t)rt);
            continue;
        }

        if(is_adrp(w)){
            int rd=(int)(w&0x1F);
            int32_t immhi=(int32_t)((w>>5)&0x7FFFFu);
            if(immhi&0x40000) immhi|=(int32_t)0xFFF80000;
            int32_t immlo=(int32_t)((w>>29)&3);
            int64_t page_off=((int64_t)((immhi<<2)|immlo))<<12;
            uint64_t insn_page=(func_va+(uint64_t)i*4)&~0xFFFULL;
            uint64_t abs_page=(uint64_t)((int64_t)insn_page+page_off);
            if(i+1<insn_count && (insns[i+1]&0xFF800000)==0x91000000u
               && (int)((insns[i+1]>>5)&0x1F)==rd && (int)(insns[i+1]&0x1F)==rd){
                uint32_t add_imm12=(insns[i+1]>>10)&0xFFF;
                int add_sh=(int)((insns[i+1]>>22)&1);
                if(add_sh) add_imm12<<=12;
                uint64_t abs_addr=abs_page+add_imm12;
                vm_bc_emit(bc,VM_OP_LOAD_ABS,(uint8_t)rd,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
                i++;
                continue;
            }
            if(i+1<insn_count && (insns[i+1]&0xFFC00000)==0xF9400000u
               && (int)((insns[i+1]>>5)&0x1F)==rd && (int)(insns[i+1]&0x1F)==rd){
                uint32_t ldr_off=((insns[i+1]>>10)&0xFFF)*8;
                uint64_t abs_addr=abs_page+ldr_off;
                vm_bc_emit(bc,VM_OP_LOAD_ABS,(uint8_t)rd,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
                vm_bc_emit(bc,VM_OP_LDR64,(uint8_t)rd,(uint8_t)rd,0,0);
                i++;
                continue;
            }
            vm_bc_emit(bc,VM_OP_LOAD_ABS,(uint8_t)rd,0,(uint8_t)((abs_page>>32)&0xFF),(uint32_t)(abs_page&0xFFFFFFFF));
            continue;
        }

        if(is_adr(w)){
            int rd=(int)(w&0x1F);
            int32_t immhi=(int32_t)((w>>5)&0x7FFFFu);
            if(immhi&0x40000) immhi|=(int32_t)0xFFF80000;
            int32_t immlo=(int32_t)((w>>29)&3);
            int64_t offset2=(int64_t)((immhi<<2)|immlo);
            uint64_t abs_addr=(uint64_t)((int64_t)(func_va+(uint64_t)i*4)+offset2);
            vm_bc_emit(bc,VM_OP_LOAD_ABS,(uint8_t)rd,0,(uint8_t)((abs_addr>>32)&0xFF),(uint32_t)(abs_addr&0xFFFFFFFF));
            continue;
        }

        if((w&0xFFFFFC1Fu)==0xD61F0000u){
            int rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_BR_NATIVE,0,(uint8_t)rn,0,0); continue;
        }

        if((w&0xFFFFFC1Fu)==0xD63F0000u){
            int rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_BLR_REG,0,(uint8_t)rn,0,0); continue;
        }

        if((w&0xFFC00000u)==0xD3400000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            if(imms==0x3F){

                vm_bc_emit(bc,VM_OP_LSR_IMM,(uint8_t)rd,(uint8_t)rn,0,immr); continue;
            }
            if(imms+1==((64-immr)&63)){

                vm_bc_emit(bc,VM_OP_LSL_IMM,(uint8_t)rd,(uint8_t)rn,0,63-imms); continue;
            }
            EMIT_NATIVE(w); continue;
        }

        if((w&0xFFE00C00u)==0x9A800000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint8_t cond=(uint8_t)((w>>12)&0xF);
            vm_bc_emit(bc,VM_OP_CSEL,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)cond);
            continue;
        }

        if((w&0xFF800000u)==0x11000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            int sh=(int)((w>>22)&1);
            if(sh) imm12<<=12;
            vm_bc_emit(bc,VM_OP_ADD_IMM,(uint8_t)rd,(uint8_t)rn,1,imm12); continue;
        }
        if((w&0xFF800000u)==0x51000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            int sh=(int)((w>>22)&1);
            if(sh) imm12<<=12;
            vm_bc_emit(bc,VM_OP_SUB_IMM,(uint8_t)rd,(uint8_t)rn,1,imm12); continue;
        }

        if((w&0xFFE00000u)==0x0B000000u && ((w>>22)&3)==0){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_ADD_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }
        if((w&0xFFE00000u)==0x4B000000u && ((w>>22)&3)==0){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_SUB_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }

        if((w&0xFFE00000u)==0x0A000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_AND_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }
        if((w&0xFFE00000u)==0x2A000000u && ((w>>5)&0x1F)!=31){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_ORR_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }
        if((w&0xFFE00000u)==0x4A000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_EOR_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }

        if((w&0xFFE08000u)==0x1B000000u && ((w>>10)&0x1F)==31){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_MUL_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }

        if((w&0xFFE0FFE0u)==0x2A0003E0u){
            int rd=(int)(w&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_MOV_REG,(uint8_t)rd,(uint8_t)rm,0,1); continue;
        }

        if((w&0xFFE00000u)==0xEA000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            if(rd==31){
                vm_bc_emit(bc,VM_OP_TST_REG,31,(uint8_t)rn,(uint8_t)rm,0);
            } else {

                EMIT_NATIVE(w);
            }
            continue;
        }

        if((w&0xFFE00000u)==0x6A000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            if(rd==31){
                vm_bc_emit(bc,VM_OP_TST_REG,31,(uint8_t)rn,(uint8_t)rm,1);
            } else {
                EMIT_NATIVE(w);
            }
            continue;
        }

        if((w&0xFFE00000u)==0xAB000000u && ((w>>22)&3)==0){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_ADDS_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }

        if((w&0xFFE00000u)==0x2B000000u && ((w>>22)&3)==0){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_ADDS_REG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }

        if((w&0xFFE00000u)==0xCB000000u && ((w>>5)&0x1F)==31 && ((w>>22)&3)==0){
            int rd=(int)(w&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_NEG_REG,(uint8_t)rd,(uint8_t)rm,0,0); continue;
        }

        if((w&0xFFE00000u)==0xAA200000u && ((w>>5)&0x1F)==31){
            int rd=(int)(w&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_MVN_REG,(uint8_t)rd,(uint8_t)rm,0,0); continue;
        }

        if((w&0xFFE00000u)==0x93C00000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            if(rn==rm){
                uint32_t shift=(w>>10)&0x3F;
                vm_bc_emit(bc,VM_OP_ROR_IMM,(uint8_t)rd,(uint8_t)rn,0,shift); continue;
            }
            EMIT_NATIVE(w); continue;
        }

        if((w&0xFFC00000u)==0x53000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            if(imms==0x1F){

                vm_bc_emit(bc,VM_OP_LSR_IMM,(uint8_t)rd,(uint8_t)rn,1,immr); continue;
            }
            if(imms+1==((32-immr)&31)){

                vm_bc_emit(bc,VM_OP_LSL_IMM,(uint8_t)rd,(uint8_t)rn,1,31-imms); continue;
            }
            EMIT_NATIVE(w); continue;
        }

        if((w&0xFFC00000u)==0x93400000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            if(imms==0x3F){
                vm_bc_emit(bc,VM_OP_ASR_IMM,(uint8_t)rd,(uint8_t)rn,0,immr); continue;
            }
            if(immr==0 && imms==31){
                vm_bc_emit(bc,VM_OP_SXTW,(uint8_t)rd,(uint8_t)rn,0,0); continue;
            }
            if(immr==0 && imms==7){
                vm_bc_emit(bc,VM_OP_SXTB,(uint8_t)rd,(uint8_t)rn,0,0); continue;
            }
            if(immr==0 && imms==15){
                vm_bc_emit(bc,VM_OP_SXTH,(uint8_t)rd,(uint8_t)rn,0,0); continue;
            }

            vm_bc_emit(bc,VM_OP_SBFX,(uint8_t)rd,(uint8_t)rn,0,(immr<<6)|imms); continue;
        }

        if((w&0xFFC00000u)==0x13000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            if(imms==0x1F){
                vm_bc_emit(bc,VM_OP_ASR_IMM,(uint8_t)rd,(uint8_t)rn,1,immr); continue;
            }
            EMIT_NATIVE(w); continue;
        }

        if((w&0xFFE00C00u)==0xB8600800u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint32_t S_bit=(w>>12)&1;
            vm_bc_emit(bc,VM_OP_LDR_W_REG,(uint8_t)rt,(uint8_t)rn,(uint8_t)rm, S_bit ? 2 : 0); continue;
        }

        if((w&0xFFE00C00u)==0xB8200800u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint32_t S_bit=(w>>12)&1;
            vm_bc_emit(bc,VM_OP_STR_W_REG,(uint8_t)rt,(uint8_t)rn,(uint8_t)rm, S_bit ? 2 : 0); continue;
        }

        if((w&0xFFC00000u)==0x39C00000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            vm_bc_emit(bc,VM_OP_LDRSB,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFC00000u)==0x79C00000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*2;
            vm_bc_emit(bc,VM_OP_LDRSH,(uint8_t)rt,(uint8_t)rn,0,imm12); continue;
        }

        if((w&0xFFC00000u)==0x79800000u){
            int rt=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=((w>>10)&0xFFF)*2;
            vm_bc_emit(bc,VM_OP_LDRSH,(uint8_t)rt,(uint8_t)rn,1,imm12); continue;
        }

        if((w&0xFFE00C00u)==0x9A800400u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint8_t cond=(uint8_t)((w>>12)&0xF);
            vm_bc_emit(bc,VM_OP_CSINC,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)cond); continue;
        }

        if((w&0xFFE00C00u)==0x1A800400u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint8_t cond=(uint8_t)((w>>12)&0xF);
            vm_bc_emit(bc,VM_OP_CSINC,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)cond|0x100); continue;
        }

        if((w&0xFFE00C00u)==0xDA800000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint8_t cond=(uint8_t)((w>>12)&0xF);
            vm_bc_emit(bc,VM_OP_CSINV,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)cond); continue;
        }

        if((w&0xFFE00C00u)==0xDA800400u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint8_t cond=(uint8_t)((w>>12)&0xF);
            vm_bc_emit(bc,VM_OP_CSNEG,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)cond); continue;
        }

        if((w&0xFFC00000u)==0x29000000u){
            int rt=(int)(w&0x1F), rt2=(int)((w>>10)&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm7=(int32_t)((w>>15)&0x7F);
            if(imm7&0x40) imm7|=(int32_t)0xFFFFFF80;
            vm_bc_emit(bc,VM_OP_STP_W,(uint8_t)rt,(uint8_t)rn,(uint8_t)rt2,(uint32_t)(imm7*4)); continue;
        }
        if((w&0xFFC00000u)==0x29400000u){
            int rt=(int)(w&0x1F), rt2=(int)((w>>10)&0x1F), rn=(int)((w>>5)&0x1F);
            int32_t imm7=(int32_t)((w>>15)&0x7F);
            if(imm7&0x40) imm7|=(int32_t)0xFFFFFF80;
            vm_bc_emit(bc,VM_OP_LDP_W,(uint8_t)rt,(uint8_t)rn,(uint8_t)rt2,(uint32_t)(imm7*4)); continue;
        }

        if((w&0xFFC00000u)==0x6D000000u){ EMIT_NATIVE(w); continue; }
        if((w&0xFFC00000u)==0x6D400000u){ EMIT_NATIVE(w); continue; }

        if((w&0xFFC00000u)==0xBD000000u){ EMIT_NATIVE(w); continue; }
        if((w&0xFFC00000u)==0xBD400000u){ EMIT_NATIVE(w); continue; }
        if((w&0xFFC00000u)==0xFD000000u){ EMIT_NATIVE(w); continue; }
        if((w&0xFFC00000u)==0xFD400000u){ EMIT_NATIVE(w); continue; }
        if((w&0xFFC00000u)==0x3D800000u){ EMIT_NATIVE(w); continue; }
        if((w&0xFFC00000u)==0x3DC00000u){ EMIT_NATIVE(w); continue; }

        if((w&0xFFE0FC00u)==0x9AC00C00u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_SDIV,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }
        if((w&0xFFE0FC00u)==0x9AC00800u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_UDIV,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,0); continue;
        }

        if((w&0xFFE0FC00u)==0x1AC00C00u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_SDIV,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }
        if((w&0xFFE0FC00u)==0x1AC00800u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            vm_bc_emit(bc,VM_OP_UDIV,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,1); continue;
        }

        if((w&0xFFFFFC00u)==0xDAC01000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_CLZ,(uint8_t)rd,(uint8_t)rn,0,0); continue;
        }
        if((w&0xFFFFFC00u)==0x5AC01000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_CLZ,(uint8_t)rd,(uint8_t)rn,0,1); continue;
        }

        if((w&0xFFFFFC00u)==0xDAC01400u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_CLS,(uint8_t)rd,(uint8_t)rn,0,0); continue;
        }

        if((w&0xFFFFFC00u)==0xDAC00000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_RBIT,(uint8_t)rd,(uint8_t)rn,0,0); continue;
        }

        if((w&0xFFFFFC00u)==0xDAC00C00u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_REV,(uint8_t)rd,(uint8_t)rn,0,0); continue;
        }

        if((w&0xFFFFFC00u)==0xDAC00400u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_REV16,(uint8_t)rd,(uint8_t)rn,0,0); continue;
        }

        if((w&0xFFFFFC00u)==0xDAC00800u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            vm_bc_emit(bc,VM_OP_REV32,(uint8_t)rd,(uint8_t)rn,0,0); continue;
        }

        if((w&0xFFE08000u)==0x9B000000u && ((w>>10)&0x1F)!=31){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F), ra=(int)((w>>10)&0x1F);
            vm_bc_emit(bc,VM_OP_MADD,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)ra); continue;
        }

        if((w&0xFFE08000u)==0x9B008000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F), ra=(int)((w>>10)&0x1F);
            vm_bc_emit(bc,VM_OP_MSUB,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)ra); continue;
        }

        if((w&0xFFE08000u)==0x1B000000u && ((w>>10)&0x1F)!=31){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F), ra=(int)((w>>10)&0x1F);
            vm_bc_emit(bc,VM_OP_MADD,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)ra|0x100); continue;
        }

        if((w&0xFFE08000u)==0x1B008000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F), ra=(int)((w>>10)&0x1F);
            vm_bc_emit(bc,VM_OP_MSUB,(uint8_t)rd,(uint8_t)rn,(uint8_t)rm,(uint32_t)ra|0x100); continue;
        }

        if((w&0xFFE00C10u)==0xFA400000u){
            int rn=(int)((w>>5)&0x1F), rm=(int)((w>>16)&0x1F);
            uint8_t nzcv=(uint8_t)(w&0xF), cond=(uint8_t)((w>>12)&0xF);
            vm_bc_emit(bc,VM_OP_CCMP_REG,(uint8_t)rn,(uint8_t)rm,cond,(uint32_t)nzcv); continue;
        }

        if((w&0xFFE00C10u)==0xFA400800u){
            int rn=(int)((w>>5)&0x1F), imm5=(int)((w>>16)&0x1F);
            uint8_t nzcv=(uint8_t)(w&0xF), cond=(uint8_t)((w>>12)&0xF);
            vm_bc_emit(bc,VM_OP_CCMP_IMM,(uint8_t)rn,(uint8_t)imm5,cond,(uint32_t)nzcv); continue;
        }

        if((w&0xFF800000u)==0x92000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t N=(w>>22)&1, immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            uint64_t val=decode_bitmask_imm(N,immr,imms,1);
            vm_bc_emit(bc,VM_OP_AND_IMM,(uint8_t)rd,(uint8_t)rn,0,(uint32_t)(val&0xFFFFFFFF));
            if(val>>32) vm_bc_emit(bc,VM_OP_NOP,0,0,0,(uint32_t)(val>>32));
            continue;
        }
        if((w&0xFF800000u)==0xB2000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t N=(w>>22)&1, immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            uint64_t val=decode_bitmask_imm(N,immr,imms,1);
            vm_bc_emit(bc,VM_OP_ORR_IMM,(uint8_t)rd,(uint8_t)rn,0,(uint32_t)(val&0xFFFFFFFF));
            if(val>>32) vm_bc_emit(bc,VM_OP_NOP,0,0,0,(uint32_t)(val>>32));
            continue;
        }
        if((w&0xFF800000u)==0xD2000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t N=(w>>22)&1, immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            uint64_t val=decode_bitmask_imm(N,immr,imms,1);
            vm_bc_emit(bc,VM_OP_EOR_IMM,(uint8_t)rd,(uint8_t)rn,0,(uint32_t)(val&0xFFFFFFFF));
            if(val>>32) vm_bc_emit(bc,VM_OP_NOP,0,0,0,(uint32_t)(val>>32));
            continue;
        }

        if((w&0xFFE0001Fu)==0xD4000001u){
            uint16_t imm16=(uint16_t)((w>>5)&0xFFFF);
            vm_bc_emit(bc,VM_OP_SVC,0,0,0,(uint32_t)imm16); continue;
        }

        if((w&0xFFFFF0FFu)==0xD50330BFu){
            uint8_t opt=(uint8_t)((w>>8)&0xF);
            vm_bc_emit(bc,VM_OP_DMB,0,0,0,(uint32_t)opt); continue;
        }
        if((w&0xFFFFF0FFu)==0xD503309Fu){
            uint8_t opt=(uint8_t)((w>>8)&0xF);
            vm_bc_emit(bc,VM_OP_DSB,0,0,0,(uint32_t)opt); continue;
        }
        if(w==0xD5033FDFu){
            vm_bc_emit(bc,VM_OP_ISB,0,0,0,0); continue;
        }

        if((w&0xFFC00000u)==0xD3400000u){

            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            vm_bc_emit(bc,VM_OP_UBFX,(uint8_t)rd,(uint8_t)rn,0,(immr<<6)|imms); continue;
        }

        if((w&0xFFC00000u)==0xB3400000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t immr=(w>>16)&0x3F, imms=(w>>10)&0x3F;
            vm_bc_emit(bc,VM_OP_BFI,(uint8_t)rd,(uint8_t)rn,0,(immr<<6)|imms); continue;
        }

        if((w&0xFFC00000u)==0xB1000000u){
            int rd=(int)(w&0x1F), rn=(int)((w>>5)&0x1F);
            uint32_t imm12=(w>>10)&0xFFF;
            int sh=(int)((w>>22)&1);
            if(sh) imm12<<=12;
            vm_bc_emit(bc,VM_OP_ADDS_IMM,(uint8_t)rd,(uint8_t)rn,0,imm12); continue;
        }

        if( (w & 0x7C000000u)==0x14000000u
         || (w & 0xFE000000u)==0x54000000u
         || (w & 0x7E000000u)==0x34000000u
         || (w & 0x7E000000u)==0x36000000u
         || (w & 0x1F000000u)==0x10000000u
         || (w & 0x3B000000u)==0x18000000u ){
            VM_REJECT();
        }

        EMIT_NATIVE(w);
    }
    insn_to_vm[insn_count]=(int)bc->count;

    for(uint32_t vi=insn_to_vm[0]; vi<bc->count; vi++){
        vm_insn_t *vip=&bc->insns[vi];
        switch(vip->opcode){
        case VM_OP_B:
        case VM_OP_B_COND:
        case VM_OP_CBZ:
        case VM_OP_CBNZ:
        case VM_OP_TBZ:
        case VM_OP_TBNZ: {
            uint32_t orig_tgt_idx=vip->imm;
            if(orig_tgt_idx<insn_count){
                int32_t vm_rel=(int32_t)insn_to_vm[orig_tgt_idx] - (int32_t)(vi+1);
                vip->imm=(uint32_t)vm_rel;
            }
            break;
        }
        default: break;
        }
    }

    if(out_insn_to_vm){
        memcpy(out_insn_to_vm, insn_to_vm, (insn_count+1)*sizeof(int));
    }

    free(insn_to_vm);
    #undef EMIT_NATIVE
    #undef VM_REJECT
    return true;
}

bool ldvq2306_translate_arm64_to_vm(const uint32_t *insns, uint32_t insn_count,
                                   uint64_t func_va, uint64_t text_va, uint64_t text_sz,
                                   VmBytecode *bc,
                                   uint64_t *ext_call_targets, int *n_ext_calls, int max_ext,
                                   uint32_t *native_words, int *n_native_words, int max_native)
{
    return ldvq2306_translate_arm64_to_vm_ex(insns, insn_count, func_va, text_va, text_sz, bc,
                                    ext_call_targets, n_ext_calls, max_ext,
                                    native_words, n_native_words, max_native, NULL);
}

int ldvq2306_emit_vm_interpreter_stub(uint32_t *code, int max_insns,
                                     uint64_t bc_va, uint32_t bc_count,
                                     uint64_t stub_va,
                                     uint64_t trampoline_va, uint32_t n_trampolines __attribute__((unused)),
                                     int vm_encrypt, uint32_t enc_key0, uint32_t enc_key1)
{
    int n=0;
    if(max_insns<8192) return -1;

    #define VM_CALLEE_SAVE 96
    #define VM_REGS_SIZE   (VM_REG_COUNT*8)
    #define VM_MISC        24
    #define VM_FRAME_BASE  (VM_CALLEE_SAVE + VM_REGS_SIZE + VM_MISC)
    #define VM_EXTRA_STACK 65536
    #define VM_FRAME_SIZE  (VM_FRAME_BASE + VM_EXTRA_STACK)

    code[n++]=0xD1400000u|((uint32_t)(VM_EXTRA_STACK/4096)<<10)|(31u<<5)|31u;
    if(VM_EXTRA_STACK & 0xFFF)
        code[n++]=enc_sub_i(31,31,VM_EXTRA_STACK & 0xFFF);
    code[n++]=enc_stp_pre(29,30,31,(int)(-(int32_t)(VM_FRAME_BASE/8)));
    code[n++]=enc_add_i(29,31,0);
    code[n++]=enc_stp(19,20,31,2);
    code[n++]=enc_stp(21,22,31,4);
    code[n++]=enc_stp(23,24,31,6);
    code[n++]=enc_stp(25,26,31,8);
    code[n++]=enc_stp(27,28,31,10);

    code[n++]=enc_add_i(19,31,96);

    for(int r=0;r<9;r++)
        code[n++]=enc_str_x_off(r,19,r);
    code[n++]=enc_movz(20,0,0);
    for(int r=9;r<32;r++)
        code[n++]=enc_str_x_off(20,19,r);

    n=emit_mov64(code,n,20,(uint64_t)VM_FRAME_SIZE);
    code[n++]=0x910003E9u;
    code[n++]=enc_add_r(20,9,20);
    code[n++]=enc_str_x_off(20,19,31);

    n=emit_mov64(code,n,20,(uint64_t)bc_va);
    n=emit_mov64(code,n,21,(uint64_t)(bc_va + 16 + (uint64_t)bc_count*8));
    code[n++]=enc_add_i(20,20,16);

    code[n++]=enc_movz(22,0,0);

    {
        int adr_slide_idx = n;
        code[n++] = enc_adr(29, 0);
        uint64_t adr_compile_va = stub_va + (uint64_t)adr_slide_idx * 4;
        n = emit_mov64(code, n, 9, adr_compile_va);
        code[n++] = enc_sub_r(29, 29, 9);
        code[n++] = enc_add_r(20, 20, 29);
        code[n++] = enc_add_r(21, 21, 29);
    }

    {
        n = emit_mov64(code, n, 9, trampoline_va);
        code[n++] = enc_add_r(9, 9, 29);
        code[n++] = enc_str_x_off(9, 31, (VM_FRAME_BASE-24)/8);
        code[n++] = enc_ldr_x_off(0, 19, 0);
    }

    int loop_top=n;

    code[n++]=enc_cmp_x(20,21);
    int done_patch_idx=n;
    code[n++]=0x54000002u;

    code[n++]=enc_ldr_w_off(23,20,0);
    code[n++]=enc_ldr_w_off(24,20,1);
    code[n++]=enc_add_i(20,20,8);

    if(vm_encrypt){
        code[n++]=enc_movz(9, (uint16_t)(enc_key0 & 0xFFFF), 0);
        code[n++]=enc_movk(9, (uint16_t)((enc_key0>>16)&0xFFFF), 16);
        code[n++]=enc_eor_x(23,23,9);
        code[n++]=enc_movz(9, (uint16_t)(enc_key1 & 0xFFFF), 0);
        code[n++]=enc_movk(9, (uint16_t)((enc_key1>>16)&0xFFFF), 16);
        code[n++]=enc_eor_x(24,24,9);
    }

    code[n++]=enc_movz(25,0xFF,0);
    code[n++]=enc_and_x(25,23,25);
    code[n++]=enc_lsr_w(26,23,8);
    code[n++]=enc_movz(27,0xFF,0);
    code[n++]=enc_and_x(26,26,27);
    code[n++]=enc_lsr_w(27,23,16);
    code[n++]=enc_movz(28,0xFF,0);
    code[n++]=enc_and_x(27,27,28);
    code[n++]=enc_lsr_w(28,23,24);

    int adr_jt_idx=n;
    code[n++]=enc_adr(9,0);
    code[n++]=0xB879792Au;
    code[n++]=0x8B2AC12Au;
    code[n++]=0xD61F0140u;

    int jt_base=n;
    for(int i=0;i<256;i++) code[n++]=0;
    code[adr_jt_idx]=enc_adr(9,(jt_base-adr_jt_idx)*4);

    int hpos[256];
    memset(hpos,0,sizeof(hpos));

    int default_handler=n;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_RET]=n;
    int ret_patch=n;
    code[n++]=enc_b26(0);

    hpos[VM_OP_HALT]=n;
    int halt_patch=n;
    code[n++]=enc_b26(0);

    hpos[VM_OP_MOV_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0xAA0003E0u;
    code[n++]=enc_b26(2);
    code[n++]=0x2A0003E0u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MOV_IMM32]=n;
    code[n++]=enc_mov_x(0,24);
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MOVK_HI]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=enc_movz(1,0xFFFF,0);
    code[n++]=enc_movk(1,0xFFFF,16);
    code[n++]=enc_and_x(0,0,1);
    code[n++]=enc_lsl_x_imm(1,24,32);
    code[n++]=0xAA010000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ADD_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=enc_add_r(0,0,1);
    code[n++]=enc_b26(2);
    code[n++]=0x0B010000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ADD_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_cbnz_x(28,3);
    code[n++]=enc_add_r(0,0,24);
    code[n++]=enc_b26(2);
    code[n++]=0x0B180000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SUB_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=enc_sub_r(0,0,1);
    code[n++]=enc_b26(2);
    code[n++]=0x4B010000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SUB_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_cbnz_x(28,3);
    code[n++]=enc_sub_r(0,0,24);
    code[n++]=enc_b26(2);
    code[n++]=0x4B180000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_AND_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=enc_and_x(0,0,1);
    code[n++]=enc_b26(2);
    code[n++]=0x0A010000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ORR_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0xAA010000u;
    code[n++]=enc_b26(2);
    code[n++]=0x2A010000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_EOR_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=enc_eor_x(0,0,1);
    code[n++]=enc_b26(2);
    code[n++]=0x4A010000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MUL_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=enc_mul_x(0,0,1);
    code[n++]=enc_b26(2);
    code[n++]=0x1B017C00u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LSL_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_cbnz_x(28,3);
    code[n++]=0x9AD82000u;
    code[n++]=enc_b26(2);
    code[n++]=0x1AD82000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LSR_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_cbnz_x(28,3);
    code[n++]=0x9AD82400u;
    code[n++]=enc_b26(2);
    code[n++]=0x1AD82400u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_NEG_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_neg_x(0,0);
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MVN_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_mvn_x(0,0);
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDR64]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0xF9400000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDR32]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0xB9400000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STR64]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(1,1,24);
    code[n++]=0xF9000020u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STR32]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(1,1,24);
    code[n++]=0xB9000020u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDRB]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0x39400001u;
    code[n++]=0xF83A7A61u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STRB]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(1,1,24);
    code[n++]=0x39000020u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STP_PRE]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0xF87A7A61u;
    code[n++]=0xF87C7A62u;
    code[n++]=0xF9000001u;
    code[n++]=0xF9000402u;
    code[n++]=0xF83B7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDP_POST]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF9400001u;
    code[n++]=0xF9400402u;
    code[n++]=0xF83A7A61u;
    code[n++]=0xF83C7A62u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0xF83B7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STP]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0xF87A7A61u;
    code[n++]=0xF87C7A62u;
    code[n++]=0xF9000001u;
    code[n++]=0xF9000402u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDP]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0xF9400001u;
    code[n++]=0xF9400402u;
    code[n++]=0xF83A7A61u;
    code[n++]=0xF83C7A62u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDRH]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0x79400001u;
    code[n++]=0xF83A7A61u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STRH]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(1,1,24);
    code[n++]=0x79000020u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDRSW]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0xB9800001u;
    code[n++]=0xF83A7A61u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CMP_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=enc_cmp_x(0,1);
    code[n++]=enc_b26(2);
    code[n++]=0x6B01001Fu;
    code[n++]=0xD53B4216u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CMP_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_cbnz_x(28,3);
    code[n++]=enc_cmp_x(0,24);
    code[n++]=enc_b26(2);
    code[n++]=0x6B18001Fu;
    code[n++]=0xD53B4216u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_TST_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0xEA010000u;
    code[n++]=enc_b26(2);
    code[n++]=0x6A010000u;
    code[n++]=0xD53B4216u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SUBS_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0xEB010000u;
    code[n++]=enc_b26(2);
    code[n++]=0x6B010000u;
    code[n++]=0xD53B4216u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SUBS_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_cbnz_x(28,3);
    code[n++]=0xEB180000u;
    code[n++]=enc_b26(2);
    code[n++]=0x6B180000u;
    code[n++]=0xD53B4216u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ADDS_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0xAB010000u;
    code[n++]=enc_b26(2);
    code[n++]=0x2B010000u;
    code[n++]=0xD53B4216u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ROR_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x9AD82C00u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_B]=n;
    code[n++]=0x93407F18u;
    code[n++]=enc_lsl_x_imm(24,24,3);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_B_COND]=n;
    code[n++]=0xD51B4216u;
    code[n++]=0x93407F18u;
    code[n++]=enc_lsl_x_imm(24,24,3);
    code[n++]=enc_movz(0,0,0);

    code[n++]=enc_subs_w_i(31,26,0);
    int cond_ne_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000040u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond_ne_patch]=enc_b_ne(n-cond_ne_patch);

    code[n++]=enc_subs_w_i(31,26,1);
    int cond2_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000041u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond2_patch]=enc_b_ne(n-cond2_patch);

    code[n++]=enc_subs_w_i(31,26,11);
    int cond3_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x5400004Bu;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond3_patch]=enc_b_ne(n-cond3_patch);

    code[n++]=enc_subs_w_i(31,26,10);
    int cond4_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x5400004Au;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond4_patch]=enc_b_ne(n-cond4_patch);

    code[n++]=enc_subs_w_i(31,26,12);
    int cond5_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x5400004Cu;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond5_patch]=enc_b_ne(n-cond5_patch);

    code[n++]=enc_subs_w_i(31,26,13);
    int cond6_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x5400004Du;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond6_patch]=enc_b_ne(n-cond6_patch);

    code[n++]=enc_subs_w_i(31,26,2);
    int cond7_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000042u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond7_patch]=enc_b_ne(n-cond7_patch);

    code[n++]=enc_subs_w_i(31,26,3);
    int cond8_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000043u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond8_patch]=enc_b_ne(n-cond8_patch);

    code[n++]=enc_subs_w_i(31,26,4);
    int cond9_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000044u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond9_patch]=enc_b_ne(n-cond9_patch);

    code[n++]=enc_subs_w_i(31,26,5);
    int cond10_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000045u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond10_patch]=enc_b_ne(n-cond10_patch);

    code[n++]=enc_subs_w_i(31,26,6);
    int cond11_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000046u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond11_patch]=enc_b_ne(n-cond11_patch);

    code[n++]=enc_subs_w_i(31,26,7);
    int cond12_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000047u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond12_patch]=enc_b_ne(n-cond12_patch);

    code[n++]=enc_subs_w_i(31,26,8);
    int cond13_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000048u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond13_patch]=enc_b_ne(n-cond13_patch);

    code[n++]=enc_subs_w_i(31,26,9);
    int cond14_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=0xD51B4216u;
    code[n++]=0x54000049u;
    code[n++]=enc_movz(24,0,0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond14_patch]=enc_b_ne(n-cond14_patch);

    code[n++]=enc_subs_w_i(31,26,14);
    int cond15_patch=n; code[n++]=enc_b_ne(0);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }
    code[cond15_patch]=enc_b_ne(n-cond15_patch);

    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CBZ]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_lsl_x_imm(24,24,3);
    code[n++]=enc_cbnz_x(0, 2);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CBNZ]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407F18u;
    code[n++]=enc_lsl_x_imm(24,24,3);
    code[n++]=enc_cbz_x(0, 2);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_TBZ]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_mov_x(1,28);
    code[n++]=0x9AC12400u;
    code[n++]=0x93407F18u;
    code[n++]=enc_lsl_x_imm(24,24,3);
    code[n++]=0xF240001Fu;
    code[n++]=enc_b_ne(2);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_TBNZ]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_mov_x(1,28);
    code[n++]=0x9AC12400u;
    code[n++]=0x93407F18u;
    code[n++]=enc_lsl_x_imm(24,24,3);
    code[n++]=0xF240001Fu;
    code[n++]=enc_b_eq(2);
    code[n++]=enc_add_r(20,20,24);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LOAD_ABS]=n;
    code[n++]=enc_mov_x(0,24);
    code[n++]=enc_mov_x(1,28);
    code[n++]=enc_lsl_x_imm(1,1,32);
    code[n++]=0xAA010000u;
    code[n++]=enc_add_r(0,0,29);
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MOVK_X16]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=enc_mov_x(1,28);
    code[n++]=enc_lsl_x_imm(1,1,4);
    code[n++]=enc_mov_x(2,24);
    code[n++]=0x9AC12042u;
    code[n++]=0xD29FFFE3u;
    code[n++]=0x9AC12063u;
    code[n++]=0xAA2303E3u;
    code[n++]=enc_and_x(0,0,3);
    code[n++]=0xAA020000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MOVK_W16]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=enc_mov_x(1,28);
    code[n++]=enc_lsl_x_imm(1,1,4);
    code[n++]=enc_mov_x(2,24);
    code[n++]=0x9AC12042u;
    code[n++]=0x529FFFE3u;
    code[n++]=0x1AC12063u;
    code[n++]=0x2A2303E3u;
    code[n++]=0x0A030000u;
    code[n++]=0x2A020000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDR_REG]=n;
    code[n++]=0xF87B7A61u;
    code[n++]=0xF87C7A62u;
    code[n++]=0x9AD82042u;
    code[n++]=0xF8626820u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STR_REG]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    code[n++]=0xF87C7A62u;
    code[n++]=0x9AD82042u;
    code[n++]=0xF8226820u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CSEL]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    {
        int csel_done_patches[16];
        int csel_done_count=0;
        for(int cv=0; cv<14; cv++){
            code[n++]=enc_subs_w_i(31,24,(uint32_t)cv);
            int _cskip=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            code[n++]=0x9A810000u|((uint32_t)cv<<12);
            csel_done_patches[csel_done_count++]=n; code[n++]=enc_b26(0);
            code[_cskip]=enc_b_ne(n-_cskip);
        }
        code[n++]=enc_subs_w_i(31,24,14);
        int _cskip_al=n; code[n++]=enc_b_ne(0);
        csel_done_patches[csel_done_count++]=n; code[n++]=enc_b26(0);
        code[_cskip_al]=enc_b_ne(n-_cskip_al);
        code[n++]=enc_mov_x(0,1);
        int csel_exit=n;
        code[n++]=0xF83A7A60u;
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        for(int pi=0; pi<csel_done_count; pi++){
            code[csel_done_patches[pi]]=enc_b26(csel_exit-csel_done_patches[pi]);
        }
    }

    hpos[VM_OP_NATIVE]=n;
    code[n++]=enc_ldr_x_off(9,31,(VM_FRAME_BASE-24)/8);
    code[n++]=enc_lsl_x_imm(0,24,3);
    code[n++]=enc_add_r(9,9,0);
    code[n++]=enc_str_x_off(9,19,34);
    code[n++]=enc_ldr_x_off(1,19,31);
    code[n++]=0x910003E0u;
    code[n++]=enc_str_x_off(0,19,35);
    code[n++]=0x9244EC21u;
    code[n++]=0x9100003Fu;

    for(int r=0;r<9;r++)
        code[n++]=enc_ldr_x_off(r,19,r);

    for(int r=10;r<18;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    code[n++]=enc_ldr_x_off(9,19,34);
    code[n++]=0xD51B4216u;
    code[n++]=0xD63F0120u;
    for(int r=0;r<9;r++)
        code[n++]=enc_str_x_off(r,19,r);
    for(int r=10;r<18;r++)
        code[n++]=enc_str_x_off(r,19,r);
    code[n++]=0xD53B4216u;
    code[n++]=0x910003E0u;
    code[n++]=enc_str_x_off(0,19,31);
    code[n++]=enc_ldr_x_off(0,19,35);
    code[n++]=0x9100001Fu;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_BL_NATIVE]=n;
    code[n++]=enc_mov_x(0,24);
    code[n++]=enc_mov_x(1,28);
    code[n++]=enc_lsl_x_imm(1,1,32);
    code[n++]=0xAA010000u;
    code[n++]=enc_add_r(9,0,29);
    code[n++]=enc_str_x_off(9,19,34);
    code[n++]=enc_ldr_x_off(1,19,31);
    code[n++]=0x910003E0u;
    code[n++]=enc_str_x_off(0,19,35);
    code[n++]=0x9244EC21u;
    code[n++]=0x9100003Fu;

    for(int r=0;r<9;r++)
        code[n++]=enc_ldr_x_off(r,19,r);

    for(int r=10;r<18;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    code[n++]=enc_ldr_x_off(9,19,34);
    code[n++]=0xD63F0120u;

    for(int r=0;r<9;r++)
        code[n++]=enc_str_x_off(r,19,r);

    for(int r=10;r<18;r++)
        code[n++]=enc_str_x_off(r,19,r);
    code[n++]=enc_ldr_x_off(0,19,35);
    code[n++]=0x9100001Fu;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_BR_NATIVE]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_add_r(9,0,29);

    code[n++]=enc_str_x_off(9,31,(VM_FRAME_BASE-8)/8);

    for(int r=0;r<9;r++)
        code[n++]=enc_ldr_x_off(r,19,r);

    for(int r=10;r<18;r++)
        code[n++]=enc_ldr_x_off(r,19,r);

    code[n++]=enc_ldr_x_off(9,31,(VM_FRAME_BASE-8)/8);

    code[n++]=enc_ldp(19,20,31,2);
    code[n++]=enc_ldp(21,22,31,4);
    code[n++]=enc_ldp(23,24,31,6);
    code[n++]=enc_ldp(25,26,31,8);
    code[n++]=enc_ldp(27,28,31,10);
    code[n++]=enc_ldp_post(29,30,31,(int)(VM_FRAME_BASE/8));
    code[n++]=0x91400000u|((uint32_t)(VM_EXTRA_STACK/4096)<<10)|(31u<<5)|31u;
    if(VM_EXTRA_STACK & 0xFFF)
        code[n++]=enc_add_i(31,31,VM_EXTRA_STACK & 0xFFF);
    code[n++]=enc_br(9);

    hpos[VM_OP_B_ABS]=n;
    code[n++]=enc_mov_x(0,24);
    code[n++]=enc_mov_x(1,28);
    code[n++]=enc_lsl_x_imm(1,1,32);
    code[n++]=0xAA010000u;
    code[n++]=enc_add_r(9,0,29);
    code[n++]=enc_str_x_off(9,31,(VM_FRAME_BASE-8)/8);
    for(int r=0;r<9;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    for(int r=10;r<18;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    code[n++]=enc_ldr_x_off(9,31,(VM_FRAME_BASE-8)/8);
    code[n++]=enc_ldp(19,20,31,2);
    code[n++]=enc_ldp(21,22,31,4);
    code[n++]=enc_ldp(23,24,31,6);
    code[n++]=enc_ldp(25,26,31,8);
    code[n++]=enc_ldp(27,28,31,10);
    code[n++]=enc_ldp_post(29,30,31,(int)(VM_FRAME_BASE/8));
    code[n++]=0x91400000u|((uint32_t)(VM_EXTRA_STACK/4096)<<10)|(31u<<5)|31u;
    if(VM_EXTRA_STACK & 0xFFF)
        code[n++]=enc_add_i(31,31,VM_EXTRA_STACK & 0xFFF);
    code[n++]=enc_br(9);

    hpos[VM_OP_BLR_REG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_str_x_off(0,19,34);
    code[n++]=enc_ldr_x_off(1,19,31);
    code[n++]=0x910003E0u;
    code[n++]=enc_str_x_off(0,19,35);
    code[n++]=0x9244EC21u;
    code[n++]=0x9100003Fu;
    for(int r=0;r<9;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    for(int r=10;r<18;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    code[n++]=enc_ldr_x_off(9,19,34);
    code[n++]=0xD63F0120u;
    for(int r=0;r<9;r++)
        code[n++]=enc_str_x_off(r,19,r);
    for(int r=10;r<18;r++)
        code[n++]=enc_str_x_off(r,19,r);
    code[n++]=enc_ldr_x_off(0,19,35);
    code[n++]=0x9100001Fu;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ASR_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x37400078u;
    code[n++]=0x9AD82800u;
    { int _s=n; code[n++]=enc_b26(0);
    code[n++]=0x1AD82800u;
    code[_s]=enc_b26(n-_s); }
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SXTW]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93407C00u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SXTB]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93401C00u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SXTH]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0x93403C00u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CLZ]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0xDAC01000u;
    { int _s=n; code[n++]=enc_b26(0);
    code[n++]=0x5AC01000u;
    code[_s]=enc_b26(n-_s); }
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CLS]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xDAC01400u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_RBIT]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xDAC00000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_REV]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xDAC00C00u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_REV16]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xDAC00400u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_REV32]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xDAC00800u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SDIV]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0x9AC10C00u;
    { int _s=n; code[n++]=enc_b26(0);
    code[n++]=0x1AC10C00u;
    code[_s]=enc_b26(n-_s); }
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_UDIV]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_cbnz_x(24,3);
    code[n++]=0x9AC10800u;
    { int _s=n; code[n++]=enc_b26(0);
    code[n++]=0x1AC10800u;
    code[_s]=enc_b26(n-_s); }
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MADD]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_movz(3,0x1F,0);
    code[n++]=0x0A030303u;
    code[n++]=0xF8637A62u;
    code[n++]=0x37400078u;
    code[n++]=0x9B010800u;
    { int _s=n; code[n++]=enc_b26(0);
    code[n++]=0x1B010800u;
    code[_s]=enc_b26(n-_s); }
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_MSUB]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    code[n++]=enc_movz(3,0x1F,0);
    code[n++]=0x0A030303u;
    code[n++]=0xF8637A62u;
    code[n++]=0x37400078u;
    code[n++]=0x9B018800u;
    { int _s=n; code[n++]=enc_b26(0);
    code[n++]=0x1B018800u;
    code[_s]=enc_b26(n-_s); }
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDR_W_REG]=n;
    code[n++]=0xF87B7A61u;
    code[n++]=0xF87C7A62u;
    code[n++]=0x9AD82042u;
    code[n++]=0xB8626820u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STR_W_REG]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    code[n++]=0xF87C7A62u;
    code[n++]=0x9AD82042u;
    code[n++]=0xB8226820u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDRSB]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=0x39C00001u;
    code[n++]=0xF83A7A61u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDRSH]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_add_r(0,0,24);
    code[n++]=enc_cbnz_x(28,3);
    code[n++]=0x79C00001u;
    { int _s=n; code[n++]=enc_b26(0);
    code[n++]=0x79800001u;
    code[_s]=enc_b26(n-_s); }
    code[n++]=0xF83A7A61u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_STP_W]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87C7A62u;
    code[n++]=0xF87B7A61u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(1,1,24);
    code[n++]=0xB9000020u;
    code[n++]=0xB9000422u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_LDP_W]=n;
    code[n++]=0xF87B7A61u;
    code[n++]=0x93407F18u;
    code[n++]=enc_add_r(1,1,24);
    code[n++]=0xB9400020u;
    code[n++]=0xB9400422u;
    code[n++]=0xF83A7A60u;
    code[n++]=0xF83C7A62u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_AND_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_mov_x(1,24);
    code[n++]=0xB9400282u;
    code[n++]=enc_movz(3,0xFF,0);
    code[n++]=0x0A030042u;
    code[n++]=0x7100005Fu;
    { int _p=n; code[n++]=enc_b_ne(0);
    code[n++]=0xB9400683u;
    code[n++]=enc_lsl_x_imm(3,3,32);
    code[n++]=0xAA030021u;
    code[n++]=enc_add_i(20,20,8);
    code[_p]=enc_b_ne(n-_p); }
    code[n++]=enc_and_x(0,0,1);
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ORR_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_mov_x(1,24);
    code[n++]=0xB9400282u;
    code[n++]=enc_movz(3,0xFF,0);
    code[n++]=0x0A030042u;
    code[n++]=0x7100005Fu;
    { int _p=n; code[n++]=enc_b_ne(0);
    code[n++]=0xB9400683u;
    code[n++]=enc_lsl_x_imm(3,3,32);
    code[n++]=0xAA030021u;
    code[n++]=enc_add_i(20,20,8);
    code[_p]=enc_b_ne(n-_p); }
    code[n++]=0xAA010000u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_EOR_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_mov_x(1,24);
    code[n++]=0xB9400282u;
    code[n++]=enc_movz(3,0xFF,0);
    code[n++]=0x0A030042u;
    code[n++]=0x7100005Fu;
    { int _p=n; code[n++]=enc_b_ne(0);
    code[n++]=0xB9400683u;
    code[n++]=enc_lsl_x_imm(3,3,32);
    code[n++]=0xAA030021u;
    code[n++]=enc_add_i(20,20,8);
    code[_p]=enc_b_ne(n-_p); }
    code[n++]=enc_eor_x(0,0,1);
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ADDS_IMM]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xAB180000u;
    code[n++]=0xD53B4216u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SVC]=n;
    for(int r=0;r<9;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    for(int r=10;r<18;r++)
        code[n++]=enc_ldr_x_off(r,19,r);
    code[n++]=0xD4001001u;
    for(int r=0;r<9;r++)
        code[n++]=enc_str_x_off(r,19,r);
    for(int r=10;r<18;r++)
        code[n++]=enc_str_x_off(r,19,r);
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_DMB]=n;
    code[n++]=0xD5033FBFu;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_DSB]=n;
    code[n++]=0xD5033F9Fu;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_ISB]=n;
    code[n++]=0xD5033FDFu;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_UBFX]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_movz(2,0x3F,0);
    code[n++]=0x0A020302u;
    code[n++]=enc_lsr_w(3,24,6);
    code[n++]=enc_movz(4,0x3F,0);
    code[n++]=0x0A040063u;
    code[n++]=enc_add_i(2,2,1);
    code[n++]=enc_movz(4,1,0);
    code[n++]=0x9AC22084u;
    code[n++]=enc_sub_i(4,4,1);
    code[n++]=0x9AC32C84u;
    code[n++]=0x9AC32C00u;
    code[n++]=enc_and_x(0,0,4);
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_SBFX]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=enc_mov_x(6,0);
    code[n++]=enc_movz(2,0x3F,0);
    code[n++]=0x0A020302u;
    code[n++]=enc_lsr_w(3,24,6);
    code[n++]=enc_movz(4,0x3F,0);
    code[n++]=0x0A040063u;
    code[n++]=enc_mov_x(5,2);
    code[n++]=enc_add_i(2,2,1);
    code[n++]=enc_movz(4,1,0);
    code[n++]=0x9AC22084u;
    code[n++]=enc_sub_i(4,4,1);
    code[n++]=0x9AC32C84u;
    code[n++]=0x9AC32C00u;
    code[n++]=enc_and_x(1,0,4);
    code[n++]=0x9AC524C6u;
    code[n++]=enc_movz(7,1,0);
    code[n++]=enc_and_x(6,6,7);
    code[n++]=enc_neg_x(6,6);
    code[n++]=0x8A2400C6u;
    code[n++]=0xAA060020u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_BFI]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    code[n++]=enc_movz(2,0x3F,0);
    code[n++]=0x0A020302u;
    code[n++]=enc_lsr_w(3,24,6);
    code[n++]=enc_movz(4,0x3F,0);
    code[n++]=0x0A040063u;
    code[n++]=enc_add_i(2,2,1);
    code[n++]=enc_movz(4,1,0);
    code[n++]=0x9AC22084u;
    code[n++]=enc_sub_i(4,4,1);
    code[n++]=0x9AC32C84u;
    code[n++]=0x9AC32C21u;
    code[n++]=0x8A240005u;
    code[n++]=enc_and_x(1,1,4);
    code[n++]=0xAA0100A0u;
    code[n++]=0xF83A7A60u;
    { int _off=loop_top-n; code[n++]=enc_b26(_off); }

    hpos[VM_OP_CSINC]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    {
        int _done[32]; int _dc=0;
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,24,(uint32_t)cv);
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            code[n++]=0x9A810400u|((uint32_t)cv<<12);
            _done[_dc++]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
        }
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,24,(uint32_t)(cv+256));
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            code[n++]=0x1A810400u|((uint32_t)cv<<12);
            _done[_dc++]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
        }
        int _exit=n;
        code[n++]=0xF83A7A60u;
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        for(int i=0;i<_dc;i++) code[_done[i]]=enc_b26(_exit-_done[i]);
    }

    hpos[VM_OP_CSINV]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    {
        int _done[32]; int _dc=0;
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,24,(uint32_t)cv);
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            code[n++]=0xDA810000u|((uint32_t)cv<<12);
            _done[_dc++]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
        }
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,24,(uint32_t)(cv+256));
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            code[n++]=0x5A810000u|((uint32_t)cv<<12);
            _done[_dc++]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
        }
        int _exit=n;
        code[n++]=0xF83A7A60u;
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        for(int i=0;i<_dc;i++) code[_done[i]]=enc_b26(_exit-_done[i]);
    }

    hpos[VM_OP_CSNEG]=n;
    code[n++]=0xF87B7A60u;
    code[n++]=0xF87C7A61u;
    {
        int _done[32]; int _dc=0;
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,24,(uint32_t)cv);
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            code[n++]=0xDA810400u|((uint32_t)cv<<12);
            _done[_dc++]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
        }
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,24,(uint32_t)(cv+256));
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            code[n++]=0x5A810400u|((uint32_t)cv<<12);
            _done[_dc++]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
        }
        int _exit=n;
        code[n++]=0xF83A7A60u;
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        for(int i=0;i<_dc;i++) code[_done[i]]=enc_b26(_exit-_done[i]);
    }

    hpos[VM_OP_CCMP_REG]=n;
    code[n++]=0xF87A7A60u;
    code[n++]=0xF87B7A61u;
    {
        int _tp[16], _fp[16]; int _cc=0;
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,28,(uint32_t)cv);
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            _tp[_cc]=n; code[n++]=0x54000000u|((uint32_t)cv);
            _fp[_cc]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
            _cc++;
        }
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        int _true=n;
        code[n++]=enc_cmp_x(0,1);
        code[n++]=0xD53B4216u;
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        int _false=n;
        code[n++]=enc_lsl_x_imm(22,24,28);
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        for(int i=0;i<_cc;i++){
            int off19=_true-_tp[i];
            code[_tp[i]]=0x54000000u|((uint32_t)(off19&0x7FFFF)<<5)|((uint32_t)i);
            code[_fp[i]]=enc_b26(_false-_fp[i]);
        }
    }

    hpos[VM_OP_CCMP_IMM]=n;
    code[n++]=0xF87A7A60u;
    {
        int _tp[16], _fp[16]; int _cc=0;
        for(int cv=0;cv<15;cv++){
            code[n++]=enc_subs_w_i(31,28,(uint32_t)cv);
            int _s=n; code[n++]=enc_b_ne(0);
            code[n++]=0xD51B4216u;
            _tp[_cc]=n; code[n++]=0x54000000u|((uint32_t)cv);
            _fp[_cc]=n; code[n++]=enc_b26(0);
            code[_s]=enc_b_ne(n-_s);
            _cc++;
        }
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        int _true=n;
        code[n++]=enc_cmp_x(0,27);
        code[n++]=0xD53B4216u;
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        int _false=n;
        code[n++]=enc_lsl_x_imm(22,24,28);
        { int _off=loop_top-n; code[n++]=enc_b26(_off); }
        for(int i=0;i<_cc;i++){
            int off19=_true-_tp[i];
            code[_tp[i]]=0x54000000u|((uint32_t)(off19&0x7FFFF)<<5)|((uint32_t)i);
            code[_fp[i]]=enc_b26(_false-_fp[i]);
        }
    }

    int vm_done=n;

    {
        int off19 = vm_done - done_patch_idx;
        code[done_patch_idx] = 0x54000002u | ((uint32_t)(off19 & 0x7FFFF) << 5);
    }

    code[ret_patch]=enc_b26(vm_done-ret_patch);
    code[halt_patch]=enc_b26(vm_done-halt_patch);

    code[n++]=0xD51B4216u;

    for(int r=0;r<9;r++)
        code[n++]=enc_ldr_x_off(r,19,r);

    for(int r=10;r<18;r++)
        code[n++]=enc_ldr_x_off(r,19,r);

    code[n++]=enc_ldr_x_off(9,19,9);

    code[n++]=enc_ldp(19,20,31,2);
    code[n++]=enc_ldp(21,22,31,4);
    code[n++]=enc_ldp(23,24,31,6);
    code[n++]=enc_ldp(25,26,31,8);
    code[n++]=enc_ldp(27,28,31,10);
    code[n++]=enc_ldp_post(29,30,31,(int)(VM_FRAME_BASE/8));
    code[n++]=0x91400000u|((uint32_t)(VM_EXTRA_STACK/4096)<<10)|(31u<<5)|31u;
    if(VM_EXTRA_STACK & 0xFFF)
        code[n++]=enc_add_i(31,31,VM_EXTRA_STACK & 0xFFF);
    code[n++]=enc_ret();

    for(int i=0; i<256; i++){
        int target = hpos[i] ? hpos[i] : default_handler;
        code[jt_base + i] = (uint32_t)((target - jt_base) * 4);
    }

    #undef VM_CALLEE_SAVE
    #undef VM_REGS_SIZE
    #undef VM_MISC
    #undef VM_FRAME_BASE
    #undef VM_EXTRA_STACK
    #undef VM_FRAME_SIZE
    return n;
}
