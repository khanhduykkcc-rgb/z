#include "pcrel.h"

PCType classify_pcrel(uint32_t w, int64_t *off){
    uint32_t top2 = w & 0xFC000000u;
    if(top2 == 0x14000000u){
        int32_t o=(int32_t)(w&0x3FFFFFFu);
        if(o&0x2000000) o|=(int32_t)0xFC000000;
        *off=(int64_t)o*4; return PC_B26;
    }
    if(top2 == 0x94000000u){
        int32_t o=(int32_t)(w&0x3FFFFFFu);
        if(o&0x2000000) o|=(int32_t)0xFC000000;
        *off=(int64_t)o*4; return PC_BL26;
    }
    if((w&0xFF000010u)==0x54000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_BCOND;
    }
    uint32_t top = w & 0xFF000000u;
    if(top == 0x34000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_CBZ_W;
    }
    if(top == 0x35000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_CBNZ_W;
    }
    if(top == 0xB4000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_CBZ_X;
    }
    if(top == 0xB5000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_CBNZ_X;
    }
    if((w&0x7F000000u)==0x36000000u){
        int32_t o=(int32_t)((w>>5)&0x3FFFu);
        if(o&0x2000) o|=(int32_t)0xFFFFC000;
        *off=(int64_t)o*4; return PC_TBZ;
    }
    if((w&0x7F000000u)==0x37000000u){
        int32_t o=(int32_t)((w>>5)&0x3FFFu);
        if(o&0x2000) o|=(int32_t)0xFFFFC000;
        *off=(int64_t)o*4; return PC_TBNZ;
    }
    if((w&0x9F000000u)==0x10000000u){
        int32_t o=(int32_t)(((w>>29)&3)|(((w>>5)&0x7FFFFu)<<2));
        if(o&0x100000) o|=(int32_t)0xFFE00000;
        *off=(int64_t)o; return PC_ADR;
    }
    if((w&0x9F000000u)==0x90000000u){
        int32_t o=(int32_t)(((w>>29)&3)|(((w>>5)&0x7FFFFu)<<2));
        if(o&0x100000) o|=(int32_t)0xFFE00000;
        *off=(int64_t)o*4096; return PC_ADRP;
    }
    if((w&0x3F000000u)==0x18000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_LDR_W_LIT;
    }
    if((w&0x3F000000u)==0x1C000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_LDR_S_LIT;
    }
    if(top==0x58000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_LDR_X_LIT;
    }
    if(top==0x5C000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_LDR_D_LIT;
    }
    if(top==0x98000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_LDRSW_LIT;
    }
    if(top==0x9C000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_LDR_Q_LIT;
    }
    if(top==0xD8000000u){
        int32_t o=(int32_t)((w>>5)&0x7FFFFu);
        if(o&0x40000) o|=(int32_t)0xFFF80000;
        *off=(int64_t)o*4; return PC_PRFM_LIT;
    }
    return PC_NONE;
}

bool is_internal_br(PCType t){
    switch(t){
    case PC_B26:case PC_BCOND:
    case PC_CBZ_W:case PC_CBNZ_W:case PC_CBZ_X:case PC_CBNZ_X:
    case PC_TBZ:case PC_TBNZ: return true;
    default: return false;
    }
}

uint32_t rewrite_pcrel(uint32_t w, PCType t, int64_t new_off){
    switch(t){
    case PC_B26:case PC_BL26:
        return (w&0xFC000000u)|((uint32_t)((int32_t)(new_off/4))&0x3FFFFFFu);
    case PC_BCOND:
        return (w&0xFF00001Fu)|(((uint32_t)((int32_t)(new_off/4))&0x7FFFFu)<<5);
    case PC_CBZ_W:case PC_CBNZ_W:case PC_CBZ_X:case PC_CBNZ_X:
        return (w&0xFF00001Fu)|(((uint32_t)((int32_t)(new_off/4))&0x7FFFFu)<<5);
    case PC_ADR:{
        uint32_t e=(uint32_t)((int32_t)new_off);
        return (w&0x9F00001Fu)|((e&3)<<29)|(((e>>2)&0x7FFFF)<<5);
    }
    case PC_ADRP:{
        uint32_t e=(uint32_t)((int32_t)(new_off/4096));
        return (w&0x9F00001Fu)|((e&3)<<29)|(((e>>2)&0x7FFFF)<<5);
    }
    case PC_LDR_W_LIT:case PC_LDR_X_LIT:case PC_LDRSW_LIT:
    case PC_LDR_S_LIT:case PC_LDR_D_LIT:case PC_LDR_Q_LIT:
    case PC_PRFM_LIT:
        return (w&0xFF00001Fu)|(((uint32_t)((int32_t)(new_off/4))&0x7FFFFu)<<5);
    case PC_TBZ:case PC_TBNZ:
        return (w&0xFFF8001Fu)|(((uint32_t)((int32_t)(new_off/4))&0x3FFFu)<<5);
    default: return w;
    }
}

bool pcrel_in_range(PCType t, int64_t new_off){
    switch(t){
    case PC_B26:case PC_BL26:{
        int64_t imm=new_off/4;
        return imm>=-0x2000000LL&&imm<=0x1FFFFFFLL;
    }
    case PC_BCOND:case PC_CBZ_W:case PC_CBNZ_W:case PC_CBZ_X:case PC_CBNZ_X:
    case PC_LDR_W_LIT:case PC_LDR_X_LIT:case PC_LDRSW_LIT:
    case PC_LDR_S_LIT:case PC_LDR_D_LIT:case PC_LDR_Q_LIT:case PC_PRFM_LIT:{
        int64_t imm=new_off/4;
        return imm>=-0x40000LL&&imm<=0x3FFFFLL;
    }
    case PC_ADR:
        return new_off>=-0x100000LL&&new_off<=0xFFFFFLL;
    case PC_ADRP:{
        int64_t imm=new_off/4096;
        return imm>=-0x100000LL&&imm<=0xFFFFFLL;
    }
    case PC_TBZ:case PC_TBNZ:{
        int64_t imm=new_off/4;
        return imm>=-0x2000LL&&imm<=0x1FFFLL;
    }
    default: return true;
    }
}

int get_rd(uint32_t w){
    if((w&0x3F000000)==0x39000000) return -1;
    if((w&0x3F000000)==0x38000000) return -1;
    if((w&0xFC000000)==0x14000000) return -1;
    if((w&0xFC000000)==0x94000000) return -1;
    if((w&0xFF000010)==0x54000000) return -1;
    if(w==0xD65F03C0u) return -1;
    if((w&0xFFE0001F)==0xD4200000) return -1;
    if((w&0x7FC00000)==0x29000000) return -1;
    if((w&0x7FC00000)==0x29800000) return -1;
    if((w&0x7FC00000)==0x28800000) return -1;
    if((w&0xBF400000)==0xB9000000) return -1;
    if((w&0xFF400000)==0xF9000000) return -1;
    if((w&0xFFC00000)==0x39000000) return -1;
    if((w&0xFFC00000)==0x79000000) return -1;
    if(w==NOP) return -1;
    return (int)(w&0x1F);
}

bool sets_flags(uint32_t w){
    if((w&0x7F000000)==0x31000000) return true;
    if((w&0x7F000000)==0x71000000) return true;
    if((w&0xFF000000)==0xB1000000) return true;
    if((w&0xFF000000)==0xF1000000) return true;
    if((w&0x7F200000)==0x2B000000) return true;
    if((w&0x7F200000)==0x6B000000) return true;
    if((w&0xFF200000)==0xAB000000) return true;
    if((w&0xFF200000)==0xEB000000) return true;
    if((w&0x7FE00000)==0x2B200000) return true;
    if((w&0x7FE00000)==0x6B200000) return true;
    if((w&0xFFE00000)==0xAB200000) return true;
    if((w&0xFFE00000)==0xEB200000) return true;
    if((w&0x7F800000)==0x72000000) return true;
    if((w&0xFF800000)==0xF2000000) return true;
    if((w&0x7F200000)==0x6A000000) return true;
    if((w&0xFF200000)==0xEA000000) return true;
    if((w&0x7FE00C10)==0x3A400000) return true;
    if((w&0x7FE00C10)==0x3A400800) return true;
    if((w&0x7FE00000)==0x3A000000) return true;
    if((w&0x7FE00000)==0x7A000000) return true;
    if(w==0xD51B4200u) return true;
    return false;
}

bool uses_flags(uint32_t w){
    if((w&0xFF000010)==0x54000000) return true;
    if((w&0x7FE00000)==0x1A800000) return true;
    if((w&0x7FE00000)==0x5A800000) return true;
    if((w&0x7FE00C10)==0x3A400000) return true;
    if((w&0x7FE00C10)==0x3A400800) return true;
    if((w&0x7FE00000)==0x1A000000) return true;
    if((w&0x7FE00000)==0x5A000000) return true;
    if((w&0x7FE00000)==0x3A000000) return true;
    if((w&0x7FE00000)==0x7A000000) return true;
    if(w==0xD53B4200u) return true;
    return false;
}

bool is_adrp(uint32_t w){ return (w&0x9F000000u)==0x90000000u; }
bool is_adr(uint32_t w){ return (w&0x9F000000u)==0x10000000u; }
bool is_movz(uint32_t w){ return (w&0x7F800000u)==0x52800000u; }
bool is_movk(uint32_t w){ return (w&0x7F800000u)==0x72800000u; }

bool is_terminator(uint32_t w){
    if(w==0xD65F03C0u||w==0xD65F0BFFu||w==0xD65F0FFFu) return true;
    if((w&0xFC000000u)==0x14000000u) return true;
    if((w&0xFFFFFC1Fu)==0xD61F0000u) return true;
    if((w&0xFEFFF800u)==0xD61F0800u) return true;
    if((w&0xFFE0001Fu)==0xD4200000u) return true;
    return false;
}

bool is_cond_branch(uint32_t w){
    if((w&0xFF000010u)==0x54000000u) return true;
    uint32_t top=w&0xFF000000u;
    if(top==0x34000000u||top==0x35000000u||top==0xB4000000u||top==0xB5000000u) return true;
    if((w&0x7F000000u)==0x36000000u||(w&0x7F000000u)==0x37000000u) return true;
    return false;
}
