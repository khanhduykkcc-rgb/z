#include "types.h"
#include "util.h"
#include "macho.h"
#include "obfuscate.h"
#include "pcrel.h"
#include "vm.h"
#include "arm64_enc.h"

static FILE *g_log = NULL;

#define LOG(fmt, ...) do { \
    printf(fmt, ##__VA_ARGS__); \
    if(g_log) fprintf(g_log, fmt, ##__VA_ARGS__); \
} while(0)

static const char *vm_op_name(uint8_t op){
    switch(op){
    case VM_OP_NOP: return "NOP";
    case VM_OP_MOV_REG: return "MOV_REG";
    case VM_OP_MOV_IMM32: return "MOV_IMM32";
    case VM_OP_MOVK_HI: return "MOVK_HI";
    case VM_OP_ADD_REG: return "ADD_REG";
    case VM_OP_ADD_IMM: return "ADD_IMM";
    case VM_OP_SUB_REG: return "SUB_REG";
    case VM_OP_SUB_IMM: return "SUB_IMM";
    case VM_OP_AND_REG: return "AND_REG";
    case VM_OP_ORR_REG: return "ORR_REG";
    case VM_OP_EOR_REG: return "EOR_REG";
    case VM_OP_LSL_IMM: return "LSL_IMM";
    case VM_OP_LSR_IMM: return "LSR_IMM";
    case VM_OP_MUL_REG: return "MUL_REG";
    case VM_OP_NEG_REG: return "NEG_REG";
    case VM_OP_MVN_REG: return "MVN_REG";
    case VM_OP_LDR64: return "LDR64";
    case VM_OP_LDR32: return "LDR32";
    case VM_OP_STR64: return "STR64";
    case VM_OP_STR32: return "STR32";
    case VM_OP_LDRB: return "LDRB";
    case VM_OP_STRB: return "STRB";
    case VM_OP_STP_PRE: return "STP_PRE";
    case VM_OP_LDP_POST: return "LDP_POST";
    case VM_OP_STP: return "STP";
    case VM_OP_LDP: return "LDP";
    case VM_OP_LDRH: return "LDRH";
    case VM_OP_STRH: return "STRH";
    case VM_OP_LDRSW: return "LDRSW";
    case VM_OP_CMP_REG: return "CMP_REG";
    case VM_OP_CMP_IMM: return "CMP_IMM";
    case VM_OP_TST_REG: return "TST_REG";
    case VM_OP_B: return "B";
    case VM_OP_BL_NATIVE: return "BL_NATIVE";
    case VM_OP_BR_NATIVE: return "BR_NATIVE";
    case VM_OP_RET: return "RET";
    case VM_OP_B_COND: return "B_COND";
    case VM_OP_CBZ: return "CBZ";
    case VM_OP_CBNZ: return "CBNZ";
    case VM_OP_TBZ: return "TBZ";
    case VM_OP_TBNZ: return "TBNZ";
    case VM_OP_NATIVE: return "NATIVE";
    case VM_OP_MOVK_W16: return "MOVK_W16";
    case VM_OP_MOVK_X16: return "MOVK_X16";
    case VM_OP_LDR_REG: return "LDR_REG";
    case VM_OP_STR_REG: return "STR_REG";
    case VM_OP_BLR_REG: return "BLR_REG";
    case VM_OP_LOAD_ABS: return "LOAD_ABS";
    case VM_OP_CSEL: return "CSEL";
    case VM_OP_SUBS_REG: return "SUBS_REG";
    case VM_OP_SUBS_IMM: return "SUBS_IMM";
    case VM_OP_ADDS_REG: return "ADDS_REG";
    case VM_OP_ROR_IMM: return "ROR_IMM";
    case VM_OP_HALT: return "HALT";
    default: return "???";
    }
}

static const char *cond_name(uint8_t c){
    static const char *cn[]={"EQ","NE","HS","LO","MI","PL","VS","VC","HI","LS","GE","LT","GT","LE","AL","NV"};
    return (c<16)?cn[c]:"??";
}

static const char *arm64_disasm_brief(uint32_t w, uint64_t va){
    static char buf[256];
    if(w==NOP){ return "NOP"; }
    if(w==0xD65F03C0u){ return "RET"; }
    if((w&0xFFE0001Fu)==0xD4200000u){ snprintf(buf,sizeof(buf),"BRK #0x%x",(w>>5)&0xFFFF); return buf; }
    if((w&0xFFE0FFE0u)==0xAA0003E0u){ snprintf(buf,sizeof(buf),"MOV x%d, x%d",w&0x1F,(w>>16)&0x1F); return buf; }
    if((w&0xFF800000u)==0xD2800000u){ int rd=w&0x1F; int hw=(w>>21)&3; uint32_t im=(w>>5)&0xFFFF; snprintf(buf,sizeof(buf),"MOVZ x%d, #0x%x, LSL #%d",rd,im,hw*16); return buf; }
    if((w&0xFF800000u)==0x52800000u){ int rd=w&0x1F; int hw=(w>>21)&3; uint32_t im=(w>>5)&0xFFFF; snprintf(buf,sizeof(buf),"MOVZ w%d, #0x%x, LSL #%d",rd,im,hw*16); return buf; }
    if((w&0xFF800000u)==0xF2800000u){ int rd=w&0x1F; int hw=(w>>21)&3; uint32_t im=(w>>5)&0xFFFF; snprintf(buf,sizeof(buf),"MOVK x%d, #0x%x, LSL #%d",rd,im,hw*16); return buf; }
    if((w&0xFF800000u)==0x72800000u){ int rd=w&0x1F; int hw=(w>>21)&3; uint32_t im=(w>>5)&0xFFFF; snprintf(buf,sizeof(buf),"MOVK w%d, #0x%x, LSL #%d",rd,im,hw*16); return buf; }
    if((w&0xFFC00000u)==0x91000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; int sh=(w>>22)&1; snprintf(buf,sizeof(buf),"ADD x%d, x%d, #0x%x%s",rd,rn,im,sh?", LSL #12":""); return buf; }
    if((w&0xFFC00000u)==0xD1000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; snprintf(buf,sizeof(buf),"SUB x%d, x%d, #0x%x",rd,rn,im); return buf; }
    if((w&0xFFE00000u)==0x8B000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; snprintf(buf,sizeof(buf),"ADD x%d, x%d, x%d",rd,rn,rm); return buf; }
    if((w&0xFFE00000u)==0xCB000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; snprintf(buf,sizeof(buf),"SUB x%d, x%d, x%d",rd,rn,rm); return buf; }
    if((w&0xFFC00000u)==0xF9400000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*8; snprintf(buf,sizeof(buf),"LDR x%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0xF9000000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*8; snprintf(buf,sizeof(buf),"STR x%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0xB9400000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*4; snprintf(buf,sizeof(buf),"LDR w%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0xB9000000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*4; snprintf(buf,sizeof(buf),"STR w%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0x39400000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; snprintf(buf,sizeof(buf),"LDRB w%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0x39000000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; snprintf(buf,sizeof(buf),"STRB w%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0x79400000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*2; snprintf(buf,sizeof(buf),"LDRH w%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0x79000000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*2; snprintf(buf,sizeof(buf),"STRH w%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0xB9800000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*4; snprintf(buf,sizeof(buf),"LDRSW x%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0xA9800000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"STP x%d, x%d, [x%d, #%d]!",rt,rt2,rn,im7*8); return buf; }
    if((w&0xFFC00000u)==0xA8C00000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"LDP x%d, x%d, [x%d], #%d",rt,rt2,rn,im7*8); return buf; }
    if((w&0xFFC00000u)==0xA9000000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"STP x%d, x%d, [x%d, #%d]",rt,rt2,rn,im7*8); return buf; }
    if((w&0xFFC00000u)==0xA9400000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"LDP x%d, x%d, [x%d, #%d]",rt,rt2,rn,im7*8); return buf; }
    if((w&0xFFC00000u)==0x29800000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"STP w%d, w%d, [x%d, #%d]!",rt,rt2,rn,im7*4); return buf; }
    if((w&0xFFC00000u)==0x28C00000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"LDP w%d, w%d, [x%d], #%d",rt,rt2,rn,im7*4); return buf; }
    if((w&0xFFC00000u)==0x29000000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"STP w%d, w%d, [x%d, #%d]",rt,rt2,rn,im7*4); return buf; }
    if((w&0xFFC00000u)==0x29400000u){ int rt=w&0x1F; int rt2=(w>>10)&0x1F; int rn=(w>>5)&0x1F; int32_t im7=(int32_t)((w>>15)&0x7F); if(im7&0x40)im7|=(int32_t)0xFFFFFF80; snprintf(buf,sizeof(buf),"LDP w%d, w%d, [x%d, #%d]",rt,rt2,rn,im7*4); return buf; }
    if((w&0xFC000000u)==0x14000000u){ int32_t off=(int32_t)(w&0x3FFFFFF); if(off&0x2000000)off|=(int32_t)0xFC000000; snprintf(buf,sizeof(buf),"B 0x%llx",(unsigned long long)(va+(int64_t)off*4)); return buf; }
    if((w&0xFC000000u)==0x94000000u){ int32_t off=(int32_t)(w&0x3FFFFFF); if(off&0x2000000)off|=(int32_t)0xFC000000; snprintf(buf,sizeof(buf),"BL 0x%llx",(unsigned long long)(va+(int64_t)off*4)); return buf; }
    if((w&0xFF000010u)==0x54000000u){ int32_t off=(int32_t)((w>>5)&0x7FFFF); if(off&0x40000)off|=(int32_t)0xFFF80000; uint8_t cond=w&0xF; snprintf(buf,sizeof(buf),"B.%s 0x%llx",cond_name(cond),(unsigned long long)(va+(int64_t)off*4)); return buf; }
    if((w&0xFF000000u)==0xB4000000u||(w&0xFF000000u)==0xB5000000u){ int rt=w&0x1F; bool nz=(w&0xFF000000u)==0xB5000000u; int32_t off=(int32_t)((w>>5)&0x7FFFF); if(off&0x40000)off|=(int32_t)0xFFF80000; snprintf(buf,sizeof(buf),"%s x%d, 0x%llx",nz?"CBNZ":"CBZ",rt,(unsigned long long)(va+(int64_t)off*4)); return buf; }
    if((w&0xFF000000u)==0x34000000u||(w&0xFF000000u)==0x35000000u){ int rt=w&0x1F; bool nz=(w&0xFF000000u)==0x35000000u; int32_t off=(int32_t)((w>>5)&0x7FFFF); if(off&0x40000)off|=(int32_t)0xFFF80000; snprintf(buf,sizeof(buf),"%s w%d, 0x%llx",nz?"CBNZ":"CBZ",rt,(unsigned long long)(va+(int64_t)off*4)); return buf; }
    if((w&0x7F000000u)==0x36000000u||(w&0x7F000000u)==0x37000000u){ int rt=w&0x1F; bool nz=(w&0x7F000000u)==0x37000000u; uint8_t bit=((w>>31)<<5)|((w>>19)&0x1F); int32_t off=(int32_t)((w>>5)&0x3FFF); if(off&0x2000)off|=(int32_t)0xFFFFC000; snprintf(buf,sizeof(buf),"%s %s%d, #%d, 0x%llx",nz?"TBNZ":"TBZ",bit>=32?"x":"w",rt,bit,(unsigned long long)(va+(int64_t)off*4)); return buf; }
    if((w&0x9F000000u)==0x90000000u){ int rd=w&0x1F; int32_t immhi=(int32_t)((w>>5)&0x7FFFF); if(immhi&0x40000)immhi|=(int32_t)0xFFF80000; int32_t immlo=(int32_t)((w>>29)&3); int64_t page_off=(int64_t)((immhi<<2)|immlo)<<12; uint64_t page=(va&~0xFFFULL)+(uint64_t)page_off; snprintf(buf,sizeof(buf),"ADRP x%d, 0x%llx",rd,(unsigned long long)page); return buf; }
    if((w&0x9F000000u)==0x10000000u){ int rd=w&0x1F; int32_t immhi=(int32_t)((w>>5)&0x7FFFF); if(immhi&0x40000)immhi|=(int32_t)0xFFF80000; int32_t immlo=(int32_t)((w>>29)&3); int64_t off2=(int64_t)((immhi<<2)|immlo); snprintf(buf,sizeof(buf),"ADR x%d, 0x%llx",rd,(unsigned long long)(va+(uint64_t)off2)); return buf; }
    if((w&0xFF000000u)==0x58000000u){ int rt=w&0x1F; int32_t off=(int32_t)((w>>5)&0x7FFFF); if(off&0x40000)off|=(int32_t)0xFFF80000; snprintf(buf,sizeof(buf),"LDR x%d, 0x%llx (literal)",rt,(unsigned long long)(va+(int64_t)off*4)); return buf; }
    if((w&0xFFFFFC1Fu)==0xD61F0000u){ int rn=(w>>5)&0x1F; snprintf(buf,sizeof(buf),"BR x%d",rn); return buf; }
    if((w&0xFFFFFC1Fu)==0xD63F0000u){ int rn=(w>>5)&0x1F; snprintf(buf,sizeof(buf),"BLR x%d",rn); return buf; }
    if((w&0xFFE00000u)==0xEB000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; if(rd==31) snprintf(buf,sizeof(buf),"CMP x%d, x%d",rn,rm); else snprintf(buf,sizeof(buf),"SUBS x%d, x%d, x%d",rd,rn,rm); return buf; }
    if((w&0xFFE00000u)==0x6B000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; if(rd==31) snprintf(buf,sizeof(buf),"CMP w%d, w%d",rn,rm); else snprintf(buf,sizeof(buf),"SUBS w%d, w%d, w%d",rd,rn,rm); return buf; }
    if((w&0xFFC00000u)==0xF1000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; if(rd==31) snprintf(buf,sizeof(buf),"CMP x%d, #0x%x",rn,im); else snprintf(buf,sizeof(buf),"SUBS x%d, x%d, #0x%x",rd,rn,im); return buf; }
    if((w&0xFFC00000u)==0x71000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; if(rd==31) snprintf(buf,sizeof(buf),"CMP w%d, #0x%x",rn,im); else snprintf(buf,sizeof(buf),"SUBS w%d, w%d, #0x%x",rd,rn,im); return buf; }
    if((w&0xFFC00000u)==0x51000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; snprintf(buf,sizeof(buf),"SUB w%d, w%d, #0x%x",rd,rn,im); return buf; }
    if((w&0xFFC00000u)==0x11000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=(w>>10)&0xFFF; snprintf(buf,sizeof(buf),"ADD w%d, w%d, #0x%x",rd,rn,im); return buf; }
    if((w&0xFFE00C00u)==0x9A800000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; int cond=(w>>12)&0xF; snprintf(buf,sizeof(buf),"CSEL x%d, x%d, x%d, %s",rd,rn,rm,cond_name((uint8_t)cond)); return buf; }
    if((w&0xFFE00000u)==0x8A000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; snprintf(buf,sizeof(buf),"AND x%d, x%d, x%d",rd,rn,rm); return buf; }
    if((w&0xFFE00000u)==0xAA000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; if(rn==31) snprintf(buf,sizeof(buf),"MOV x%d, x%d",rd,rm); else snprintf(buf,sizeof(buf),"ORR x%d, x%d, x%d",rd,rn,rm); return buf; }
    if((w&0xFFE00000u)==0xCA000000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; snprintf(buf,sizeof(buf),"EOR x%d, x%d, x%d",rd,rn,rm); return buf; }
    if((w&0xFFE08000u)==0x9B000000u&&((w>>10)&0x1F)==31){ int rd=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; snprintf(buf,sizeof(buf),"MUL x%d, x%d, x%d",rd,rn,rm); return buf; }
    if((w&0xFFC00000u)==0xD3400000u){ int rd=w&0x1F; int rn=(w>>5)&0x1F; uint32_t immr=(w>>16)&0x3F; uint32_t imms=(w>>10)&0x3F; if(imms==0x3F) snprintf(buf,sizeof(buf),"LSR x%d, x%d, #%d",rd,rn,immr); else snprintf(buf,sizeof(buf),"UBFM x%d, x%d, #%d, #%d",rd,rn,immr,imms); return buf; }
    if((w&0xFFC00C00u)==0xF8400000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; int32_t im9=(int32_t)((w>>12)&0x1FF); if(im9&0x100)im9|=(int32_t)0xFFFFFF00; snprintf(buf,sizeof(buf),"LDR x%d, [x%d, #%d] (unscaled)",rt,rn,im9); return buf; }
    if((w&0xFFC00C00u)==0xF8000000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; int32_t im9=(int32_t)((w>>12)&0x1FF); if(im9&0x100)im9|=(int32_t)0xFFFFFF00; snprintf(buf,sizeof(buf),"STR x%d, [x%d, #%d] (unscaled)",rt,rn,im9); return buf; }
    if((w&0xFFE00C00u)==0xF8600800u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; snprintf(buf,sizeof(buf),"LDR x%d, [x%d, x%d]",rt,rn,rm); return buf; }
    if((w&0xFFE00C00u)==0xF8200800u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; int rm=(w>>16)&0x1F; snprintf(buf,sizeof(buf),"STR x%d, [x%d, x%d]",rt,rn,rm); return buf; }
    if((w&0xFF000000u)==0x1C000000u){ int rt=w&0x1F; snprintf(buf,sizeof(buf),"LDR s%d, (literal)",rt); return buf; }
    if((w&0xFF000000u)==0x5C000000u){ int rt=w&0x1F; snprintf(buf,sizeof(buf),"LDR d%d, (literal)",rt); return buf; }
    if((w&0xFF000000u)==0x9C000000u){ int rt=w&0x1F; snprintf(buf,sizeof(buf),"LDR q%d, (literal)",rt); return buf; }
    if((w&0xFFC00000u)==0xBD400000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*4; snprintf(buf,sizeof(buf),"LDR s%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0xFD400000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*8; snprintf(buf,sizeof(buf),"LDR d%d, [x%d, #%d]",rt,rn,im); return buf; }
    if((w&0xFFC00000u)==0x3DC00000u){ int rt=w&0x1F; int rn=(w>>5)&0x1F; uint32_t im=((w>>10)&0xFFF)*16; snprintf(buf,sizeof(buf),"LDR q%d, [x%d, #%d]",rt,rn,im); return buf; }
    snprintf(buf,sizeof(buf),"??? 0x%08X",w);
    return buf;
}

typedef struct {
    int arm_idx;
    int vm_start;
    int vm_end;
    bool is_native;
    bool is_fused;
} InsnMapping;

static const char *verify_mapping(const uint32_t *src, uint32_t icnt __attribute__((unused)),
                                   uint64_t func_va __attribute__((unused)),
                                   const VmBytecode *bc, const InsnMapping *m,
                                   const uint32_t *native_words, int n_native)
{
    static char err[256];
    int ai = m->arm_idx;
    uint32_t w = src[ai];
    int vs = m->vm_start;

    if(m->is_native){
        if(vs < (int)bc->count && bc->insns[vs].opcode == VM_OP_NATIVE){
            uint32_t tidx = bc->insns[vs].imm;
            if(tidx < (uint32_t)n_native){
                if(native_words[tidx] != w){
                    snprintf(err,sizeof(err),"NATIVE trampoline mismatch: expected 0x%08X got 0x%08X", w, native_words[tidx]);
                    return err;
                }
            }
        }
        return NULL;
    }

    if(vs >= (int)bc->count) return "VM index out of range";

    const vm_insn_t *vi = &bc->insns[vs];

    if(w == NOP && vi->opcode == VM_OP_NOP) return NULL;
    if(w == 0xD65F03C0u && vi->opcode == VM_OP_RET) return NULL;

    if((w&0xFFE0FFE0u)==0xAA0003E0u){
        int rd = w & 0x1F, rm = (w>>16) & 0x1F;
        if(vi->opcode == VM_OP_MOV_REG && vi->rd == rd && vi->rn == rm) return NULL;
        snprintf(err,sizeof(err),"MOV reg mismatch: ARM rd=%d rm=%d, VM rd=%d rn=%d", rd, rm, vi->rd, vi->rn);
        return err;
    }

    if((w&0xFF800000u)==0xD2800000u || (w&0xFF800000u)==0x52800000u){
        if(vi->opcode == VM_OP_MOV_IMM32) return NULL;
    }

    if((w&0xFF800000u)==0xF2800000u){
        if(vi->opcode == VM_OP_MOVK_X16) return NULL;
    }
    if((w&0xFF800000u)==0x72800000u){
        if(vi->opcode == VM_OP_MOVK_W16) return NULL;
    }

    if((w&0xFFC00000u)==0x91000000u){
        int rd=w&0x1F, rn=(w>>5)&0x1F;
        uint32_t imm12=(w>>10)&0xFFF;
        int sh=(w>>22)&1;
        if(sh) imm12<<=12;
        if(vi->opcode == VM_OP_ADD_IMM && vi->rd == rd && vi->rn == rn && vi->imm == imm12) return NULL;
        if(vi->opcode == VM_OP_ADD_IMM) return NULL;
    }

    if((w&0xFFC00000u)==0xD1000000u){
        if(vi->opcode == VM_OP_SUB_IMM) return NULL;
    }

    if((w&0xFFE00000u)==0x8B000000u){
        if(vi->opcode == VM_OP_ADD_REG) return NULL;
    }
    if((w&0xFFE00000u)==0xCB000000u){
        if(vi->opcode == VM_OP_SUB_REG) return NULL;
    }
    if((w&0xFFE00000u)==0x8A000000u){
        if(vi->opcode == VM_OP_AND_REG) return NULL;
    }
    if((w&0xFFE00000u)==0xCA000000u){
        if(vi->opcode == VM_OP_EOR_REG) return NULL;
    }

    if((w&0xFFE00000u)==0xEB000000u || (w&0xFFE00000u)==0x6B000000u){
        int rd=w&0x1F;
        if(rd==31 && vi->opcode == VM_OP_CMP_REG) return NULL;
        if(rd!=31 && vi->opcode == VM_OP_SUBS_REG) return NULL;
    }
    if((w&0xFFC00000u)==0xF1000000u || (w&0xFFC00000u)==0x71000000u){
        int rd=w&0x1F;
        if(rd==31 && vi->opcode == VM_OP_CMP_IMM) return NULL;
        if(rd!=31 && vi->opcode == VM_OP_SUBS_IMM) return NULL;
    }

    if((w&0xFFC00000u)==0xF9400000u){ if(vi->opcode == VM_OP_LDR64) return NULL; }
    if((w&0xFFC00000u)==0xB9400000u){ if(vi->opcode == VM_OP_LDR32) return NULL; }
    if((w&0xFFC00000u)==0xF9000000u){ if(vi->opcode == VM_OP_STR64) return NULL; }
    if((w&0xFFC00000u)==0xB9000000u){ if(vi->opcode == VM_OP_STR32) return NULL; }
    if((w&0xFFC00000u)==0x39400000u){ if(vi->opcode == VM_OP_LDRB) return NULL; }
    if((w&0xFFC00000u)==0x39000000u){ if(vi->opcode == VM_OP_STRB) return NULL; }
    if((w&0xFFC00000u)==0x79400000u){ if(vi->opcode == VM_OP_LDRH) return NULL; }
    if((w&0xFFC00000u)==0x79000000u){ if(vi->opcode == VM_OP_STRH) return NULL; }
    if((w&0xFFC00000u)==0xB9800000u){ if(vi->opcode == VM_OP_LDRSW) return NULL; }

    if((w&0xFFC00C00u)==0xF8400000u){ if(vi->opcode == VM_OP_LDR64) return NULL; }
    if((w&0xFFC00C00u)==0xF8000000u){ if(vi->opcode == VM_OP_STR64) return NULL; }
    if((w&0xFFE00C00u)==0xF8600800u){ if(vi->opcode == VM_OP_LDR_REG) return NULL; }
    if((w&0xFFE00C00u)==0xF8200800u){ if(vi->opcode == VM_OP_STR_REG) return NULL; }

    if((w&0xFFC00000u)==0xA9800000u){ if(vi->opcode == VM_OP_STP_PRE) return NULL; }
    if((w&0xFFC00000u)==0xA8C00000u){ if(vi->opcode == VM_OP_LDP_POST) return NULL; }
    if((w&0xFFC00000u)==0xA9000000u){ if(vi->opcode == VM_OP_STP) return NULL; }
    if((w&0xFFC00000u)==0xA9400000u){ if(vi->opcode == VM_OP_LDP) return NULL; }

    if((w&0xFC000000u)==0x14000000u){
        if(vi->opcode == VM_OP_B || vi->opcode == VM_OP_NATIVE) return NULL;
    }
    if((w&0xFC000000u)==0x94000000u){
        if(vi->opcode == VM_OP_BL_NATIVE) return NULL;
    }
    if((w&0xFF000010u)==0x54000000u){
        if(vi->opcode == VM_OP_B_COND || vi->opcode == VM_OP_NATIVE) return NULL;
    }
    if((w&0xFF000000u)==0xB4000000u || (w&0xFF000000u)==0xB5000000u ||
       (w&0xFF000000u)==0x34000000u || (w&0xFF000000u)==0x35000000u){
        if(vi->opcode == VM_OP_CBZ || vi->opcode == VM_OP_CBNZ || vi->opcode == VM_OP_NATIVE) return NULL;
    }
    if((w&0x7F000000u)==0x36000000u || (w&0x7F000000u)==0x37000000u){
        if(vi->opcode == VM_OP_TBZ || vi->opcode == VM_OP_TBNZ || vi->opcode == VM_OP_NATIVE) return NULL;
    }

    if(is_adrp(w) || is_adr(w)){
        if(vi->opcode == VM_OP_LOAD_ABS) return NULL;
    }

    if((w&0xFF000000u)==0x58000000u){
        if(vi->opcode == VM_OP_LOAD_ABS) return NULL;
    }

    if((w&0xFF000000u)==0x1C000000u || (w&0xFF000000u)==0x5C000000u || (w&0xFF000000u)==0x9C000000u){
        if(vi->opcode == VM_OP_LOAD_ABS) return NULL;
    }

    if((w&0xFFFFFC1Fu)==0xD61F0000u){
        if(vi->opcode == VM_OP_BR_NATIVE) return NULL;
    }
    if((w&0xFFFFFC1Fu)==0xD63F0000u){
        if(vi->opcode == VM_OP_BLR_REG) return NULL;
    }

    if((w&0xFFE00C00u)==0x9A800000u){
        if(vi->opcode == VM_OP_CSEL) return NULL;
    }

    if((w&0xFFE08000u)==0x9B000000u && ((w>>10)&0x1F)==31){
        if(vi->opcode == VM_OP_MUL_REG) return NULL;
    }

    if((w&0xFFC00000u)==0xD3400000u){
        if(vi->opcode == VM_OP_LSR_IMM || vi->opcode == VM_OP_LSL_IMM || vi->opcode == VM_OP_NATIVE) return NULL;
    }

    if((w&0xFFE0001Fu)==0xD4200000u){
        if(vi->opcode == VM_OP_HALT) return NULL;
    }

    if(vi->opcode == VM_OP_NATIVE) return NULL;

    snprintf(err,sizeof(err),"unexpected VM op 0x%02X (%s) for ARM64 0x%08X", vi->opcode, vm_op_name(vi->opcode), w);
    return err;
}

static void verify_branch_targets(const VmBytecode *bc, uint32_t icnt __attribute__((unused)))
{
    int errors = 0;
    for(uint32_t i = 0; i < bc->count; i++){
        const vm_insn_t *vi = &bc->insns[i];
        switch(vi->opcode){
        case VM_OP_B:
        case VM_OP_B_COND:
        case VM_OP_CBZ:
        case VM_OP_CBNZ:
        case VM_OP_TBZ:
        case VM_OP_TBNZ: {
            int32_t rel = (int32_t)vi->imm;
            int32_t target = (int32_t)(i + 1) + rel;
            if(target < 0 || target > (int32_t)bc->count){
                LOG("  [!] VM[%u] %s: branch target %d out of range [0..%u]\n",
                    i, vm_op_name(vi->opcode), target, bc->count);
                errors++;
            }
            break;
        }
        default: break;
        }
    }
    if(errors == 0)
        LOG("  Branch target verification: PASS (all %u checked)\n", bc->count);
    else
        LOG("  Branch target verification: FAIL (%d errors)\n", errors);
}

static void verify_abs_addresses(const VmBytecode *bc, uint64_t text_va __attribute__((unused)),
                                  uint64_t text_sz __attribute__((unused)))
{
    int total = 0, suspect = 0;
    for(uint32_t i = 0; i < bc->count; i++){
        const vm_insn_t *vi = &bc->insns[i];
        if(vi->opcode == VM_OP_LOAD_ABS || vi->opcode == VM_OP_BL_NATIVE){
            uint64_t addr = ((uint64_t)vi->rm << 32) | vi->imm;
            total++;
            if(addr == 0){
                LOG("  [!] VM[%u] %s: null address\n", i, vm_op_name(vi->opcode));
                suspect++;
            }
        }
    }
    LOG("  Absolute address verification: %d total, %d suspect\n", total, suspect);
}

static void analyze_func(const uint8_t *text_data, uint64_t text_va, uint64_t text_sz,
                          uint64_t *func_vas, int nfuncs, int idx)
{
    uint64_t fs = func_vas[idx];
    uint64_t nx = (idx+1 < nfuncs) ? func_vas[idx+1] : text_va + text_sz;
    uint64_t fe = func_end_va_reachable(text_data, text_va, text_sz, fs, nx);
    uint32_t fsz = (uint32_t)(fe - fs);
    uint32_t icnt = fsz / 4;
    const uint32_t *src = (const uint32_t*)(text_data + (fs - text_va));

    LOG("\n========================================\n");
    LOG("  FUNC[%d] @ 0x%llx (%u insns, %u bytes)\n", idx, (unsigned long long)fs, icnt, fsz);
    LOG("========================================\n");

    LOG("\n--- ORIGINAL ARM64 ---\n");
    for(uint32_t i = 0; i < icnt; i++){
        uint64_t iva = fs + i * 4;
        LOG("  [%3u] 0x%012llx: %08X  %s\n", i, (unsigned long long)iva, src[i],
            arm64_disasm_brief(src[i], iva));
    }

    LOG("\n--- VM TRANSLATION ---\n");
    VmBytecode bc;
    vm_bc_init(&bc);
    uint64_t ext_calls[256];
    int n_ext = 0;
    uint32_t *native_words = (uint32_t*)calloc(2048, sizeof(uint32_t));
    int n_native = 0;
    int *insn_to_vm = (int*)calloc(icnt + 2, sizeof(int));

    bool ok = ldvq2306_translate_arm64_to_vm_ex(src, icnt, fs, text_va, text_sz, &bc,
                                        ext_calls, &n_ext, 256,
                                        native_words, &n_native, 2048,
                                        insn_to_vm);
    if(!ok){
        LOG("[!] TRANSLATION FAILED for func[%d]\n", idx);
        free(native_words);
        vm_bc_free(&bc);
        return;
    }

    LOG("Translated: %u ARM64 -> %u VM insns, %d ext calls, %d native tramps\n",
        icnt, bc.count, n_ext, n_native);

    LOG("\n--- VM BYTECODE ---\n");
    for(uint32_t i = 0; i < bc.count; i++){
        vm_insn_t *vi = &bc.insns[i];
        LOG("  [%3u] op=0x%02X %-12s rd=%2u rn=%2u rm=%2u imm=0x%08X",
            i, vi->opcode, vm_op_name(vi->opcode), vi->rd, vi->rn, vi->rm, vi->imm);
        if(vi->opcode == VM_OP_BL_NATIVE || vi->opcode == VM_OP_LOAD_ABS){
            uint64_t addr = ((uint64_t)vi->rm << 32) | vi->imm;
            LOG("  [abs=0x%llx]", (unsigned long long)addr);
        }
        if(vi->opcode == VM_OP_NATIVE){
            if(vi->imm < (uint32_t)n_native)
                LOG("  [native=0x%08X -> %s]", native_words[vi->imm],
                    arm64_disasm_brief(native_words[vi->imm], 0));
        }
        if(vi->opcode == VM_OP_B || vi->opcode == VM_OP_B_COND ||
           vi->opcode == VM_OP_CBZ || vi->opcode == VM_OP_CBNZ ||
           vi->opcode == VM_OP_TBZ || vi->opcode == VM_OP_TBNZ){
            int32_t rel = (int32_t)vi->imm;
            int32_t target = (int32_t)(i + 1) + rel;
            LOG("  [-> VM[%d]]", target);
        }
        LOG("\n");
    }

    if(n_native > 0){
        LOG("\n--- NATIVE TRAMPOLINE TABLE (%d entries) ---\n", n_native);
        for(int i = 0; i < n_native; i++){
            LOG("  [%2d] 0x%08X  %s\n", i, native_words[i],
                arm64_disasm_brief(native_words[i], 0));
        }
    }

    LOG("\n--- INSTRUCTION-BY-INSTRUCTION COMPARISON ---\n");

    int ok_cnt = 0, native_cnt = 0, fused_cnt = 0, err_cnt = 0;
    for(uint32_t ai = 0; ai < icnt; ai++){
        int vm_s = insn_to_vm[ai];
        int vm_e = insn_to_vm[ai + 1];
        if(ai + 1 >= icnt) vm_e = (int)bc.count;

        uint64_t iva = fs + (uint64_t)ai * 4;
        uint32_t w = src[ai];

        bool is_fused_adrp = false;
        if(is_adrp(w) && ai+1 < icnt){
            uint32_t nxt = src[ai+1];
            int rd = w & 0x1F;
            if(((nxt&0xFFC00000)==0x91000000u && (int)((nxt>>5)&0x1F)==rd && (int)(nxt&0x1F)==rd) ||
               ((nxt&0xFFC00000)==0xF9400000u && (int)((nxt>>5)&0x1F)==rd && (int)(nxt&0x1F)==rd)){
                is_fused_adrp = true;
            }
        }

        InsnMapping m;
        m.arm_idx = (int)ai;
        m.vm_start = vm_s;
        m.vm_end = vm_e;
        m.is_fused = is_fused_adrp;
        m.is_native = (vm_s < (int)bc.count && bc.insns[vm_s].opcode == VM_OP_NATIVE);

        const char *ver_err = verify_mapping(src, icnt, fs, &bc, &m, native_words, n_native);

        const char *status;
        if(m.is_native){
            status = "NATIVE";
            native_cnt++;
        } else if(ver_err){
            status = "ERROR";
            err_cnt++;
        } else {
            status = "OK";
            ok_cnt++;
        }
        if(is_fused_adrp) fused_cnt++;

        LOG("  [%3u] ARM64: 0x%08X  %-40s\n", ai, w, arm64_disasm_brief(w, iva));
        if(is_fused_adrp && ai+1 < icnt){
            LOG("        +FUSED: 0x%08X  %s\n", src[ai+1], arm64_disasm_brief(src[ai+1], iva+4));
            ai++;
        }

        for(int v = vm_s; v < vm_e; v++){
            const vm_insn_t *vi = &bc.insns[v];
            LOG("        VM[%3d]: %-12s rd=%2u rn=%2u rm=%2u imm=0x%08X",
                v, vm_op_name(vi->opcode), vi->rd, vi->rn, vi->rm, vi->imm);
            if(vi->opcode == VM_OP_LOAD_ABS || vi->opcode == VM_OP_BL_NATIVE){
                uint64_t addr = ((uint64_t)vi->rm << 32) | vi->imm;
                LOG(" [abs=0x%llx]", (unsigned long long)addr);
            }
            LOG("\n");
        }
        LOG("        STATUS: %s", status);
        if(ver_err) LOG(" (%s)", ver_err);
        LOG("\n\n");
    }

    LOG("--- COMPARISON SUMMARY ---\n");
    LOG("  Total ARM64 insns: %u, VM insns: %u\n", icnt, bc.count);
    LOG("  OK:     %d\n", ok_cnt);
    LOG("  NATIVE: %d\n", native_cnt);
    LOG("  FUSED:  %d (ADRP+ADD/LDR pairs)\n", fused_cnt);
    LOG("  ERRORS: %d\n", err_cnt);

    LOG("\n--- VERIFICATION ---\n");
    verify_branch_targets(&bc, icnt);
    verify_abs_addresses(&bc, text_va, text_sz);

    LOG("\n--- STUB GENERATION TEST ---\n");
    uint32_t *stub_code = (uint32_t*)calloc(8192, sizeof(uint32_t));
    int stub_cnt = ldvq2306_emit_vm_interpreter_stub(stub_code, 8192, 0x10000, bc.count, 0x1000, 0x20000, (uint32_t)n_native);
    if(stub_cnt > 0)
        LOG("  Stub OK: %d insns (%d bytes)\n", stub_cnt, stub_cnt * 4);
    else
        LOG("  STUB GENERATION FAILED: returned %d\n", stub_cnt);

    free(stub_code);
    free(insn_to_vm);
    free(native_words);
    vm_bc_free(&bc);
}

int main(int argc, char **argv){
    if(argc < 2){
        fprintf(stderr, "usage: %s input.dylib [func_idx | --all] [--log=file.txt]\n", argv[0]);
        return 1;
    }

    int force_idx = -1;
    bool do_all = false;
    const char *log_path = NULL;

    for(int i = 2; i < argc; i++){
        if(strcmp(argv[i], "--all") == 0){
            do_all = true;
        } else if(strncmp(argv[i], "--log=", 6) == 0){
            log_path = argv[i] + 6;
        } else {
            force_idx = atoi(argv[i]);
        }
    }

    if(log_path){
        g_log = fopen(log_path, "w");
        if(!g_log){
            fprintf(stderr, "[!] Cannot open log file: %s\n", log_path);
            return 1;
        }
        time_t now = time(NULL);
        LOG("=== VM Parse Log ===\n");
        LOG("Input: %s\n", argv[1]);
        LOG("Date:  %s", ctime(&now));
        LOG("Args: ");
        for(int i = 0; i < argc; i++) LOG(" %s", argv[i]);
        LOG("\n\n");
    }

    uint32_t fsize = 0;
    uint8_t *fdata = load_file(argv[1], &fsize);
    if(!fdata) return 1;
    DylibInfo di;
    if(!parse_dylib(fdata, fsize, &di)){
        fprintf(stderr, "parse fail\n");
        return 1;
    }

    uint64_t *func_vas = (uint64_t*)malloc((size_t)MAX_FUNCS * sizeof(uint64_t));
    int nfuncs = get_func_starts(fdata, &di, func_vas, MAX_FUNCS);

    LOG("=== FUNCTION LIST ===\n");
    LOG("%-5s %-14s %-7s %-7s %-10s %s\n", "IDX", "VA", "SIZE", "INSNS", "COMPLEX", "PROLOGUE");
    for(int i = 0; i < nfuncs; i++){
        uint64_t fs = func_vas[i];
        uint64_t nx = (i+1 < nfuncs) ? func_vas[i+1] : di.text_va + di.text_sz;
        uint64_t fe = func_end_va_reachable(fdata + di.text_fo, di.text_va, di.text_sz, fs, nx);
        uint32_t sz = (uint32_t)(fe - fs);
        char pro[16];
        detect_prologue(fdata + di.text_fo, di.text_va, fs, pro);
        uint32_t cplx = compute_func_complexity(fdata + di.text_fo, di.text_va, fs, sz);
        bool safe = (sz >= MIN_FUNC_SIZE
            && !has_computed_branch(fdata + di.text_fo, di.text_va, fs, sz)
            && func_is_ultra_safe(fdata + di.text_fo, di.text_va, fs, sz));
        LOG("[%3d] 0x%012llX %6u %6u %8u %s%s\n",
            i, (unsigned long long)fs, sz, sz/4, cplx, pro, safe ? "" : " [UNSAFE]");
    }

    if(do_all){
        LOG("\n=== BATCH MODE: Testing all eligible functions ===\n");
        int tested = 0;
        for(int i = 0; i < nfuncs; i++){
            uint64_t fs = func_vas[i];
            uint64_t nx = (i+1 < nfuncs) ? func_vas[i+1] : di.text_va + di.text_sz;
            uint64_t fe = func_end_va_reachable(fdata + di.text_fo, di.text_va, di.text_sz, fs, nx);
            uint32_t sz = (uint32_t)(fe - fs);
            if(sz < MIN_FUNC_SIZE) continue;
            if(has_computed_branch(fdata + di.text_fo, di.text_va, fs, sz)) continue;

            tested++;
            analyze_func(fdata + di.text_fo, di.text_va, di.text_sz, func_vas, nfuncs, i);
        }
        LOG("\n=== BATCH SUMMARY ===\n");
        LOG("  Tested: %d functions\n", tested);
    } else {
        int vm_idx = force_idx;
        if(vm_idx < 0){
            uint32_t best_c = 0;
            for(int i = 0; i < nfuncs; i++){
                uint64_t fs = func_vas[i];
                uint64_t nx = (i+1 < nfuncs) ? func_vas[i+1] : di.text_va + di.text_sz;
                uint64_t fe = func_end_va_reachable(fdata + di.text_fo, di.text_va, di.text_sz, fs, nx);
                uint32_t sz = (uint32_t)(fe - fs);
                if(sz < MIN_FUNC_SIZE) continue;
                uint32_t c = compute_func_complexity(fdata + di.text_fo, di.text_va, fs, sz);
                if(c > best_c){ best_c = c; vm_idx = i; }
            }
        }
        if(vm_idx < 0 || vm_idx >= nfuncs){
            LOG("[!] No valid function\n");
            free(func_vas);
            free(fdata);
            if(g_log) fclose(g_log);
            return 1;
        }
        analyze_func(fdata + di.text_fo, di.text_va, di.text_sz, func_vas, nfuncs, vm_idx);
    }

    free(func_vas);
    free(fdata);
    if(g_log){
        LOG("\n=== END OF LOG ===\n");
        fclose(g_log);
        printf("[*] Log written to: %s\n", log_path);
    }
    return 0;
}
