#include "macho.h"
#include "pcrel.h"
#include "arm64_enc.h"
#include "util.h"

bool parse_dylib(const uint8_t *d, uint32_t sz, DylibInfo *di){
    memset(di,0,sizeof(*di));
    if(sz<32) return false;
    const mh64 *h=(const mh64*)d;
    if(h->magic!=MH_MAGIC_64) return false;
    di->first_section_fo=0xFFFFFFFFFFFFFFFFull;
    di->insert_point=align_up(32+h->sizeofcmds+256,16);
    const uint8_t *p=d+32;
    for(uint32_t i=0;i<h->ncmds;i++){
        const lc_t *cmd=(const lc_t*)p;
        if(cmd->cmd==LC_SEGMENT_64){
            const seg64 *sg=(const seg64*)p;
            if(!strncmp(sg->segname,"__TEXT",6)&&sg->segname[6]==0){
                di->tseg_va=sg->vmaddr; di->tseg_fo=sg->fileoff;
                di->tseg_fsz=sg->filesize; di->tseg_vsz=sg->vmsize;
            }
            if(!strncmp(sg->segname,"__LINKEDIT",10)){
                di->le_va=sg->vmaddr; di->le_fo=sg->fileoff;
                di->le_fsz=sg->filesize; di->le_vsz=sg->vmsize;
            }
            const uint8_t *sp=p+sizeof(seg64);
            for(uint32_t j=0;j<sg->nsects;j++){
                const sec64 *sc=(const sec64*)sp;
                if(!strncmp(sc->sectname,"__text",16)&&!strncmp(sc->segname,"__TEXT",6)){
                    di->text_va=sc->addr; di->text_fo=sc->offset; di->text_sz=sc->size;
                }
                if(!strncmp(sc->sectname,"__stubs",16)){
                    di->stubs_va=sc->addr; di->stubs_fo=sc->offset; di->stubs_sz=sc->size;
                }
                if(!strncmp(sc->sectname,"__stub_helper",16)){
                    di->stub_helper_va=sc->addr; di->stub_helper_fo=sc->offset; di->stub_helper_sz=sc->size;
                }
                if((sc->flags&0xFF)==S_MOD_INIT_FUNC_PTRS){
                    di->mod_init_fo=sc->offset; di->mod_init_sz=sc->size; di->mod_init_va=sc->addr;
                }
                if(sc->offset&&sc->offset<di->first_section_fo) di->first_section_fo=sc->offset;
                sp+=sizeof(sec64);
            }
        }
        p+=cmd->cmdsize;
    }
    return di->text_sz>0;
}

int get_func_starts(const uint8_t *d, const DylibInfo *di, uint64_t *out, int max_out){
    const mh64 *h=(const mh64*)d;
    const uint8_t *p=d+32; int cnt=0;
    for(uint32_t i=0;i<h->ncmds;i++){
        const lc_t *cmd=(const lc_t*)p;
        if(cmd->cmd==LC_FUNCTION_STARTS){
            const linkedit_lc *ll=(const linkedit_lc*)p;
            const uint8_t *fs=d+ll->dataoff, *fe=fs+ll->datasize;
            uint64_t addr=di->tseg_va;
            while(fs<fe){
                uint64_t dd=0; int sh=0; uint8_t fb;
                do{ if(fs>=fe)break; fb=*fs++; dd|=((uint64_t)(fb&0x7F))<<sh; sh+=7; }while(fb&0x80);
                if(!dd&&cnt>0)break;
                addr+=dd;
                if(!cnt&&!dd)continue;
                if(addr>=di->text_va&&addr<di->text_va+di->text_sz){
                    if(cnt<max_out) out[cnt++]=addr;
                }
            }
            break;
        }
        p+=cmd->cmdsize;
    }
    return cnt;
}

const char *find_symbol_name(const uint8_t *d, uint32_t dsz, uint64_t va){
    const mh64 *h=(const mh64*)d;
    uint32_t symoff=0,nsyms=0,stroff=0,strsize=0;
    const uint8_t *p=d+32;
    for(uint32_t i=0;i<h->ncmds;i++){
        const lc_t *lc=(const lc_t*)p;
        if(lc->cmd==LC_SYMTAB){
            const symtab_lc *sc=(const symtab_lc*)p;
            symoff=sc->symoff; nsyms=sc->nsyms; stroff=sc->stroff; strsize=sc->strsize;
        }
        p+=lc->cmdsize;
    }
    if(!symoff||!nsyms) return NULL;
    for(uint32_t i=0;i<nsyms;i++){
        uint32_t so=symoff+i*16;
        if(so+16>dsz) break;
        nlist_64_t sym; memcpy(&sym,d+so,sizeof(sym));
        if(sym.n_value==va && sym.n_strx>0 && (uint32_t)sym.n_strx<strsize){
            return (const char*)(d+stroff+sym.n_strx);
        }
    }
    return NULL;
}

void detect_prologue(const uint8_t *text_data, uint64_t text_va, uint64_t fva, char *out){
    uint64_t off = fva - text_va;
    uint32_t w = rd32(text_data + off);
    if((w&0xFFC00000)==0xA9800000 && ((w>>5)&0x1F)==31)
        strcpy(out, "STP");
    else if((w&0xFF0003FF)==0xD10003FF)
        strcpy(out, "SUB SP");
    else if(w==0xD503237Fu)
        strcpy(out, "PACIBSP");
    else if(w==0xD503233Fu)
        strcpy(out, "PACISP");
    else if(w==0xD65F03C0u)
        strcpy(out, "RET");
    else if((w&0xFC000000)==0x14000000u)
        strcpy(out, "B");
    else if((w&0x9F000000u)==0x90000000u)
        strcpy(out, "ADRP");
    else if((w&0x9F000000u)==0x10000000u)
        strcpy(out, "ADR");
    else if((w&0xFF800000u)==0xD2800000u)
        strcpy(out, "MOV");
    else if((w&0xFFE00000u)==0xAA000000u)
        strcpy(out, "MOV Xn");
    else if((w&0x7FC00000)==0x29000000 || (w&0x7FC00000)==0x29800000)
        strcpy(out, "STP(var)");
    else if(w==NOP)
        strcpy(out, "NOP");
    else if((w&0xFC000000)==0x94000000u)
        strcpy(out, "BL");
    else if((w&0xFF000010)==0x54000000u)
        strcpy(out, "B.cond");
    else if((w&0xFF000000)==0x34000000u||
            (w&0xFF000000)==0x35000000u||
            (w&0xFF000000)==0xB4000000u||
            (w&0xFF000000)==0xB5000000u)
        strcpy(out, "CBx");
    else if((w&0xFFE0001F)==0xD4200000u)
        strcpy(out, "BRK");
    else if((w&0xFF0003E0)==0xD10003E0)
        strcpy(out, "SUB Xn");
    else
        strcpy(out, "-");
}

uint32_t compute_func_complexity(const uint8_t *text_data, uint64_t text_va,
                                  uint64_t fva, uint32_t fsz){
    if(!text_data || fsz < 4) return 0;
    uint64_t off = fva - text_va;
    uint32_t insns = fsz / 4;
    uint32_t score = insns;
    uint32_t cond_br = 0, calls = 0, mem_ops = 0;
    for(uint32_t i = 0; i < insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if((w&0xFF000010)==0x54000000) cond_br++;
        if((w&0xFF000000)==0x34000000||(w&0xFF000000)==0x35000000) cond_br++;
        if((w&0xFF000000)==0xB4000000||(w&0xFF000000)==0xB5000000) cond_br++;
        if((w&0x7E000000)==0x36000000) cond_br++;
        if((w&0xFC000000)==0x94000000) calls++;
        if((w&0xBF400000)==0xB9000000||(w&0xFF400000)==0xF9000000) mem_ops++;
    }
    score += cond_br * 8;
    score += calls * 3;
    score += mem_ops;
    return score;
}

bool has_computed_branch(const uint8_t *text_data, uint64_t text_va, uint64_t fva, uint32_t fsz){
    if(!text_data || fsz < 4) return false;
    uint64_t off = fva - text_va;
    uint32_t n = fsz / 4;
    for(uint32_t i=0; i<n; i++){
        uint32_t w = rd32(text_data + off + i*4);

        if((w&0xFFFFFC1Fu)==0xD61F0000u){
            int rn = (int)((w>>5)&0x1F);
            if(rn == 30) continue;
            if(rn == 16 || rn == 17) continue;

            bool is_tail = false;
            if(i > 0){
                uint32_t prev = rd32(text_data + off + (i-1)*4);
                if((prev & 0xFFC00000u) == 0xF9400000u && (int)(prev & 0x1F) == rn)
                    is_tail = true;
                if((prev & 0xFF200000u) == 0x8B000000u && (int)(prev & 0x1F) == rn)
                    is_tail = true;
            }
            if(i >= n - 2) is_tail = true;
            if(!is_tail) return true;
        }

        if((w&0xFEFFF800u)==0xD61F0800u) return true;
    }
    return false;
}

bool func_is_ultra_safe(const uint8_t *text_data, uint64_t text_va,
                         uint64_t fva, uint32_t fsz)
{
    if(!text_data || fsz < MIN_FUNC_SIZE) return false;
    uint64_t off = fva - text_va;
    uint32_t insns = fsz / 4;
    uint32_t w0 = rd32(text_data + off);

    bool good_prolog = ((w0&0xFFC00000)==0xA9800000 && ((w0>>5)&0x1F)==31)
                    || ((w0&0xFF0003FF)==0xD10003FF)
                    || ((w0&0xFF000000)==0xD1000000 && (w0&0x1F)==31);
    if(!good_prolog) return false;

    uint32_t pac_count = 0;
    uint32_t ldr_lit = 0;
    uint32_t stp_cnt = 0, ldp_cnt = 0;
    for(uint32_t i = 0; i < insns; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if(w==0xD503237Fu||w==0xD503233Fu||w==0xD50323BFu||w==0xD50323FFu) pac_count++;
        if((w&0xFF000000)==0x58000000) ldr_lit++;
        if((w&0xFFC00000)==0xA9800000 && ((w>>5)&0x1F)==31) stp_cnt++;
        if((w&0xFFC00000)==0xA8C00000 && ((w>>5)&0x1F)==31) ldp_cnt++;
    }
    if(pac_count > 0) return false;
    if(ldr_lit * 20 > insns) return false;
    uint32_t unpaired_stp = (stp_cnt > ldp_cnt) ? (stp_cnt - ldp_cnt) : (ldp_cnt - stp_cnt);
    if(unpaired_stp > 3) return false;
    return true;
}

void select_heaviest_n(FuncEntry *funcs, int nfuncs,
                       const uint8_t *text_data, uint64_t text_va, int n)
{
    int *order = (int*)malloc((size_t)nfuncs * sizeof(int));
    if(!order) return;
    for(int i=0;i<nfuncs;i++) order[i]=i;
    for(int i=0;i<nfuncs-1;i++){
        for(int j=i+1;j<nfuncs;j++){
            if(funcs[order[j]].complexity > funcs[order[i]].complexity){
                int tmp=order[i]; order[i]=order[j]; order[j]=tmp;
            }
        }
    }
    int picked = 0;
    for(int i=0;i<nfuncs && picked<n;i++){
        int idx = order[i];
        if(funcs[idx].size >= MIN_FUNC_SIZE
           && !has_computed_branch(text_data, text_va, funcs[idx].va, funcs[idx].size)){
            funcs[idx].selected = true;
            picked++;
        }
    }
    free(order);
}

void select_by_offset_range(FuncEntry *funcs, int nfuncs,
                            uint64_t range_lo, uint64_t range_hi,
                            const uint8_t *text_data, uint64_t text_va)
{
    for(int i=0;i<nfuncs;i++){
        uint64_t fva = funcs[i].va;
        if(fva >= range_lo && fva < range_hi
           && funcs[i].size >= MIN_FUNC_SIZE
           && !has_computed_branch(text_data, text_va, fva, funcs[i].size)){
            funcs[i].selected = true;
        }
    }
}

void select_ultra_safe(FuncEntry *funcs, int nfuncs,
                       const uint8_t *text_data, uint64_t text_va)
{
    (void)text_data; (void)text_va;
    for(int i=0;i<nfuncs;i++){
        if(funcs[i].is_safe) funcs[i].selected = true;
    }
}

#define REBASE_VA_LOW_MASK 0x0000FFFFFFFFFFFFull
static void fix_one_rebase_slot(uint8_t *out, uint64_t fo, uint32_t out_sz,
    uint64_t shift_threshold, uint64_t shift_end, uint64_t shift_amount)
{
    if(fo+8>out_sz) return;
    uint64_t val=rd64(out+fo);
    if(val>=shift_threshold&&val<shift_end){
        wr64(out+fo,val+shift_amount);
        return;
    }
    uint64_t tag=val&~REBASE_VA_LOW_MASK;
    uint64_t va =val& REBASE_VA_LOW_MASK;
    if(tag && va>=shift_threshold && va<shift_end)
        wr64(out+fo, tag | (va+shift_amount));
}

void fix_rebase_pointer_values(uint8_t *out, uint32_t out_sz,
    const uint8_t *rebase_data, uint32_t rebase_size,
    const SegLayout *layout, uint64_t shift_threshold, uint64_t shift_end, uint64_t shift_amount)
{
    if(!rebase_data||!rebase_size) return;
    int seg_idx=0; uint64_t offset=0;
    const uint8_t *p=rebase_data, *end=p+rebase_size;
    while(p<end){
        uint8_t byte=*p++; uint8_t opcode=byte&0xF0; uint8_t imm=byte&0x0F;
        switch(opcode){
        case REBASE_OPCODE_DONE: return;
        case REBASE_OPCODE_SET_TYPE_IMM: break;
        case REBASE_OPCODE_SET_SEGMENT_AND_OFFSET_ULEB: seg_idx=imm; offset=read_uleb128(&p,end); break;
        case REBASE_OPCODE_ADD_ADDR_ULEB: offset+=read_uleb128(&p,end); break;
        case REBASE_OPCODE_ADD_ADDR_IMM_SCALED: offset+=(uint64_t)imm*8; break;
        case REBASE_OPCODE_DO_REBASE_IMM_TIMES:
            for(int i=0;i<imm;i++){
                if(seg_idx<layout->nseg){ uint64_t fo=layout->seg_fileoff[seg_idx]+offset;
                    fix_one_rebase_slot(out,fo,out_sz,shift_threshold,shift_end,shift_amount); }
                offset+=8;
            } break;
        case REBASE_OPCODE_DO_REBASE_ULEB_TIMES: {
            uint64_t count=read_uleb128(&p,end);
            for(uint64_t i=0;i<count;i++){
                if(seg_idx<layout->nseg){ uint64_t fo=layout->seg_fileoff[seg_idx]+offset;
                    fix_one_rebase_slot(out,fo,out_sz,shift_threshold,shift_end,shift_amount); }
                offset+=8;
            } break; }
        case REBASE_OPCODE_DO_REBASE_ADD_ADDR_ULEB: {
            if(seg_idx<layout->nseg){ uint64_t fo=layout->seg_fileoff[seg_idx]+offset;
                fix_one_rebase_slot(out,fo,out_sz,shift_threshold,shift_end,shift_amount); }
            offset+=read_uleb128(&p,end)+8; break; }
        case REBASE_OPCODE_DO_REBASE_ULEB_TIMES_SKIPPING_ULEB: {
            uint64_t count=read_uleb128(&p,end); uint64_t skip=read_uleb128(&p,end);
            for(uint64_t i=0;i<count;i++){
                if(seg_idx<layout->nseg){ uint64_t fo=layout->seg_fileoff[seg_idx]+offset;
                    fix_one_rebase_slot(out,fo,out_sz,shift_threshold,shift_end,shift_amount); }
                offset+=skip+8;
            } break; }
        default: break;
        }
    }
}

void fix_symbol_values(uint8_t *out, uint32_t out_sz, uint32_t symoff, uint32_t nsyms,
    uint64_t shift_threshold, uint64_t shift_end, uint64_t shift_amount)
{
    for(uint32_t i=0;i<nsyms;i++){
        uint32_t off=symoff+i*16;
        if(off+16>out_sz) break;
        nlist_64_t sym; memcpy(&sym,out+off,sizeof(sym));
        if(sym.n_value>=shift_threshold&&sym.n_value<shift_end)
            sym.n_value+=shift_amount;
        memcpy(out+off,&sym,sizeof(sym));
    }
}

static uint64_t trie_read_uleb(const uint8_t *p, uint32_t *pos, uint32_t end){
    uint64_t r=0; int s=0;
    while(*pos<end){ uint8_t b=p[(*pos)++]; r|=((uint64_t)(b&0x7F))<<s; if(!(b&0x80))break; s+=7; }
    return r;
}

static uint32_t uleb_len(uint64_t v){ uint32_t n=0; do{ n++; v>>=7; }while(v); return n; }

static int trie_walk(const uint8_t *trie, uint32_t trie_base, uint32_t node_off, uint32_t end,
    char *prefix, int prefix_len, ExportEntry **parr, int *pn, int *pcap)
{
    uint32_t pos=trie_base+node_off;
    if(pos>=end) return 0;
    uint64_t term_size=trie_read_uleb(trie,&pos,end);
    uint32_t payload_start=pos;
    if(term_size>0){
        uint64_t flags=trie_read_uleb(trie,&pos,end);
        ExportEntry e; memset(&e,0,sizeof(e));
        if(prefix_len>510) prefix_len=510;
        memcpy(e.name,prefix,(size_t)prefix_len); e.name[prefix_len]=0;
        e.flags=flags;
        if(flags&0x08){
            e.offset=trie_read_uleb(trie,&pos,end);
            int j=0;
            while(pos<end && trie[pos] && j<510){ e.reexport_lib[j++]=(char)trie[pos++]; }
            if(pos<end && trie[pos]==0) pos++;
            e.reexport_lib[j]=0;
        } else {
            e.offset=trie_read_uleb(trie,&pos,end);
            if(flags&0x10) e.resolver=trie_read_uleb(trie,&pos,end);
        }
        if(*pn>=*pcap){
            int nc=(*pcap)?(*pcap)*2:64;
            ExportEntry *na=(ExportEntry*)realloc(*parr,(size_t)nc*sizeof(ExportEntry));
            if(!na) return -1;
            *parr=na; *pcap=nc;
        }
        (*parr)[(*pn)++]=e;
    }
    pos=payload_start+(uint32_t)term_size;
    if(pos>=end) return 0;
    uint8_t child_count=trie[pos++];
    for(int c=0;c<child_count;c++){
        int edge_len=0;
        while(pos<end && trie[pos]!=0){
            if(prefix_len+edge_len<510) prefix[prefix_len+edge_len]=(char)trie[pos];
            edge_len++; pos++;
        }
        if(pos<end) pos++;
        uint64_t child_off=trie_read_uleb(trie,&pos,end);
        int npl=prefix_len+edge_len; if(npl>510) npl=510;
        prefix[npl]=0;
        if(trie_walk(trie,trie_base,(uint32_t)child_off,end,prefix,npl,parr,pn,pcap)) return -1;
    }
    return 0;
}

static void trie_write_uleb(uint8_t *buf, uint32_t *pos, uint64_t val){
    do{ uint8_t b=(uint8_t)(val&0x7F); val>>=7; if(val)b|=0x80; buf[(*pos)++]=b; }while(val);
}

typedef struct TrieN {
    char            edge[512];
    uint8_t        *term;
    uint32_t        term_len;
    struct TrieN  **kids;
    int             nkids, kcap;
    uint32_t        node_off;
} TrieN;

static TrieN *trie_new_node(void){ return (TrieN*)calloc(1,sizeof(TrieN)); }

static void trie_free(TrieN *n){
    if(!n) return;
    for(int c=0;c<n->nkids;c++) trie_free(n->kids[c]);
    if(n->kids) free(n->kids);
    if(n->term) free(n->term);
    free(n);
}

static int trie_add_kid(TrieN *p, TrieN *c){
    if(p->nkids>=p->kcap){
        int nc=p->kcap?p->kcap*2:4;
        TrieN **k=(TrieN**)realloc(p->kids,(size_t)nc*sizeof(TrieN*));
        if(!k) return -1;
        p->kids=k; p->kcap=nc;
    }
    p->kids[p->nkids++]=c; return 0;
}

static int trie_insert(TrieN *root, const char *name, const uint8_t *term, uint32_t term_len){
    TrieN *node=root;
    uint32_t i=0, nlen=(uint32_t)strlen(name);
    for(;;){
        if(i==nlen){
            if(node->term) free(node->term);
            node->term=(uint8_t*)malloc(term_len?term_len:1);
            if(!node->term) return -1;
            memcpy(node->term,term,term_len); node->term_len=term_len;
            return 0;
        }
        TrieN *kid=NULL; int kidx=-1;
        for(int c=0;c<node->nkids;c++){
            if((unsigned char)node->kids[c]->edge[0]==(unsigned char)name[i]){ kid=node->kids[c]; kidx=c; break; }
        }
        if(!kid){
            TrieN *leaf=trie_new_node(); if(!leaf) return -1;
            uint32_t el=nlen-i; if(el>510) el=510;
            memcpy(leaf->edge,name+i,el); leaf->edge[el]=0;
            leaf->term=(uint8_t*)malloc(term_len?term_len:1);
            if(!leaf->term){ free(leaf); return -1; }
            memcpy(leaf->term,term,term_len); leaf->term_len=term_len;
            if(trie_add_kid(node,leaf)){ trie_free(leaf); return -1; }
            return 0;
        }
        uint32_t el=(uint32_t)strlen(kid->edge), k=0;
        while(k<el && i+k<nlen && kid->edge[k]==name[i+k]) k++;
        if(k==el){ i+=k; node=kid; continue; }

        TrieN *mid=trie_new_node(); if(!mid) return -1;
        memcpy(mid->edge,kid->edge,k); mid->edge[k]=0;
        memmove(kid->edge,kid->edge+k,(size_t)(el-k)+1);
        if(trie_add_kid(mid,kid)){ trie_free(mid); return -1; }
        node->kids[kidx]=mid;
        node=mid; i+=k;
    }
}

static int trie_count(const TrieN *n){
    int t=1; for(int c=0;c<n->nkids;c++) t+=trie_count(n->kids[c]); return t;
}
static int trie_collect(TrieN *n, TrieN **arr, int *cnt, int cap){
    if(*cnt>=cap) return -1;
    arr[(*cnt)++]=n;
    for(int c=0;c<n->nkids;c++) if(trie_collect(n->kids[c],arr,cnt,cap)) return -1;
    return 0;
}
static uint32_t trie_node_size(const TrieN *n){
    uint32_t s=uleb_len(n->term_len)+n->term_len+1;
    for(int c=0;c<n->nkids;c++)
        s+=(uint32_t)strlen(n->kids[c]->edge)+1+uleb_len(n->kids[c]->node_off);
    return s;
}
static void trie_emit_node(const TrieN *n, uint8_t *buf, uint32_t *p){
    trie_write_uleb(buf,p,n->term_len);
    if(n->term_len){ memcpy(buf+*p,n->term,n->term_len); *p+=n->term_len; }
    buf[(*p)++]=(uint8_t)n->nkids;
    for(int c=0;c<n->nkids;c++){
        const char *e=n->kids[c]->edge;
        for(uint32_t j=0;e[j];j++) buf[(*p)++]=(uint8_t)e[j];
        buf[(*p)++]=0;
        trie_write_uleb(buf,p,n->kids[c]->node_off);
    }
}

static uint32_t trie_encode_term(const ExportEntry *e, uint64_t shift, uint8_t *buf){
    uint32_t p=0;
    trie_write_uleb(buf,&p,e->flags);
    if(e->flags&0x08){
        trie_write_uleb(buf,&p,e->offset);
        const char *s=e->reexport_lib;
        for(uint32_t i=0;s[i] && p<590;i++) buf[p++]=(uint8_t)s[i];
        buf[p++]=0;
    } else if(e->flags&0x10){
        trie_write_uleb(buf,&p,e->offset+shift);
        trie_write_uleb(buf,&p,e->resolver+shift);
    } else {
        trie_write_uleb(buf,&p,e->offset+shift);
    }
    return p;
}

static uint8_t *build_export_trie(ExportEntry *entries, int n, uint64_t shift, uint32_t *out_size){
    *out_size=0;
    TrieN *root=trie_new_node(); if(!root) return NULL;
    for(int i=0;i<n;i++){
        uint8_t term[600]; uint32_t tl=trie_encode_term(&entries[i],shift,term);
        if(trie_insert(root,entries[i].name,term,tl)){ trie_free(root); return NULL; }
    }
    int cap=trie_count(root);
    TrieN **arr=(TrieN**)malloc((size_t)cap*sizeof(TrieN*));
    if(!arr){ trie_free(root); return NULL; }
    int cnt=0;
    if(trie_collect(root,arr,&cnt,cap)){ free(arr); trie_free(root); return NULL; }
    for(int i=0;i<cnt;i++) if(arr[i]->nkids>255){ free(arr); trie_free(root); return NULL; }

    uint32_t total=0; int changed=1, guard=0;
    while(changed && guard<128){
        changed=0; guard++;
        uint32_t cur=0;
        for(int i=0;i<cnt;i++){
            if(arr[i]->node_off!=cur){ arr[i]->node_off=cur; changed=1; }
            cur+=trie_node_size(arr[i]);
        }
        total=cur;
    }
    uint8_t *buf=(uint8_t*)calloc(1,(size_t)total+16);
    if(!buf){ free(arr); trie_free(root); return NULL; }
    uint32_t p=0;
    for(int i=0;i<cnt;i++) trie_emit_node(arr[i],buf,&p);
    free(arr); trie_free(root);
    *out_size=p;
    return buf;
}

void fix_export_trie(uint8_t *out, uint32_t *out_sz, uint32_t max_alloc, uint64_t shift_amount){
    mh64 *hdr=(mh64*)out;
    uint32_t exp_off=0,exp_size=0; uint8_t *exp_lc=NULL; int is_separate=0;
    uint8_t *lcp=out+32;
    for(uint32_t i=0;i<hdr->ncmds;i++){
        lc_t *lc=(lc_t*)lcp;
        if(lc->cmd==LC_DYLD_EXPORTS_TRIE||lc->cmd==0x80000033u){
            linkedit_lc *ld=(linkedit_lc*)lcp;
            exp_off=ld->dataoff; exp_size=ld->datasize; exp_lc=lcp; is_separate=1;
        }
        if((lc->cmd==LC_DYLD_INFO_ONLY||lc->cmd==0x22)&&!exp_lc){
            dyldinfo_lc *di2=(dyldinfo_lc*)lcp;
            exp_off=di2->export_off; exp_size=di2->export_size; exp_lc=lcp; is_separate=0;
        }
        lcp+=lc->cmdsize;
    }
    if(!exp_lc||!exp_off||!exp_size) return;
    if(exp_off+exp_size>*out_sz) return;
    ExportEntry *entries=NULL; int nentries=0, ecap=0;
    char prefix[512]={0};
    if(trie_walk(out,exp_off,0,exp_off+exp_size,prefix,0,&entries,&nentries,&ecap)){
        if(entries) free(entries);
        return;
    }
    if(nentries==0){ if(entries) free(entries); return; }
    uint32_t new_size=0;
    uint8_t *new_trie=build_export_trie(entries,nentries,shift_amount,&new_size);
    free(entries);
    if(!new_trie) return;
    uint32_t aligned=(new_size+7u)&~7u;
    while(new_size<aligned) new_trie[new_size++]=0;
    int32_t size_delta=(int32_t)new_size-(int32_t)exp_size;
    if(size_delta==0){ memcpy(out+exp_off,new_trie,new_size); }
    else {
        uint32_t after=exp_off+exp_size; uint32_t tail=*out_sz-after;
        if(*out_sz+(uint32_t)abs(size_delta)>max_alloc) return;
        memmove(out+after+size_delta,out+after,tail);
        memcpy(out+exp_off,new_trie,new_size);
        *out_sz=(uint32_t)((int32_t)*out_sz+size_delta);
        if(is_separate){ linkedit_lc *ld=(linkedit_lc*)exp_lc; ld->datasize=new_size; }
        else { dyldinfo_lc *di2=(dyldinfo_lc*)exp_lc; di2->export_size=new_size; }
        lcp=out+32;
        for(uint32_t i=0;i<hdr->ncmds;i++){
            lc_t *lc=(lc_t*)lcp;
            if(lc->cmd==LC_SEGMENT_64){
                seg64 *seg=(seg64*)lcp;
                if(strncmp(seg->segname,"__LINKEDIT",11)==0){
                    seg->filesize=(uint64_t)((int64_t)seg->filesize+(int64_t)size_delta);

                    if(seg->vmsize<seg->filesize) seg->vmsize=align_up(seg->filesize,0x4000);
                }
            }
            if(lc->cmd==LC_SYMTAB){
                symtab_lc *sc=(symtab_lc*)lcp;
                if(sc->symoff>exp_off) sc->symoff=(uint32_t)((int32_t)sc->symoff+size_delta);
                if(sc->stroff>exp_off) sc->stroff=(uint32_t)((int32_t)sc->stroff+size_delta);
            }
            else if(lc->cmd==LC_DYSYMTAB){
                dysymtab_lc *dc=(dysymtab_lc*)lcp;
                if(dc->indirectsymoff>exp_off) dc->indirectsymoff=(uint32_t)((int32_t)dc->indirectsymoff+size_delta);
            }
            else if(lc->cmd==LC_FUNCTION_STARTS||lc->cmd==LC_DATA_IN_CODE||lc->cmd==LC_CODE_SIGNATURE){
                linkedit_lc *ld=(linkedit_lc*)lcp;
                if(ld->dataoff>exp_off&&lcp!=exp_lc) ld->dataoff=(uint32_t)((int32_t)ld->dataoff+size_delta);
            }
            lcp+=lc->cmdsize;
        }
    }
    free(new_trie);
}

void fix_lc_function_starts(uint8_t *out, uint32_t *out_sz, uint32_t max_alloc,
    uint64_t shift_amount, uint64_t text_seg_va)
{
    mh64 *hdr=(mh64*)out;
    uint32_t fs_dataoff=0,fs_datasize=0; uint8_t *fs_lc=NULL;
    { uint8_t *lcp=out+32;
        for(uint32_t i=0;i<hdr->ncmds;i++){
            lc_t *lc=(lc_t*)lcp;
            if(lc->cmd==LC_FUNCTION_STARTS){ linkedit_lc *ld=(linkedit_lc*)lcp; fs_dataoff=ld->dataoff; fs_datasize=ld->datasize; fs_lc=lcp; break; }
            lcp+=lc->cmdsize;
        }
    }
    if(!fs_lc||!fs_dataoff||!fs_datasize) return;
    if(fs_dataoff+fs_datasize>*out_sz) return;
    uint64_t *addrs=(uint64_t*)malloc(65536*sizeof(uint64_t)); int naddrs=0;
    if(!addrs) return;
    { uint32_t pos=fs_dataoff; uint32_t end=fs_dataoff+fs_datasize; uint64_t addr=text_seg_va;
      while(pos<end&&naddrs<65536){
          uint64_t delta=decode_uleb128(out,&pos,end);
          if(delta==0&&naddrs>0) break;
          addr+=delta; if(naddrs==0&&delta==0) continue;
          addrs[naddrs++]=addr;
      }
    }
    if(naddrs==0){free(addrs);return;}
    for(int i=0;i<naddrs;i++) addrs[i]+=shift_amount;
    uint8_t *new_fs=(uint8_t*)malloc(131072); uint32_t new_pos=0;
    if(!new_fs){free(addrs);return;}
    uint64_t prev=text_seg_va;
    for(int i=0;i<naddrs;i++){
        uint64_t delta=addrs[i]-prev;
        encode_uleb128(new_fs,&new_pos,delta);
        prev=addrs[i];
    }
    new_fs[new_pos++]=0;
    int32_t size_delta=(int32_t)new_pos-(int32_t)fs_datasize;
    if(size_delta==0){ memcpy(out+fs_dataoff,new_fs,new_pos); }
    else {
        uint32_t after_fs=fs_dataoff+fs_datasize; uint32_t tail_len=*out_sz-after_fs;
        if(*out_sz+(uint32_t)abs(size_delta)>max_alloc){free(addrs);free(new_fs);return;}
        memmove(out+after_fs+size_delta,out+after_fs,tail_len);
        memcpy(out+fs_dataoff,new_fs,new_pos);
        *out_sz=(uint32_t)((int32_t)*out_sz+size_delta);
        linkedit_lc *fs_cmd=(linkedit_lc*)fs_lc; fs_cmd->datasize=new_pos;
        uint8_t *lcp=out+32;
        for(uint32_t i=0;i<hdr->ncmds;i++){
            lc_t *lc=(lc_t*)lcp;
            if(lc->cmd==LC_SEGMENT_64){
                seg64 *seg=(seg64*)lcp;
                if(strncmp(seg->segname,"__LINKEDIT",11)==0){
                    seg->filesize=(uint64_t)((int64_t)seg->filesize+(int64_t)size_delta);
                    if(seg->vmsize<seg->filesize) seg->vmsize=align_up(seg->filesize,0x4000);
                }
            }
            else if(lc->cmd==LC_SYMTAB){
                symtab_lc *sc=(symtab_lc*)lcp;
                if(sc->symoff>fs_dataoff) sc->symoff=(uint32_t)((int32_t)sc->symoff+size_delta);
                if(sc->stroff>fs_dataoff) sc->stroff=(uint32_t)((int32_t)sc->stroff+size_delta);
            }
            else if(lc->cmd==LC_DYSYMTAB){
                dysymtab_lc *dc=(dysymtab_lc*)lcp;
                if(dc->tocoff>fs_dataoff) dc->tocoff=(uint32_t)((int32_t)dc->tocoff+size_delta);
                if(dc->modtaboff>fs_dataoff) dc->modtaboff=(uint32_t)((int32_t)dc->modtaboff+size_delta);
                if(dc->extrefsymoff>fs_dataoff) dc->extrefsymoff=(uint32_t)((int32_t)dc->extrefsymoff+size_delta);
                if(dc->indirectsymoff>fs_dataoff) dc->indirectsymoff=(uint32_t)((int32_t)dc->indirectsymoff+size_delta);
                if(dc->extreloff>fs_dataoff) dc->extreloff=(uint32_t)((int32_t)dc->extreloff+size_delta);
                if(dc->locreloff>fs_dataoff) dc->locreloff=(uint32_t)((int32_t)dc->locreloff+size_delta);
            }
            else if(lc->cmd==LC_DYLD_INFO_ONLY||lc->cmd==0x22){
                dyldinfo_lc *di2=(dyldinfo_lc*)lcp;
                if(di2->rebase_off>fs_dataoff) di2->rebase_off=(uint32_t)((int32_t)di2->rebase_off+size_delta);
                if(di2->bind_off>fs_dataoff) di2->bind_off=(uint32_t)((int32_t)di2->bind_off+size_delta);
                if(di2->weak_bind_off>fs_dataoff) di2->weak_bind_off=(uint32_t)((int32_t)di2->weak_bind_off+size_delta);
                if(di2->lazy_bind_off>fs_dataoff) di2->lazy_bind_off=(uint32_t)((int32_t)di2->lazy_bind_off+size_delta);
                if(di2->export_off>fs_dataoff) di2->export_off=(uint32_t)((int32_t)di2->export_off+size_delta);
            }
            else if(lc->cmd==LC_DATA_IN_CODE||lc->cmd==LC_CODE_SIGNATURE||
                     lc->cmd==LC_DYLD_EXPORTS_TRIE||lc->cmd==0x80000034u){
                linkedit_lc *ld=(linkedit_lc*)lcp;
                if(ld->dataoff>fs_dataoff&&lcp!=fs_lc) ld->dataoff=(uint32_t)((int32_t)ld->dataoff+size_delta);
            }
            lcp+=lc->cmdsize;
        }
    }
    free(addrs);
    free(new_fs);
}

void fix_chained_fixups(uint8_t *out, uint32_t out_sz,
    uint64_t vm_pad, uint64_t shift_threshold, uint64_t shift_end, uint64_t actual_shift)
{
    mh64 *hdr = (mh64*)out;
    uint32_t cf_off = 0, cf_size = 0;

    uint8_t *lcp = out + 32;
    for(uint32_t i = 0; i < hdr->ncmds; i++){
        lc_t *lc = (lc_t*)lcp;
        if(lc->cmd == LC_DYLD_CHAINED_FIXUPS){
            linkedit_lc *ld = (linkedit_lc*)lcp;
            cf_off = ld->dataoff;
            cf_size = ld->datasize;
            break;
        }
        lcp += lc->cmdsize;
    }
    if(!cf_off || !cf_size || cf_off + cf_size > out_sz) return;

    uint8_t *cf = out + cf_off;

    uint32_t starts_offset = rd32(cf + 4);
    if(starts_offset + 4 > cf_size) return;

    uint8_t *starts_img = cf + starts_offset;
    uint32_t seg_count = rd32(starts_img);

    printf("[*] Chained fixups: %u segments, fixups at fo=0x%x size=%u\n",
           seg_count, cf_off, cf_size);

    int fixed_segs = 0, fixed_rebases = 0;

    for(uint32_t si = 0; si < seg_count && si < 16; si++){
        uint32_t seg_info_off = rd32(starts_img + 4 + si * 4);
        if(seg_info_off == 0) continue;

        uint8_t *seg_starts = starts_img + seg_info_off;
        if(seg_starts + 24 > cf + cf_size) continue;

        uint16_t page_size   = *(uint16_t*)(seg_starts + 4);
        uint16_t ptr_format  = *(uint16_t*)(seg_starts + 6);
        uint64_t seg_offset  = rd64(seg_starts + 8);
        uint16_t page_count  = *(uint16_t*)(seg_starts + 20);

        if(seg_offset >= shift_threshold){
            uint64_t new_seg_offset = seg_offset + vm_pad;
            wr64(seg_starts + 8, new_seg_offset);
            printf("[+] Chained fixups: seg[%u] segment_offset 0x%llx -> 0x%llx\n",
                   si, (unsigned long long)seg_offset, (unsigned long long)new_seg_offset);
            seg_offset = new_seg_offset;
            fixed_segs++;
        }

        if(page_size == 0 || page_count == 0) continue;
        if(ptr_format != 2 && ptr_format != 6){
            printf("[!] Chained fixups: unsupported pointer_format %u in seg[%u], skipping\n",
                   ptr_format, si);
            continue;
        }

        uint64_t seg_file_start = seg_offset;
        uint64_t seg_file_end = seg_offset + (uint64_t)page_count * page_size;

        for(uint64_t fo = seg_file_start; fo + 8 <= seg_file_end && fo + 8 <= out_sz; fo += 8){
            uint64_t raw = rd64(out + fo);
            if(raw == 0) continue;

            uint64_t bind_bit = raw >> 63;
            if(bind_bit) continue;

            uint64_t target = raw & 0xFFFFFFFFFULL;
            uint64_t high8  = (raw >> 36) & 0xFF;
            uint64_t next   = (raw >> 52) & 0x7FF;
            uint64_t full_target = target | (high8 << 56);

            if(full_target >= shift_threshold && full_target < shift_end){
                full_target += actual_shift;
                uint64_t new_target = full_target & 0xFFFFFFFFFULL;
                uint64_t new_high8  = (full_target >> 56) & 0xFF;
                uint64_t new_raw = new_target | (new_high8 << 36) | (next << 52);
                wr64(out + fo, new_raw);
                fixed_rebases++;
            }
        }
    }

    printf("[*] Chained fixups: fixed %d segment_offsets, %d rebase targets\n",
           fixed_segs, fixed_rebases);
}

static bool find_section_by_name(const uint8_t *d, uint32_t sz, const char *name,
                                 uint32_t *out_fo, uint32_t *out_sz, uint64_t *out_va){
    if(sz<32) return false;
    const mh64 *h=(const mh64*)d;
    if(h->magic!=MH_MAGIC_64) return false;
    const uint8_t *p=d+32;
    for(uint32_t i=0;i<h->ncmds;i++){
        if(p+sizeof(lc_t)>d+sz) break;
        const lc_t *cmd=(const lc_t*)p;
        if(cmd->cmd==LC_SEGMENT_64){
            const seg64 *sg=(const seg64*)p;
            const uint8_t *sp=p+sizeof(seg64);
            for(uint32_t j=0;j<sg->nsects;j++){
                if(sp+sizeof(sec64)>d+sz) break;
                const sec64 *sc=(const sec64*)sp;
                if(!strncmp(sc->sectname,name,16)){
                    if(out_fo) *out_fo=sc->offset;
                    if(out_sz) *out_sz=(uint32_t)sc->size;
                    if(out_va) *out_va=sc->addr;
                    return true;
                }
                sp+=sizeof(sec64);
            }
        }
        p+=cmd->cmdsize;
    }
    return false;
}

bool func_makes_calls(const uint8_t *text_data, uint64_t text_va,
                      uint64_t fva, uint32_t fsz){
    if(!text_data || fsz < 4) return false;
    uint64_t off = fva - text_va;
    uint32_t n = fsz / 4;
    for(uint32_t i=0; i<n; i++){
        uint32_t w = rd32(text_data + off + i*4);
        if((w & 0xFC000000u) == 0x94000000u) return true;
        if((w & 0xFE000000u) == 0xD6000000u && ((w >> 21) & 7u) == 1u) return true;
    }
    return false;
}

bool binary_uses_eh(const uint8_t *d, uint32_t sz){
    uint32_t fo=0, ssz=0; uint64_t va=0;
    if(find_section_by_name(d,sz,"__eh_frame",&fo,&ssz,&va) && ssz>0) return true;
    if(find_section_by_name(d,sz,"__unwind_info",&fo,&ssz,&va) && ssz>=28){
        if((uint64_t)fo+20<=sz && rd32(d+fo+16)>0) return true;
    }
    return false;
}

int collect_eh_active(const uint8_t *d, uint32_t sz, uint64_t image_base,
                      uint64_t *out, int max_out){
    int n=0;
    uint32_t fo=0, ssz=0; uint64_t va=0;
    if(!find_section_by_name(d,sz,"__unwind_info",&fo,&ssz,&va)) return 0;
    if((uint64_t)fo+28>sz || ssz<28) return 0;
    uint32_t enc_off=rd32(d+fo+4),  enc_cnt=rd32(d+fo+8);
    uint32_t idx_off=rd32(d+fo+20), idx_cnt=rd32(d+fo+24);
    if(idx_cnt==0) return 0;
    for(uint32_t i=0;i+1<idx_cnt;i++){
        uint64_t e=(uint64_t)fo+idx_off+(uint64_t)i*12;
        if(e+12>sz) break;
        uint32_t func_rva=rd32(d+e);
        uint32_t second=rd32(d+e+4);
        if(second==0) continue;
        uint64_t so=(uint64_t)fo+second;
        if(so+8>sz) continue;
        uint32_t kind=rd32(d+so);
        if(kind==2){
            uint16_t eoff=0, ecnt=0;
            memcpy(&eoff,d+so+4,2); memcpy(&ecnt,d+so+6,2);
            for(uint32_t j=0;j<ecnt;j++){
                uint64_t ee=so+eoff+(uint64_t)j*8;
                if(ee+8>sz) break;
                uint32_t frva=rd32(d+ee);
                uint32_t enc =rd32(d+ee+4);
                if(((enc>>28)&0x3u) || (enc&0x40000000u)){
                    if(n<max_out) out[n++]=image_base+frva;
                }
            }
        } else if(kind==3){
            uint16_t eoff=0, ecnt=0, enc_pg_off=0, enc_pg_cnt=0;
            memcpy(&eoff,d+so+4,2);   memcpy(&ecnt,d+so+6,2);
            memcpy(&enc_pg_off,d+so+8,2); memcpy(&enc_pg_cnt,d+so+10,2);
            (void)enc_pg_cnt;
            for(uint32_t j=0;j<ecnt;j++){
                uint64_t ee=so+eoff+(uint64_t)j*4;
                if(ee+4>sz) break;
                uint32_t v=rd32(d+ee);
                uint32_t fnoff =v&0xFFFFFFu;
                uint32_t encidx=(v>>24)&0xFFu;
                uint32_t enc; uint64_t eo;
                if(encidx<enc_cnt) eo=(uint64_t)fo+enc_off+(uint64_t)encidx*4;
                else               eo=so+enc_pg_off+(uint64_t)(encidx-enc_cnt)*4;
                if(eo+4>sz) continue;
                enc=rd32(d+eo);
                if(((enc>>28)&0x3u) || (enc&0x40000000u)){
                    if(n<max_out) out[n++]=image_base+func_rva+fnoff;
                }
            }
        }
    }
    return n;
}

static void relocate_unwind_info(uint8_t *uw, uint32_t uw_size,
                                 uint32_t threshold, uint32_t vm_pad){
    if(uw_size < 28) return;
    uint32_t persOff = rd32(uw+12), persCnt = rd32(uw+16);
    uint32_t idxOff  = rd32(uw+20), idxCnt  = rd32(uw+24);
    for(uint32_t i=0;i<persCnt;i++){
        uint32_t fo = persOff + 4u*i;
        if(fo+4 > uw_size) break;
        uint32_t v = rd32(uw+fo);
        if(v >= threshold) wr32(uw+fo, v+vm_pad);
    }
    if(idxCnt==0) return;
    for(uint32_t i=0;i<idxCnt;i++){
        uint32_t e = idxOff + 12u*i;
        if(e+12 > uw_size) break;
        uint32_t fn = rd32(uw+e);
        if(fn >= threshold) wr32(uw+e, fn+vm_pad);
    }
    for(uint32_t i=0;i+1<idxCnt;i++){
        uint32_t e0 = idxOff + 12u*i, e1 = idxOff + 12u*(i+1);
        if(e1+12 > uw_size) break;
        uint32_t slp     = rd32(uw+e0+4);
        uint32_t lsdaBeg = rd32(uw+e0+8);
        uint32_t lsdaEnd = rd32(uw+e1+8);
        if(lsdaEnd > lsdaBeg && lsdaEnd <= uw_size){
            for(uint32_t k=lsdaBeg; k+8<=lsdaEnd; k+=8){
                uint32_t lf=rd32(uw+k), ll=rd32(uw+k+4);
                if(lf>=threshold) wr32(uw+k,   lf+vm_pad);
                if(ll>=threshold) wr32(uw+k+4, ll+vm_pad);
            }
        }
        if(slp!=0 && slp+8<=uw_size){
            uint32_t kind = rd32(uw+slp);
            if(kind==2){
                uint16_t entryOff=0, entryCnt=0;
                memcpy(&entryOff, uw+slp+4, 2);
                memcpy(&entryCnt, uw+slp+6, 2);
                for(uint32_t k=0;k<entryCnt;k++){
                    uint32_t ee = slp + entryOff + 8u*k;
                    if(ee+8 > uw_size) break;
                    uint32_t fo2 = rd32(uw+ee);
                    if(fo2>=threshold) wr32(uw+ee, fo2+vm_pad);
                }
            }

        }
    }
}

uint8_t *build_output(const uint8_t *orig, uint32_t orig_sz,
    const uint8_t *vm_code, uint32_t vm_size,
    uint64_t insert_point, uint64_t *out_shift, uint32_t *out_sz,
    bool add_exec_seg, uint64_t *exec_fo_out, uint64_t *exec_va_out)
{
    uint64_t vm_pad=align_up((uint64_t)vm_size+0x100,0x4000);
    uint32_t vdata_sz=0x4000;
    *out_shift=vm_pad;
    const mh64 *oh=(const mh64*)orig;
    uint32_t hdr_end=32+oh->sizeofcmds;
    uint64_t le_fo=0,le_fsz=0,le_va=0;
    { const uint8_t *p=orig+32;
      for(uint32_t i=0;i<oh->ncmds;i++){
          const lc_t *lc=(const lc_t*)p;
          if(lc->cmd==LC_SEGMENT_64){
              const seg64 *seg=(const seg64*)p;
              if(strncmp(seg->segname,"__LINKEDIT",11)==0){ le_fo=seg->fileoff; le_fsz=seg->filesize; le_va=seg->vmaddr; }
          }
          p+=lc->cmdsize;
      }
    }
    uint64_t new_vdata_fo=le_fo+vm_pad;
    uint64_t new_le_fo=new_vdata_fo+vdata_sz;
    uint64_t new_vdata_va=le_va+vm_pad;
    uint64_t new_le_va=new_vdata_va+vdata_sz;
    uint64_t le_total=vm_pad+vdata_sz;
    if(exec_fo_out) *exec_fo_out=new_vdata_fo;
    if(exec_va_out) *exec_va_out=new_vdata_va;
    uint64_t file_end_64=new_le_fo+le_fsz;

    if(file_end_64 > 0xFFFFFFFEULL){
        fprintf(stderr,"[!] Output file too large (>4GB)\n");
        return NULL;
    }
    uint32_t file_end=(uint32_t)file_end_64;
    uint64_t total_alloc_64=align_up((uint64_t)file_end+0x400000,0x4000);
    if(total_alloc_64>0xFFFFFFFFULL) total_alloc_64=0xFFFFFFFFULL;
    uint32_t total_alloc=(uint32_t)total_alloc_64;
    uint8_t *out=(uint8_t*)calloc(1,total_alloc);
    if(!out) return NULL;
    memcpy(out,orig,hdr_end);
    memcpy(out+insert_point,vm_code,vm_size);
    if(le_fo>insert_point){
        uint32_t mid=(uint32_t)(le_fo-insert_point);
        memcpy(out+insert_point+vm_pad,orig+insert_point,mid);
    }
    {
        uint8_t *vd=out+new_vdata_fo;
        wr32(vd+0x00,0x41484558u);
        wr32(vd+0x04,0);
        wr32(vd+0x08,0);
        wr32(vd+0x0C,0);
        wr32(vd+0x40,0x1C); wr32(vd+0x44,1);
        wr32(vd+0xC0,0x30); wr32(vd+0xC4,1);
        wr32(vd+0xC8,(uint32_t)insert_point);
        wr32(vd+0xCC,(uint32_t)(vm_pad>>8));
        wr32(vd+0xD0,(uint32_t)vm_pad);
        uint32_t h=0x5E89FC49u;
        for(uint32_t i=0;i<vm_size&&i<256;i+=4){
            uint32_t w=0; memcpy(&w,vm_code+i,(i+4<=vm_size)?4:vm_size-i);
            h^=w; h=(h<<7)|(h>>25);
        }
        wr32(vd+0xE0,h); wr32(vd+0xE4,h^0xEA8693C3u);
    }
    if(le_fo+le_fsz<=orig_sz)
        memcpy(out+new_le_fo,orig+le_fo,(size_t)le_fsz);
    uint8_t *lcp=out+32;
    mh64 *nh=(mh64*)out;
    for(uint32_t i=0;i<nh->ncmds;i++){
        lc_t *lc=(lc_t*)lcp;
        if(lc->cmd==LC_SEGMENT_64){
            seg64 *seg=(seg64*)lcp;
            bool is_text=(strncmp(seg->segname,"__TEXT",6)==0&&seg->segname[6]==0);
            bool is_le=(strncmp(seg->segname,"__LINKEDIT",11)==0);
            if(is_text){
                seg->vmsize+=vm_pad; seg->filesize+=vm_pad;
                uint8_t *sp=lcp+sizeof(seg64);
                for(uint32_t j=0;j<seg->nsects;j++){
                    sec64 *sect=(sec64*)sp;
                    if(sect->offset>=(uint32_t)insert_point){
                        sect->offset+=(uint32_t)vm_pad;
                        sect->addr+=vm_pad;
                    }
                    sp+=sizeof(sec64);
                }
            } else if(is_le){
                seg->fileoff=new_le_fo; seg->vmaddr=new_le_va;
            } else {
                if(seg->fileoff>0) seg->fileoff+=vm_pad;
                seg->vmaddr+=vm_pad;
                uint8_t *sp=lcp+sizeof(seg64);
                for(uint32_t j=0;j<seg->nsects;j++){
                    sec64 *sect=(sec64*)sp;
                    if(sect->offset>0) sect->offset+=(uint32_t)vm_pad;
                    sect->addr+=vm_pad;
                    sp+=sizeof(sec64);
                }
            }
        }
        else if(lc->cmd==LC_SYMTAB){
            symtab_lc *sc=(symtab_lc*)lcp;
            if(sc->symoff) sc->symoff+=(uint32_t)le_total;
            if(sc->stroff) sc->stroff+=(uint32_t)le_total;
        }
        else if(lc->cmd==LC_DYSYMTAB){
            dysymtab_lc *dc=(dysymtab_lc*)lcp;
            if(dc->tocoff) dc->tocoff+=(uint32_t)le_total;
            if(dc->modtaboff) dc->modtaboff+=(uint32_t)le_total;
            if(dc->extrefsymoff) dc->extrefsymoff+=(uint32_t)le_total;
            if(dc->indirectsymoff) dc->indirectsymoff+=(uint32_t)le_total;
            if(dc->extreloff) dc->extreloff+=(uint32_t)le_total;
            if(dc->locreloff) dc->locreloff+=(uint32_t)le_total;
        }
        else if(lc->cmd==LC_DYLD_INFO_ONLY||lc->cmd==0x22){
            dyldinfo_lc *di2=(dyldinfo_lc*)lcp;
            if(di2->rebase_off) di2->rebase_off+=(uint32_t)le_total;
            if(di2->bind_off) di2->bind_off+=(uint32_t)le_total;
            if(di2->weak_bind_off) di2->weak_bind_off+=(uint32_t)le_total;
            if(di2->lazy_bind_off) di2->lazy_bind_off+=(uint32_t)le_total;
            if(di2->export_off) di2->export_off+=(uint32_t)le_total;
        }
        else if(lc->cmd==LC_FUNCTION_STARTS||lc->cmd==LC_DATA_IN_CODE||
                 lc->cmd==LC_CODE_SIGNATURE||lc->cmd==LC_DYLD_EXPORTS_TRIE||
                 lc->cmd==0x80000034u||
                 lc->cmd==LC_SEGMENT_SPLIT_INFO||lc->cmd==LC_DYLIB_CODE_SIGN_DRS||
                 lc->cmd==LC_LINKER_OPTIMIZATION_HINT||lc->cmd==LC_ATOM_INFO){

            linkedit_lc *ld=(linkedit_lc*)lcp;
            if(ld->dataoff) ld->dataoff+=(uint32_t)le_total;
        }
        else if(lc->cmd==LC_ENCRYPTION_INFO_64){
            encryption_info_64_t *ei=(encryption_info_64_t*)lcp;
            if(ei->cryptoff) ei->cryptoff+=(uint32_t)vm_pad;
        }
        lcp+=lc->cmdsize;
    }

    {
        uint32_t uw_fo=0, uw_size=0; uint64_t uw_va=0;
        if(find_section_by_name(orig, orig_sz, "__unwind_info", &uw_fo, &uw_size, &uw_va)
           && uw_size>=28 && uw_fo>=insert_point){
            relocate_unwind_info(out + uw_fo + vm_pad, uw_size,
                                 (uint32_t)insert_point, (uint32_t)vm_pad);
        }
    }
    {
        uint8_t *le_lc_p=NULL;
        lcp=out+32;
        for(uint32_t i=0;i<nh->ncmds;i++){
            lc_t *lc=(lc_t*)lcp;
            if(lc->cmd==LC_SEGMENT_64){
                seg64 *seg=(seg64*)lcp;
                if(strncmp(seg->segname,"__LINKEDIT",11)==0){ le_lc_p=lcp; break; }
            }
            lcp+=lc->cmdsize;
        }
        if(le_lc_p && add_exec_seg){
            uint32_t nlcsz=sizeof(seg64)+sizeof(sec64);
            uint32_t cur_end=32+nh->sizeofcmds;
            uint32_t tail=cur_end-(uint32_t)(le_lc_p-out);
            if(cur_end+nlcsz<insert_point){
                memmove(le_lc_p+nlcsz,le_lc_p,tail);
                seg64 vs; memset(&vs,0,sizeof(vs));
                vs.cmd=LC_SEGMENT_64; vs.cmdsize=nlcsz;
                memcpy(vs.segname,"__VDATA",7);
                vs.vmaddr=new_vdata_va; vs.vmsize=vdata_sz;
                vs.fileoff=new_vdata_fo; vs.filesize=vdata_sz;

                vs.maxprot=VM_PROT_READ|VM_PROT_WRITE;
                vs.initprot=VM_PROT_READ|VM_PROT_WRITE;
                vs.nsects=1;
                memcpy(le_lc_p,&vs,sizeof(vs));
                sec64 vsect; memset(&vsect,0,sizeof(vsect));
                memcpy(vsect.sectname,"__vdata",7);
                memcpy(vsect.segname,"__VDATA",7);
                vsect.addr=new_vdata_va; vsect.size=vdata_sz;
                vsect.offset=(uint32_t)new_vdata_fo; vsect.align_=14;
                memcpy(le_lc_p+sizeof(seg64),&vsect,sizeof(vsect));
                nh->ncmds+=1; nh->sizeofcmds+=nlcsz;
            }
        }
    }
    *out_sz=file_end;
    return out;
}
