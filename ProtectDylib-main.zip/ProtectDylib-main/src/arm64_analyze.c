#include "arm64_analyze.h"

#include <string.h>

#include <capstone/arm64.h>
#include <capstone/capstone.h>

static csh g_arm64_cs = 0;
static bool g_arm64_cs_ready = false;

static bool arm64_has_prefix(const char *s, const char *prefix){
    while(*prefix){
        if(*s++ != *prefix++) return false;
    }
    return true;
}

static bool arm64_special_init(void){
    if(g_arm64_cs_ready) return true;
    if(cs_open(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN, &g_arm64_cs) != CS_ERR_OK)
        return false;
    if(cs_option(g_arm64_cs, CS_OPT_DETAIL, CS_OPT_ON) != CS_ERR_OK){
        cs_close(&g_arm64_cs);
        g_arm64_cs = 0;
        return false;
    }
    g_arm64_cs_ready = true;
    return true;
}

static int arm64_map_gpr(unsigned int reg){
    switch(reg){
    case ARM64_REG_X0: case ARM64_REG_W0: return 0;
    case ARM64_REG_X1: case ARM64_REG_W1: return 1;
    case ARM64_REG_X2: case ARM64_REG_W2: return 2;
    case ARM64_REG_X3: case ARM64_REG_W3: return 3;
    case ARM64_REG_X4: case ARM64_REG_W4: return 4;
    case ARM64_REG_X5: case ARM64_REG_W5: return 5;
    case ARM64_REG_X6: case ARM64_REG_W6: return 6;
    case ARM64_REG_X7: case ARM64_REG_W7: return 7;
    case ARM64_REG_X8: case ARM64_REG_W8: return 8;
    case ARM64_REG_X9: case ARM64_REG_W9: return 9;
    case ARM64_REG_X10: case ARM64_REG_W10: return 10;
    case ARM64_REG_X11: case ARM64_REG_W11: return 11;
    case ARM64_REG_X12: case ARM64_REG_W12: return 12;
    case ARM64_REG_X13: case ARM64_REG_W13: return 13;
    case ARM64_REG_X14: case ARM64_REG_W14: return 14;
    case ARM64_REG_X15: case ARM64_REG_W15: return 15;
    case ARM64_REG_X16: case ARM64_REG_W16: return 16;
    case ARM64_REG_X17: case ARM64_REG_W17: return 17;
    case ARM64_REG_X18: case ARM64_REG_W18: return 18;
    case ARM64_REG_X19: case ARM64_REG_W19: return 19;
    case ARM64_REG_X20: case ARM64_REG_W20: return 20;
    case ARM64_REG_X21: case ARM64_REG_W21: return 21;
    case ARM64_REG_X22: case ARM64_REG_W22: return 22;
    case ARM64_REG_X23: case ARM64_REG_W23: return 23;
    case ARM64_REG_X24: case ARM64_REG_W24: return 24;
    case ARM64_REG_X25: case ARM64_REG_W25: return 25;
    case ARM64_REG_X26: case ARM64_REG_W26: return 26;
    case ARM64_REG_X27: case ARM64_REG_W27: return 27;
    case ARM64_REG_X28: case ARM64_REG_W28: return 28;
    case ARM64_REG_X29: case ARM64_REG_W29: return 29;
    case ARM64_REG_X30: case ARM64_REG_W30: return 30;
    case ARM64_REG_SP:
#ifdef ARM64_REG_WSP
    case ARM64_REG_WSP:
#endif
        return 31;
#ifdef ARM64_REG_IP0
    case ARM64_REG_IP0: return 16;
#endif
#ifdef ARM64_REG_IP1
    case ARM64_REG_IP1: return 17;
#endif
    default:
        return -1;
    }
}

static bool arm64_is_exclusive_mnemonic(const char *m){
    return arm64_has_prefix(m, "ldxr") ||
           arm64_has_prefix(m, "ldaxr") ||
           arm64_has_prefix(m, "ldxp") ||
           arm64_has_prefix(m, "ldaxp") ||
           arm64_has_prefix(m, "stxr") ||
           arm64_has_prefix(m, "stlxr") ||
           arm64_has_prefix(m, "stxp") ||
           arm64_has_prefix(m, "stlxp") ||
           arm64_has_prefix(m, "cas") ||
           arm64_has_prefix(m, "swp") ||
           arm64_has_prefix(m, "ldadd") ||
           arm64_has_prefix(m, "stadd") ||
           arm64_has_prefix(m, "ldclr") ||
           arm64_has_prefix(m, "stclr") ||
           arm64_has_prefix(m, "ldeor") ||
           arm64_has_prefix(m, "steor") ||
           arm64_has_prefix(m, "ldset") ||
           arm64_has_prefix(m, "stset") ||
           arm64_has_prefix(m, "ldsmax") ||
           arm64_has_prefix(m, "ldsmin") ||
           arm64_has_prefix(m, "ldumax") ||
           arm64_has_prefix(m, "ldumin");
}

static bool arm64_is_barrier_mnemonic(const char *m){
    return strcmp(m, "dmb") == 0 ||
           strcmp(m, "dsb") == 0 ||
           strcmp(m, "isb") == 0 ||
           strcmp(m, "clrex") == 0 ||
           strcmp(m, "csdb") == 0 ||
           strcmp(m, "ssbb") == 0 ||
           strcmp(m, "pssbb") == 0 ||
           strcmp(m, "sb") == 0;
}

static bool arm64_is_system_mnemonic(const char *m){
    return strcmp(m, "svc") == 0 ||
           strcmp(m, "hvc") == 0 ||
           strcmp(m, "smc") == 0 ||
           strcmp(m, "dcps1") == 0 ||
           strcmp(m, "dcps2") == 0 ||
           strcmp(m, "dcps3") == 0 ||
           strcmp(m, "eret") == 0 ||
           strcmp(m, "drps") == 0 ||
           strcmp(m, "mrs") == 0 ||
           strcmp(m, "msr") == 0 ||
           strcmp(m, "sys") == 0 ||
           strcmp(m, "sysl") == 0;
}

static bool arm64_is_pauth_mnemonic(const char *m){
    return arm64_has_prefix(m, "pac") ||
           arm64_has_prefix(m, "aut") ||
           arm64_has_prefix(m, "xpac") ||
           strcmp(m, "retaa") == 0 ||
           strcmp(m, "retab") == 0 ||
           strcmp(m, "braa") == 0 ||
           strcmp(m, "brab") == 0 ||
           strcmp(m, "blraa") == 0 ||
           strcmp(m, "blrab") == 0;
}

bool arm64_analyze_words(const uint32_t *words, int word_count,
                         uint64_t base_va, Arm64FuncAnalysis *out)
{
    bool ok = true;
    if(!out) return false;
    memset(out, 0, sizeof(*out));
    if(!words || word_count <= 0) return false;
    if(!arm64_special_init()){
        out->feature_flags |= ARM64_ANALYSIS_INVALID;
        out->invalid_count++;
        return false;
    }

    cs_insn *insn = cs_malloc(g_arm64_cs);
    if(!insn){
        out->feature_flags |= ARM64_ANALYSIS_INVALID;
        out->invalid_count++;
        return false;
    }

    for(int i=0; i<word_count; i++){
        const uint8_t *code = (const uint8_t *)&words[i];
        size_t size = 4;
        uint64_t addr = base_va + (uint64_t)i * 4;
        cs_regs regs_read, regs_write;
        uint8_t read_count = 0, write_count = 0;
        out->insn_count++;

        if(!cs_disasm_iter(g_arm64_cs, &code, &size, &addr, insn)){
            out->feature_flags |= ARM64_ANALYSIS_INVALID;
            out->invalid_count++;
            ok = false;
            continue;
        }

        if(cs_regs_access(g_arm64_cs, insn, regs_read, &read_count, regs_write, &write_count) == CS_ERR_OK){
            for(uint8_t ri=0; ri<read_count; ri++){
                if(regs_read[ri] == ARM64_REG_NZCV) out->reads_flags = true;
                int idx = arm64_map_gpr(regs_read[ri]);
                if(idx >= 0){
                    out->gpr_read_mask |= (1u << idx);
                    out->gpr_read_count[idx]++;
                }
            }
            for(uint8_t wi=0; wi<write_count; wi++){
                if(regs_write[wi] == ARM64_REG_NZCV) out->writes_flags = true;
                int idx = arm64_map_gpr(regs_write[wi]);
                if(idx >= 0){
                    out->gpr_write_mask |= (1u << idx);
                    out->gpr_write_count[idx]++;
                }
            }
        } else {
            out->feature_flags |= ARM64_ANALYSIS_INVALID;
            out->invalid_count++;
            ok = false;
        }

        if(arm64_is_exclusive_mnemonic(insn->mnemonic)){
            out->feature_flags |= ARM64_ANALYSIS_EXCLUSIVE;
            out->exclusive_count++;
        }
        if(arm64_is_system_mnemonic(insn->mnemonic)){
            out->feature_flags |= ARM64_ANALYSIS_SYSTEM;
            out->system_count++;
        }
        if(arm64_is_barrier_mnemonic(insn->mnemonic)){
            out->feature_flags |= ARM64_ANALYSIS_BARRIER;
            out->barrier_count++;
        }
        if(arm64_is_pauth_mnemonic(insn->mnemonic)){
            out->feature_flags |= ARM64_ANALYSIS_PAUTH;
            out->ptrauth_count++;
        }
    }

    cs_free(insn, 1);

    out->gpr_used_mask = out->gpr_read_mask | out->gpr_write_mask;
    out->uses_x15 = (out->gpr_used_mask & (1u << 15)) != 0;
    out->uses_x16 = (out->gpr_used_mask & (1u << 16)) != 0;
    out->uses_x17 = (out->gpr_used_mask & (1u << 17)) != 0;
    return ok;
}

int arm64_pick_unused_pair(uint32_t used_mask, const int *candidates,
                           int candidate_count, int *out0, int *out1)
{
    int found = 0;
    if(out0) *out0 = -1;
    if(out1) *out1 = -1;
    if(!candidates || candidate_count <= 0) return 0;

    for(int i=0; i<candidate_count && found < 2; i++){
        int reg = candidates[i];
        if(reg < 0 || reg > 31) continue;
        if(used_mask & (1u << reg)) continue;
        if(found == 0 && out0) *out0 = reg;
        if(found == 1 && out1) *out1 = reg;
        found++;
    }
    return found;
}

const char *arm64_gpr_name(int reg_idx){
    static const char *names[32] = {
        "x0","x1","x2","x3","x4","x5","x6","x7",
        "x8","x9","x10","x11","x12","x13","x14","x15",
        "x16","x17","x18","x19","x20","x21","x22","x23",
        "x24","x25","x26","x27","x28","x29","x30","sp"
    };
    if(reg_idx < 0 || reg_idx > 31) return "x?";
    return names[reg_idx];
}
