#include "obfuscate.h"
#include "arm64_analyze.h"
#include "pcrel.h"
#include "arm64_enc.h"
#include "extpc.h"
#include "util.h"

uint64_t func_end_va_reachable(const uint8_t *text_data,
    uint64_t text_va, uint64_t text_sz,
    uint64_t fva, uint64_t next_fva)
{
    uint64_t max_end=(next_fva<text_va+text_sz)?next_fva:text_va+text_sz;
    uint32_t func_insns=(uint32_t)((max_end-fva)/4);
    if(func_insns==0) return fva;
    bool *reachable=(bool*)calloc((size_t)(func_insns+1),sizeof(bool));
    if(!reachable) return max_end;
    reachable[0]=true;
    bool changed=true;
    int iterations=0;
    while(changed&&iterations<200){
        changed=false; iterations++;
        for(uint32_t i=0;i<func_insns;i++){
            if(!reachable[i]) continue;
            uint64_t insn_va=fva+(uint64_t)i*4;
            uint64_t insn_fo=(insn_va-text_va);
            if(insn_fo+4>text_sz) continue;
            uint32_t w=rd32(text_data+insn_fo);
            bool is_ret_i=(w==0xD65F03C0u||w==0xD65F0BFFu||w==0xD65F0FFFu);
            bool is_b_uncond=((w&0xFC000000u)==0x14000000u);
            bool is_br_i=((w&0xFFFFFC1Fu)==0xD61F0000u);
            bool is_brk=((w&0xFFE0001Fu)==0xD4200000u);
            bool is_braa=((w&0xFEFFF800u)==0xD61F0800u);
            if(!is_ret_i&&!is_b_uncond&&!is_br_i&&!is_brk&&!is_braa){
                if(i+1<func_insns&&!reachable[i+1]){ reachable[i+1]=true; changed=true; }
            }
            int64_t off=0;
            PCType pt=classify_pcrel(w,&off);
            if(is_internal_br(pt)||pt==PC_B26){
                int64_t abs_tgt=(int64_t)insn_va+off;
                if(abs_tgt>=(int64_t)fva&&abs_tgt<(int64_t)max_end){
                    uint32_t tgt_idx=(uint32_t)((uint64_t)abs_tgt-fva)/4;
                    if(tgt_idx<func_insns&&!reachable[tgt_idx]){ reachable[tgt_idx]=true; changed=true; }
                }
            }
        }
    }
    uint32_t last_reachable=0;
    for(uint32_t i=0;i<func_insns;i++){
        if(reachable[i]) last_reachable=i;
    }
    free(reachable);
    return fva+(uint64_t)(last_reachable+1)*4;
}

int ldvq2306_split_basic_blocks(const uint32_t *src, int src_cnt, uint64_t orig_va,
                       BasicBlock *bbs, int max_bbs)
{
    bool *is_leader=(bool*)calloc((size_t)(src_cnt+1),sizeof(bool));
    if(!is_leader) return 0;
    is_leader[0]=true;
    for(int i=0;i<src_cnt;i++){
        uint32_t w=src[i];
        if(is_terminator(w)||is_cond_branch(w)){
            if(i+1<src_cnt) is_leader[i+1]=true;
        }
        int64_t off=0;
        PCType t=classify_pcrel(w,&off);
        if(is_internal_br(t)||t==PC_B26){
            int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)i*4)+off;
            int64_t tgt_idx=((int64_t)abs_tgt-(int64_t)orig_va)/4;
            if(tgt_idx>=0&&tgt_idx<src_cnt) is_leader[(int)tgt_idx]=true;
        }

        if(t==PC_BL26){
            if(i+1<src_cnt) is_leader[i+1]=true;
        }
    }
    int nbb=0;
    for(int i=0;i<src_cnt;i++){
        if(is_leader[i]){
            if(nbb>0) bbs[nbb-1].end_idx=i;
            if(nbb>=max_bbs){free(is_leader);return nbb;}
            bbs[nbb].start_idx=i;
            bbs[nbb].end_idx=src_cnt;
            bbs[nbb].block_id=nbb;
            nbb++;
        }
    }
    free(is_leader);
    return nbb;
}

int find_bb_for_idx(const BasicBlock *bbs, int nbb, int idx){
    for(int i=0;i<nbb;i++){
        if(idx>=bbs[i].start_idx&&idx<bbs[i].end_idx) return i;
    }
    return -1;
}

#define ENC_BR_V2_SIZE 23

int ldvq2306_emit_encrypted_branch_v2(uint32_t *dst, int n, int max_n){
    if(n+ENC_BR_V2_SIZE>max_n) return -1;
    dst[n++]=enc_movz(16,0,0);
    dst[n++]=enc_movk(16,0,16);
    dst[n++]=enc_movk(16,0,32);
    dst[n++]=enc_movk(16,0,48);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);
    dst[n++]=enc_mul_x(16,16,17);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);
    dst[n++]=enc_eor_x(16,16,17);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);
    dst[n++]=enc_add_r(16,16,17);
    dst[n++]=enc_adr(17,0);
    dst[n++]=enc_add_r(16,16,17);
    dst[n++]=enc_br(16);
    dst[n++]=NOP;
    return n;
}

void ldvq2306_patch_encrypted_branch_v2(uint32_t *dst, int enc_start, uint64_t target_va, uint64_t adr_va){
    uint64_t mul_key, xor_key, add_key;
    do {
        mul_key=((uint64_t)rand()<<32)|(uint64_t)rand();
        mul_key |= 1ULL;
    } while(mul_key == 0 || mul_key == 1);
    xor_key=((uint64_t)rand()<<32)|(uint64_t)rand();
    xor_key ^= ((uint64_t)rand()<<16);
    add_key=((uint64_t)rand()<<32)|(uint64_t)rand();

    int64_t rel_off = (int64_t)target_va - (int64_t)adr_va;

    uint64_t after_add = (uint64_t)rel_off - add_key;
    uint64_t after_xor = after_add ^ xor_key;

    uint64_t inv_mul = 1;
    uint64_t mk = mul_key;
    for(int i=0;i<63;i++){
        inv_mul *= mk;
        mk *= mk;
    }
    uint64_t val = after_xor * inv_mul;

    dst[enc_start+0]=enc_movz(16,(uint16_t)(val&0xFFFF),0);
    dst[enc_start+1]=enc_movk(16,(uint16_t)((val>>16)&0xFFFF),16);
    dst[enc_start+2]=enc_movk(16,(uint16_t)((val>>32)&0xFFFF),32);
    dst[enc_start+3]=enc_movk(16,(uint16_t)((val>>48)&0xFFFF),48);
    dst[enc_start+4]=enc_movz(17,(uint16_t)(mul_key&0xFFFF),0);
    dst[enc_start+5]=enc_movk(17,(uint16_t)((mul_key>>16)&0xFFFF),16);
    dst[enc_start+6]=enc_movk(17,(uint16_t)((mul_key>>32)&0xFFFF),32);
    dst[enc_start+7]=enc_movk(17,(uint16_t)((mul_key>>48)&0xFFFF),48);
    dst[enc_start+9]=enc_movz(17,(uint16_t)(xor_key&0xFFFF),0);
    dst[enc_start+10]=enc_movk(17,(uint16_t)((xor_key>>16)&0xFFFF),16);
    dst[enc_start+11]=enc_movk(17,(uint16_t)((xor_key>>32)&0xFFFF),32);
    dst[enc_start+12]=enc_movk(17,(uint16_t)((xor_key>>48)&0xFFFF),48);
    dst[enc_start+14]=enc_movz(17,(uint16_t)(add_key&0xFFFF),0);
    dst[enc_start+15]=enc_movk(17,(uint16_t)((add_key>>16)&0xFFFF),16);
    dst[enc_start+16]=enc_movk(17,(uint16_t)((add_key>>32)&0xFFFF),32);
    dst[enc_start+17]=enc_movk(17,(uint16_t)((add_key>>48)&0xFFFF),48);
    dst[enc_start+19]=enc_adr(17,0);
}

int ldvq2306_emit_encrypted_branch(uint32_t *dst, int n, int max_n){
    if(n+ENC_BR_SIZE>max_n) return -1;
    dst[n++]=enc_movz(16,0,0);
    dst[n++]=enc_movk(16,0,16);
    dst[n++]=enc_movk(16,0,32);
    dst[n++]=enc_movk(16,0,48);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);
    dst[n++]=enc_ror_x(17,17,7);
    dst[n++]=enc_eor_x(16,16,17);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);
    dst[n++]=enc_sub_r(16,16,17);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_eor_x(16,16,17);
    dst[n++]=enc_adr(17,0);
    dst[n++]=enc_add_r(16,16,17);
    dst[n++]=enc_br(16);
    return n;
}

void ldvq2306_patch_encrypted_branch(uint32_t *dst, int enc_start, uint64_t target_va, uint64_t adr_va){
    uint64_t key1=((uint64_t)rand()<<32)|(uint64_t)rand(); key1^=((uint64_t)rand()<<16);
    uint64_t key2=((uint64_t)rand()<<32)|(uint64_t)rand(); key2^=((uint64_t)rand()<<8);
    uint64_t key3=((uint64_t)rand()<<32)|(uint64_t)rand();
    key3 &= 0x00000000FFFFFFFFull;
    int64_t rel_off = (int64_t)target_va - (int64_t)adr_va;
    uint64_t val = (uint64_t)rel_off;
    val = val ^ key3;
    val = val + key2;
    uint64_t key1_ror7 = (key1 >> 7) | (key1 << 57);
    val = val ^ key1_ror7;
    dst[enc_start+0]=enc_movz(16,(uint16_t)(val&0xFFFF),0);
    dst[enc_start+1]=enc_movk(16,(uint16_t)((val>>16)&0xFFFF),16);
    dst[enc_start+2]=enc_movk(16,(uint16_t)((val>>32)&0xFFFF),32);
    dst[enc_start+3]=enc_movk(16,(uint16_t)((val>>48)&0xFFFF),48);
    dst[enc_start+4]=enc_movz(17,(uint16_t)(key1&0xFFFF),0);
    dst[enc_start+5]=enc_movk(17,(uint16_t)((key1>>16)&0xFFFF),16);
    dst[enc_start+6]=enc_movk(17,(uint16_t)((key1>>32)&0xFFFF),32);
    dst[enc_start+7]=enc_movk(17,(uint16_t)((key1>>48)&0xFFFF),48);
    dst[enc_start+10]=enc_movz(17,(uint16_t)(key2&0xFFFF),0);
    dst[enc_start+11]=enc_movk(17,(uint16_t)((key2>>16)&0xFFFF),16);
    dst[enc_start+12]=enc_movk(17,(uint16_t)((key2>>32)&0xFFFF),32);
    dst[enc_start+13]=enc_movk(17,(uint16_t)((key2>>48)&0xFFFF),48);
    dst[enc_start+15]=enc_movz(17,(uint16_t)(key3&0xFFFF),0);
    dst[enc_start+16]=enc_movk(17,(uint16_t)((key3>>16)&0xFFFF),16);
    dst[enc_start+18]=enc_adr(17,0);
}

static uint64_t obf_rand64(void){
    return ((uint64_t)rand()<<48) ^ ((uint64_t)rand()<<32) ^
           ((uint64_t)rand()<<16) ^ (uint64_t)rand();
}

static uint32_t obf_rand32(void){
    return (uint32_t)rand() ^ ((uint32_t)rand()<<16);
}

static int obf_emit_mov64(uint32_t *dst, int n, int reg, uint64_t val){
    dst[n++]=enc_movz(reg,(uint16_t)(val&0xFFFF),0);
    dst[n++]=enc_movk(reg,(uint16_t)((val>>16)&0xFFFF),16);
    dst[n++]=enc_movk(reg,(uint16_t)((val>>32)&0xFFFF),32);
    dst[n++]=enc_movk(reg,(uint16_t)((val>>48)&0xFFFF),48);
    return n;
}

static void obf_gen_state_ids(uint32_t *ids, int count){
    for(int i=0;i<count;i++){
        uint32_t id;
        bool unique;
        do {
            id = obf_rand32();
            if(id==0) id=1;
            unique=true;
            for(int j=0;j<i;j++){
                if(ids[j]==id){ unique=false; break; }
            }
        } while(!unique);
        ids[i]=id;
    }
}

#define CFF_ENC_BR_SIZE 19
#define CFF_ENC_BR_SIZE_SAVE 20

static int cff_emit_enc_br(uint32_t *dst, int n, int max_n,
                           bool save_x16x17, int *movz_start){
    int need = save_x16x17 ? CFF_ENC_BR_SIZE_SAVE : CFF_ENC_BR_SIZE;
    if(n+need > max_n) return -1;
    if(save_x16x17)
        dst[n++]=enc_stp_pre(16,17,31,-2);
    if(movz_start) *movz_start = n;
    dst[n++]=enc_movz(16,0,0);
    dst[n++]=enc_movk(16,0,16);
    dst[n++]=enc_movk(16,0,32);
    dst[n++]=enc_movk(16,0,48);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);
    dst[n++]=enc_eor_x(16,16,17);
    dst[n++]=enc_movz(17,0,0);
    dst[n++]=enc_movk(17,0,16);
    dst[n++]=enc_movk(17,0,32);
    dst[n++]=enc_movk(17,0,48);
    dst[n++]=enc_add_r(16,16,17);
    dst[n++]=enc_adr(17,0);
    dst[n++]=enc_add_r(16,16,17);
    dst[n++]=enc_br(16);
    dst[n++]=NOP;
    dst[n++]=NOP;
    return n;
}

static void cff_patch_enc_br(uint32_t *dst, int enc_start,
                             uint64_t target_va, uint64_t adr_va){
    uint64_t xor_key = obf_rand64();
    uint64_t add_key = obf_rand64();
    int64_t rel_off = (int64_t)target_va - (int64_t)adr_va;
    uint64_t val = ((uint64_t)rel_off - add_key) ^ xor_key;
    dst[enc_start+0]=enc_movz(16,(uint16_t)(val&0xFFFF),0);
    dst[enc_start+1]=enc_movk(16,(uint16_t)((val>>16)&0xFFFF),16);
    dst[enc_start+2]=enc_movk(16,(uint16_t)((val>>32)&0xFFFF),32);
    dst[enc_start+3]=enc_movk(16,(uint16_t)((val>>48)&0xFFFF),48);
    dst[enc_start+4]=enc_movz(17,(uint16_t)(xor_key&0xFFFF),0);
    dst[enc_start+5]=enc_movk(17,(uint16_t)((xor_key>>16)&0xFFFF),16);
    dst[enc_start+6]=enc_movk(17,(uint16_t)((xor_key>>32)&0xFFFF),32);
    dst[enc_start+7]=enc_movk(17,(uint16_t)((xor_key>>48)&0xFFFF),48);
    dst[enc_start+9]=enc_movz(17,(uint16_t)(add_key&0xFFFF),0);
    dst[enc_start+10]=enc_movk(17,(uint16_t)((add_key>>16)&0xFFFF),16);
    dst[enc_start+11]=enc_movk(17,(uint16_t)((add_key>>32)&0xFFFF),32);
    dst[enc_start+12]=enc_movk(17,(uint16_t)((add_key>>48)&0xFFFF),48);
    dst[enc_start+14]=enc_adr(17,0);
    dst[enc_start+17]=NOP;
    dst[enc_start+18]=NOP;
}

static int obf_emit_bcf_r(uint32_t *dst, int n, int max_n, int r0, int r1){
    if(r0 < 0 || r1 < 0) return n;
    if(n+24 > max_n) return n;
    int dead_count = 2 + (rand() % 3);

    uint64_t opaque_val = obf_rand64() | 1ULL;
    int variant = rand() % 8;
    uint16_t safe_const = (uint16_t)((rand() & 0xFFFE) | 1);

    n=obf_emit_mov64(dst,n,r1,opaque_val);
    uint32_t orr_r1_r0 = 0xAA000000u|((uint32_t)r1<<16)|((uint32_t)r0<<5)|(uint32_t)r0;
    switch(variant){
    case 0:
            dst[n++]=enc_orn_x(r0,r1,r1);
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    case 1:
            dst[n++]=enc_movz(r0,1,0); dst[n++]=orr_r1_r0;
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    case 2:
            dst[n++]=enc_eor_x(r0,r1,r1); dst[n++]=enc_add_i(r0,r0,1);
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    case 3:
            dst[n++]=enc_mvn_x(r0,r1); dst[n++]=orr_r1_r0;
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    case 4:
            dst[n++]=enc_movz(r0,safe_const,0); dst[n++]=orr_r1_r0;
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    case 5:
            dst[n++]=enc_and_x(r0,r1,r1); dst[n++]=enc_orn_x(r0,r0,r0);
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    case 6:
            dst[n++]=enc_movz(r0,safe_const,0); dst[n++]=enc_orn_x(r0,r0,r1);
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    case 7:
            dst[n++]=enc_orn_x(r0,r1,r1);
            dst[n++]=enc_cbnz_x(r0,dead_count+1); break;
    }

    for(int di=0; di<dead_count && n<max_n; di++)
        dst[n++]=NOP;
    return n;
}

static int obf_emit_junk_r(uint32_t *dst, int n, int max_n, int count, int r0, int r1){
    if(r0 < 0 || r1 < 0) return n;
    for(int i=0;i<count && n<max_n;i++){
        int kind = rand() % 24;
        switch(kind){
        case 0:  dst[n++]=enc_eor_x(r0,r0,r0); break;
        case 1:  dst[n++]=enc_add_r(r1,r1,r0); break;
        case 2:  dst[n++]=enc_movz(r0,(uint16_t)(rand()&0xFFFF),0); break;
        case 3:  dst[n++]=enc_ror_x(r1,r1,rand()%63+1); break;
        case 4:  dst[n++]=enc_mul_x(r0,r1,r0); break;
        case 5:  dst[n++]=enc_eor_x(r1,r1,r0); break;
        case 6:  dst[n++]=enc_sub_r(r0,r0,r1); break;
        case 7:  dst[n++]=enc_movk(r0,(uint16_t)(rand()&0xFFFF),16); break;
        case 8:  dst[n++]=enc_mvn_x(r0,r0); break;
        case 9:  dst[n++]=enc_movz(r1,(uint16_t)(rand()&0xFFFF),0); break;
        case 10: dst[n++]=enc_orn_x(r0,r1,r0); break;
        case 11: dst[n++]=enc_add_i(r0,r0,rand()%0xFFF+1); break;
        case 12: dst[n++]=enc_neg_x(r0,r1); break;
        case 13: dst[n++]=enc_and_x(r0,r0,r1); break;
        case 14: dst[n++]=enc_lsl_x_imm(r0,r0,rand()%63+1); break;
        case 15: dst[n++]=enc_lsr_x_imm(r0,r0,rand()%63+1); break;
        case 16: dst[n++]=enc_bic_x(r0,r1,r0); break;
        case 17: dst[n++]=enc_eon_x(r0,r1,r0); break;
        case 18: dst[n++]=enc_rev_x(r0,r0); break;
        case 19: dst[n++]=enc_rbit_x(r0,r0); break;
        case 20: dst[n++]=enc_clz_x(r0,r1); break;
        case 21: dst[n++]=enc_orr_x(r0,r1,r0); break;
        case 22: dst[n++]=enc_movk(r1,(uint16_t)(rand()&0xFFFF),32); break;
        case 23: dst[n++]=enc_sub_i(r0,r0,rand()%0xFFF+1); break;
        }
    }
    return n;
}

typedef struct {
    bool flags_live_at_entry;
    bool flags_live_at_exit;
    bool has_flag_setter;
    bool has_flag_consumer;
    int first_flag_use_idx;
    int last_flag_set_idx;
} BlockFlagInfo;

static void analyze_block_flags(const uint32_t *src, const BasicBlock *bb,
                                BlockFlagInfo *info)
{
    memset(info, 0, sizeof(*info));
    info->first_flag_use_idx = -1;
    info->last_flag_set_idx = -1;

    for(int i = bb->start_idx; i < bb->end_idx; i++){
        uint32_t w = src[i];
        if(uses_flags(w)){
            info->has_flag_consumer = true;
            if(info->first_flag_use_idx < 0)
                info->first_flag_use_idx = i;

            if(i == bb->start_idx || !info->has_flag_setter)
                info->flags_live_at_entry = true;
        }
        if(sets_flags(w)){
            info->has_flag_setter = true;
            info->last_flag_set_idx = i;
        }
    }

    if(info->last_flag_set_idx >= 0 &&
       info->last_flag_set_idx == bb->end_idx - 1){
        info->flags_live_at_exit = true;
    }

    if(bb->end_idx > bb->start_idx){
        uint32_t last_w = src[bb->end_idx - 1];
        if(is_cond_branch(last_w) && uses_flags(last_w)){

            info->flags_live_at_exit = false;
        }
    }
}

typedef struct {
    int adrp_idx;
    int pair_idx;
    int rd;
    uint64_t abs_target;
    bool is_split;
    bool is_call_target;
} AdrpPairInfo;

static int analyze_adrp_pairs(const uint32_t *src, int src_cnt, uint64_t orig_va,
                               const BasicBlock *bbs, int nbb,
                               AdrpPairInfo *pairs, int max_pairs)
{
    int npairs = 0;
    for(int i = 0; i < src_cnt && npairs < max_pairs; i++){
        uint32_t w = src[i];
        if(!is_adrp(w)) continue;

        int rd = (int)(w & 0x1F);
        int32_t immhi = (int32_t)((w >> 5) & 0x7FFFFu);
        if(immhi & 0x40000) immhi |= (int32_t)0xFFF80000;
        int32_t immlo = (int32_t)((w >> 29) & 3u);
        int64_t page_off = ((int64_t)((immhi << 2) | immlo)) << 12;
        uint64_t insn_va = orig_va + (uint64_t)i * 4;
        uint64_t abs_page = (uint64_t)((int64_t)(insn_va & ~0xFFFULL) + page_off);

        pairs[npairs].adrp_idx = i;
        pairs[npairs].pair_idx = -1;
        pairs[npairs].rd = rd;
        pairs[npairs].abs_target = abs_page;
        pairs[npairs].is_split = false;
        pairs[npairs].is_call_target = false;

        for(int j = i + 1; j < src_cnt && j <= i + 3; j++){
            uint32_t w2 = src[j];
            int rn2 = (int)((w2 >> 5) & 0x1F);
            int rd2 = (int)(w2 & 0x1F);

            if((w2 & 0xFFC00000u) == 0x91000000u && rn2 == rd){
                uint32_t add_imm = (w2 >> 10) & 0xFFF;
                bool add_sh = ((w2 >> 22) & 1) != 0;
                if(add_sh) add_imm <<= 12;
                pairs[npairs].abs_target = abs_page + add_imm;
                pairs[npairs].pair_idx = j;

                if(j + 1 < src_cnt){
                    uint32_t w3 = src[j + 1];
                    if((w3 & 0xFFFFFC1Fu) == 0xD63F0000u){
                        int blr_rn = (int)((w3 >> 5) & 0x1F);
                        if(blr_rn == rd2)
                            pairs[npairs].is_call_target = true;
                    }
                }
                break;
            }

            if((w2 & 0xFFC00000u) == 0xF9400000u && rn2 == rd){
                uint32_t ldr_off = ((w2 >> 10) & 0xFFF) * 8;
                pairs[npairs].abs_target = abs_page + ldr_off;
                pairs[npairs].pair_idx = j;
                break;
            }

            if((w2 & 0xFFC00000u) == 0xF9000000u && rn2 == rd){
                uint32_t str_off = ((w2 >> 10) & 0xFFF) * 8;
                pairs[npairs].abs_target = abs_page + str_off;
                pairs[npairs].pair_idx = j;
                break;
            }

            int dest_of_w2 = (int)(w2 & 0x1F);
            if(dest_of_w2 == rd && !is_adrp(w2)){
                break;
            }
        }

        if(pairs[npairs].pair_idx >= 0){
            int bb1 = find_bb_for_idx(bbs, nbb, i);
            int bb2 = find_bb_for_idx(bbs, nbb, pairs[npairs].pair_idx);
            if(bb1 >= 0 && bb2 >= 0 && bb1 != bb2)
                pairs[npairs].is_split = true;
        }

        npairs++;
    }
    return npairs;
}

typedef struct {
    int max_depth;
    int entry_adjustment;
    int exit_adjustment;
    bool has_dynamic_sp;
    bool balanced;
    int n_push;
    int n_pop;
} StackAnalysis;

static void analyze_stack_depth(const uint32_t *src, int src_cnt, StackAnalysis *sa)
{
    memset(sa, 0, sizeof(*sa));
    int depth = 0;
    sa->balanced = true;

    for(int i = 0; i < src_cnt; i++){
        uint32_t w = src[i];

        if((w & 0xFFC003FFu) == 0xD10003FFu){
            uint32_t imm12 = (w >> 10) & 0xFFF;
            bool sh = ((w >> 22) & 1) != 0;
            if(sh) imm12 <<= 12;
            depth -= (int)imm12;
            if(sa->entry_adjustment == 0)
                sa->entry_adjustment = (int)imm12;
            if(depth < sa->max_depth) sa->max_depth = depth;
        }

        if((w & 0xFFC003FFu) == 0x910003FFu){
            uint32_t imm12 = (w >> 10) & 0xFFF;
            bool sh = ((w >> 22) & 1) != 0;
            if(sh) imm12 <<= 12;
            depth += (int)imm12;
            sa->exit_adjustment = (int)imm12;
        }

        if((w & 0xFF2003FFu) == 0xCB0003FFu){
            sa->has_dynamic_sp = true;
        }

        if((w & 0xFFC00000u) == 0xA9000000u ||
           (w & 0xFFC00000u) == 0xA9800000u){
            int rn = (int)((w >> 5) & 0x1F);
            if(rn == 31) sa->n_push++;
        }

        if((w & 0xFFC00000u) == 0xA9400000u ||
           (w & 0xFFC00000u) == 0xA8C00000u){
            int rn = (int)((w >> 5) & 0x1F);
            if(rn == 31) sa->n_pop++;
        }
    }

    if(depth != 0) sa->balanced = false;
}

typedef struct {
    int from_bb;
    int to_bb;
    int depth;
} LoopEdge;

static int detect_loops(const uint32_t *src, int src_cnt, uint64_t orig_va,
                        const BasicBlock *bbs, int nbb,
                        LoopEdge *loops, int max_loops)
{
    int nloops = 0;
    for(int bi = 0; bi < nbb && nloops < max_loops; bi++){
        const BasicBlock *bb = &bbs[bi];
        if(bb->end_idx <= bb->start_idx) continue;

        uint32_t last_w = src[bb->end_idx - 1];
        int64_t off = 0;
        PCType t = classify_pcrel(last_w, &off);

        if(t == PC_B26 || is_internal_br(t)){
            int64_t abs_tgt = (int64_t)(orig_va + (uint64_t)(bb->end_idx - 1) * 4) + off;
            int64_t tgt_idx = ((int64_t)abs_tgt - (int64_t)orig_va) / 4;
            if(tgt_idx >= 0 && tgt_idx < src_cnt){
                int tgt_bb = find_bb_for_idx(bbs, nbb, (int)tgt_idx);

                if(tgt_bb >= 0 && tgt_bb <= bi){
                    loops[nloops].from_bb = bi;
                    loops[nloops].to_bb = tgt_bb;
                    loops[nloops].depth = 1;
                    nloops++;
                }
            }
        }

        if(is_cond_branch(last_w)){
            int64_t abs_tgt = (int64_t)(orig_va + (uint64_t)(bb->end_idx - 1) * 4) + off;
            int64_t tgt_idx = ((int64_t)abs_tgt - (int64_t)orig_va) / 4;
            if(tgt_idx >= 0 && tgt_idx < src_cnt){
                int tgt_bb = find_bb_for_idx(bbs, nbb, (int)tgt_idx);
                if(tgt_bb >= 0 && tgt_bb <= bi && nloops < max_loops){
                    loops[nloops].from_bb = bi;
                    loops[nloops].to_bb = tgt_bb;
                    loops[nloops].depth = 1;
                    nloops++;
                }
            }
        }
    }

    for(int i = 0; i < nloops; i++){
        for(int j = 0; j < nloops; j++){
            if(i == j) continue;
            if(loops[j].to_bb <= loops[i].to_bb &&
               loops[j].from_bb >= loops[i].from_bb &&
               (loops[j].to_bb != loops[i].to_bb || loops[j].from_bb != loops[i].from_bb)){
                loops[i].depth++;
            }
        }
    }

    return nloops;
}

typedef struct {
    uint32_t def_mask;
    uint32_t use_mask;
    uint32_t live_in;
    uint32_t live_out;
    int max_simultaneous;
} BlockRegInfo;

static uint32_t get_insn_read_regs(uint32_t w){
    uint32_t mask = 0;

    int rn = (int)((w >> 5) & 0x1F);
    int rm = (int)((w >> 16) & 0x1F);
    int rd = (int)(w & 0x1F);

    if(rn < 31) mask |= (1u << rn);

    uint32_t top8 = (w >> 24) & 0xFF;
    if(top8 == 0x8B || top8 == 0xCB || top8 == 0xAA || top8 == 0xCA ||
       top8 == 0x0A || top8 == 0x2A || top8 == 0x4A || top8 == 0x6A ||
       top8 == 0x9B || top8 == 0x1B){
        if(rm < 31) mask |= (1u << rm);
    }

    if((w & 0xBFC00000u) == 0xB9000000u ||
       (w & 0xBFE00C00u) == 0xB8000000u){
        if(rd < 31) mask |= (1u << rd);
    }

    if((w & 0xFFFFFC1Fu) == 0xD63F0000u ||
       (w & 0xFFFFFC1Fu) == 0xD61F0000u){
        if(rn < 31) mask |= (1u << rn);
    }

    if((w & 0x7FE0001Fu) == 0x6B00001Fu ||
       (w & 0x7FE0001Fu) == 0x6A00001Fu){
        if(rn < 31) mask |= (1u << rn);
        if(rm < 31) mask |= (1u << rm);
    }

    return mask;
}

static uint32_t get_insn_write_regs(uint32_t w){
    uint32_t mask = 0;
    int rd = (int)(w & 0x1F);

    uint32_t top = (w >> 24) & 0xFF;
    bool is_write = false;

    if((top & 0x1F) == 0x11 ||
       (top & 0x1F) == 0x0B ||
       (top & 0x1F) == 0x0A ||
       (top & 0x1F) == 0x12 ||
       top == 0xD2 || top == 0x92 || top == 0xF2 ||
       top == 0xAA || top == 0xCA ||
       top == 0x8B || top == 0xCB ||
       (w & 0xBFC00000u) == 0xB9400000u ||
       (w & 0xFF000000u) == 0x58000000u ||
       (w & 0xFF800000u) == 0xD2800000u ||
       (w & 0xFF800000u) == 0xF2800000u ||
       top == 0x90 || top == 0x10){
        is_write = true;
    }

    if((w & 0xFFC00000u) == 0xA9800000u ||
       (w & 0xFFC00000u) == 0xA8C00000u){
        int rn = (int)((w >> 5) & 0x1F);
        if(rn < 31) mask |= (1u << rn);
    }

    if((w & 0xFFC00000u) == 0xA9400000u ||
       (w & 0xFFC00000u) == 0xA8C00000u){
        int rt2 = (int)((w >> 10) & 0x1F);
        if(rd < 31) mask |= (1u << rd);
        if(rt2 < 31) mask |= (1u << rt2);
        is_write = false;
    }

    if((w & 0xFC000000u) == 0x94000000u){
        mask |= (1u << 30);

    }

    if(is_write && rd < 31)
        mask |= (1u << rd);

    return mask;
}

static void analyze_block_registers(const uint32_t *src, const BasicBlock *bb,
                                    BlockRegInfo *info)
{
    memset(info, 0, sizeof(*info));
    uint32_t current_live = 0;
    info->max_simultaneous = 0;

    for(int i = bb->start_idx; i < bb->end_idx; i++){
        uint32_t w = src[i];
        uint32_t reads = get_insn_read_regs(w);
        uint32_t writes = get_insn_write_regs(w);

        info->use_mask |= (reads & ~info->def_mask);
        info->def_mask |= writes;

        current_live |= reads;

        current_live |= writes;

        int live_count = __builtin_popcount(current_live);
        if(live_count > info->max_simultaneous)
            info->max_simultaneous = live_count;
    }

    info->live_in = info->use_mask;
    info->live_out = info->def_mask;
}

typedef struct {
    int n_blocks;
    int n_instructions;
    int n_loops;
    int max_loop_depth;
    int n_adrp_pairs;
    int n_split_adrp_pairs;
    int n_call_sites;
    int max_reg_pressure;
    bool has_dynamic_stack;
    bool stack_balanced;
    int stack_depth;
    bool has_flag_sensitive_transitions;
    int n_external_branches;
    int n_internal_branches;
    float estimated_expansion;
} FuncAnalysisReport;

static void deep_analyze_function(const uint32_t *src, int src_cnt, uint64_t orig_va,
                                  const BasicBlock *bbs, int nbb,
                                  FuncAnalysisReport *report)
{
    memset(report, 0, sizeof(*report));
    report->n_blocks = nbb;
    report->n_instructions = src_cnt;

    StackAnalysis sa;
    analyze_stack_depth(src, src_cnt, &sa);
    report->has_dynamic_stack = sa.has_dynamic_sp;
    report->stack_balanced = sa.balanced;
    report->stack_depth = sa.max_depth;

    LoopEdge loops[256];
    int nloops = detect_loops(src, src_cnt, orig_va, bbs, nbb, loops, 256);
    report->n_loops = nloops;
    for(int i = 0; i < nloops; i++){
        if(loops[i].depth > report->max_loop_depth)
            report->max_loop_depth = loops[i].depth;
    }

    AdrpPairInfo adrp_pairs[512];
    int n_adrp = analyze_adrp_pairs(src, src_cnt, orig_va, bbs, nbb, adrp_pairs, 512);
    report->n_adrp_pairs = n_adrp;
    for(int i = 0; i < n_adrp; i++){
        if(adrp_pairs[i].is_split) report->n_split_adrp_pairs++;
        if(adrp_pairs[i].is_call_target) report->n_call_sites++;
    }

    for(int bi = 0; bi < nbb && bi < 256; bi++){
        BlockFlagInfo fi;
        analyze_block_flags(src, &bbs[bi], &fi);
        if(fi.flags_live_at_entry && bi > 0){
            report->has_flag_sensitive_transitions = true;
        }
    }

    for(int bi = 0; bi < nbb && bi < 256; bi++){
        BlockRegInfo ri;
        analyze_block_registers(src, &bbs[bi], &ri);
        if(ri.max_simultaneous > report->max_reg_pressure)
            report->max_reg_pressure = ri.max_simultaneous;
    }

    for(int i = 0; i < src_cnt; i++){
        uint32_t w = src[i];
        int64_t off = 0;
        PCType t = classify_pcrel(w, &off);
        if(t == PC_NONE || t == PC_ADRP || t == PC_ADR) continue;
        if(t == PC_BL26) { report->n_call_sites++; continue; }

        int64_t abs_tgt = (int64_t)(orig_va + (uint64_t)i * 4) + off;
        int64_t tgt_idx = ((int64_t)abs_tgt - (int64_t)orig_va) / 4;
        if(tgt_idx >= 0 && tgt_idx < src_cnt)
            report->n_internal_branches++;
        else
            report->n_external_branches++;
    }

    float base = 3.0f;
    if(nloops > 0) base += 0.5f;
    if(report->has_flag_sensitive_transitions) base += 0.3f;
    if(report->n_external_branches > 5) base += 0.5f;
    report->estimated_expansion = base;
}

static int cff_emit_state_update(uint32_t *dst, int n, int max_n, uint32_t state_id, int s0, int s1){
    if(n+12>max_n) return -1;
    int variant = rand() % 6;
    uint32_t key1 = obf_rand32();
    uint32_t key2 = obf_rand32();
    switch(variant){
    case 0: {
        uint32_t enc = state_id ^ key1;
        dst[n++]=enc_movz(s0,(uint16_t)(enc&0xFFFF),0);
        dst[n++]=enc_movk(s0,(uint16_t)((enc>>16)&0xFFFF),16);
        dst[n++]=enc_movz(s1,(uint16_t)(key1&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key1>>16)&0xFFFF),16);
        dst[n++]=enc_eor_w(15,s0,s1);
        break;
    }
    case 1: {
        uint32_t enc = state_id + key1;
        dst[n++]=enc_movz(s0,(uint16_t)(enc&0xFFFF),0);
        dst[n++]=enc_movk(s0,(uint16_t)((enc>>16)&0xFFFF),16);
        dst[n++]=enc_movz(s1,(uint16_t)(key1&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key1>>16)&0xFFFF),16);
        dst[n++]=enc_sub_w_r(15,s0,s1);
        break;
    }
    case 2: {
        uint32_t enc = state_id ^ key1 ^ key2;
        dst[n++]=enc_movz(s0,(uint16_t)(enc&0xFFFF),0);
        dst[n++]=enc_movk(s0,(uint16_t)((enc>>16)&0xFFFF),16);
        dst[n++]=enc_movz(s1,(uint16_t)(key1&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key1>>16)&0xFFFF),16);
        dst[n++]=enc_eor_w(s0,s0,s1);
        dst[n++]=enc_movz(s1,(uint16_t)(key2&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key2>>16)&0xFFFF),16);
        dst[n++]=enc_eor_w(15,s0,s1);
        break;
    }
    case 3: {
        uint32_t enc = (state_id - key1) ^ key2;
        dst[n++]=enc_movz(s0,(uint16_t)(enc&0xFFFF),0);
        dst[n++]=enc_movk(s0,(uint16_t)((enc>>16)&0xFFFF),16);
        dst[n++]=enc_movz(s1,(uint16_t)(key2&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key2>>16)&0xFFFF),16);
        dst[n++]=enc_eor_w(s0,s0,s1);
        dst[n++]=enc_movz(s1,(uint16_t)(key1&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key1>>16)&0xFFFF),16);
        dst[n++]=enc_add_w_r(15,s0,s1);
        break;
    }
    case 4: {

        uint32_t enc = (state_id ^ key1) - key2;
        dst[n++]=enc_movz(s0,(uint16_t)(enc&0xFFFF),0);
        dst[n++]=enc_movk(s0,(uint16_t)((enc>>16)&0xFFFF),16);
        dst[n++]=enc_movz(s1,(uint16_t)(key2&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key2>>16)&0xFFFF),16);
        dst[n++]=enc_add_w_r(s0,s0,s1);
        dst[n++]=enc_movz(s1,(uint16_t)(key1&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key1>>16)&0xFFFF),16);
        dst[n++]=enc_eor_w(15,s0,s1);
        break;
    }
    case 5: {

        uint32_t enc = (state_id ^ key1) + key2;
        dst[n++]=enc_movz(s0,(uint16_t)(enc&0xFFFF),0);
        dst[n++]=enc_movk(s0,(uint16_t)((enc>>16)&0xFFFF),16);
        dst[n++]=enc_movz(s1,(uint16_t)(key2&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key2>>16)&0xFFFF),16);
        dst[n++]=enc_sub_w_r(s0,s0,s1);
        dst[n++]=enc_movz(s1,(uint16_t)(key1&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((key1>>16)&0xFFFF),16);
        dst[n++]=enc_eor_w(15,s0,s1);
        break;
    }
    }
    return n;
}

typedef struct { int enc_br_start; int block_idx; } CffDispatchPatch;

static int cff_emit_dispatch_case(uint32_t *dst, int n, int max_n,
                                  uint32_t state_id, int s0, int s1,
                                  CffDispatchPatch *patch, int *npatch,
                                  int max_patches,
                                  int block_idx,
                                  bool save_x16x17 __attribute__((unused))){
    if(n+42>max_n) return -1;
    if(*npatch >= max_patches) return -1;

    uint32_t cmp_mask = obf_rand32();
    uint32_t masked_id = state_id ^ cmp_mask;
    dst[n++]=enc_movz(s0,(uint16_t)(cmp_mask&0xFFFF),0);
    dst[n++]=enc_movk(s0,(uint16_t)((cmp_mask>>16)&0xFFFF),16);
    dst[n++]=enc_eor_w(s0,15,s0);
    if(masked_id <= 0xFFF){
        dst[n++]=enc_subs_w_i(31,s0,(int)(masked_id & 0xFFF));
    } else {
        dst[n++]=enc_movz(s1,(uint16_t)(masked_id&0xFFFF),0);
        dst[n++]=enc_movk(s1,(uint16_t)((masked_id>>16)&0xFFFF),16);
        dst[n++]=0x6B000000u | ((uint32_t)s1<<16) | ((uint32_t)s0<<5) | 31u;
    }

    int bne_pos = n;
    dst[n++]=enc_b_ne(0);

    int movz_pos = 0;

    int new_n = cff_emit_enc_br(dst,n,max_n,false,&movz_pos);
    if(new_n<0) return -1;
    n = new_n;

    int bne_skip = n - bne_pos;
    dst[bne_pos] = enc_b_ne(bne_skip);

    patch[*npatch].enc_br_start = movz_pos;
    patch[*npatch].block_idx = block_idx;
    (*npatch)++;

    return n;
}

typedef struct { int enc_start; } CffBackPatch;

int ldvq2306_obfuscate_func(const uint32_t *src, int src_cnt,
                   uint64_t orig_va, uint64_t new_va,
                   uint32_t *dst, int max_dst,
                   uint32_t buf_base_byte_off, float obf_weight,
                   bool conservative_mode,
                   uint32_t used_gpr_mask,
                   uint32_t analysis_flags)
{
    BasicBlock *bbs=(BasicBlock*)malloc((size_t)MAX_BB*sizeof(BasicBlock));
    if(!bbs) return -1;
    int nbb=ldvq2306_split_basic_blocks(src,src_cnt,orig_va,bbs,MAX_BB);
    if(nbb<=0){ free(bbs); return -1; }

    FuncAnalysisReport func_report;
    deep_analyze_function(src, src_cnt, orig_va, bbs, nbb, &func_report);

    if(func_report.has_dynamic_stack && !conservative_mode){

        if(func_report.n_external_branches > 3)
            conservative_mode = true;
    }

    bool reg_used[32];
    memset(reg_used, 0, sizeof(reg_used));
    used_gpr_mask |= (1u << 29) | (1u << 30) | (1u << 31);
    for(int r = 0; r < 32; r++)
        reg_used[r] = (used_gpr_mask & (1u << r)) != 0;

    static const int scratch_candidates[] = {16, 17, 9, 10, 11, 12, 13, 14};
    int scratch0 = -1, scratch1 = -1;
    (void)arm64_pick_unused_pair(used_gpr_mask, scratch_candidates, 8, &scratch0, &scratch1);

    bool junk_safe = (scratch0 >= 0 && scratch1 >= 0);

    bool needs_save_x16x17 = reg_used[16] || reg_used[17];

    int state_s0 = -1, state_s1 = -1;
    if(!needs_save_x16x17){
        state_s0 = 16;
        state_s1 = 17;
    } else {

        static const int state_candidates[] = {9, 10, 11, 12, 13, 14};
        (void)arm64_pick_unused_pair(used_gpr_mask, state_candidates, 6, &state_s0, &state_s1);
        if(state_s0 >= 0 && state_s1 >= 0){
            scratch0 = state_s0;
            scratch1 = state_s1;
            junk_safe = true;
        }
    }
    if(!junk_safe){

        scratch0 = -1;
        scratch1 = -1;
    }

    bool uses_x15 = reg_used[15];

    bool use_cff = (nbb >= 2) && (src_cnt >= 4) && !conservative_mode;

    if(uses_x15) use_cff = false;
    if((analysis_flags & ARM64_ANALYSIS_FORCE_SAFE_MASK) != 0) use_cff = false;
    if(needs_save_x16x17 && (state_s0 < 0 || state_s1 < 0)) use_cff = false;

    if(nbb > 200) use_cff = false;

    if(!use_cff){

        bool allow_enc_br = !conservative_mode;
        bool insert_bcf = !conservative_mode;
        bool insert_junk = !conservative_mode;
        int *shuffle=(int*)malloc((size_t)nbb*sizeof(int));
        if(!shuffle){ free(bbs); return -1; }
        for(int i=0;i<nbb;i++) shuffle[i]=i;
        if(!conservative_mode && nbb>2){
            for(int i=nbb-1;i>0;i--){
                int j=rand()%(i+1);
                int tmp=shuffle[i]; shuffle[i]=shuffle[j]; shuffle[j]=tmp;
            }
        }
        for(int i=0;i<nbb;i++){
            if(shuffle[i]==0){
                int tmp=shuffle[0]; shuffle[0]=shuffle[i]; shuffle[i]=tmp;
                break;
            }
        }

        int *bb_entry_pos=(int*)calloc((size_t)nbb,sizeof(int));
        int max_patches_fb = src_cnt+nbb*4+512;
        BranchPatch *patches=(BranchPatch*)malloc((size_t)max_patches_fb*sizeof(BranchPatch));
        int npatch=0;
        if(!bb_entry_pos||!patches){
            free(shuffle); free(bb_entry_pos); free(patches); free(bbs); return -1;
        }

        int n=0;
        bool truncated=false;

        #define FB_PATCH_ADD(pos, tbb, enc, var) do { \
            if(npatch < max_patches_fb) { \
                patches[npatch].dst_pos=(pos); \
                patches[npatch].target_bb=(tbb); \
                patches[npatch].is_encrypted=(enc); \
                patches[npatch].enc_variant=(var); \
                npatch++; \
            } \
        } while(0)

        for(int si=0;si<nbb;si++){
            int bi=shuffle[si];
            BasicBlock *bb=&bbs[bi];
            if(n+400>max_dst){ truncated=true; break; }

            if(insert_bcf && si > 0 && n+40<max_dst){
                n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);
            }

            bb_entry_pos[bi]=n;

            if(needs_save_x16x17 && allow_enc_br && si > 0 && n+1<max_dst)
                dst[n++]=enc_ldp_post(16,17,31,2);

            for(int i=bb->start_idx;i<bb->end_idx;i++){
                if(n+120>max_dst){ truncated=true; break; }
                uint32_t w=src[i];
                int64_t off=0;
                PCType t=classify_pcrel(w,&off);

                if(insert_junk && i > bb->start_idx && n+30 < max_dst && (rand()%3==0)){
                    n=obf_emit_junk_r(dst,n,max_dst,rand()%2+1,scratch0,scratch1);
                }

                if(t==PC_NONE||t==PC_BL26){
                    if(t==PC_BL26){
                        int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)i*4)+off;
                        extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                        dst[n++]=w;
                        dst[n++]=NOP;
                        dst[n++]=NOP;
                    } else {

                        if((w & 0xFFE0001Fu) == 0xD4200000u){
                            bool is_last = (i == bb->end_idx - 1);
                            bool is_exit_blk = is_last && is_terminator(w);

                            if(is_exit_blk && bi == shuffle[nbb-1]){

                                dst[n++] = w;
                            } else if(is_exit_blk){

                                dst[n++] = w;
                            } else {
                                dst[n++] = NOP;
                            }
                        } else {
                            dst[n++]=w;
                        }
                    }
                    continue;
                }
                int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)i*4)+off;
                int64_t orig_tgt_idx=((int64_t)abs_tgt-(int64_t)orig_va)/4;
                bool is_int=(is_internal_br(t)&&t!=PC_BL26&&orig_tgt_idx>=0&&orig_tgt_idx<src_cnt);
                if(!is_int){
                    extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                    dst[n++]=w;
                    if(t==PC_ADR || t==PC_LDR_W_LIT || t==PC_LDR_X_LIT || t==PC_LDRSW_LIT ||
                       t==PC_LDR_S_LIT || t==PC_LDR_D_LIT || t==PC_LDR_Q_LIT ||
                       t==PC_PRFM_LIT){
                        dst[n++]=NOP;
                    } else if(t==PC_BCOND || t==PC_CBZ_W || t==PC_CBNZ_W ||
                              t==PC_CBZ_X || t==PC_CBNZ_X || t==PC_TBZ || t==PC_TBNZ){

                        dst[n++]=NOP; dst[n++]=NOP; dst[n++]=NOP;
                    } else if(t==PC_B26){

                        dst[n++]=NOP; dst[n++]=NOP;
                    }
                    continue;
                }
                int target_bb_id=find_bb_for_idx(bbs,nbb,(int)orig_tgt_idx);
                if(t==PC_B26){
                    if(target_bb_id>=0){

                        int variant = rand() % 2;
                        bool use_enc = allow_enc_br;
                        int enc_sz = (variant==1) ? ENC_BR_V2_SIZE : ENC_BR_SIZE;
                        if(use_enc && n+enc_sz+4<max_dst){

                            if(needs_save_x16x17 && allow_enc_br && n+1<max_dst)
                                dst[n++]=enc_stp_pre(16,17,31,-2);
                            patches[npatch].dst_pos=n;
                            patches[npatch].target_bb=target_bb_id;
                            patches[npatch].is_encrypted=1;
                            patches[npatch].enc_variant=variant;
                            npatch++;
                            int new_n = (variant==1) ? ldvq2306_emit_encrypted_branch_v2(dst,n,max_dst) : ldvq2306_emit_encrypted_branch(dst,n,max_dst);
                            if(new_n>0){ n=new_n; }
                            else {
                                npatch--;

                                if(needs_save_x16x17 && allow_enc_br) n--;
                                patches[npatch].dst_pos=n;
                                patches[npatch].target_bb=target_bb_id;
                                patches[npatch].is_encrypted=0;
                                patches[npatch].enc_variant=0;
                                npatch++;
                                dst[n++]=NOP;
                            }
                        } else {
                            patches[npatch].dst_pos=n;
                            patches[npatch].target_bb=target_bb_id;
                            patches[npatch].is_encrypted=0;
                            npatch++;
                            dst[n++]=NOP;
                        }
                    } else {
                        extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                        dst[n++]=w;
                    }
                    continue;
                }
                if(target_bb_id>=0){
                    uint32_t inv_w; PCType inv_t;
                    switch(t){
                    case PC_BCOND: inv_w=w^1u; inv_t=PC_BCOND; break;
                    case PC_CBZ_W: inv_w=(w&~0xFF000000u)|0x35000000u; inv_t=PC_CBNZ_W; break;
                    case PC_CBNZ_W: inv_w=(w&~0xFF000000u)|0x34000000u; inv_t=PC_CBZ_W; break;
                    case PC_CBZ_X: inv_w=(w&~0xFF000000u)|0xB5000000u; inv_t=PC_CBNZ_X; break;
                    case PC_CBNZ_X: inv_w=(w&~0xFF000000u)|0xB4000000u; inv_t=PC_CBZ_X; break;
                    case PC_TBZ: inv_w=(w&~0x7F000000u)|0x37000000u; inv_t=PC_TBNZ; break;
                    case PC_TBNZ: inv_w=(w&~0x7F000000u)|0x36000000u; inv_t=PC_TBZ; break;
                    default: inv_w=w; inv_t=t; break;
                    }

                    int cond_variant = rand() % 2;
                    int cond_enc_sz = (cond_variant==1) ? ENC_BR_V2_SIZE : ENC_BR_SIZE;
                    bool enc_cond = allow_enc_br && n+cond_enc_sz+8<max_dst;
                    if(enc_cond){

                        int32_t stp_extra = needs_save_x16x17 ? 1 : 0;
                        int32_t skip_enc = cond_enc_sz + stp_extra + 1;
                        dst[n]=rewrite_pcrel(inv_w,inv_t,skip_enc*4);
                        n++;

                        if(needs_save_x16x17 && allow_enc_br && n+1<max_dst)
                            dst[n++]=enc_stp_pre(16,17,31,-2);
                        patches[npatch].dst_pos=n;
                        patches[npatch].target_bb=target_bb_id;
                        patches[npatch].is_encrypted=1;
                        patches[npatch].enc_variant=cond_variant;
                        npatch++;
                        int new_n = (cond_variant==1) ? ldvq2306_emit_encrypted_branch_v2(dst,n,max_dst) : ldvq2306_emit_encrypted_branch(dst,n,max_dst);
                        if(new_n>0){ n=new_n; }
                        else {
                            npatch--;

                            if(needs_save_x16x17 && allow_enc_br) n--;
                            dst[n-1]=rewrite_pcrel(inv_w,inv_t,2*4);
                            patches[npatch].dst_pos=n;
                            patches[npatch].target_bb=target_bb_id;
                            patches[npatch].is_encrypted=0;
                            patches[npatch].enc_variant=0;
                            npatch++;
                            dst[n++]=NOP;
                        }
                    } else {
                        dst[n]=rewrite_pcrel(inv_w,inv_t,2*4);
                        n++;
                        patches[npatch].dst_pos=n;
                        patches[npatch].target_bb=target_bb_id;
                        patches[npatch].is_encrypted=0;
                        patches[npatch].enc_variant=0;
                        npatch++;
                        dst[n++]=NOP;
                    }
                } else {
                    extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                    dst[n++]=w;
                }
            }
            if(truncated) break;

            uint32_t last_w=(bb->end_idx>bb->start_idx)?src[bb->end_idx-1]:0;
            bool needs_fallthrough=!is_terminator(last_w)||is_cond_branch(last_w);
            if(needs_fallthrough&&bb->end_idx<src_cnt){
                int succ_bb=find_bb_for_idx(bbs,nbb,bb->end_idx);
                if(succ_bb>=0){

                    int ft_variant = rand() % 2;
                    int ft_enc_sz = (ft_variant==1) ? ENC_BR_V2_SIZE : ENC_BR_SIZE;
                    bool enc_ft = allow_enc_br && n+ft_enc_sz+4<max_dst;
                    if(enc_ft){

                        if(needs_save_x16x17 && allow_enc_br && n+1<max_dst)
                            dst[n++]=enc_stp_pre(16,17,31,-2);
                        patches[npatch].dst_pos=n;
                        patches[npatch].target_bb=succ_bb;
                        patches[npatch].is_encrypted=1;
                        patches[npatch].enc_variant=ft_variant;
                        npatch++;
                        int new_n = (ft_variant==1) ? ldvq2306_emit_encrypted_branch_v2(dst,n,max_dst) : ldvq2306_emit_encrypted_branch(dst,n,max_dst);
                        if(new_n>0){ n=new_n; }
                        else {
                            npatch--;

                            if(needs_save_x16x17 && allow_enc_br) n--;
                            patches[npatch].dst_pos=n;
                            patches[npatch].target_bb=succ_bb;
                            patches[npatch].is_encrypted=0;
                            patches[npatch].enc_variant=0;
                            npatch++;
                            dst[n++]=NOP;
                        }
                    } else {
                        patches[npatch].dst_pos=n;
                        patches[npatch].target_bb=succ_bb;
                        patches[npatch].is_encrypted=0;
                        patches[npatch].enc_variant=0;
                        npatch++;
                        dst[n++]=NOP;
                    }
                }
            }

            if(insert_bcf && n+30<max_dst && (rand()%2==0)){
                n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);
            }
        }

        if(truncated){
            free(shuffle); free(bb_entry_pos); free(patches); free(bbs); return -2;
        }

        for(int p=0;p<npatch;p++){
            int pos=patches[p].dst_pos;
            int tbb=patches[p].target_bb;
            if(tbb<0||tbb>=nbb) continue;
            int tgt_pos=bb_entry_pos[tbb];
            if(patches[p].is_encrypted){
                int var = patches[p].enc_variant;
                int adr_idx = (var==1) ? 19 : 18;
                uint64_t tgt_va=new_va+(uint64_t)tgt_pos*4;
                uint64_t adr_va=new_va+(uint64_t)(pos+adr_idx)*4;

                if(var==1) ldvq2306_patch_encrypted_branch_v2(dst,pos,tgt_va,adr_va);
                else ldvq2306_patch_encrypted_branch(dst,pos,tgt_va,adr_va);
            } else {
                int32_t b_off=tgt_pos-pos;
                if(b_off>=-0x2000000&&b_off<=0x1FFFFFF) dst[pos]=enc_b26(b_off);
                else dst[pos]=NOP;
            }
        }

        free(shuffle); free(bb_entry_pos); free(patches); free(bbs);
        #undef FB_PATCH_ADD
        return n;
    }

    float desired_factor = 2.0f + obf_weight * 5.0f;
    if(desired_factor < 2.0f) desired_factor = 2.0f;
    if(desired_factor > 7.5f) desired_factor = 7.5f;

    int target_out = (int)(src_cnt * desired_factor);

    int est_real = (int)(src_cnt * 1.8) + nbb * 30 + 60;

    int avg_bogus_sz = 35;
    int n_bogus = (target_out - est_real) / avg_bogus_sz;
    int max_bogus = 1 + (int)(obf_weight * 14.0f);
    if(n_bogus < 1) n_bogus = 1;
    if(n_bogus > max_bogus) n_bogus = max_bogus;

    int junk_freq = 1 + (int)((1.0f - obf_weight) * 5.0f);
    if(junk_freq < 1) junk_freq = 1;
    if(junk_freq > 6) junk_freq = 6;

    int bcf_pct = 10 + (int)(obf_weight * 90.0f);
    if(bcf_pct < 10) bcf_pct = 10;
    if(bcf_pct > 100) bcf_pct = 100;

    int total_blocks = nbb + n_bogus;

    uint32_t *state_ids = (uint32_t*)malloc((size_t)(total_blocks+2)*sizeof(uint32_t));
    if(!state_ids){ free(bbs); return -1; }
    obf_gen_state_ids(state_ids, total_blocks+1);
    uint32_t dispatcher_state_id __attribute__((unused)) = state_ids[total_blocks];

    int *bb_succ = (int*)calloc((size_t)nbb*2, sizeof(int));
    int *bb_cond_succ = (int*)calloc((size_t)nbb, sizeof(int));
    bool *bb_has_cond = (bool*)calloc((size_t)nbb, sizeof(bool));
    bool *bb_is_exit = (bool*)calloc((size_t)nbb, sizeof(bool));

    bool *bb_cond_external = (bool*)calloc((size_t)nbb, sizeof(bool));
    if(!bb_succ||!bb_cond_succ||!bb_has_cond||!bb_is_exit||!bb_cond_external){
        free(state_ids); free(bbs); free(bb_succ); free(bb_cond_succ); free(bb_has_cond); free(bb_is_exit); free(bb_cond_external);
        return -1;
    }

    for(int bi=0;bi<nbb;bi++){
        BasicBlock *bb=&bbs[bi];
        uint32_t last_w=(bb->end_idx>bb->start_idx)?src[bb->end_idx-1]:0;
        bool is_term=is_terminator(last_w);
        bool is_cond=is_cond_branch(last_w);

        bb_succ[bi]=-1;
        bb_cond_succ[bi]=-1;
        bb_has_cond[bi]=false;
        bb_is_exit[bi]=false;
        if(bb_cond_external) bb_cond_external[bi]=false;

        if(is_term && !is_cond){
            int64_t off=0;
            PCType t=classify_pcrel(last_w,&off);
            if(t==PC_B26){
                int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)(bb->end_idx-1)*4)+off;
                int64_t tgt_idx=((int64_t)abs_tgt-(int64_t)orig_va)/4;
                if(tgt_idx>=0&&tgt_idx<src_cnt){
                    int tgt_bb=find_bb_for_idx(bbs,nbb,(int)tgt_idx);
                    bb_succ[bi]=tgt_bb;
                } else {
                    bb_is_exit[bi]=true;
                }
            } else {
                bb_is_exit[bi]=true;
            }
        } else if(is_cond){
            bb_has_cond[bi]=true;
            int64_t off=0;
            PCType t=classify_pcrel(last_w,&off);
            if(is_internal_br(t)){
                int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)(bb->end_idx-1)*4)+off;
                int64_t tgt_idx=((int64_t)abs_tgt-(int64_t)orig_va)/4;
                if(tgt_idx>=0&&tgt_idx<src_cnt){
                    int tb=find_bb_for_idx(bbs,nbb,(int)tgt_idx);
                    bb_cond_succ[bi]=tb;
                } else {

                    if(bb_cond_external) bb_cond_external[bi]=true;
                }
            } else {

                if(bb_cond_external) bb_cond_external[bi]=true;
            }
            if(bb->end_idx<src_cnt)
                bb_succ[bi]=find_bb_for_idx(bbs,nbb,bb->end_idx);
            else {

                if(bb_cond_succ[bi]<0)
                    bb_is_exit[bi]=true;
            }
        } else {
            if(bb->end_idx<src_cnt)
                bb_succ[bi]=find_bb_for_idx(bbs,nbb,bb->end_idx);
            else
                bb_is_exit[bi]=true;
        }
    }

    int *emit_order=(int*)malloc((size_t)total_blocks*sizeof(int));
    if(!emit_order){
        free(state_ids); free(bbs); free(bb_succ); free(bb_cond_succ); free(bb_has_cond); free(bb_is_exit); free(bb_cond_external); return -1;
    }
    for(int i=0;i<total_blocks;i++) emit_order[i]=i;
    for(int i=total_blocks-1;i>0;i--){
        int j=rand()%(i+1);
        int tmp=emit_order[i]; emit_order[i]=emit_order[j]; emit_order[j]=tmp;
    }

    int *dispatch_order=(int*)malloc((size_t)(total_blocks)*sizeof(int));
    if(!dispatch_order){
        free(emit_order); free(state_ids); free(bbs); free(bb_succ); free(bb_cond_succ); free(bb_has_cond); free(bb_is_exit); free(bb_cond_external); return -1;
    }

    for(int i=0;i<total_blocks;i++) dispatch_order[i]=i;
    for(int i=total_blocks-1;i>0;i--){
        int j=rand()%(i+1);
        int tmp=dispatch_order[i]; dispatch_order[i]=dispatch_order[j]; dispatch_order[j]=tmp;
    }

    int max_dpatches = total_blocks * 2 + 128;
    int max_back = total_blocks * 4 + 128;
    CffDispatchPatch *dpatches=(CffDispatchPatch*)malloc((size_t)max_dpatches*sizeof(CffDispatchPatch));
    int ndpatch=0;
    CffBackPatch *back_patches=(CffBackPatch*)malloc((size_t)max_back*sizeof(CffBackPatch));
    int nback=0;
    int *block_pos=(int*)calloc((size_t)total_blocks, sizeof(int));

    if(!dpatches||!back_patches||!block_pos){
        free(emit_order); free(dispatch_order); free(state_ids); free(bbs);
        free(bb_succ); free(bb_cond_succ); free(bb_has_cond); free(bb_is_exit); free(bb_cond_external);
        free(dpatches); free(back_patches); free(block_pos);
        return -1;
    }

    int n=0;

    #define BACK_PATCH_ADD(enc_s) do { \
        if(nback >= max_back) goto cff_fail; \
        back_patches[nback].enc_start = (enc_s); \
        nback++; \
    } while(0)

    n=obf_emit_junk_r(dst,n,max_dst,rand()%2+1,scratch0,scratch1);

    n=cff_emit_state_update(dst,n,max_dst,state_ids[0],state_s0,state_s1);
    if(n<0) goto cff_fail;

    n=obf_emit_junk_r(dst,n,max_dst,rand()%2+1,scratch0,scratch1);

    int init_enc_start = 0;
    {
        int nn=cff_emit_enc_br(dst,n,max_dst,needs_save_x16x17,&init_enc_start);
        if(nn<0) goto cff_fail;
        n=nn;
    }

    BACK_PATCH_ADD(init_enc_start);

    int dispatcher_pos = n;

    if(rand()%100 < bcf_pct)
        n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);
    n=obf_emit_junk_r(dst,n,max_dst,rand()%3+1,scratch0,scratch1);

    for(int si=0;si<total_blocks;si++){
        int bi=dispatch_order[si];
        if(n+60>max_dst) goto cff_fail;
        n=cff_emit_dispatch_case(dst,n,max_dst,state_ids[bi],state_s0,state_s1,
                                 dpatches,&ndpatch,max_dpatches,bi,needs_save_x16x17);
        if(n<0) goto cff_fail;

        if(rand()%100 < bcf_pct/2 && n+10<max_dst){
            n=obf_emit_junk_r(dst,n,max_dst,rand()%2+1,scratch0,scratch1);
        }
    }

    for(int dd=0; dd<(rand()%3+2) && n<max_dst; dd++)
        dst[n++]=NOP;

    for(int si=0;si<total_blocks;si++){
        int bi=emit_order[si];
        if(n+300>max_dst) goto cff_fail;
        block_pos[bi]=n;

        if(bi >= nbb){

            if(rand()%100 < bcf_pct)
                n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);
            n=obf_emit_junk_r(dst,n,max_dst,rand()%4+2,scratch0,scratch1);

            if(rand()%2==0 && rand()%100 < bcf_pct)
                n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);

            n=cff_emit_state_update(dst,n,max_dst,state_ids[rand()%nbb],state_s0,state_s1);
            if(n<0) goto cff_fail;

            n=obf_emit_junk_r(dst,n,max_dst,rand()%2+1,scratch0,scratch1);

            int bp_start=0;

            int nn=cff_emit_enc_br(dst,n,max_dst,false,&bp_start);
            if(nn<0) goto cff_fail;
            n=nn;
            BACK_PATCH_ADD(bp_start);
            continue;
        }

        BasicBlock *bb=&bbs[bi];

        if(needs_save_x16x17 && n+1<max_dst)
            dst[n++]=enc_ldp_post(16,17,31,2);

        if(rand()%100 < bcf_pct)
            n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);

        int insn_end = bb->end_idx;
        uint32_t last_w = (bb->end_idx > bb->start_idx) ? src[bb->end_idx-1] : 0;
        bool last_is_internal_uncond = false;
        bool last_is_internal_cond = false;
        bool last_is_external_cond = false;

        if(bb->end_idx > bb->start_idx){
            int64_t off=0;
            PCType t=classify_pcrel(last_w,&off);
            if(t==PC_B26 && is_internal_br(t)){
                int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)(bb->end_idx-1)*4)+off;
                int64_t tgt_idx=((int64_t)abs_tgt-(int64_t)orig_va)/4;
                if(tgt_idx>=0 && tgt_idx<src_cnt){
                    last_is_internal_uncond = true;
                    insn_end = bb->end_idx - 1;
                }
            } else if(is_cond_branch(last_w) && is_internal_br(t)){
                int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)(bb->end_idx-1)*4)+off;
                int64_t tgt_idx=((int64_t)abs_tgt-(int64_t)orig_va)/4;
                if(tgt_idx>=0 && tgt_idx<src_cnt){
                    int tb = find_bb_for_idx(bbs,nbb,(int)tgt_idx);
                    if(tb >= 0){
                        last_is_internal_cond = true;
                        insn_end = bb->end_idx - 1;
                    } else {

                        last_is_external_cond = true;
                        insn_end = bb->end_idx - 1;
                    }
                } else {

                    last_is_external_cond = true;
                    insn_end = bb->end_idx - 1;
                }
            } else if(is_cond_branch(last_w)){

                last_is_external_cond = true;
                insn_end = bb->end_idx - 1;
            }
        }

        for(int i=bb->start_idx;i<insn_end;i++){
            if(n+50>max_dst) goto cff_fail;
            uint32_t w=src[i];
            int64_t off=0;
            PCType t=classify_pcrel(w,&off);

            if(i > bb->start_idx && n+20 < max_dst && (rand()%junk_freq==0)){
                n=obf_emit_junk_r(dst,n,max_dst,rand()%2+1,scratch0,scratch1);
            }

            if(t==PC_NONE){

                if((w & 0xFFE0001Fu) == 0xD4200000u){
                    bool is_last_of_exit = (i == bb->end_idx - 1) && bb_is_exit[bi];
                    if(is_last_of_exit)
                        dst[n++] = w;
                    else
                        dst[n++] = NOP;
                } else {
                    dst[n++]=w;
                }
                continue;
            }

            if(t==PC_BL26){
                int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)i*4)+off;
                extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                dst[n++]=w;
                dst[n++]=NOP;
                dst[n++]=NOP;
                continue;
            }

            int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)i*4)+off;
            int64_t orig_tgt_idx=((int64_t)abs_tgt-(int64_t)orig_va)/4;
            bool is_int=(is_internal_br(t)&&t!=PC_BL26&&orig_tgt_idx>=0&&orig_tgt_idx<src_cnt);

            if(!is_int){
                extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                dst[n++]=w;
                if(t==PC_ADR || t==PC_LDR_W_LIT || t==PC_LDR_X_LIT || t==PC_LDRSW_LIT ||
                   t==PC_LDR_S_LIT || t==PC_LDR_D_LIT || t==PC_LDR_Q_LIT ||
                   t==PC_PRFM_LIT){
                    dst[n++]=NOP;
                } else if(t==PC_BCOND || t==PC_CBZ_W || t==PC_CBNZ_W ||
                          t==PC_CBZ_X || t==PC_CBNZ_X || t==PC_TBZ || t==PC_TBNZ){

                    dst[n++]=NOP; dst[n++]=NOP; dst[n++]=NOP;
                } else if(t==PC_B26){

                    dst[n++]=NOP; dst[n++]=NOP;
                }
                continue;
            }

            extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
            dst[n++]=w;
            if(t!=PC_B26) dst[n++]=NOP;
        }

        if(bb_is_exit[bi]){

            if(insn_end < bb->end_idx){
                uint32_t w=src[bb->end_idx-1];
                int64_t off=0;
                PCType t=classify_pcrel(w,&off);
                if(t!=PC_NONE && t!=PC_B26){
                    int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)(bb->end_idx-1)*4)+off;
                    extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                }
                if(t==PC_B26){

                    int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)(bb->end_idx-1)*4)+off;
                    extpc_add(buf_base_byte_off+(uint32_t)n*4,(uint64_t)abs_tgt,t);
                }

                dst[n++]=w;

                if(is_cond_branch(w)){
                    dst[n++]=NOP;
                    if(n+2<max_dst){ dst[n++]=NOP; dst[n++]=NOP; }
                } else if(t==PC_B26){
                    if(n+2<max_dst){ dst[n++]=NOP; dst[n++]=NOP; }
                }
            }
            continue;
        }

        if(last_is_external_cond || (bb_cond_external && bb_cond_external[bi] && bb_has_cond[bi])){

            uint32_t cond_w = src[bb->end_idx-1];
            int64_t cond_off = 0;
            PCType cond_t = classify_pcrel(cond_w, &cond_off);
            int64_t abs_tgt = (int64_t)(orig_va+(uint64_t)(bb->end_idx-1)*4) + cond_off;
            extpc_add(buf_base_byte_off+(uint32_t)n*4, (uint64_t)abs_tgt, cond_t);
            dst[n++]=cond_w;
            dst[n++]=NOP;
            if(n+2<max_dst){ dst[n++]=NOP; dst[n++]=NOP; }

            int fall_bb = bb_succ[bi];
            if(fall_bb >= 0){
                n=cff_emit_state_update(dst,n,max_dst,state_ids[fall_bb],state_s0,state_s1);
            } else {

                n=cff_emit_state_update(dst,n,max_dst,state_ids[0],state_s0,state_s1);
            }
            if(n<0) goto cff_fail;

            if(n+5<max_dst && rand()%100 < bcf_pct/2)
                n=obf_emit_junk_r(dst,n,max_dst,1,scratch0,scratch1);

            int bp_start=0;
            int nn2=cff_emit_enc_br(dst,n,max_dst,needs_save_x16x17,&bp_start);
            if(nn2<0) goto cff_fail;
            n=nn2;
            BACK_PATCH_ADD(bp_start);

        } else if(last_is_internal_cond){

            int taken_bb = bb_cond_succ[bi];
            int fall_bb = bb_succ[bi];

            uint32_t cond_w = src[bb->end_idx-1];
            int64_t cond_off = 0;
            PCType cond_t = classify_pcrel(cond_w, &cond_off);

            uint32_t inv_w;
            PCType inv_t;
            switch(cond_t){
            case PC_BCOND: inv_w=cond_w^1u; inv_t=PC_BCOND; break;
            case PC_CBZ_W: inv_w=(cond_w&~0xFF000000u)|0x35000000u; inv_t=PC_CBNZ_W; break;
            case PC_CBNZ_W: inv_w=(cond_w&~0xFF000000u)|0x34000000u; inv_t=PC_CBZ_W; break;
            case PC_CBZ_X: inv_w=(cond_w&~0xFF000000u)|0xB5000000u; inv_t=PC_CBNZ_X; break;
            case PC_CBNZ_X: inv_w=(cond_w&~0xFF000000u)|0xB4000000u; inv_t=PC_CBZ_X; break;
            case PC_TBZ: inv_w=(cond_w&~0x7F000000u)|0x37000000u; inv_t=PC_TBNZ; break;
            case PC_TBNZ: inv_w=(cond_w&~0x7F000000u)|0x36000000u; inv_t=PC_TBZ; break;
            default: inv_w=cond_w; inv_t=cond_t; break;
            }

            int skip_est = 12 + CFF_ENC_BR_SIZE;
            int inv_pos = n;
            dst[n++]=rewrite_pcrel(inv_w, inv_t, skip_est*4);
            int inv_fallback_pos = n;
            dst[n++]=NOP;

            if(taken_bb >= 0){
                n=cff_emit_state_update(dst,n,max_dst,state_ids[taken_bb],state_s0,state_s1);
            } else {

                n=cff_emit_state_update(dst,n,max_dst,state_ids[0],state_s0,state_s1);
            }
            if(n<0) goto cff_fail;

            if(n+5<max_dst && rand()%100 < bcf_pct/2)
                n=obf_emit_junk_r(dst,n,max_dst,1,scratch0,scratch1);

            int taken_bp=0;
            int nn2=cff_emit_enc_br(dst,n,max_dst,needs_save_x16x17,&taken_bp);
            if(nn2<0) goto cff_fail;
            n=nn2;
            BACK_PATCH_ADD(taken_bp);

            int actual_skip = n - inv_pos;
            if(pcrel_in_range(inv_t, (int64_t)actual_skip * 4)){

                dst[inv_pos]=rewrite_pcrel(inv_w, inv_t, actual_skip*4);
                dst[inv_fallback_pos]=NOP;
            } else {

                int32_t b26_skip = n - inv_fallback_pos;

                dst[inv_pos]=rewrite_pcrel(cond_w, cond_t, 2*4);
                if(b26_skip >= -0x2000000 && b26_skip <= 0x1FFFFFF){
                    dst[inv_fallback_pos]=enc_b26(b26_skip);
                } else {

                    dst[inv_fallback_pos]=NOP;
                }
            }

            if(fall_bb >= 0){
                n=cff_emit_state_update(dst,n,max_dst,state_ids[fall_bb],state_s0,state_s1);
            } else {

                n=cff_emit_state_update(dst,n,max_dst,state_ids[0],state_s0,state_s1);
            }
            if(n<0) goto cff_fail;

            if(n+5<max_dst && rand()%100 < bcf_pct/2)
                n=obf_emit_junk_r(dst,n,max_dst,1,scratch0,scratch1);

            int fall_bp=0;
            nn2=cff_emit_enc_br(dst,n,max_dst,needs_save_x16x17,&fall_bp);
            if(nn2<0) goto cff_fail;
            n=nn2;
            BACK_PATCH_ADD(fall_bp);

        } else if(last_is_internal_uncond){

            int tgt_bb = bb_succ[bi];
            if(tgt_bb >= 0)
                n=cff_emit_state_update(dst,n,max_dst,state_ids[tgt_bb],state_s0,state_s1);
            else
                n=cff_emit_state_update(dst,n,max_dst,state_ids[0],state_s0,state_s1);
            if(n<0) goto cff_fail;

            if(n+5<max_dst && rand()%100 < bcf_pct/2)
                n=obf_emit_junk_r(dst,n,max_dst,1,scratch0,scratch1);

            int bp_start=0;
            int nn2=cff_emit_enc_br(dst,n,max_dst,needs_save_x16x17,&bp_start);
            if(nn2<0) goto cff_fail;
            n=nn2;
            BACK_PATCH_ADD(bp_start);

        } else {

            int fall_bb = bb_succ[bi];
            if(fall_bb >= 0)
                n=cff_emit_state_update(dst,n,max_dst,state_ids[fall_bb],state_s0,state_s1);
            else
                n=cff_emit_state_update(dst,n,max_dst,state_ids[0],state_s0,state_s1);
            if(n<0) goto cff_fail;

            if(n+5<max_dst && rand()%100 < bcf_pct/2)
                n=obf_emit_junk_r(dst,n,max_dst,1,scratch0,scratch1);

            int bp_start=0;
            int nn2=cff_emit_enc_br(dst,n,max_dst,needs_save_x16x17,&bp_start);
            if(nn2<0) goto cff_fail;
            n=nn2;
            BACK_PATCH_ADD(bp_start);
        }

        if(n+20<max_dst && rand()%100 < bcf_pct){
            n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);
        }
    }

    for(int i=0;i<ndpatch;i++){
        int enc_start = dpatches[i].enc_br_start;
        int bi = dpatches[i].block_idx;
        int target_idx = block_pos[bi];
        uint64_t target_va = new_va + (uint64_t)target_idx * 4;
        uint64_t adr_va = new_va + (uint64_t)(enc_start + 14) * 4;

        cff_patch_enc_br(dst, enc_start, target_va, adr_va);
    }

    for(int i=0;i<nback;i++){
        int enc_start = back_patches[i].enc_start;
        uint64_t target_va = new_va + (uint64_t)dispatcher_pos * 4;
        uint64_t adr_va = new_va + (uint64_t)(enc_start + 14) * 4;

        cff_patch_enc_br(dst, enc_start, target_va, adr_va);
    }

    {
        float min_factor = 1.5f + obf_weight * 2.0f;
        int min_target = (int)(src_cnt * min_factor);
        while(n < min_target && n + 30 < max_dst){

            n=obf_emit_bcf_r(dst,n,max_dst,scratch0,scratch1);
            n=obf_emit_junk_r(dst,n,max_dst,rand()%4+2,scratch0,scratch1);
        }
    }

    free(emit_order); free(dispatch_order);
    free(state_ids); free(bb_succ); free(bb_cond_succ); free(bb_has_cond); free(bb_is_exit); free(bb_cond_external);
    free(dpatches); free(back_patches); free(block_pos);
    free(bbs);
    #undef BACK_PATCH_ADD
    return n;

cff_fail:
    free(emit_order); free(dispatch_order);
    free(state_ids); free(bb_succ); free(bb_cond_succ); free(bb_has_cond); free(bb_is_exit); free(bb_cond_external);
    free(dpatches); free(back_patches); free(block_pos);
    free(bbs);
    return -2;
}

int ldvq2306_build_antihex_ctor_raw(uint32_t *b, int max_insns,
                           uint64_t exec_seg_va,
                           uint64_t text_va,
                           uint32_t text_sz,
                           uint32_t text_xhash)
{
    (void)text_xhash;
    int n=0;
    if(max_insns>2048) max_insns=2048;

    uint32_t seed_mask = (uint32_t)rand() ^ ((uint32_t)rand() << 16);
    uint32_t seed_blind = 0x55AA55AAu ^ seed_mask;
    uint32_t magic_mask = (uint32_t)rand() ^ ((uint32_t)rand() << 16);
    uint32_t magic_blind = 0xFEEDFACFu ^ magic_mask;

#define IC(x) do{ if(n>=max_insns) return -1; b[n++]=(x); }while(0)
    IC(enc_sub_i(31,31,0x50));
    IC(enc_stp(19,20,31,0));
    IC(enc_stp(21,22,31,2));
    IC(enc_stp(23,24,31,4));
    IC(enc_stp(25,26,31,6));
    IC(enc_str_x_off(30,31,8));
    b[n++]=0x10000013u;
    IC(0x92000000u|(1u<<22)|(50u<<16)|(49u<<10)|(19u<<5)|19u);
    n=emit_mov64(b,n,21,(uint64_t)magic_blind);
    n=emit_mov64(b,n,0,(uint64_t)magic_mask);
    IC(enc_eor_w(21,21,0));
    int wb_start=n;
    IC(enc_ldr_w_off(22,19,0));
    IC(enc_cmp_x(22,21));
    IC(enc_b_eq(3));
    IC(enc_sub_i_lsl12(19,19,4));
    { int _wb_off=wb_start-n; IC(enc_b26(_wb_off)); }
    n=emit_mov64(b,n,20,(uint64_t)text_va);
    IC(enc_add_r(20,19,20));
    n=emit_mov64(b,n,21,(uint64_t)text_sz);
    n=emit_mov64(b,n,25,(uint64_t)exec_seg_va);
    IC(enc_add_r(25,19,25));
    IC(enc_ldr_w_off(22,25,1));
    IC(enc_mov_x(23,20));
    IC(enc_lsr_w(24,21,2));
    n=emit_mov64(b,n,26,(uint64_t)seed_blind);
    n=emit_mov64(b,n,0,(uint64_t)seed_mask);
    IC(enc_eor_w(26,26,0));
    int hl_start=n;
    IC(enc_ldr_w_post(0,23,4));
    IC(enc_eor_w(26,26,0));
    IC(enc_ror_w(26,26,7));
    IC(enc_subs_w_i(24,24,1));
    { int _hl_off=hl_start-n; IC(enc_b_ne(_hl_off)); }
    IC(0x6B16035Fu);
    int hash_ok_patch = n;
    IC(enc_b_eq(0));

    IC(enc_movz(21,0xA5C3,0));
    IC(enc_movk(21,0x7E19,16));
    IC(enc_movk(21,0xD4B2,32));
    IC(0xF9000BE0u | 21u);
    IC(enc_movk(21,0x38F6,48));
    IC(0xF9000FE0u | 21u);
    IC(0x910003F5u);
    IC(enc_movz(22,0x4C8A,0));
    IC(enc_movk(22,0xE57D,16));
    IC(enc_eor_x(21,21,22));
    IC(enc_ldr_x_off(30,31,8));
    IC(enc_ldp(25,26,31,6));
    IC(enc_ldp(23,24,31,4));
    IC(enc_ldp(19,20,31,0));
    IC(enc_add_i(31,31,0x50));
    IC(enc_br(21));

    int hash_ok_target = n;
    { int _eq_off = hash_ok_target - hash_ok_patch; b[hash_ok_patch] = enc_b_eq(_eq_off); }
    IC(enc_ldr_x_off(30,31,8));
    IC(enc_ldp(25,26,31,6));
    IC(enc_ldp(23,24,31,4));
    IC(enc_ldp(21,22,31,2));
    IC(enc_ldp(19,20,31,0));
    IC(enc_add_i(31,31,0x50));
    IC(enc_ret());
    if(n>max_insns) return -1;
    return n;
#undef IC
}

int ldvq2306_obfuscate_internal_buf(const uint32_t *src, int src_cnt,
                           uint64_t orig_va, uint64_t new_va,
                           uint32_t *dst, int max_dst)
{
    if(src_cnt>max_dst) return -1;
    int n=0;
    for(int i=0;i<src_cnt;i++){
        if(n>=max_dst) return -1;
        dst[n++]=src[i];
    }
    for(int i=0;i<src_cnt;i++){
        uint32_t w=dst[i];
        int64_t off=0;
        PCType t=classify_pcrel(w,&off);
        if(t==PC_NONE) continue;
        int64_t abs_tgt=(int64_t)(orig_va+(uint64_t)i*4)+off;
        int64_t orig_tgt_idx=(abs_tgt-(int64_t)orig_va)/4;
        if(is_internal_br(t)&&t!=PC_BL26&&orig_tgt_idx>=0&&orig_tgt_idx<src_cnt){
        } else {
            int64_t new_off;
            if(t==PC_ADRP){
                int64_t abs_page=abs_tgt&~0xFFFLL;
                int64_t cur_page=(int64_t)(new_va+(uint64_t)i*4)&~0xFFFLL;
                new_off=abs_page-cur_page;
            } else {
                new_off=abs_tgt-(int64_t)(new_va+(uint64_t)i*4);
            }
            if(pcrel_in_range(t,new_off))
                dst[i]=rewrite_pcrel(w,t,new_off);
        }
    }
    return n;
}

int ldvq2306_build_timeprotect_raw(uint32_t *b, int max_insns,
                          uint64_t deadline_epoch)
{
    int n=0;
    if(max_insns>2048) max_insns=2048;
#define TP(x) do{ if(n>=max_insns) return -1; b[n++]=(x); }while(0)

    TP(enc_sub_i(31,31,0x60));
    TP(enc_stp(29,30,31,0));
    TP(enc_stp(19,20,31,2));
    TP(enc_stp(21,22,31,4));

    TP(enc_movz(19,0,0));
    TP(enc_str_x_off(19,31,8));
    TP(enc_str_x_off(19,31,9));

    TP(enc_add_i(0,31,0x40));
    TP(enc_movz(1,0,0));
    TP(enc_movz(16,0x74,0));
    TP(0xD4001001u);

    TP(enc_ldr_x_off(19,31,8));

    n=emit_mov64(b,n,20,deadline_epoch);

    TP(enc_cmp_x(19,20));

    int not_expired_patch = n;
    TP(0x54000003u);

    TP(enc_movz(21,0xDEAD,0));
    TP(enc_movk(21,0xBEEF,16));
    TP(enc_movk(21,0xCAFE,32));

    TP(0xF9000BE0u | 21u);

    TP(enc_movk(21,0xF00D,48));
    TP(0xF9000FE0u | 21u);

    TP(0x910003F5u);
    TP(enc_movz(22,0x1337,0));
    TP(enc_movk(22,0x7331,16));
    TP(enc_eor_x(21,21,22));

    TP(enc_ldp(29,30,31,0));
    TP(enc_add_i(31,31,0x60));
    TP(enc_br(21));

    int not_expired_target = n;
    {
        int off19 = not_expired_target - not_expired_patch;
        b[not_expired_patch] = 0x54000003u | ((uint32_t)(off19 & 0x7FFFF) << 5);
    }

    TP(enc_ldp(21,22,31,4));
    TP(enc_ldp(19,20,31,2));
    TP(enc_ldp(29,30,31,0));
    TP(enc_add_i(31,31,0x60));
    TP(enc_ret());

    if(n>max_insns) return -1;
    return n;
#undef TP
}
