
#include "tui.h"
#include "macho.h"
#include "pcrel.h"
#include "util.h"
#include <ncurses.h>

void run_tui_fallback(FuncEntry *funcs, int nfuncs, bool *do_obf, bool *do_antihex, bool *do_vm,
                              bool *do_timeprotect, int *expire_days,
                              const uint8_t *text_data, uint64_t text_va){
    char line[256];
    printf("\n=== ARM64 Mach-O Dylib Protector v7 (VM+TimeProtect) ===\n");
    printf("Functions detected: %d\n\n", nfuncs);

    printf("Enable function obfuscation? [Y/n]: ");
    fflush(stdout);
    if(fgets(line,sizeof(line),stdin) && (line[0]=='n'||line[0]=='N'))
        *do_obf = false;
    else
        *do_obf = true;

    printf("Enable anti-hex integrity check? [Y/n]: ");
    fflush(stdout);
    if(fgets(line,sizeof(line),stdin) && (line[0]=='n'||line[0]=='N'))
        *do_antihex = false;
    else
        *do_antihex = true;

    printf("Enable time-based expiration protection? [Y/n]: ");
    fflush(stdout);
    if(fgets(line,sizeof(line),stdin) && (line[0]=='n'||line[0]=='N')){
        *do_timeprotect = false;
    } else {
        *do_timeprotect = true;
        printf("  Expire after how many days? [1]: ");
        fflush(stdout);
        *expire_days = 1;
        if(fgets(line,sizeof(line),stdin)){
            int v = atoi(line);
            if(v > 0) *expire_days = v;
        }
    }

    printf("Enable VM mode for heaviest function? [Y/n]: ");
    fflush(stdout);
    if(fgets(line,sizeof(line),stdin) && (line[0]=='n'||line[0]=='N'))
        *do_vm = false;
    else
        *do_vm = true;

    if(!*do_obf && !*do_antihex && !*do_timeprotect && !*do_vm){
        printf("[!] All features disabled, nothing to do.\n");
        return;
    }

    if(!*do_obf) return;

    printf("\nSelect mode:\n");
    printf("  [1] Manual   - choose functions by index\n");
    printf("  [2] Offset   - encrypt by VA range\n");
    printf("  [3] Heaviest - top N by complexity\n");
    printf("  [4] SafeMode - ultra-safe auto filter\n");
    printf("Mode [1-4, default=1]: ");
    fflush(stdout);
    int mode = 1;
    if(fgets(line,sizeof(line),stdin)){ int m=atoi(line); if(m>=1&&m<=4) mode=m; }

    if(mode == 2){
        printf("Enter start VA (hex, e.g. 0x1000): "); fflush(stdout);
        uint64_t lo=0, hi=0xFFFFFFFFFFFFFFFFULL;
        if(fgets(line,sizeof(line),stdin)) lo=(uint64_t)strtoull(line,NULL,16);
        printf("Enter end VA (hex, exclusive): "); fflush(stdout);
        if(fgets(line,sizeof(line),stdin)) hi=(uint64_t)strtoull(line,NULL,16);
        select_by_offset_range(funcs,nfuncs,lo,hi,text_data,text_va);
        int cnt=0; for(int i=0;i<nfuncs;i++) if(funcs[i].selected) cnt++;
        printf("[*] Selected %d functions in range [0x%llx, 0x%llx)\n",cnt,(unsigned long long)lo,(unsigned long long)hi);
        return;
    }
    if(mode == 3){
        printf("How many heaviest functions? [10]: "); fflush(stdout);
        int n=10;
        if(fgets(line,sizeof(line),stdin)){ int v=atoi(line); if(v>0) n=v; }
        select_heaviest_n(funcs,nfuncs,text_data,text_va,n);
        int cnt=0; for(int i=0;i<nfuncs;i++) if(funcs[i].selected) cnt++;
        printf("[*] Selected top %d heaviest functions (%d selected)\n",n,cnt);
        return;
    }
    if(mode == 4){
        select_ultra_safe(funcs,nfuncs,text_data,text_va);
        int cnt=0; for(int i=0;i<nfuncs;i++) if(funcs[i].selected) cnt++;
        printf("[*] SafeMode: selected %d ultra-safe functions\n",cnt);
        return;
    }

    printf("\n%-5s %-14s %-7s %-5s %-10s %-6s %-6s %s\n", "#", "VA", "Size", "Insns", "Prologue", "Risk", "Score", "Symbol");
    printf("------------------------------------------------------------------------------\n");
    for(int i=0;i<nfuncs;i++){
        bool is_tiny = (funcs[i].size < MIN_FUNC_SIZE);
        bool is_br = (!is_tiny && has_computed_branch(text_data,text_va,funcs[i].va,funcs[i].size));
        const char *risk = is_tiny ? "TINY" : (is_br ? "BR" : (funcs[i].is_safe ? "SAFE" : "OK"));
        const char *sn = funcs[i].sym_name ? funcs[i].sym_name : "";
        char sbuf[40];
        if(strlen(sn)>35){ memcpy(sbuf,sn,32); sbuf[32]='.'; sbuf[33]='.'; sbuf[34]='.'; sbuf[35]=0; sn=sbuf; }
        printf("[%4d] 0x%012llX %6u %5u %-10s %-6s %6u %s\n",
            i, (unsigned long long)funcs[i].va, funcs[i].size, funcs[i].insn_cnt,
            funcs[i].prologue, risk, funcs[i].complexity, sn);
    }
    printf("\nEnter function indices (space-separated), or ENTER for ALL eligible:\n> ");
    fflush(stdout);
    if(!fgets(line,sizeof(line),stdin) || line[0]=='\n' || line[0]=='\r'){
        for(int i=0;i<nfuncs;i++)
            if(funcs[i].size >= MIN_FUNC_SIZE
               && !has_computed_branch(text_data,text_va,funcs[i].va,funcs[i].size))
                funcs[i].selected = true;
    } else {
        char *tok = strtok(line, " ,\t\n\r");
        while(tok){
            int idx = atoi(tok);
            if(idx>=0 && idx<nfuncs) funcs[idx].selected = true;
            tok = strtok(NULL, " ,\t\n\r");
        }
    }
}

void run_tui(FuncEntry *funcs, int nfuncs, bool *do_obf, bool *do_antihex, bool *do_vm,
                    bool *do_timeprotect, int *expire_days,
                    const uint8_t *text_data, uint64_t text_va){
    const char *term = getenv("TERM");
    if(!term || !isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)){
        run_tui_fallback(funcs, nfuncs, do_obf, do_antihex, do_vm, do_timeprotect, expire_days, text_data, text_va);
        return;
    }
    SCREEN *sp = newterm(NULL, stdout, stdin);
    if(!sp){
        run_tui_fallback(funcs, nfuncs, do_obf, do_antihex, do_vm, do_timeprotect, expire_days, text_data, text_va);
        return;
    }
    endwin();
    delscreen(sp);
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    start_color();
    curs_set(0);
    init_pair(1, COLOR_GREEN,   COLOR_BLACK);
    init_pair(2, COLOR_YELLOW,  COLOR_BLACK);
    init_pair(3, COLOR_RED,     COLOR_BLACK);
    init_pair(4, COLOR_CYAN,    COLOR_BLACK);
    init_pair(5, COLOR_WHITE,   COLOR_BLUE);
    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(7, COLOR_GREEN,   COLOR_BLUE);
    init_pair(8, COLOR_YELLOW,  COLOR_BLACK);

    int max_y, max_x;
    getmaxyx(stdscr, max_y, max_x);

    int phase = 0;
    *do_obf = false;
    *do_antihex = false;
    *do_vm = false;
    *do_timeprotect = false;
    *expire_days = 1;

    while(phase < 4){
        clear();
        attron(A_BOLD | COLOR_PAIR(4));
        mvprintw(0, 0, " ARM64 Mach-O Dylib Protector v7 (VM+TimeProtect) ");
        attroff(A_BOLD | COLOR_PAIR(4));
        attron(COLOR_PAIR(6));
        mvprintw(2, 2, "File: %d functions detected", nfuncs);
        attroff(COLOR_PAIR(6));

        int sy = 3;
        if(phase > 0){
            attron(COLOR_PAIR(1));
            mvprintw(sy, 2, "OBF: %s", *do_obf ? "ENABLED" : "DISABLED");
            attroff(COLOR_PAIR(1));
            sy++;
        }
        if(phase > 1){
            attron(COLOR_PAIR(1));
            mvprintw(sy, 2, "Anti-hex: %s", *do_antihex ? "ENABLED" : "DISABLED");
            attroff(COLOR_PAIR(1));
            sy++;
        }
        if(phase > 2){
            attron(COLOR_PAIR(1));
            if(*do_timeprotect)
                mvprintw(sy, 2, "Time-protect: ENABLED (%d days)", *expire_days);
            else
                mvprintw(sy, 2, "Time-protect: DISABLED");
            attroff(COLOR_PAIR(1));
            sy++;
        }

        sy += 1;
        if(phase == 0){
            attron(A_BOLD);
            mvprintw(sy, 2, "Enable function obfuscation (BB shuffle + junk + encrypted targets)?");
            attroff(A_BOLD);
            mvprintw(sy+2, 4, "[Y] Yes    [N] No");
        } else if(phase == 1){
            attron(A_BOLD);
            mvprintw(sy, 2, "Enable anti-hex integrity check?");
            attroff(A_BOLD);
            mvprintw(sy+2, 4, "[Y] Yes    [N] No");
        } else if(phase == 2){
            attron(A_BOLD);
            mvprintw(sy, 2, "Enable time-based expiration protection?");
            attroff(A_BOLD);
            mvprintw(sy+1, 2, "(File will crash after N days from protection time)");
            mvprintw(sy+3, 4, "[Y] Yes    [N] No");
        } else if(phase == 3){
            attron(A_BOLD);
            mvprintw(sy, 2, "Enable VM mode for heaviest function?");
            attroff(A_BOLD);
            mvprintw(sy+1, 2, "(VM replaces obfuscation on the most complex function)");
            mvprintw(sy+3, 4, "[Y] Yes    [N] No");
        }
        attron(COLOR_PAIR(5));
        mvhline(max_y-1, 0, ' ', max_x);
        mvprintw(max_y-1, 1, " Press Y/N to choose ");
        attroff(COLOR_PAIR(5));
        refresh();
        int ch = getch();
        if(phase == 0){
            if(ch=='y'||ch=='Y'){ *do_obf=true; phase=1; }
            else if(ch=='n'||ch=='N'){ *do_obf=false; phase=1; }
        } else if(phase == 1){
            if(ch=='y'||ch=='Y'){ *do_antihex=true; phase=2; }
            else if(ch=='n'||ch=='N'){ *do_antihex=false; phase=2; }
        } else if(phase == 2){
            if(ch=='y'||ch=='Y'){
                *do_timeprotect=true;

                clear();
                attron(A_BOLD | COLOR_PAIR(4));
                mvprintw(0, 0, " Time-Based Expiration ");
                attroff(A_BOLD | COLOR_PAIR(4));
                mvprintw(2, 2, "How many days until expiration?");
                mvprintw(3, 2, "(1 = 1 day, 7 = 1 week, 30 = 1 month, etc.)");
                mvprintw(5, 4, "Enter days [1]: ");
                curs_set(1); echo();
                char ibuf[32];
                getnstr(ibuf, sizeof(ibuf)-1);
                noecho(); curs_set(0);
                int v = atoi(ibuf);
                if(v > 0) *expire_days = v;
                else *expire_days = 1;
                phase=3;
            }
            else if(ch=='n'||ch=='N'){ *do_timeprotect=false; phase=3; }
        } else if(phase == 3){
            if(ch=='y'||ch=='Y'){ *do_vm=true; phase=4; }
            else if(ch=='n'||ch=='N'){ *do_vm=false; phase=4; }
        }
    }

    if(!*do_obf && !*do_antihex && !*do_timeprotect && !*do_vm){
        endwin();
        printf("[!] All features disabled, nothing to do.\n");
        return;
    }

    if(!*do_obf){ endwin(); return; }

    TMode tmode = TMODE_MANUAL;
    {
        int safe_count = 0;
        for(int i=0;i<nfuncs;i++) if(funcs[i].is_safe) safe_count++;
        int eligible = 0;
        for(int i=0;i<nfuncs;i++)
            if(funcs[i].size>=MIN_FUNC_SIZE && !has_computed_branch(text_data,text_va,funcs[i].va,funcs[i].size))
                eligible++;
        int mode_cursor = 0;
        while(1){
            clear();
            getmaxyx(stdscr, max_y, max_x);
            attron(A_BOLD | COLOR_PAIR(4));
            mvprintw(0, 0, " ARM64 Mach-O Dylib Protector v7 - Select Mode ");
            attroff(A_BOLD | COLOR_PAIR(4));
            attron(COLOR_PAIR(6));
            mvprintw(2, 2, "Functions: %d total, %d eligible, %d ultra-safe", nfuncs, eligible, safe_count);
            attroff(COLOR_PAIR(6));

            const char *modes[4] = {
                "[1] Manual     - Browse & toggle individual functions",
                "[2] Offset     - Select by VA range (from X to Y)",
                "[3] Heaviest N - Select top N most complex functions",
                "[4] Ultra-Safe - Deep analysis, safest candidates only",
            };
            const char *descs[4] = {
                "Full control. Navigate with arrows, SPACE to toggle.",
                "Enter start/end VA. All eligible funcs in range selected.",
                "Enter N. Sorts by complexity score, picks top N.",
                "Strict safety filter: proper prologue, no PAC, balanced frames.",
            };
            for(int i=0;i<4;i++){
                if(i==mode_cursor){
                    attron(A_REVERSE | A_BOLD | COLOR_PAIR(7));
                    mvprintw(4+i*3, 4, "%-60s", modes[i]);
                    attroff(A_REVERSE | A_BOLD | COLOR_PAIR(7));
                    attron(COLOR_PAIR(2));
                    mvprintw(5+i*3, 8, "%-60s", descs[i]);
                    attroff(COLOR_PAIR(2));
                } else {
                    mvprintw(4+i*3, 4, "%-60s", modes[i]);
                }
            }
            attron(COLOR_PAIR(5));
            mvhline(max_y-1, 0, ' ', max_x);
            mvprintw(max_y-1, 1, " UP/DOWN=navigate  ENTER=select  1-4=direct select ");
            attroff(COLOR_PAIR(5));
            refresh();
            int ch = getch();
            if(ch==KEY_UP && mode_cursor>0) mode_cursor--;
            else if(ch==KEY_DOWN && mode_cursor<3) mode_cursor++;
            else if(ch>='1'&&ch<='4'){ tmode=(TMode)(ch-'1'); break; }
            else if(ch=='\n'||ch=='\r'||ch==KEY_ENTER){ tmode=(TMode)mode_cursor; break; }
            else if(ch=='q'||ch=='Q'){ endwin(); printf("[!] Cancelled\n"); exit(0); }
        }
    }

    if(tmode == TMODE_OFFSET){
        uint64_t lo=0, hi=0;
        char ibuf[64];
        curs_set(1); echo();
        clear();
        attron(A_BOLD | COLOR_PAIR(4));
        mvprintw(0, 0, " Offset Range Mode ");
        attroff(A_BOLD | COLOR_PAIR(4));
        mvprintw(2, 2, "Enter start VA (hex, e.g. 0x1000):");
        mvprintw(3, 4, "> "); refresh();
        getnstr(ibuf, sizeof(ibuf)-1);
        lo = (uint64_t)strtoull(ibuf, NULL, 16);
        mvprintw(5, 2, "Enter end VA (hex, exclusive):");
        mvprintw(6, 4, "> "); refresh();
        getnstr(ibuf, sizeof(ibuf)-1);
        hi = (uint64_t)strtoull(ibuf, NULL, 16);
        noecho(); curs_set(0);
        select_by_offset_range(funcs, nfuncs, lo, hi, text_data, text_va);
        int cnt=0; for(int i=0;i<nfuncs;i++) if(funcs[i].selected) cnt++;
        clear();
        mvprintw(2, 2, "Selected %d functions in [0x%llx, 0x%llx). Press any key...",
                 cnt, (unsigned long long)lo, (unsigned long long)hi);
        refresh(); getch();
        endwin(); return;
    }
    if(tmode == TMODE_HEAVIEST){
        char ibuf[32];
        curs_set(1); echo();
        clear();
        attron(A_BOLD | COLOR_PAIR(4));
        mvprintw(0, 0, " Heaviest N Functions Mode ");
        attroff(A_BOLD | COLOR_PAIR(4));
        int *order = (int*)malloc((size_t)nfuncs*sizeof(int));
        if(order){
            for(int i=0;i<nfuncs;i++) order[i]=i;
            for(int i=0;i<nfuncs-1&&i<20;i++){
                int best=i;
                for(int j=i+1;j<nfuncs;j++)
                    if(funcs[order[j]].complexity > funcs[order[best]].complexity) best=j;
                int tmp=order[i]; order[i]=order[best]; order[best]=tmp;
            }
            mvprintw(2, 0, "  %-4s %-12s %-7s %-7s %-6s %s", "#", "VA", "Size", "Score", "Safe?", "Symbol");
            for(int i=0;i<20&&i<nfuncs;i++){
                int idx=order[i];
                bool eligible2 = (funcs[idx].size>=MIN_FUNC_SIZE &&
                    !has_computed_branch(text_data,text_va,funcs[idx].va,funcs[idx].size));
                if(!eligible2){ attron(COLOR_PAIR(3)); }
                else if(funcs[idx].is_safe){ attron(COLOR_PAIR(8)); }
                const char *sn=funcs[idx].sym_name?funcs[idx].sym_name:"";
                char sb[28]; if(strlen(sn)>25){ memcpy(sb,sn,22); sb[22]='.'; sb[23]='.'; sb[24]=0; sn=sb; }
                mvprintw(3+i, 0, "  [%2d] 0x%08llX %6uB %7u %-6s %s",
                    i+1, (unsigned long long)funcs[idx].va, funcs[idx].size,
                    funcs[idx].complexity, funcs[idx].is_safe?"SAFE":"", sn);
                attroff(COLOR_PAIR(3)); attroff(COLOR_PAIR(8));
            }
            free(order);
        }
        mvprintw(max_y-3, 2, "How many heaviest functions to select? [10]:");
        mvprintw(max_y-2, 4, "> "); refresh();
        getnstr(ibuf, sizeof(ibuf)-1);
        int n=10; int v=atoi(ibuf); if(v>0) n=v;
        noecho(); curs_set(0);
        select_heaviest_n(funcs, nfuncs, text_data, text_va, n);
        int cnt=0; for(int i=0;i<nfuncs;i++) if(funcs[i].selected) cnt++;
        clear();
        mvprintw(2, 2, "Selected top %d heaviest = %d functions. Press any key...", n, cnt);
        refresh(); getch();
        endwin(); return;
    }
    if(tmode == TMODE_SAFE){
        select_ultra_safe(funcs, nfuncs, text_data, text_va);
        int cnt=0; for(int i=0;i<nfuncs;i++) if(funcs[i].selected) cnt++;
        clear();
        attron(A_BOLD | COLOR_PAIR(4));
        mvprintw(0, 0, " Ultra-Safe Mode ");
        attroff(A_BOLD | COLOR_PAIR(4));
        attron(COLOR_PAIR(1));
        mvprintw(2, 2, "Ultra-Safe filter selected %d/%d functions.", cnt, nfuncs);
        attroff(COLOR_PAIR(1));
        mvprintw(4, 2, "Criteria: standard prologue, no PAC, no LDR-lit density, balanced frames.");
        mvprintw(6, 2, "Press ENTER to proceed or Q to go back to manual.");
        refresh();
        int ch=getch();
        if(ch=='q'||ch=='Q'){
            for(int i=0;i<nfuncs;i++) funcs[i].selected=false;
            tmode = TMODE_MANUAL;
        } else {
            endwin(); return;
        }
    }

    int cursor = 0, scroll_off = 0;
    int list_h = max_y - 7;
    if(list_h < 5) list_h = 5;
    int sel_count = 0;
    while(1){
        clear();
        getmaxyx(stdscr, max_y, max_x);
        list_h = max_y - 7;
        if(list_h < 5) list_h = 5;
        attron(A_BOLD | COLOR_PAIR(4));
        mvprintw(0, 0, " Select Functions to Obfuscate [MANUAL] ");
        attroff(A_BOLD | COLOR_PAIR(4));
        attron(A_UNDERLINE | COLOR_PAIR(6));
        mvprintw(2, 0, "  # %-8s %-7s %-5s %-10s %-6s %-6s %-30s",
                 "VA", "Size", "Insns", "Prologue", "Risk", "Score", "Symbol");
        attroff(A_UNDERLINE | COLOR_PAIR(6));
        if(cursor < scroll_off) scroll_off = cursor;
        if(cursor >= scroll_off + list_h) scroll_off = cursor - list_h + 1;
        for(int row=0; row<list_h && scroll_off+row<nfuncs; row++){
            int idx = scroll_off + row;
            FuncEntry *fe = &funcs[idx];
            int y = 3 + row;
            bool is_cursor = (idx == cursor);
            bool is_sel = fe->selected;
            bool is_tiny = (fe->size < MIN_FUNC_SIZE);
            bool is_br = (!is_tiny && has_computed_branch(text_data, text_va, fe->va, fe->size));
            bool is_risky = is_tiny || is_br;
            if(is_cursor) attron(A_REVERSE);
            if(is_sel) attron(COLOR_PAIR(1));
            else if(fe->is_safe && !is_risky) attron(COLOR_PAIR(8));
            else if(is_risky) attron(COLOR_PAIR(3));
            char marker = is_sel ? '*' : (fe->is_safe && !is_risky ? '+' : ' ');
            char risk[8];
            if(is_tiny) strcpy(risk, "TINY");
            else if(is_br) strcpy(risk, "BR");
            else if(fe->is_safe) strcpy(risk, "SAFE");
            else strcpy(risk, "OK");
            const char *sname = fe->sym_name ? fe->sym_name : "";
            char sbuf[31];
            if(strlen(sname) > 30){
                memcpy(sbuf, sname, 27);
                sbuf[27]='.'; sbuf[28]='.'; sbuf[29]='.'; sbuf[30]=0;
                sname = sbuf;
            }
            mvprintw(y, 0, "%c%4d %08llX %6u %5u %-10s %-6s %6u %-30s",
                marker, idx, (unsigned long long)fe->va, fe->size, fe->insn_cnt,
                fe->prologue, risk, fe->complexity, sname);
            if(is_cursor) attroff(A_REVERSE);
            if(is_sel) attroff(COLOR_PAIR(1));
            else if(fe->is_safe && !is_risky) attroff(COLOR_PAIR(8));
            else if(is_risky) attroff(COLOR_PAIR(3));
        }
        sel_count = 0;
        for(int i=0;i<nfuncs;i++) if(funcs[i].selected) sel_count++;
        attron(COLOR_PAIR(5));
        mvhline(max_y-3, 0, ' ', max_x);
        mvprintw(max_y-3, 1, " SPACE=toggle  A=all  S=safe-only  H=heaviest10  N=none  ENTER=start  Q=quit ");
        attroff(COLOR_PAIR(5));
        attron(COLOR_PAIR(5));
        mvhline(max_y-2, 0, ' ', max_x);
        mvprintw(max_y-2, 1, " Selected: %d/%d  |  *=sel  +=safe  [red]=risky ", sel_count, nfuncs);
        attroff(COLOR_PAIR(5));
        attron(COLOR_PAIR(6));
        mvprintw(max_y-1, 1, " [%d/%d] Up/Down/PgUp/PgDn/Home/End to navigate ", cursor+1, nfuncs);
        attroff(COLOR_PAIR(6));
        refresh();
        int ch = getch();
        switch(ch){
        case KEY_UP:   case 'k': if(cursor > 0) cursor--; break;
        case KEY_DOWN: case 'j': if(cursor < nfuncs-1) cursor++; break;
        case KEY_PPAGE: cursor -= list_h; if(cursor < 0) cursor = 0; break;
        case KEY_NPAGE: cursor += list_h; if(cursor >= nfuncs) cursor = nfuncs - 1; break;
        case KEY_HOME: cursor = 0; break;
        case KEY_END:  cursor = nfuncs - 1; break;
        case ' ': funcs[cursor].selected = !funcs[cursor].selected; if(cursor < nfuncs-1) cursor++; break;
        case 'a': case 'A':
            for(int i=0;i<nfuncs;i++)
                if(funcs[i].size >= MIN_FUNC_SIZE && !has_computed_branch(text_data,text_va,funcs[i].va,funcs[i].size))
                    funcs[i].selected = true;
            break;
        case 's': case 'S':
            for(int i=0;i<nfuncs;i++) funcs[i].selected=false;
            select_ultra_safe(funcs,nfuncs,text_data,text_va);
            break;
        case 'h': case 'H':
            for(int i=0;i<nfuncs;i++) funcs[i].selected=false;
            select_heaviest_n(funcs,nfuncs,text_data,text_va,10);
            break;
        case 'n': case 'N': for(int i=0;i<nfuncs;i++) funcs[i].selected = false; break;
        case '\n': case '\r': case KEY_ENTER:
            if(sel_count == 0)
                for(int i=0;i<nfuncs;i++)
                    if(funcs[i].size >= MIN_FUNC_SIZE && !has_computed_branch(text_data,text_va,funcs[i].va,funcs[i].size))
                        funcs[i].selected = true;
            endwin(); return;
        case 'q': case 'Q': endwin(); printf("[!] Cancelled by user\n"); exit(0);
        }
    }
}
