# dylib_protect — LDVQuang2306 Edition

![License](https://img.shields.io/badge/License-GPL--3.0-blue)
![Language](https://img.shields.io/badge/Language-C11-blue)
![Status](https://img.shields.io/badge/Status-Beta-orange)

**Trình bảo vệ & ảo hóa (protector / virtualizer) cho thư viện động Mach-O ARM64 / arm64e (iOS / macOS).**

Công cụ nhận file `.dylib` Mach-O 64-bit và tạo bản đã **làm rối luồng điều khiển**, **ảo hóa hàm**, **chống sửa hex**, tùy chọn **hết hạn theo thời gian**, và **ký ad-hoc**. Viết bằng C11; build được trên **Ubuntu**, **macOS**, và (tùy chọn) **Windows / MSYS2**.

> **⚠️ PHIÊN BẢN BETA** — Đây **không phải** bản phát hành đích (release). Pipeline còn nhiều lỗi, edge case chưa xử lý, và hành vi có thể thay đổi giữa các commit. **Không dùng cho production** cho đến khi có bản stable chính thức. Mọi báo cáo lỗi / PR đều được hoan nghênh.

---

## Tính năng

| Tính năng | Mô tả |
|-----------|-------|
| **Control-Flow Flattening (full-CFF)** | Tách basic-block, dispatcher state-machine trên state-ID đã mã hóa, chèn control-flow giả + junk. Giãn nở ~17–35× (hàm thường); **safe-CFG** (~1.4–1.7×) cho hàm cực lớn hoặc có computed-branch. |
| **Obfuscation per-instruction** | Làm rối **từng lệnh máy**. Scratch/state register dùng `x9–x17`, không đụng `x0–x8`. |
| **Virtual Machine (VM)** | Dịch hàm “nặng” sang bytecode VM 33 thanh ghi; bytecode **XOR mã hóa theo word** (tắt bằng `-no-vmenc`). Lệnh không ảo hóa an toàn qua native trampoline; hàm **REJECT** nếu không host được. |
| **Anti-hex-edit** | Hash toàn vẹn runtime; phát hiện sửa hex trực tiếp trên binary đã bảo vệ (`-no-antihex` để tắt). |
| **Time-based expiration** | `-expire=DAYS` — quá hạn binary từ chối chạy. |
| **Ad-hoc code signing** | Ký lại ad-hoc sau biến đổi Mach-O. |
| **Init wrapper** | Chuỗi `mod_init_func` obfuscated (CFF + indirect branch) trước constructor gốc. |
| **Container mode** | `-container=DIR` — tái tạo pipeline `inputOther` → `outputOther` từ asset. |
| **Double-process guard** | Từ chối input đã có marker AHEX/VMBC; `-force` để bỏ qua (không an toàn). |

Kiến trúc **whole-image-shift**: engine (hàm đã obfuscate + VM interpreter) chèn đầu image; nội dung gốc dịch lên; entry gốc thành trampoline xuống bản protected.

---

## Yêu cầu chung

| Thành phần | Ghi chú |
|------------|---------|
| **Compiler** | GCC hoặc Clang, hỗ trợ **C11** |
| **Capstone** | Phân tích / disassemble ARM64 (`libcapstone`) |
| **ncurses (wide)** | Giao diện TUI chọn hàm (`libncursesw`) |
| **make** | Build qua `Makefile` |

> Makefile mặc định có `-I/mingw64/include/ncursesw` (MSYS2). Trên **Ubuntu** và **macOS** cần chỉnh `CFLAGS` / `LDFLAGS` — xem từng mục bên dưới.

---

## Build trên Ubuntu (22.04 / 24.04)

### 1. Cài dependency

```bash
sudo apt update
sudo apt install -y build-essential pkg-config \
  libcapstone-dev libncursesw5-dev
```

Trên một số bản Ubuntu mới, nếu không có `libncursesw5-dev`:

```bash
sudo apt install -y libncurses-dev
```

### 2. Chỉnh Makefile (bắt buộc trên Linux)

Mở `Makefile`, thay dòng `CFLAGS` để **bỏ** đường dẫn MinGW:

```makefile
CFLAGS   = -O2 -Wall -Wextra -std=c11 -Iinclude
LDFLAGS  = -lncursesw -lcapstone -lm
```

Nếu linker báo thiếu `ncursesw`, thử thêm:

```makefile
LDFLAGS  = -lncursesw -ltinfo -lcapstone -lm
```

### 3. Biên dịch

```bash
cd beta2
make clean && make
```

Sinh ra: `./dylib_protect`

### 4. Kiểm tra nhanh

```bash
./dylib_protect
# Kỳ vọng: in usage (exit 1) — chứng tỏ binary chạy được
```

---

## Build trên macOS (Apple Silicon / Intel)

### 1. Cài dependency (Homebrew)

```bash
brew install capstone ncurses make
```

### 2. Chỉnh Makefile

```makefile
NCURSES_PREFIX := $(shell brew --prefix ncurses 2>/dev/null)

CFLAGS   = -O2 -Wall -Wextra -std=c11 -Iinclude \
           -I$(NCURSES_PREFIX)/include
LDFLAGS  = -L$(NCURSES_PREFIX)/lib -lncursesw -lcapstone -lm
```

Hoặc export một lần rồi `make`:

```bash
export NCURSES_PREFIX="$(brew --prefix ncurses)"
make clean && make \
  CFLAGS="-O2 -Wall -Wextra -std=c11 -Iinclude -I$NCURSES_PREFIX/include" \
  LDFLAGS="-L$NCURSES_PREFIX/lib -lncursesw -lcapstone -lm"
```

### 3. Biên dịch

```bash
cd beta2
make clean && make
```

### 4. Lưu ý macOS

- Tool **chỉ build host** (chạy trên Mac để xử lý file `.dylib`); đầu ra vẫn là Mach-O ARM64 cho iOS/macOS target.
- Nếu Gatekeeper chặn binary tự build: `xattr -cr ./dylib_protect` hoặc chạy từ terminal đã trust.
- Kiểm thử **arm64e / PAC** phải trên **thiết bị iOS thật**, không đủ trên simulator hoặc host x86_64.

---

## Build trên Windows (MSYS2 / MinGW64) — tùy chọn

### 1. Cài MSYS2

Tải từ [msys2.org](https://www.msys2.org/), mở shell **MINGW64** (không dùng MSYS thuần).

### 2. Cài gói

```bash
pacman -Syu
pacman -S mingw-w64-x86_64-toolchain \
          mingw-w64-x86_64-capstone \
          mingw-w64-x86_64-ncurses
```

### 3. Build

Makefile gốc đã có `-I/mingw64/include/ncursesw` — trong MINGW64:

```bash
make clean && make
```

### 4. Runtime

Đảm bảo `C:\msys64\mingw64\bin` trong `PATH` để nạp `libcapstone-*.dll` và `libncursesw-*.dll` khi chạy `dylib_protect.exe`.

---

## Cách dùng

```text
dylib_protect [options] input.dylib output.dylib
```

| Flag | Ý nghĩa |
|------|---------|
| `-a` | Auto: chọn tất cả hàm đủ điều kiện, không TUI |
| `-no-antihex` | Tắt kiểm tra toàn vẹn anti-hex |
| `-no-vmenc` | Tắt mã hóa bytecode VM (decrypt-on-fetch) |
| `-force` | Xử lý lại dylib đã protected (**nguy hiểm**, output có thể hỏng) |
| `-expire=DAYS` | Hết hạn sau N ngày (tối thiểu 1) |
| `-container=DIR` | Chế độ container: rebuild từ asset trong `DIR` |

**TUI (không có `-a`):** ncurses — chọn hàm, bật/tắt obfuscation, VM, anti-hex, time-protect.

**Không có stdin (pipe/CI):** fallback tự chọn mặc định (obfuscation + anti-hex + VM + time-protect tùy flag).

### Ví dụ

```bash
# TUI — chọn hàm thủ công
./dylib_protect MyTweak.dylib MyTweak.protected.dylib

# Batch — mọi hàm safe + hết hạn 30 ngày
./dylib_protect -a -expire=30 MyTweak.dylib MyTweak.protected.dylib

# Tắt VM encryption (debug)
./dylib_protect -a -no-vmenc input.dylib output.dylib

# Container
./dylib_protect -container=./assets inputOther outputOther
```

---

## Cấu trúc dự án

```text
.
├── Makefile
├── LICENSE                 # GPL-3.0
├── README.md
├── include/                # headers
└── src/
    ├── main.c              # CLI, pipeline, signing, time-protect
    ├── obfuscate.c         # CFF / per-instruction obfuscation
    ├── vm.c                # ARM64 → VM bytecode + interpreter stub
    ├── arm64_analyze.c     # phân tích lệnh ARM64
    ├── arm64_enc.c         # emit ARM64
    ├── macho.c             # parse / rebuild Mach-O
    ├── pcrel.c / extpc.c   # PC-relative fixup
    ├── ctor_obf.c          # obfuscate constructor / wrapper
    ├── container.c         # container asset mode
    ├── sha256.c / sign.c   # hash + ad-hoc sign
    ├── tui.c               # ncurses UI
    ├── buf.c / util.c
    └── vmparse*.c          # công cụ dev (không vào build chính)
```

Các hàm lõi dùng tiền tố `ldvq2306_` (VM translate, encrypted-branch, obfuscate, anti-hex ctor, time-protect, …).

---

## Tính tái lập (determinism)

Obfuscation, VM và anti-hex **tất định** theo VA / key derivation cố định trong một lần chạy. **Ngoại lệ:** `-expire` dùng `time(NULL)` → khối time-protect và chữ ký ad-hoc **khác nhau** giữa các lần chạy khác thời điểm.

---

## Hạn chế & lưu ý (đọc trước khi dùng)

### Beta — không phải bản đích

- Pipeline **chưa ổn định**: có thể crash, reject hàm hợp lệ, hoặc sinh dylib không load được.
- **Không** cam kết tương thích mọi dylib / mọi phiên bản iOS.
- API CLI và format marker (AHEX, VMBC, …) có thể đổi trước bản release.
- Dùng `-force` trên file đã protected dễ **hỏng file** — chỉ khi debug.

### Nền tảng đầu ra

- Đầu ra hướng tới **arm64 / arm64e** (PAC-aware).
- Validate trên device thật; build host Ubuntu/macOS/Windows **không** thay thế test trên iPhone/iPad.

### Pháp lý / trách nhiệm

Chỉ bảo vệ phần mềm bạn **sở hữu** hoặc **được phép**. Tác giả không chịu trách nhiệm misuse, mất dữ liệu, hoặc binary hỏng sau khi dùng công cụ beta này.

---

## Giấy phép

Copyright © 2026 **LDVQuang2306**.

Phát hành theo **[GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.html)** (GPL-3.0).  
Fork / phân phối phải tuân thủ GPL (công khai mã nguồn tương ứng). Chi tiết: [LICENSE](LICENSE).
