
#ifndef DYLIB_PROTECT_OBFUSCATE_H
#define DYLIB_PROTECT_OBFUSCATE_H

#include "types.h"

int ldvq2306_split_basic_blocks(const uint32_t *src, int src_cnt, uint64_t orig_va,
                       BasicBlock *bbs, int max_bbs);
int find_bb_for_idx(const BasicBlock *bbs, int nbb, int idx);

uint64_t func_end_va_reachable(const uint8_t *text_data,
    uint64_t text_va, uint64_t text_sz,
    uint64_t fva, uint64_t next_fva);

int ldvq2306_emit_encrypted_branch(uint32_t *dst, int n, int max_n);
void ldvq2306_patch_encrypted_branch(uint32_t *dst, int enc_start, uint64_t target_va, uint64_t adr_va);

int ldvq2306_emit_encrypted_branch_v2(uint32_t *dst, int n, int max_n);
void ldvq2306_patch_encrypted_branch_v2(uint32_t *dst, int enc_start, uint64_t target_va, uint64_t adr_va);

int ldvq2306_obfuscate_func(const uint32_t *src, int src_cnt,
                   uint64_t orig_va, uint64_t new_va,
                   uint32_t *dst, int max_dst,
                   uint32_t buf_base_byte_off, float obf_weight,
                   bool conservative_mode,
                   uint32_t used_gpr_mask,
                   uint32_t analysis_flags);

int ldvq2306_obfuscate_internal_buf(const uint32_t *src, int src_cnt,
                           uint64_t orig_va, uint64_t new_va,
                           uint32_t *dst, int max_dst);

int ldvq2306_build_antihex_ctor_raw(uint32_t *b, int max_insns,
                           uint64_t exec_seg_va,
                           uint64_t text_va,
                           uint32_t text_sz,
                           uint32_t text_xhash);

int ldvq2306_build_timeprotect_raw(uint32_t *b, int max_insns,
                          uint64_t deadline_epoch);

#endif
