
#ifndef DYLIB_PROTECT_TUI_H
#define DYLIB_PROTECT_TUI_H

#include "types.h"

void run_tui(FuncEntry *funcs, int nfuncs, bool *do_obf, bool *do_antihex, bool *do_vm,
             bool *do_timeprotect, int *expire_days,
             const uint8_t *text_data, uint64_t text_va);
void run_tui_fallback(FuncEntry *funcs, int nfuncs, bool *do_obf, bool *do_antihex, bool *do_vm,
                      bool *do_timeprotect, int *expire_days,
                      const uint8_t *text_data, uint64_t text_va);

#endif
