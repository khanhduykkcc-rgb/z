
#ifndef DYLIB_PROTECT_ARM64_ENC_H
#define DYLIB_PROTECT_ARM64_ENC_H

#include "types.h"

uint32_t enc_b26(int32_t im);
uint32_t enc_bl26(int32_t im);
uint32_t enc_movz(int d,uint16_t im,int sh);
uint32_t enc_movk(int d,uint16_t im,int sh);
uint32_t enc_add_i(int d,int n,int im);
uint32_t enc_sub_i(int d,int n,int im);
uint32_t enc_add_r(int d,int n,int m);
uint32_t enc_mov_x(int d,int m);
uint32_t enc_str_x_off(int t,int n,int sc);
uint32_t enc_ldr_x_off(int t,int n,int sc);
uint32_t enc_ldr_w_off(int t,int n,int sc);
uint32_t enc_ldr_w_post(int t,int n,int im9);
uint32_t enc_stp_pre(int a,int b,int n,int im7);
uint32_t enc_ldp_post(int a,int b,int n,int im7);
uint32_t enc_stp(int a,int b,int n,int im7);
uint32_t enc_ldp(int a,int b,int n,int im7);
uint32_t enc_br(int n);
uint32_t enc_ret(void);
uint32_t enc_b_ne(int32_t im19);
uint32_t enc_b_eq(int32_t im19);
uint32_t enc_subs_w_i(int d,int n,int im);
uint32_t enc_cmp_x(int n,int m);
uint32_t enc_eor_w(int d,int n,int m);
uint32_t enc_eor_x(int d,int n,int m);
uint32_t enc_ror_w(int d,int n,int sh);
uint32_t enc_lsr_w(int d,int n,int sh);
uint32_t enc_sub_i_lsl12(int d,int n,int im);
uint32_t enc_orr_w(int d,int n,int m);
uint32_t enc_and_x(int d,int n,int m);
uint32_t enc_sub_r(int d,int n,int m);
uint32_t enc_orn_x(int d,int n,int m);
uint32_t enc_adr(int d, int32_t off);
uint32_t enc_adrp(int d, int32_t page_delta);
uint32_t enc_mul_x(int d,int n,int m);
uint32_t enc_madd_x(int d,int n,int m,int a);
uint32_t enc_csel_x(int d,int n,int m,int cond);
uint32_t enc_lsl_x_imm(int d,int n,int sh);
uint32_t enc_lsr_x_imm(int d,int n,int sh);
uint32_t enc_ror_x(int d,int n,int sh);
uint32_t enc_mvn_x(int d,int m);
uint32_t enc_neg_x(int d,int m);
uint32_t enc_cbz_x(int rt,int32_t off19);
uint32_t enc_cbnz_x(int rt,int32_t off19);
uint32_t enc_cbz_w(int rt,int32_t off19);
uint32_t enc_cbnz_w(int rt,int32_t off19);
uint32_t enc_subs_x_r(int d,int n,int m);
uint32_t enc_adds_x_r(int d,int n,int m);
uint32_t enc_subs_w_r(int d,int n,int m);
uint32_t enc_adds_w_r(int d,int n,int m);
uint32_t enc_sub_w_r(int d,int n,int m);
uint32_t enc_add_w_r(int d,int n,int m);
uint32_t enc_sub_w_i(int d,int n,int im);
uint32_t enc_add_w_i(int d,int n,int im);
uint32_t enc_eor_x_imm(int d,int n,uint32_t immr,uint32_t imms);
uint32_t enc_orr_x(int d,int n,int m);
uint32_t enc_bic_x(int d,int n,int m);
uint32_t enc_eon_x(int d,int n,int m);
uint32_t enc_sdiv_x(int d,int n,int m);
uint32_t enc_udiv_x(int d,int n,int m);
uint32_t enc_msub_x(int d,int n,int m,int a);
uint32_t enc_clz_x(int d,int n);
uint32_t enc_rev_x(int d,int n);
uint32_t enc_rbit_x(int d,int n);
uint32_t enc_b_cc(int cond,int32_t im19);
uint32_t enc_tbz(int rt,int bit,int32_t off14);
uint32_t enc_tbnz(int rt,int bit,int32_t off14);
uint32_t enc_blr(int n);
uint32_t enc_nop(void);
uint32_t enc_movn_x(int d,uint16_t im,int sh);

uint32_t enc_movz_w(int d,uint16_t im,int sh);
uint32_t enc_movk_w(int d,uint16_t im,int sh);
uint32_t enc_movn_w(int d,uint16_t im,int sh);
uint32_t enc_mov_w(int d,int m);

uint32_t enc_subs_x_i(int d,int n,int im);
uint32_t enc_adds_x_i(int d,int n,int im);
uint32_t enc_adds_w_i(int d,int n,int im);
uint32_t enc_add_i_lsl12(int d,int n,int im);

uint32_t enc_and_w(int d,int n,int m);
uint32_t enc_bic_w(int d,int n,int m);
uint32_t enc_orn_w(int d,int n,int m);
uint32_t enc_eon_w(int d,int n,int m);
uint32_t enc_orr_w_r(int d,int n,int m);

uint32_t enc_and_x_imm(int d,int n,uint32_t immr,uint32_t imms);
uint32_t enc_orr_x_imm(int d,int n,uint32_t immr,uint32_t imms);
uint32_t enc_ands_x_imm(int d,int n,uint32_t immr,uint32_t imms);

uint32_t enc_csel_w(int d,int n,int m,int cond);
uint32_t enc_csinc_x(int d,int n,int m,int cond);
uint32_t enc_csinc_w(int d,int n,int m,int cond);
uint32_t enc_csinv_x(int d,int n,int m,int cond);
uint32_t enc_csinv_w(int d,int n,int m,int cond);
uint32_t enc_csneg_x(int d,int n,int m,int cond);
uint32_t enc_csneg_w(int d,int n,int m,int cond);

uint32_t enc_mul_w(int d,int n,int m);
uint32_t enc_madd_w(int d,int n,int m,int a);
uint32_t enc_msub_w(int d,int n,int m,int a);
uint32_t enc_sdiv_w(int d,int n,int m);
uint32_t enc_udiv_w(int d,int n,int m);

uint32_t enc_clz_w(int d,int n);
uint32_t enc_rev_w(int d,int n);
uint32_t enc_rbit_w(int d,int n);
uint32_t enc_cls_x(int d,int n);
uint32_t enc_neg_w(int d,int m);
uint32_t enc_mvn_w(int d,int m);

uint32_t enc_str_w_off(int t,int n,int sc);
uint32_t enc_ldrb_off(int t,int n,int imm);
uint32_t enc_strb_off(int t,int n,int imm);
uint32_t enc_ldrh_off(int t,int n,int imm);
uint32_t enc_strh_off(int t,int n,int imm);
uint32_t enc_ldrsw_off(int t,int n,int sc);
uint32_t enc_stp_w(int a,int b,int n,int im7);
uint32_t enc_ldp_w(int a,int b,int n,int im7);
uint32_t enc_stp_w_pre(int a,int b,int n,int im7);
uint32_t enc_ldp_w_post(int a,int b,int n,int im7);

uint32_t enc_lsl_w_imm(int d,int n,int sh);

uint32_t enc_sbfm_x(int d,int n,int immr,int imms);
uint32_t enc_ubfm_x(int d,int n,int immr,int imms);
uint32_t enc_sbfm_w(int d,int n,int immr,int imms);
uint32_t enc_ubfm_w(int d,int n,int immr,int imms);
uint32_t enc_asr_x(int d,int n,int sh);
uint32_t enc_sxtw(int d,int n);

uint32_t enc_ccmp_x_i(int n,int imm5,int nzcv,int cond);
uint32_t enc_ccmp_x_r(int n,int m,int nzcv,int cond);
uint32_t enc_ccmn_x_i(int n,int imm5,int nzcv,int cond);

int emit_mov64(uint32_t *buf, int n, int reg, uint64_t val);

uint64_t decode_bitmask_imm(uint32_t N, uint32_t immr, uint32_t imms, int is64);
bool encode_bitmask_imm(uint64_t val, int is64, uint32_t *N, uint32_t *immr, uint32_t *imms);
#endif
