
#ifndef DYLIB_PROTECT_VM_H
#define DYLIB_PROTECT_VM_H

#include "types.h"

void vm_bc_init(VmBytecode *bc);
void vm_bc_free(VmBytecode *bc);
void vm_bc_emit(VmBytecode *bc, uint8_t op, uint8_t rd, uint8_t rn, uint8_t rm, uint32_t imm);
uint32_t vm_bc_serialize(const VmBytecode *bc, uint8_t *out, uint32_t max_sz);

bool ldvq2306_translate_arm64_to_vm(const uint32_t *insns, uint32_t insn_count,
                           uint64_t func_va, uint64_t text_va, uint64_t text_sz,
                           VmBytecode *bc,
                           uint64_t *ext_call_targets, int *n_ext_calls, int max_ext,
                           uint32_t *native_words, int *n_native_words, int max_native);

bool ldvq2306_translate_arm64_to_vm_ex(const uint32_t *insns, uint32_t insn_count,
                              uint64_t func_va, uint64_t text_va, uint64_t text_sz,
                              VmBytecode *bc,
                              uint64_t *ext_call_targets, int *n_ext_calls, int max_ext,
                              uint32_t *native_words, int *n_native_words, int max_native,
                              int *out_insn_to_vm);

int ldvq2306_emit_vm_interpreter_stub(uint32_t *code, int max_insns,
                             uint64_t bc_va, uint32_t bc_count,
                             uint64_t stub_va,
                             uint64_t trampoline_va, uint32_t n_trampolines,
                             int vm_encrypt, uint32_t enc_key0, uint32_t enc_key1);

#endif
