
#ifndef DYLIB_PROTECT_EXTPC_H
#define DYLIB_PROTECT_EXTPC_H

#include "types.h"

void extpc_init(void);
void extpc_free(void);
void extpc_add(uint32_t boff, uint64_t abs_t, PCType t);

ExtPCRef *extpc_get_refs(void);
int extpc_get_count(void);

#endif
