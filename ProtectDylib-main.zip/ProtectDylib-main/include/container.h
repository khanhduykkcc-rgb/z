#ifndef CONTAINER_H
#define CONTAINER_H

int container_run(const char *in_path, const char *out_path, const char *assetdir);

#endif
