
#ifndef DYLIB_PROTECT_PCREL_H
#define DYLIB_PROTECT_PCREL_H

#include "types.h"

PCType classify_pcrel(uint32_t w, int64_t *off);
bool is_internal_br(PCType t);
uint32_t rewrite_pcrel(uint32_t w, PCType t, int64_t new_off);
bool pcrel_in_range(PCType t, int64_t new_off);
int get_rd(uint32_t w);
bool sets_flags(uint32_t w);
bool uses_flags(uint32_t w);
bool is_adrp(uint32_t w);
bool is_adr(uint32_t w);
bool is_movz(uint32_t w);
bool is_movk(uint32_t w);
bool is_terminator(uint32_t w);
bool is_cond_branch(uint32_t w);

#endif
