
#ifndef DYLIB_PROTECT_BUF_H
#define DYLIB_PROTECT_BUF_H

#include "types.h"

void buf_init(Buf *b);
void buf_reserve(Buf *b, uint32_t extra);
void buf_push(Buf *b, const void *src, uint32_t n);
void buf_u8(Buf *b, uint8_t v);
void buf_u32(Buf *b, uint32_t v);
void buf_free(Buf *b);
void buf_pad16(Buf *b);

#endif
