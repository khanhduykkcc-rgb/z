
#ifndef DYLIB_PROTECT_MACHO_H
#define DYLIB_PROTECT_MACHO_H

#include "types.h"

bool parse_dylib(const uint8_t *d, uint32_t sz, DylibInfo *di);
int get_func_starts(const uint8_t *d, const DylibInfo *di, uint64_t *out, int max_out);
const char *find_symbol_name(const uint8_t *d, uint32_t dsz, uint64_t va);

void detect_prologue(const uint8_t *text_data, uint64_t text_va, uint64_t fva, char *out);
uint32_t compute_func_complexity(const uint8_t *text_data, uint64_t text_va,
                                  uint64_t fva, uint32_t fsz);
bool has_computed_branch(const uint8_t *text_data, uint64_t text_va, uint64_t fva, uint32_t fsz);
bool func_is_ultra_safe(const uint8_t *text_data, uint64_t text_va,
                         uint64_t fva, uint32_t fsz);

void select_heaviest_n(FuncEntry *funcs, int nfuncs,
                       const uint8_t *text_data, uint64_t text_va, int n);
void select_by_offset_range(FuncEntry *funcs, int nfuncs,
                            uint64_t range_lo, uint64_t range_hi,
                            const uint8_t *text_data, uint64_t text_va);
void select_ultra_safe(FuncEntry *funcs, int nfuncs,
                       const uint8_t *text_data, uint64_t text_va);

void fix_rebase_pointer_values(uint8_t *out, uint32_t out_sz,
    const uint8_t *rebase_data, uint32_t rebase_size,
    const SegLayout *layout, uint64_t shift_threshold, uint64_t shift_end, uint64_t shift_amount);
void fix_symbol_values(uint8_t *out, uint32_t out_sz, uint32_t symoff, uint32_t nsyms,
    uint64_t shift_threshold, uint64_t shift_end, uint64_t shift_amount);
void fix_export_trie(uint8_t *out, uint32_t *out_sz, uint32_t max_alloc, uint64_t shift_amount);
void fix_lc_function_starts(uint8_t *out, uint32_t *out_sz, uint32_t max_alloc,
    uint64_t shift_amount, uint64_t text_seg_va);

void fix_chained_fixups(uint8_t *out, uint32_t out_sz,
    uint64_t vm_pad, uint64_t shift_threshold, uint64_t shift_end, uint64_t actual_shift);

int  collect_eh_active(const uint8_t *d, uint32_t sz, uint64_t image_base,
                       uint64_t *out, int max_out);
bool binary_uses_eh(const uint8_t *d, uint32_t sz);
bool func_makes_calls(const uint8_t *text_data, uint64_t text_va,
                      uint64_t fva, uint32_t fsz);

uint8_t *build_output(const uint8_t *orig, uint32_t orig_sz,
    const uint8_t *vm_code, uint32_t vm_size,
    uint64_t insert_point, uint64_t *out_shift, uint32_t *out_sz,
    bool add_exec_seg, uint64_t *exec_fo_out, uint64_t *exec_va_out);

#endif
