
#ifndef DYLIB_PROTECT_TYPES_H
#define DYLIB_PROTECT_TYPES_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
#include <math.h>

#define MH_MAGIC_64          0xFEEDFACFu
#define MH_DYLIB             0x6
#define LC_SEGMENT_64        0x19u
#define LC_SYMTAB            0x2u
#define LC_DYSYMTAB          0xBu
#define LC_FUNCTION_STARTS   0x26u
#define LC_DATA_IN_CODE      0x29u
#define LC_CODE_SIGNATURE    0x1Du
#define LC_DYLD_INFO_ONLY    0x80000022u
#define LC_DYLD_EXPORTS_TRIE 0x80000033u
#define LC_ENCRYPTION_INFO_64 0x2Cu
#define LC_SEGMENT_SPLIT_INFO 0x1Eu
#define LC_DYLIB_CODE_SIGN_DRS 0x2Bu
#define LC_LINKER_OPTIMIZATION_HINT 0x2Eu
#define LC_ATOM_INFO 0x36u
#define S_MOD_INIT_FUNC_PTRS 0x9u
#define VM_PROT_READ    1
#define VM_PROT_WRITE   2
#define VM_PROT_EXECUTE 4

#define LC_DYLD_CHAINED_FIXUPS 0x80000034u
#define DYLD_CHAINED_PTR_START_NONE 0xFFFF
#define DYLD_CHAINED_PTR_START_MULTI 0x8000

#define REBASE_OPCODE_DONE 0x00
#define REBASE_OPCODE_SET_TYPE_IMM 0x10
#define REBASE_OPCODE_SET_SEGMENT_AND_OFFSET_ULEB 0x20
#define REBASE_OPCODE_ADD_ADDR_ULEB 0x30
#define REBASE_OPCODE_ADD_ADDR_IMM_SCALED 0x40
#define REBASE_OPCODE_DO_REBASE_IMM_TIMES 0x50
#define REBASE_OPCODE_DO_REBASE_ULEB_TIMES 0x60
#define REBASE_OPCODE_DO_REBASE_ADD_ADDR_ULEB 0x70
#define REBASE_OPCODE_DO_REBASE_ULEB_TIMES_SKIPPING_ULEB 0x80

#define NOP      0xD503201Fu
#define BRK_0    0xD4200000u

#define MAX_FUNCS       16384
#define MIN_FUNC_SIZE   16
#define MAX_OBF         (256u*1024u*1024u)
#define EXEC_HEADER_SIZE 64
#define MAX_BB          1048576
#define ENC_BR_SIZE     21
#define ENC_BR_V3_SIZE  31
#define ENC_BR_V4_SIZE  27
#define ENC_BR_V5_SIZE  35

#define FUNC_RISK_NONE        0u
#define FUNC_RISK_COND_TRAP   (1u << 0)
#define FUNC_RISK_FLAG_GAP    (1u << 1)
#define FUNC_RISK_EXT_COND    (1u << 2)
#define FUNC_RISK_REG_CLOBBER (1u << 3)
#define FUNC_RISK_SPECIAL_OP  (1u << 4)

typedef struct { uint32_t magic,cputype,cpusubtype,filetype,ncmds,sizeofcmds,flags,reserved; } mh64;
typedef struct { uint32_t cmd,cmdsize; } lc_t;
typedef struct { uint32_t cmd,cmdsize; char segname[16]; uint64_t vmaddr,vmsize,fileoff,filesize; uint32_t maxprot,initprot,nsects,flags; } seg64;
typedef struct { char sectname[16],segname[16]; uint64_t addr,size; uint32_t offset,align_,reloff,nreloc,flags,res1,res2,res3; } sec64;
typedef struct { uint32_t cmd,cmdsize,dataoff,datasize; } linkedit_lc;
typedef struct { uint32_t cmd,cmdsize,symoff,nsyms,stroff,strsize; } symtab_lc;
typedef struct { uint32_t cmd,cmdsize,ilocalsym,nlocalsym,iextdefsym,nextdefsym,iundefsym,nundefsym,tocoff,ntoc,modtaboff,nmodtab,extrefsymoff,nextrefsyms,indirectsymoff,nindirectsyms,extreloff,nextrel,locreloff,nlocrel; } dysymtab_lc;
typedef struct { uint32_t cmd,cmdsize,rebase_off,rebase_size,bind_off,bind_size,weak_bind_off,weak_bind_size,lazy_bind_off,lazy_bind_size,export_off,export_size; } dyldinfo_lc;
typedef struct { uint32_t cmd,cmdsize,cryptoff,cryptsize,cryptid,pad; } encryption_info_64_t;
typedef struct { int32_t n_strx; uint8_t n_type,n_sect; int16_t n_desc; uint64_t n_value; } nlist_64_t;

typedef enum {
    PC_NONE,PC_B26,PC_BL26,PC_BCOND,
    PC_CBZ_W,PC_CBNZ_W,PC_CBZ_X,PC_CBNZ_X,
    PC_TBZ,PC_TBNZ,PC_ADR,PC_ADRP,
    PC_LDR_W_LIT,PC_LDR_X_LIT,PC_LDRSW_LIT,
    PC_LDR_S_LIT,PC_LDR_D_LIT,PC_LDR_Q_LIT,PC_PRFM_LIT,
} PCType;

typedef struct { int start_idx; int end_idx; int block_id; } BasicBlock;
typedef struct { int dst_pos; int target_bb; int is_encrypted; int enc_variant; } BranchPatch;

typedef struct { uint32_t buf_byte_off; uint64_t abs_target; PCType type; } ExtPCRef;

typedef struct { uint8_t *data; uint32_t size, cap; } Buf;

typedef struct {
    uint64_t text_va, text_fo, text_sz;
    uint64_t tseg_va, tseg_fo, tseg_fsz, tseg_vsz;
    uint64_t le_va, le_fo, le_fsz, le_vsz;
    uint64_t mod_init_fo, mod_init_sz, mod_init_va;
    uint64_t insert_point;
    uint64_t first_section_fo;
    uint64_t stubs_va, stubs_fo, stubs_sz;
    uint64_t stub_helper_va, stub_helper_fo, stub_helper_sz;
} DylibInfo;

typedef struct {
    uint64_t va;
    uint32_t size;
    uint32_t insn_cnt;
    const char *sym_name;
    bool selected;
    char prologue[16];
    uint32_t complexity;
    bool is_safe;
    bool is_trap_helper;
    bool force_safe_mode;
    uint32_t risk_flags;
    uint32_t used_gpr_mask;
    uint32_t analysis_flags;
} FuncEntry;

typedef struct {
    int func_idx;
    uint64_t orig_va;
    uint64_t new_va;
    uint32_t buf_off;
    uint32_t orig_sz;
    bool ok;
} FuncMap;

typedef struct {
    uint64_t seg_vmaddr[16];
    uint64_t seg_fileoff[16];
    uint64_t seg_filesize[16];
    int nseg;
} SegLayout;

typedef struct { char name[512]; uint64_t offset; uint64_t flags; uint64_t resolver; char reexport_lib[512]; } ExportEntry;

typedef enum { TMODE_MANUAL=0, TMODE_OFFSET=1, TMODE_HEAVIEST=2, TMODE_SAFE=3 } TMode;

#define VM_OP_NOP        0x00
#define VM_OP_MOV_REG    0x01
#define VM_OP_MOV_IMM32  0x02
#define VM_OP_MOVK_HI    0x03
#define VM_OP_ADD_REG    0x04
#define VM_OP_ADD_IMM    0x05
#define VM_OP_SUB_REG    0x06
#define VM_OP_SUB_IMM    0x07
#define VM_OP_AND_REG    0x08
#define VM_OP_ORR_REG    0x09
#define VM_OP_EOR_REG    0x0A
#define VM_OP_LSL_IMM    0x0B
#define VM_OP_LSR_IMM    0x0C
#define VM_OP_MUL_REG    0x0D
#define VM_OP_NEG_REG    0x0E
#define VM_OP_MVN_REG    0x0F
#define VM_OP_LDR64      0x10
#define VM_OP_LDR32      0x11
#define VM_OP_STR64      0x12
#define VM_OP_STR32      0x13
#define VM_OP_LDRB       0x14
#define VM_OP_STRB       0x15
#define VM_OP_STP_PRE    0x16
#define VM_OP_LDP_POST   0x17
#define VM_OP_STP        0x18
#define VM_OP_LDP        0x19
#define VM_OP_LDRH       0x1A
#define VM_OP_STRH       0x1B
#define VM_OP_LDRSW      0x1C
#define VM_OP_CMP_REG    0x20
#define VM_OP_CMP_IMM    0x21
#define VM_OP_TST_REG    0x22
#define VM_OP_B          0x30
#define VM_OP_BL_NATIVE  0x31
#define VM_OP_BR_NATIVE  0x32
#define VM_OP_RET        0x33
#define VM_OP_B_COND     0x34
#define VM_OP_CBZ        0x35
#define VM_OP_CBNZ       0x36
#define VM_OP_TBZ        0x37
#define VM_OP_TBNZ       0x38
#define VM_OP_NATIVE     0x40
#define VM_OP_MOVK_W16   0x47
#define VM_OP_MOVK_X16   0x48
#define VM_OP_LDR_REG    0x49
#define VM_OP_STR_REG    0x4A
#define VM_OP_BLR_REG    0x4B
#define VM_OP_LOAD_ABS   0x41
#define VM_OP_CSEL       0x42
#define VM_OP_SUBS_REG   0x43
#define VM_OP_SUBS_IMM   0x44
#define VM_OP_ADDS_REG   0x45
#define VM_OP_ROR_IMM    0x46

#define VM_OP_ASR_IMM    0x50
#define VM_OP_SXTW       0x51
#define VM_OP_SXTB       0x52
#define VM_OP_SXTH       0x53
#define VM_OP_UBFX       0x54
#define VM_OP_SBFX       0x55
#define VM_OP_BFI        0x56
#define VM_OP_BFXIL      0x57

#define VM_OP_CSINC      0x58
#define VM_OP_CSINV      0x59
#define VM_OP_CSNEG      0x5A
#define VM_OP_CCMP_REG   0x5B
#define VM_OP_CCMP_IMM   0x5C

#define VM_OP_SDIV       0x60
#define VM_OP_UDIV       0x61

#define VM_OP_CLZ        0x62
#define VM_OP_CLS        0x63
#define VM_OP_RBIT       0x64
#define VM_OP_REV        0x65
#define VM_OP_REV16      0x66
#define VM_OP_REV32      0x67

#define VM_OP_MADD       0x68
#define VM_OP_MSUB       0x69

#define VM_OP_LDRSB      0x6A
#define VM_OP_LDRSH      0x6B
#define VM_OP_LDR_W_REG  0x6C
#define VM_OP_STR_W_REG  0x6D
#define VM_OP_STP_W      0x6E
#define VM_OP_LDP_W      0x6F
#define VM_OP_STP_D_FP   0x70
#define VM_OP_LDP_D_FP   0x71
#define VM_OP_STR_S_FP   0x72
#define VM_OP_LDR_S_FP   0x73
#define VM_OP_STR_D_FP   0x74
#define VM_OP_LDR_D_FP   0x75
#define VM_OP_STR_Q_FP   0x76
#define VM_OP_LDR_Q_FP   0x77

#define VM_OP_AND_IMM    0x78
#define VM_OP_ORR_IMM    0x79
#define VM_OP_EOR_IMM    0x7A
#define VM_OP_TST_IMM    0x7B

#define VM_OP_SVC        0x80
#define VM_OP_DMB        0x81
#define VM_OP_DSB        0x82
#define VM_OP_ISB        0x83

#define VM_OP_CAS        0x84
#define VM_OP_LDADD      0x85
#define VM_OP_LDSET      0x86
#define VM_OP_SWP        0x87
#define VM_OP_STLR       0x88
#define VM_OP_LDAR       0x89

#define VM_OP_ADDS_IMM   0x8A
#define VM_OP_EXTR       0x8B
#define VM_OP_PRFM       0x8C

#define VM_OP_B_ABS      0x8D

#define VM_OP_HALT       0xFF

#define VM_MAGIC         0x564D4243u
#define VM_REG_COUNT     33
#define VM_FLAG_REG      32

typedef struct {
    uint8_t opcode;
    uint8_t rd;
    uint8_t rn;
    uint8_t rm;
    uint32_t imm;
} vm_insn_t;

typedef struct {
    vm_insn_t *insns;
    uint32_t count;
    uint32_t cap;
} VmBytecode;

#endif
