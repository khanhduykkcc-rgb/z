#ifndef SIGN_H
#define SIGN_H
int sign_file_adhoc(const char *path);
#endif
