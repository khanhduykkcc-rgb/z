
#ifndef DYLIB_PROTECT_UTIL_H
#define DYLIB_PROTECT_UTIL_H

#include "types.h"

uint8_t *load_file(const char *path, uint32_t *out_sz);
bool save_file(const char *path, const uint8_t *d, uint32_t sz);

static inline uint32_t rd32(const uint8_t *p){ uint32_t v; memcpy(&v,p,4); return v; }
static inline uint64_t rd64(const uint8_t *p){ uint64_t v; memcpy(&v,p,8); return v; }
static inline void wr32(uint8_t *p,uint32_t v){ memcpy(p,&v,4); }
static inline void wr64(uint8_t *p,uint64_t v){ memcpy(p,&v,8); }
static inline uint64_t align_up(uint64_t x,uint64_t a){ return (x+a-1)&~(a-1); }

uint32_t xhash(const uint8_t *d, uint32_t sz);

uint64_t read_uleb128(const uint8_t **pp, const uint8_t *end);
void encode_uleb128(uint8_t *buf, uint32_t *pos, uint64_t val);
uint64_t decode_uleb128(const uint8_t *buf, uint32_t *pos, uint32_t end);

#endif
