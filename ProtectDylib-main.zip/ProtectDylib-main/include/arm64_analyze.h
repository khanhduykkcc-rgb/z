#ifndef DYLIB_PROTECT_ARM64_ANALYZE_H
#define DYLIB_PROTECT_ARM64_ANALYZE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define ARM64_ANALYSIS_EXCLUSIVE (1u << 0)
#define ARM64_ANALYSIS_SYSTEM    (1u << 1)
#define ARM64_ANALYSIS_BARRIER   (1u << 2)
#define ARM64_ANALYSIS_PAUTH     (1u << 3)
#define ARM64_ANALYSIS_INVALID   (1u << 4)

#define ARM64_ANALYSIS_FORCE_VERBATIM (1u << 5)

#define ARM64_ANALYSIS_FORCE_SAFE_MASK \
    (ARM64_ANALYSIS_EXCLUSIVE | ARM64_ANALYSIS_SYSTEM | \
     ARM64_ANALYSIS_BARRIER | ARM64_ANALYSIS_PAUTH | ARM64_ANALYSIS_INVALID)

typedef struct {
    uint32_t insn_count;
    uint32_t gpr_read_mask;
    uint32_t gpr_write_mask;
    uint32_t gpr_used_mask;
    uint32_t gpr_read_count[32];
    uint32_t gpr_write_count[32];
    uint32_t feature_flags;
    uint32_t exclusive_count;
    uint32_t system_count;
    uint32_t barrier_count;
    uint32_t ptrauth_count;
    uint32_t invalid_count;
    bool reads_flags;
    bool writes_flags;
    bool uses_x15;
    bool uses_x16;
    bool uses_x17;
} Arm64FuncAnalysis;

bool arm64_analyze_words(const uint32_t *words, int word_count,
                         uint64_t base_va, Arm64FuncAnalysis *out);
int arm64_pick_unused_pair(uint32_t used_mask, const int *candidates,
                           int candidate_count, int *out0, int *out1);
const char *arm64_gpr_name(int reg_idx);

#endif
