
#ifndef DYLIB_PROTECT_CTOR_OBF_H
#define DYLIB_PROTECT_CTOR_OBF_H

#include "types.h"

int build_antihex_ctor_obfuscated(
    uint32_t *buf, int max_insns,
    uint64_t exec_seg_va,
    uint64_t text_va,
    uint32_t text_sz,
    uint32_t text_xhash,
    uint64_t next_va);

int build_timeprotect_obfuscated(
    uint32_t *buf, int max_insns,
    uint64_t deadline_epoch,
    uint64_t next_va);

int build_init_wrapper_obfuscated(
    uint32_t *buf, int max_insns,
    uint64_t wrapper_va,
    uint64_t antihex_va,
    uint64_t timeprotect_va,
    uint64_t orig_init_va);

void fixup_ctor_obf_branches(uint32_t *buf, int insn_count, uint64_t base_va);

#endif
